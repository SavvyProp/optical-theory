This project is describing a theoretical dual optical computing and computer science approach for a sufficiently powerful optical computing framework. It should leverage both free space and minimal photonics components to be as powerful as possible. It should be an almost all-optical computing approach making use of optical nonlinearities. It should create a primitive time series optical neural network such as an optical version of mamba / attention.

The following types of multiplexing are important:

Spatial (Spatial modes in fiber, spatial modes in free space)
Time (Time multiplexing, temporal convolution)
Polarization (2 modes)
Frequency
Subtime (Probabilistic neural networks max time multiplexing)

The following types of multiplication / nonlinearities are important:

SFG / DFG
Saturable Absorbtion
Pockels / Kerr effect inferometry
Fixed gain amplification system

The following types of temporal convolution are possible:

Fiber bragg grating
Recirculating loop

Either incorporate all optical training or:
The architecture must be sufficiently efficient on silicon to allow for silicon training.

The intention is to have a review paper highlighting motivations that leads to this optical neural network design and a simulations highlighting tasks that can be learnt and the efficiency and accuracy.

Plan to publish to laser and photonics reviews