"""Check an ideal sampled fiber Bragg reflector on the Hankel reader's slot grid.

Each site is a lossless, spectrally flat point reflector with real field
reflectivity. Equal site spacings give one slot of round-trip propagation.
The model includes multiple reflections. Inscription bandwidth, chromatic
dispersion, polarization, propagation loss and packaging require separate data.
"""

import numpy as np

if __package__:
    from . import matmul_power_budget as budget
else:
    import matmul_power_budget as budget


def peel_reflectors(target, delay, site_count):
    """Recover the first site coefficients from a causal reflection spectrum."""
    residual = target.copy()
    sites = np.empty(site_count)
    for i in range(site_count):
        # The zero-delay impulse sample is the front site's field reflection.
        front = residual.mean().real
        sites[i] = front
        residual = (residual - front) / (delay * (1 - front * residual))
    return sites


def reflection_spectrum(sites, delay):
    """Rebuild reflection from the far end, with a reflection-free termination."""
    reflection = np.zeros_like(delay)
    for front in reversed(sites):
        returned = delay * reflection
        reflection = (front + returned) / (1 + front * returned)
    return reflection


def read_error(impulse):
    """RMS field error for independent, equal-variance input slots and frames."""
    frame_slots = round(budget.FRAME_S / budget.SLOT_S)
    write_slots = np.arange(budget.SLOTS)
    read_slots = write_slots + budget.SLOTS
    lags = read_slots[:, None] - write_slots[None, :]
    current = impulse[lags]
    calibrated_tap = current.mean()
    error_energy = np.sum(abs(current - calibrated_tap) ** 2)
    for offset in range(frame_slots, len(impulse), frame_slots):
        previous_lags = lags + offset
        previous = impulse[previous_lags[previous_lags < len(impulse)]]
        error_energy += np.sum(abs(previous) ** 2)
    return np.sqrt(error_energy / current.size) / abs(calibrated_tap)


def main():
    grid_size = 8192
    tap_count = budget.TAPS
    target_peak = 0.80  # assumed on-resonance power reflectivity
    delay = np.exp(-2j * np.pi * np.arange(grid_size) / grid_size)
    target = np.fft.fft(np.full(tap_count, np.sqrt(target_peak) / tap_count), n=grid_size)
    counts = (tap_count, 2 * tap_count, 3 * tap_count)
    profiled = peel_reflectors(target, delay, max(counts))
    # Identical mirrors aligned on resonance give r_peak = tanh(N atanh(r_site)).
    uniform = np.full(tap_count, np.tanh(np.arctanh(np.sqrt(target_peak)) / tap_count))
    designs = [("uniform", uniform)] + [("profiled", profiled[:n]) for n in counts]

    spacing_m = 299792458 * budget.SLOT_S / (2 * 1.468)
    print(f"Target peak power reflectivity {target_peak:.0%}, site spacing {spacing_m * 1e3:.3f} mm")
    print("Profile     sites   span (cm)   peak R (%)   reflected energy after tap 127 (%)   read RMS (%)")
    for name, sites in designs:
        response = reflection_spectrum(sites, delay)
        impulse = np.fft.ifft(response)
        tail = np.sum(abs(impulse[tap_count:]) ** 2) / np.sum(abs(impulse) ** 2)
        span_cm = (len(sites) - 1) * spacing_m * 100
        print(f"{name:10s}  {len(sites):4d}   {span_cm:9.2f}   {100 * abs(response[0]) ** 2:10.3f}"
              f"   {100 * tail:36.4f}   {100 * read_error(impulse):12.3f}")


if __name__ == "__main__":
    main()
