"""Compare a DFG row reader and a two-DFG Hankel bank at the same optical interface."""

import argparse
import math

import numpy as np

if __package__:
    from . import dfg_power_sweep as dfg
    from . import matmul_power_budget as budget
    from .layer_cascade_screen import phase_ramp_encoding
else:
    import dfg_power_sweep as dfg
    import matmul_power_budget as budget
    from layer_cascade_screen import phase_ramp_encoding


def row_pumps(matrix, selected, cap_w):
    """Program row m on the pump teeth that contribute to its selected idler."""
    rows, cols = matrix.shape
    pumps = np.zeros((rows, 2 * cols - 1), dtype=complex)
    max_row_norm = np.linalg.norm(matrix, axis=1).max()
    if max_row_norm == 0:
        return pumps
    tooth = selected[:, None] + np.arange(cols)
    scale = math.sqrt(cap_w) / max_row_norm
    pumps[np.arange(rows)[:, None], tooth] = scale * matrix.conj()
    return pumps


def direct_read(inputs, target, selected, cap_w, eta, steps, guard):
    """Return raw selected B-band fields, one complex scalar per input and slot."""
    rows = len(target)
    pumps = row_pumps(target, selected, cap_w)
    seed = np.broadcast_to(inputs[:, None, :], (len(inputs), rows, inputs.shape[-1]))
    idlers, _ = dfg.propagate_guide(seed * math.sqrt(budget.transmission(0.5)), pumps,
                                    budget.DATA_HZ, budget.INTERMEDIATE_HZ, steps, guard, eta)
    return idlers[:, np.arange(rows), selected]


def report(label, held, inputs, target_fields):
    power_ratio = np.sum(abs(held)**2, axis=1) / np.sum(abs(inputs)**2, axis=1)
    loss = -10 * np.log10(power_ratio)
    # One complex scale for all four signed inputs, fit in the stated carrier convention.
    desired = target_fields[2:]
    actual = held[2:]
    scale = np.vdot(desired, actual) / np.vdot(desired, desired)
    fit_error = np.linalg.norm(actual - scale * desired) / np.linalg.norm(actual)
    print(f"{label:<21} {loss[0]:7.2f} {loss[1]:7.2f}  "
          f"{loss[2:].min():.2f}..{loss[2:].max():.2f}    {fit_error:.2%}")


def compare_two_banks(args, target, weights, reference):
    """One signed 512-vector, shared local unitary, no intermediate signal amplifier."""
    size = len(target)
    line = np.arange(size)
    # For destination lane l and frequency (or tagged slot) m, read source l-m.
    source = (np.arange(budget.LANES)[:, None] - line) % budget.LANES
    signs = np.random.default_rng(301).choice((-1, 1), size=(budget.LANES, size))
    inputs = math.sqrt(args.data_uw * 1e-6) * signs
    guides = (args.steps, args.guard, (args.eta, args.eta))

    first, _, _ = dfg.read_bank(inputs, weights, reference, *guides)
    routed = first[source, line] * math.sqrt(budget.transmission(6.0))
    hankel, _, _ = dfg.read_bank(routed, weights, reference, *guides)

    cap_w = args.weight_mw * 1e-3
    rows = direct_read(inputs, target, line, cap_w, args.eta, args.steps, args.guard)
    b_seed = np.zeros((budget.LANES, size, size), dtype=complex)
    # One B tooth per slot after the row filter, the B-band shuffle and the next mux.
    b_seed[:, line, line] = rows[source, line] * math.sqrt(budget.transmission(1.0 + 6.0 + 0.5))
    columns = row_pumps(target.conj().T, line, cap_w)
    generated, _ = dfg.propagate_guide(b_seed, columns, budget.INTERMEDIATE_HZ, budget.DATA_HZ,
                                       args.steps, args.guard, args.eta)
    held = generated.sum(axis=1) * math.sqrt(budget.transmission(1.0 + 7.0)) / budget.TAPS
    desired = (inputs @ target.T)[source, line] @ target.T
    for label, actual in (("Two Hankel banks", hankel), ("Rows then columns", held)):
        loss = -20 * math.log10(np.linalg.norm(actual) / np.linalg.norm(inputs))
        scale = np.vdot(desired, actual) / np.vdot(desired, desired)
        error = np.linalg.norm(actual - scale * desired) / np.linalg.norm(actual)
        print(f"{label}: {loss:.2f} dB over both banks, common-scale field residual {error:.2%}")


def compare(args):
    size = budget.LINES
    weight_w = args.weight_mw * 1e-3
    reference_w = args.reference_mw * 1e-3
    selected = np.full(size, size // 2) if args.fixed_idler else np.arange(size)
    route = budget.transmission(6.0)
    print(f"Weight cap {args.weight_mw:g} mW, Hankel reference {args.reference_mw:g} mW, "
          f"launch {args.data_uw:g} µW/tooth, eta {args.eta:g}/W, guard {args.guard}")
    print(f"Row mapper {args.mapper_db:g} dB net power loss, 1 dB selection filter, 6 dB shuffle. "
          f"Idler {'fixed' if args.fixed_idler else 'set by row'}.")
    for name in ("circulant", "random-unitary"):
        target, patterns = dfg.benchmark_vectors(name)
        inputs = math.sqrt(args.data_uw * 1e-6) * patterns
        desired = inputs @ target.T
        reference, conjugated_weights = phase_ramp_encoding(target)
        peak_norm = np.linalg.norm(conjugated_weights, axis=1).max()
        weights = math.sqrt(weight_w) * conjugated_weights.conj() / peak_norm
        hankel, _, _ = dfg.read_bank(inputs, weights, math.sqrt(reference_w) * reference,
                                     args.steps, args.guard, (args.eta, args.eta))
        raw = direct_read(inputs, target, selected, weight_w, args.eta, args.steps, args.guard)
        # A 10 ps row packet is spread over the full 640 ps output at fixed energy.
        # The physical DFG field is conjugated relative to the logical target.
        held = raw * math.sqrt(budget.transmission(1.0 + args.mapper_db) * route / size)
        print(f"\n{name}: routed loss (dB), aligned / chirped / four signed; "
              "common-scale field fit residual on the four signed inputs")
        report("Hankel", hankel * math.sqrt(route), inputs, desired)
        report("One row per slot", held, inputs, desired.conj())
        photons = abs(held[2:])**2 * budget.READ_S / budget.PHOTON_J
        print(f"Direct reader, coherent photons per held A tooth on the four signed inputs: "
              f"mean {photons.mean():.1f}, 10th percentile {np.quantile(photons, 0.1):.1f}")
        if args.two_banks:
            compare_two_banks(args, target, weights, math.sqrt(reference_w) * reference)

    weak_matched_gain = args.eta * weight_w
    fixed_loss = 1.5 + 6.0 + 10 * math.log10(size)
    print(f"First-order unitary row estimate: "
          f"{fixed_loss + args.mapper_db - 10 * math.log10(weak_matched_gain):.2f} dB.")
    lattice_transfer = size / budget.TAPS**2 * budget.transmission(7.0)
    print(f"Old lattice applied to isolated tagged rows: "
          f"{-10 * math.log10(lattice_transfer):.2f} dB additional loss relative to ideal packing.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--weight-mw", type=float, default=40.0, help="per-slot guide cap for both readers")
    parser.add_argument("--reference-mw", type=float, default=200.0, help="inside the second Hankel guide")
    parser.add_argument("--data-uw", type=float, default=10.0, help="input per tooth during the active burst")
    parser.add_argument("--eta", type=float, default=2.0, help="whole-guide weak coefficient in inverse watts")
    parser.add_argument("--steps", type=int, default=64)
    parser.add_argument("--guard", type=int, default=0, help="extra teeth per band edge in each guide")
    parser.add_argument("--mapper-db", type=float, default=0.0, help="net mapper loss after row selection")
    parser.add_argument("--fixed-idler", action="store_true", help="select the same central B tooth in every slot")
    parser.add_argument("--two-banks", action="store_true",
                        help="also test passing one tagged row per slot directly to the next bank's column")
    args = parser.parse_args()
    if any(not math.isfinite(v) or v <= 0 for v in (args.weight_mw, args.reference_mw, args.data_uw, args.eta)):
        parser.error("powers and guide efficiency must be finite and positive")
    if args.steps < 1 or args.guard < 0 or not math.isfinite(args.mapper_db):
        parser.error("steps must be positive, guard nonnegative and mapper loss finite")
    compare(args)
