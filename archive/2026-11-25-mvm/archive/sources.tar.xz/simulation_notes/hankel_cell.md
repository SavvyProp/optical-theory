# Hankel cell simulation

Working notes · 18 November 2026

The first simulation is forward inference with a fixed matrix. One Hankel lane reads a preloaded weight sequence, passes the input through two difference-frequency generation (DFG) sections and accumulates the product. Measure the complex output, first usable result and interval between independent inputs. The full structured matmul connects two banks of these readers with one inter-bank shuffle. The later TTT simulation adds adaptive state, an adjoint visit and a sum-frequency generation (SFG) writer. [Figure 1a reader](../inkscape_diagrams/simplified_hankel_multiplier_cleaned.svg) · [Figure 1b loop](../inkscape_diagrams/1b_forward_backward_hankel_compact.svg)

## Fixed-weight matmul round trip

Use a **680 ps short weight loop** for the initial matmul. Each lap contains 64 populated 10 ps slots followed by **four dark slots (40 ps)** before the next copy of the matrix. All 127 coefficient frequencies in a slot travel together. Initialize the weights once. Set \(t=0\) when slot zero and the input meet at the reader. A single matmul uses the 64 slots from one lap. For a stream of independent vectors, turn on the shared reference \(M_m\) on alternate laps, with a **1.36 ns** interval between launches.

| Timing under the current single-accumulator design | Ideal value |
| --- | --- |
| Read the 64 weight slots with the reference on | 0–640 ps (64 × 10 ps) |
| Dark margin at the end of the first weight lap | 640–680 ps |
| Accept the completed local output with the reference off | 640–1280 ps from launch, plus reader propagation |
| Reference off between input bursts | 640–1360 ps (720 ps dark) |
| Launch the next independent input | 1.36 ns after the previous launch, aligned to weight slot zero |
| First accepted output of a two-bank matmul | 1.28 ns from launch, plus propagation through both readers and the shuffle |

At slot \(q\) after launch, index the weight sequence by \(q\bmod68\) and the reference by \(q\bmod136\). Set each drive to zero when its own index is 64 or greater. The four-slot margin adds 80 ps per independent input relative to the unguarded 1.28 ns reader interval. The 128-tap accumulator supplies the same 640–1280 ps scheduled output window and can have a tail during the extra 80 ps. Start the second bank's reference when the accepted window arrives through the shuffle.

For a layout that makes **one physical lap per independent input**, use a 1.36 ns ring with 64 populated and 72 dark slots and read on every lap. Both layouts have the same output window and interval between inputs. Report weight loading separately from inference on a preloaded matrix. [Reference-pump gating](../hankel_monarch_delta/photonic_component.md#read-path-and-acceptance-by-the-reference-comb) · [Unguarded reader timing](../hankel_monarch_delta/paper_design_point.md#timing-with-a-dedicated-query-reader) · [Short-loop loss budget](component_gains.md#fixed-weight-matmul)

## Carrier grids

Use ordinary optical frequency in THz and vacuum wavelength in nm, with \(\lambda=299792.458/f\). In both cases the spacing is \(\Delta f=0.100\) THz. The 64 data lines span 6.3 THz between outer carrier centers. The 127 coefficient lines span 12.6 THz. The A-band frequencies lie on the ITU 100 GHz grid. [ITU-T G.694.1, section 7](https://www.itu.int/rec/T-REC-G.694.1-202010-I/en)

| Field | Lines | Wavelength selection, THz | Vacuum wavelengths, nm | Polarization selection, THz | Vacuum wavelengths, nm |
| --- | ---: | --- | --- | --- | --- |
| A · input, error and final matmul output | 64 | 190.2–196.5 | 1525.66–1576.20 | 190.2–196.5 | 1525.66–1576.20 |
| B · selected output of DFG 1 | 64 | 176.8–183.1 | 1637.32–1695.66 | 190.2–196.5 | 1525.66–1576.20 |
| P · stored weights, reference and SFG update | 127 | 367.0–379.6 | 789.76–816.87 | 380.4–393.0 | 762.83–788.10 |

Generate carriers from integer indices. For \(i,j=0,\ldots,63\), use \(f_{A,i}=f_{A,0}+i\Delta f\), \(f_{B,j}=f_{B,0}+j\Delta f\), and \(f_{P,s}=f_{A,0}+f_{B,0}+s\Delta f\) for \(s=0,\ldots,126\). Then \(f_{P,i+j}-f_{A,i}=f_{B,j}\) on read and \(f_{A,i}+f_{B,j}=f_{P,i+j}\) on write. A DFG with 127 pump and 64 seed teeth can generate **190** carrier positions indexed from −63 through 126. Propagate them to the filter, whose ideal passband retains indices 0–63. With finite extinction, carry the rejected-band leakage into the following section.

- **Wavelength selection, first simulation.** The coefficient center is 803.09 nm. The two unwanted self-sum bands are 353.6–366.2 THz (B+B) and 380.4–393.0 THz (A+A). This gives 0.8 THz from each outer cross-SFG carrier to the nearest self-sum carrier. The nearest unwanted DFG idler is only 0.1 THz from the retained DFG band. Both figures are carrier-center separations. Modulation sidebands and filter transitions consume that clearance.
- **Polarization selection, comparison.** The coefficient center is 775.26 nm. Assign A and B to orthogonal guided modes and model the polarization splitter, its finite extinction and the nonlinear tensor coupling. Here A+A, A+B and B+B share carrier frequencies. For the later writer test, check residual self-products in the collected P mode by exciting each operand separately. Kumar et al. measured a two-dimensional type-II SFG response near this wavelength combination. [Kumar et al., Figs. 2 and 4](https://www.frontiersin.org/journals/photonics/articles/10.3389/fphot.2022.951949/full)

The matmul output is band A, centered at 1550.52 nm. For a later MLP activation, the example transmission grating is specified through 1565 nm. Its published efficiency covers only part of this simulated data grid. [Grating datasheet, p. 2](https://www.coherent.com/content/dam/coherent/site/en/resources/datasheet/optics/diffraction-grating-t-1000c-series-ds.pdf)

## Waveguide model and inputs

Use the proposed silicon substrate, silicon nitride routing and local periodically poled thin-film lithium niobate (LN) sections. Start the two reader DFG length sweeps at 5 mm, the nominal length in the floorplan. Record film thickness, ridge width, etch depth, claddings, crystal cut, propagation direction, material dispersion, temperature, poling period and duty cycle. Koyaz et al. give a 4.8 mm device precedent and separate pump and signal sweeps against which to check the solver. [Local floorplan](../hankel_monarch_delta/single_branch_layout.md) · [Koyaz et al., Figs. 4–5](https://arxiv.org/html/2410.08790v1)

1. **Solve the guided modes.** Compute \(\beta_\mu(f)\), group delay per unit length, propagation loss and power-normalized vector mode profiles across A, B and P, including the modeled sidebands. Track modes by field overlap and use consistent phase references between frequencies. Evaluate the LN tensor overlap for each intended triplet and for competing self-products. Extract complex multiport scattering parameters for the passive transitions, combiners, selectors and couplers at defined port planes. [Mode-solver frequency sweep](https://optics.ansys.com/hc/en-us/articles/360034396774-Frequency-Analysis-Modal-Analysis-Tab) · [Passive scattering-matrix extraction](https://optics.ansys.com/hc/en-us/articles/360034917513-EME-Solver-analysis-window-overview)
2. **Map all 4,096 desired pairs per section.** For a first-order uniform poling period \(\Lambda\), calculate the mismatch and the small-signal SFG field response below. Here \(\kappa_{ij}\) includes the modal overlap and effective poling coefficient, \(\mathrm{sinc}(u)=\sin(u)/u\), and fields have units of \(\sqrt{\mathrm W}\). The expression uses lossless propagation and the convention \(E^{(+)}\propto e^{i\beta z-i2\pi ft}\). Export amplitude and phase. Derive both DFG directions with the corresponding conjugation and power normalization. Allow the two physical sections to have different parameters. [Phase-matching function and measured two-frequency scan](https://www.frontiersin.org/journals/photonics/articles/10.3389/fphot.2022.951949/full)

   \[
   \Delta k_{ij}=\beta_P(f_{P,i+j})-\beta_A(f_{A,i})-\beta_B(f_{B,j})-2\pi/\Lambda,
   \qquad
   G^{\mathrm{SFG}}_{ij}=\kappa_{ij}L\,e^{-i\Delta k_{ij}L/2}\,\mathrm{sinc}(\Delta k_{ij}L/2).
   \]

3. **Establish the usable power range.** Sweep on-chip power per tooth and total comb power, with the relative phases recorded. Compare the small-signal map with coupled-wave propagation including walk-off, loss and pump depletion where appreciable. In an isolated, lossless A+B↔P test, check photon-flux balance \(\Delta\Phi_A=\Delta\Phi_B=-\Delta\Phi_P\), with \(\Phi=P_{\rm opt}/(hf)\). This catches normalization errors between the fundamental and sum-frequency bands.

## Beam power for the forward matmul

For the fixed-weight matmul, launch **6.4 mW of data per lane**, deliver **4.00 mW of weights inside each DFG 1**, and set the eight-lane reference root to **100 mW**, giving **7.89 mW of reference inside each DFG 2**. All three powers are averaged over an occupied slot. A **90:10 read tap** sends 10% of the circulating power toward DFG 1 on each physical lap. A holding amplifier replaces the round-trip loss. Compare in-phase data teeth with data that distribute the same power evenly among Fourier components to check depletion in the brightest slot. [Identity power at each stage](matmul_power_budget.md#identity-power-at-each-stage) · [DFG 1 power and depletion estimates](matmul_power_budget.md#increasing-the-weight-power-at-dfg-1)

There are three independently set optical field scales in the first bank. Encode a dimensionless entry \(v_k\) as a guided field \(a_k=s\,v_k\) in \(\sqrt{\mathrm W}\). Its line power is \(|s|^2|v_k|^2\). A known fixed matrix can use the available weight-pump headroom by choosing a single scale for all its slots. Record that scale for output calibration. Use a common data scale across test vectors for that matrix.

| Field | What sets its power |
| --- | --- |
| Input \(x\), 64 data teeth | The laser output, comb-generation efficiency, line-by-line encoder and input coupling set the power incident on DFG 1. For a second bank, use the actual field from the first bank after its output amplifier and shuffle. |
| Weights \(W_m\), 127 pump teeth per slot | The loading comb sets the circulating field. Quote power just before the read tap. The tap and pump delivery path set how much reaches DFG 1. A holding amplifier adjusted for unity net round-trip gain preserves the loaded scale. |
| Reference \(M_m\), 127 pump teeth per slot | The shared reference source and shaper set the field at the root of the distribution tree. Fan-out, routing and the pump mux set the power reaching DFG 2 in each lane. |

With **50.357 mW circulating in one lane**, the 10% tap with 0.5 dB excess delivers **4.488 mW** to the read branch. The 0.5 dB pump mux leaves **4.00 mW at DFG 1**, or **31.5 µW per weight tooth** for 127 equal-power teeth. Three balanced reference splits with 0.5 dB excess each, followed by one 0.5 dB mux, deliver **7.887 mW at DFG 2** per lane. The short loop requires **+2.46 dB per lap** for the through port, tap excess and hold switch. Add the actual transition, routing and facet losses for the selected layout. [Component gains and single-tooth calibration](component_gains.md)

For one phase-matched pair in the weak-conversion regime, \(P_\mathrm{idler}=\eta_\mathrm{DFG}P_\mathrm{seed}P_\mathrm{pump}\), with powers at the guide and \(\eta_\mathrm{DFG}\) in W⁻¹ for the complete section. Koyaz et al. measured 0.04–0.07 W⁻¹ at 765/1550 nm. Obtain both sections' mixing coefficients on our actual grid near the 803 nm pump center. At fixed spectral shapes the two DFGs give generated output power proportional to \(P_xP_WP_M\) in this regime. For a populated comb, add the pair contributions as complex fields before squaring. [Koyaz et al., Eq. 2 and §3.2](https://arxiv.org/html/2410.08790v1)

**Setting the operating point.** Specify the tolerated output-field error, then work back from the accepted output window. As a numerical reference, consider an ideal balanced heterodyne receiver measuring both quadratures of one resolved output tooth, with a strong local oscillator and a coherent signal. Its relative RMS complex-field error from shot noise alone is \(1/\sqrt{N_\mathrm{det}}\), where \(N_\mathrm{det}=\eta_\mathrm{det} P_\mathrm{rec}T/(hf)\). For a bright tooth near 1550 nm, **1% error**, **80% detection efficiency** and integration over the full **640 ps** plateau, this gives **2.5 µW of incident signal power at the receiver** (1.6 fJ). This illustrates a possible terminal measurement for the standalone matmul. For matrix outputs near zero, score absolute residual field or error normalized to the whole output vector. [Balanced heterodyne noise, Eqs. 27–28](https://ocw.mit.edu/courses/6-453-quantum-optical-communication-fall-2016/5b693a34603704abae7e0fa4a7a72eca_MIT6_453F16_Lect9_Notes.pdf)

For the first matrix calibration, program the **64 × 64 identity** with matching weight and reference phase ramps. Measure the common complex gain on calibration inputs, then check \(y=gx\) on held-out inputs with different phases. Record the generated B power, the regenerated A power before the lattice, and the accepted A power alongside the gain-corrected matrix error. With either pump disabled, monitor residual A at the output to quantify feedthrough. Include amplifier and receiver noise and sweep the pump scales to check for depletion or gain compression. [Identity power at each stage](matmul_power_budget.md#identity-power-at-each-stage)

Record total active-slot power, frame-averaged power and the peak of the coherent waveform inside each guide. Comb phases can concentrate the same energy into much larger instantaneous peaks. With flat occupied slots and ideal blanks, the circulating weight duty factor is \(64/68\) and the delivered reference duty factor is \(64/136\). Use peak power and pulse energy to check compression, and integrate source power over the reader frame for energy per matmul. [Amplifier loading and noise](../hankel_monarch_delta/optical_amplifiers.md)

## Photontorch circuit and timing

For the first physical run, use the forward reader, accumulator and short fixed-weight loop gains. When connecting the two banks, apply the selected shuffle once in the data path. The loop transfer acts on the circulating weight field at the read tap. [Component gain budget](component_gains.md)

Use Photontorch for the connected circuit and monitor complex fields. Its passive scattering matrices are defined per wavelength. Implement the two DFG sections as cross-frequency operations using the maps above. In the weak-conversion limit, DFG 1 forms \(u_j=\sum_i G^{(1)}_{ji}p_{i+j}x_i^*\). Sum complex amplitudes before forming powers. [Photontorch component API](https://docs.photontorch.com/components.html) · [Network API](https://docs.photontorch.com/networks.html)

- **Forward visit.** Drive DFG 1 with the tapped 127-line weights \(W_m\) and the held input \(x\). Filter B, drive DFG 2 with reference \(M_m\), then filter A and accumulate. In the calibrated ideal limit, \(F(x)=c\sum_m H(M_m)H(\overline{W_m})x\), where \(H(h)_{ji}=h_{i+j}\) and \(c=1/128\).
- **Timing.** Drive each 1.36 ns reader frame with 640 ps of reference followed by 720 ps dark. Keep the seven differential delays at 10, 20, 40, 80, 160, 320 and 640 ps. Propagate consecutive frames with finite pulse edges and continuous filter and delay histories. At \(\Delta f\tau=1\) adjacent carrier centers acquire the same relative delay phase modulo \(2\pi\). Actual slot isolation depends on the pulse spectrum, dispersion and complex filter response across each tooth and its sidebands. Recombine overlapping spectra coherently in each physical mode and resolve them with the modeled receiver filters. [Unguarded lattice reference](../hankel_monarch_delta/paper_design_point.md#scope-of-checks-and-remaining-choices)

## Checks and first results to save

| Run | Observable |
| --- | --- |
| One tooth per operand at each grid corner, then all teeth in phase | Check the idler frequency, generated power and conjugation after each DFG section. Compare the retained B and A fields against the forward equations. |
| Basis inputs, then held-out random complex combs and a cancelling pair | Forward field error \(\lVert y_{\rm sim}-y_{\rm ideal}\rVert_2/\lVert y_{\rm ideal}\rVert_2\), and absolute residual power for a zero target. Record raw error and error after a single complex gain fitted on calibration inputs. |
| One weight round trip | Compare all 68 returning slots with the loaded waveform at the same tap plane. Record lap delay, attenuation, phase, per-tooth pump power and the energy in the four dark slots relative to the populated burst. |
| Two different consecutive input vectors, then a dark input, using the same weights | Plot the first valid output, accepted window width, earliest reusable input time and residual field from the preceding vector. Repeat with phase and timing offsets. |

For each frequency plan, save the complex conversion matrices, filter spectra, powers at the cell ports and time traces with the accepted window marked. Refine the transverse mesh, axial and temporal steps, and spectral resolution and padding. Record how much the reported field errors change. Once converged, sweep ridge width, film thickness, temperature, comb phase drift and pulse rise time to identify the dominant physical sensitivity. Save solver versions, settings, seed and calibration, and use the same input powers and test vectors for both plans.

The integer-grid checks give 4,096 pairs, 127 sums and 190 possible DFG difference indices in both cases. A lossless forward check used 64 data lines, 64 populated slots, two samples per slot and three independent complex inputs with the same matrix (seed 64). With the reference active for the first 64 of every 136 slots, the 68-slot and 136-slot weight loops both reproduced the direct local Hankel sum to within \(2\times10^{-16}\) maximum absolute field error. A second check used the 680 ps loop in two banks of eight lanes with distinct matrices, the cyclic shuffle, zero link delay and the second reference offset by 64 slots. Maximum absolute output error for three 512-coordinate inputs was \(2.73\times10^{-17}\) in the accepted windows. These checks use ideal rectangular fields. The first physical test of the margin needs the DFG conversion map, filter response and pulse edges at the tap. [Ideal DFG and lattice routines](../hankel_monarch_delta/check_single_lattice.py)

## Later TTT simulation

For adaptive inference, drive the same DFG pair with output error \(e\) and pumps in reverse order. Tap the first filtered field \(r_m=H(M_m)\overline e\) for cross-SFG with the saved forward input. The writer forms \(v_s=\sum_{i+j=s}G^{\mathrm{SFG}}_{ij}x_i r_j\), with ideal increment \(\Delta W_m=\eta c(x*r_m)\) at step size \(\eta\). Sweep writer length independently. With unit coupling and flat fields the ideal SFG field multiplicities are \(1,2,\ldots,64,\ldots,2,1\). All 64 pairs with \(i+j=63\) add at 373.3 THz in the wavelength-selected case.

Use \(e=t-F(x)\) with target \(t\) to check the adjoint inner products and both quadratures of the update against finite differences of the same squared-error loss. Model coherent injection into the matching old state, including tap loss, switch extinction, write phase and residual P-band power with the write input disabled. The approximately 150 m loop belongs to this later multi-layer, multi-head revisit schedule. [TTT timing and fiber storage](../hankel_monarch_delta/paper_design_point.md#memory-organization-and-fiber-length) · [Write and storage losses](component_gains.md#ttt-state-storage)
