"""Full-matrix, fixed-phase reference codes for the two-DFG, equal-tap reader.

Encoders return the reference b and the conjugated adaptive field v = conj(a)
such that sum H(b_m) H(v_m) equals the target before pump and tap scaling.
"""

import math

import numpy as np

if __package__:
    from . import matmul_power_budget as budget
    from .layer_cascade_screen import matrix_power_targets, phase_ramp_encoding
else:
    import matmul_power_budget as budget
    from layer_cascade_screen import matrix_power_targets, phase_ramp_encoding


def slot_matrices(references, weights):
    size = (references.shape[1] + 1) // 2
    indices = np.add.outer(np.arange(size), np.arange(size))
    return references[:, indices] @ weights[:, indices]


def cyclic_pairs(target, *, flat_source=False):
    """Cyclic reversals with equal delivered power, or passive selection from a flat source."""
    size = len(target)
    index = np.arange(size)
    copies = np.full(size, 2)
    copies[-1] = 1
    amplitude = 1 / np.sqrt(copies)
    if flat_source:
        amplitude = np.full(size, 1 / math.sqrt(2 * size - 1))
    references = np.zeros((size, 2 * size - 1))
    references[index, index] = amplitude
    references[index[:-1], size + index[:-1]] = amplitude[:-1]

    # The jump along a cyclic diagonal fixes the high-minus-low pump pair.
    jumps = (np.roll(target, -1, axis=0)[:, 1:] - target[:, :-1]) / amplitude[:, None]
    # For diagonal d = j-i (mod K), the pair on tooth r = m+d (mod K)
    # has a free mean. Its two endpoints fix the sum of those means over slots.
    tooth = (index[:, None] + index) % size
    endpoints = (target[-index % size, 0] + target[(-1 - index) % size, -1]) / 2
    slot_cost = np.sqrt(copies[tooth])
    normalization = (amplitude[:, None] / slot_cost).sum(axis=0)
    means = np.empty((size, size), dtype=np.result_type(target, float))
    means[index[:, None], tooth] = endpoints / (slot_cost * normalization)
    weights = np.column_stack((means[:, :-1] - jumps / 2, means[:, -1], means[:, :-1] + jumps / 2))
    return references, weights


def two_rows_per_slot(target, slots):
    """Independent low/high row differences, then a central reference for the Toeplitz remainder."""
    size = len(target)
    center = size - 1
    correction_slots = size // 2
    if slots <= correction_slots:
        raise ValueError("One additional slot is needed for the Toeplitz remainder.")
    references = np.zeros((slots, 2 * size - 1))
    weights = np.zeros(references.shape, dtype=np.result_type(target, float))
    jumps = target[1:, 1:] - target[:-1, :-1]
    for slot, lower_row in enumerate(range(0, center, 2)):
        upper_row = lower_row + 1
        amplitude = 1 / math.sqrt(2) if upper_row < center else 1.0
        references[slot, lower_row] = amplitude
        weights[slot, :center] = -jumps[lower_row] / amplitude
        if upper_row < center:
            references[slot, size + upper_row] = amplitude
            weights[slot, size:] = jumps[upper_row] / amplitude
    remainder = target - slot_matrices(references[:correction_slots], weights[:correction_slots]).sum(axis=0)
    np.testing.assert_allclose(remainder[1:, 1:], remainder[:-1, :-1], atol=1e-12)
    diagonals = np.concatenate((remainder[:0:-1, 0], remainder[0]))
    references[correction_slots:, center] = 1
    weights[correction_slots:] = diagonals / (slots - correction_slots)
    return references, weights


def center_and_tag_identity(size, tag_ratio):
    """Make each slot a positive multiple of I using a center tooth and one lower tooth."""
    center = size - 1
    references = np.zeros((size, 2 * size - 1))
    weights = np.zeros_like(references)
    for slot in range(center):
        references[slot, [center, slot]] = [1, tag_ratio]
        stride = center - slot
        teeth = np.arange(center, 2 * size - 1, stride)
        weights[slot, teeth] = (-tag_ratio) ** np.arange(len(teeth))
    references[-1, center] = weights[-1, center] = 1
    references /= np.linalg.norm(references, axis=1, keepdims=True)
    weights /= np.linalg.norm(weights, axis=1, keepdims=True)
    return references, weights


def check_coverage():
    rng = np.random.default_rng(751)
    for size in (5, 8, budget.LINES):
        target = rng.standard_normal((size, size)) + 1j * rng.standard_normal((size, size))
        indices = np.add.outer(np.arange(size), np.arange(size))
        for refs, weights in (two_rows_per_slot(target, size // 2 + 1), cyclic_pairs(target)):
            assert np.all(refs >= 0)
            np.testing.assert_allclose(np.linalg.norm(refs, axis=1), 1)
            np.testing.assert_allclose(slot_matrices(refs, weights).sum(axis=0), target, atol=1e-12)
            # Reverse the physical order and conjugations, as in the backward reader.
            error = rng.standard_normal(size) + 1j * rng.standard_normal(size)
            backward = (weights[:, indices].conj() @ (refs[:, indices].conj() @ error)[..., None]).sum(axis=0)
            np.testing.assert_allclose(backward[:, 0], target.conj().T @ error, atol=1e-12)
            if size <= 8:
                hankel_basis = np.eye(2 * size - 1)[indices]
                design = np.einsum("mik,kjs->ijms", refs[:, indices], hankel_basis)
                assert np.linalg.matrix_rank(design.reshape(size**2, -1)) == size**2

        # Mix a little of the common mean into every cyclic pair. The inverse
        # transpose on the weights accounts for the changed, normalized basis.
        refs, weights = cyclic_pairs(target)
        mixing = 0.8 * np.eye(size) + 0.2 / size
        mixing /= np.linalg.norm(mixing @ refs, axis=1, keepdims=True)
        positive_refs = mixing @ refs
        assert np.all(positive_refs > 0)
        changed_weights = np.linalg.solve(mixing.T, weights)
        np.testing.assert_allclose(slot_matrices(positive_refs, changed_weights).sum(axis=0), target,
                                   atol=1e-12)


def report():
    size = budget.LINES
    baseline_field = size**2 / (2 * size - 1)  # old matched identity, before the common 1/128
    print("Coherent power in dB relative to the matched phase-ramp identity, same per-slot pump caps")
    print("Target                 phase ramps  cyclic pairs  cyclic overlap  any-code upper bound")
    for name, target in matrix_power_targets(size):
        ramp_refs, ramp_weights = phase_ramp_encoding(target)
        refs, weights = cyclic_pairs(target)
        terms = slot_matrices(refs, weights)
        for reconstructed in (slot_matrices(ramp_refs, ramp_weights).sum(axis=0), terms.sum(axis=0)):
            np.testing.assert_allclose(reconstructed, target, atol=1e-12)
        ramp_peak = np.linalg.norm(ramp_weights, axis=1).max()
        peak = np.linalg.norm(weights, axis=1).max()
        ramp_db = -20 * math.log10(ramp_peak * baseline_field)
        cyclic_db = -20 * math.log10(peak * baseline_field)
        overlap = np.linalg.norm(target)**2 / np.sum(abs(terms)**2)
        jumps = target[1:, 1:] - target[:-1, :-1]
        nuclear_norm = np.linalg.svd(jumps, compute_uv=False).sum()
        difference_bound = size / nuclear_norm if nuclear_norm else math.inf
        if nuclear_norm:
            overlap_bound = 8 * size * np.linalg.norm(target)**2 / nuclear_norm**2
            assert overlap <= overlap_bound + 1e-10
        # Each unit-pump pair has |tr H(b) H(v)| <= K, including the
        # zero-displacement identity where the difference bound is vacuous.
        trace = abs(np.trace(target))
        trace_bound = size**2 / trace if trace else math.inf
        bound = 20 * math.log10(min(difference_bound, trace_bound) / baseline_field)
        assert max(ramp_db, cyclic_db) <= bound + 1e-10
        print(f"{name:21} {ramp_db:9.2f}    {cyclic_db:9.2f}    {overlap:11.4f}    {bound:10.2f}")

    refs, weights = center_and_tag_identity(size, 0.5)
    terms = slot_matrices(refs, weights)
    scales = terms[:, 0, 0]
    np.testing.assert_allclose(terms, scales[:, None, None] * np.eye(size), atol=1e-12)
    print(f"80:20 center/tag identity: {20 * math.log10(scales.sum() / baseline_field):+.2f} dB")


if __name__ == "__main__":
    check_coverage()
    report()
