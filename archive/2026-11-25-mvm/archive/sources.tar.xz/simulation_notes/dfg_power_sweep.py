"""Coherent, pump-depleted power sweep for one 64-tooth Hankel bank.

All retained three-wave triplets are phase matched with the same coupling.
Slots are independent. The bands use center frequencies for photon balance.
Use --guard to admit extra triplets inside each guide before filtering.
"""

import argparse
import math

import numpy as np
from scipy.fft import fft, ifft, next_fast_len

if __package__:
    from . import matmul_power_budget as budget
    from .layer_cascade_screen import matrix_power_targets, phase_ramp_encoding
else:
    import matmul_power_budget as budget
    from layer_cascade_screen import matrix_power_targets, phase_ramp_encoding


def propagate_guide(seed, pump, seed_hz, idler_hz, steps, guard, efficiency=2.0):
    """Return the retained idler and the exit pump depletion for each input slot."""
    size = seed.shape[-1]
    band_size = size + 2 * guard
    pump_size = 2 * band_size - 1
    modes = next_fast_len(pump_size)
    state = np.zeros((3, *seed.shape[:-1], modes), dtype=complex)
    retained = slice(guard, guard + size)
    state[0, ..., retained] = seed
    state[2, ..., 2 * guard:2 * guard + 2 * size - 1] = pump
    initial_power = np.sum(abs(state)**2, axis=-1)
    # z runs over one guide length. The idler field slope for one pair
    # is sqrt(efficiency) * pump * conj(seed) for the whole guide.
    idler_coupling = math.sqrt(efficiency)
    seed_coupling = idler_coupling * seed_hz / idler_hz
    pump_coupling = seed_coupling + idler_coupling

    def derivative(fields):
        a, b, p = fft(fields, axis=-1)
        # Convolution for A+B -> P, correlation for P-B -> A and P-A -> B.
        dz = ifft(np.stack((seed_coupling * p * b.conj(),
                            idler_coupling * p * a.conj(),
                            -pump_coupling * a * b)), axis=-1)
        dz[:2, ..., band_size:] = 0
        dz[2, ..., pump_size:] = 0
        return dz

    dz = 1 / steps
    for _ in range(steps):
        k1 = derivative(state)
        k2 = derivative(state + (dz / 2) * k1)
        k3 = derivative(state + (dz / 2) * k2)
        k4 = derivative(state + dz * k3)
        state += (dz / 6) * (k1 + 2 * k2 + 2 * k3 + k4)

    change = np.sum(abs(state)**2, axis=-1) - initial_power
    total = np.maximum(initial_power.sum(axis=0), np.finfo(float).tiny)
    np.testing.assert_allclose(change.sum(axis=0) / total, 0, atol=1e-6)
    np.testing.assert_allclose((change[0] * idler_hz / seed_hz - change[1]) / total, 0, atol=1e-6)
    depletion = np.zeros_like(initial_power[2])
    np.divide(-change[2], initial_power[2], out=depletion, where=initial_power[2] > 0)
    return state[1, ..., retained], depletion


def read_bank(inputs, weight, reference, steps, guard, eta=(2.0, 2.0)):
    """Held field after the nominal lattice, before amplification or shuffle."""
    seed = np.broadcast_to(inputs[:, None, :], (len(inputs), budget.SLOTS, budget.LINES))
    b, dep1 = propagate_guide(seed * math.sqrt(budget.transmission(0.5)), weight,
                              budget.DATA_HZ, budget.INTERMEDIATE_HZ, steps, guard, eta[0])
    a, dep2 = propagate_guide(b * math.sqrt(budget.transmission(3.0)), reference,
                              budget.INTERMEDIATE_HZ, budget.DATA_HZ, steps, guard, eta[1])
    read_field = math.sqrt(budget.transmission(1.0 + 7.0)) / budget.TAPS
    return a.sum(axis=1) * read_field, dep1.max(axis=1), dep2.max(axis=1)


def benchmark_vectors(matrix):
    """Return the unitary and equal-power phase patterns used in the bank comparison."""
    size = budget.LINES
    indices = np.arange(size)
    modes = fft(np.eye(size)) / math.sqrt(size)
    chirp = np.exp(1j * np.pi * indices**2 / size)
    if matrix == "circulant":
        # A unit-modulus slot phase changes the matched identity program into
        # a dense circulant unitary with the same per-slot pump powers.
        slot_phase = np.exp(3j * np.pi * indices**2 / size)
        target = (modes * slot_phase) @ modes.conj().T
        np.testing.assert_allclose(abs(target), 1 / math.sqrt(size), atol=1e-12)
    else:
        target = dict(matrix_power_targets(size))["seeded dense unitary"]
    np.testing.assert_allclose(target.conj().T @ target, np.eye(size), atol=1e-12)
    signs = np.random.default_rng(819).choice((-1, 1), size=(4, size))
    return target, np.vstack((np.ones(size), chirp, signs))


def run(steps, guard, eta, pump_points, matrix):
    size = budget.LINES
    target, data = benchmark_vectors(matrix)
    signs = data[2:]
    reference, conjugated_weights = phase_ramp_encoding(target)
    conjugated_weights /= np.linalg.norm(conjugated_weights, axis=1).max()
    print(f"{matrix} program, guard={guard} extra teeth per band edge, {steps} integration steps per guide, "
          f"whole-guide efficiencies {eta[0]:g}/{eta[1]:g} per W")
    mean_fraction = np.mean(np.linalg.norm(conjugated_weights, axis=1)**2)
    print(f"Mean programmed weight power is {mean_fraction:.1%} of the per-slot cap")
    print("Guide pump caps mW | data µW/tooth | read loss dB (aligned, spread, min/max of four sign vectors)"
          " | peak exit depletion % in DFG 1/2 (aligned, spread)")
    for weight_mw, reference_mw in pump_points:
        pump1 = math.sqrt(weight_mw * 1e-3) * conjugated_weights.conj()
        pump2 = math.sqrt(reference_mw * 1e-3) * reference
        probe_field = math.sqrt(1e-9)
        probe, _, _ = read_bank(data * probe_field, pump1, pump2, steps, guard, eta)
        small_signal = probe / probe_field
        normalized_reads = []
        for data_uw in (10, 100, 1000):
            data_field = math.sqrt(data_uw * 1e-6)
            output, dep1, dep2 = read_bank(data * data_field, pump1, pump2, steps, guard, eta)
            output /= data_field
            read_loss = -10 * np.log10(np.sum(abs(output)**2, axis=1) / size)
            normalized_reads.append(output)
            print(f"{weight_mw:3g}/{reference_mw:<6g} {data_uw:9g}     "
                  f"{read_loss[0]:7.2f} {read_loss[1]:7.2f}  "
                  f"{read_loss[2:].min():.2f}..{read_loss[2:].max():.2f}        "
                  f"{100*dep1[0]:5.1f}/{100*dep2[0]:5.1f} {100*dep1[1]:5.1f}/{100*dep2[1]:5.1f}",
                  flush=True)

        for drive, output in zip((10, 100), normalized_reads[:2]):
            field_error = np.linalg.norm(output - small_signal, axis=1) / np.linalg.norm(small_signal, axis=1)
            print(f"  {drive} µW/tooth departure from 1 nW/tooth probe, relative field: "
                  f"{field_error[0]:.1%} aligned, {field_error[1]:.1%} spread, "
                  f"{field_error[2:].min():.1%}..{field_error[2:].max():.1%} signed")

        # Any fixed matrix must give the same normalized output for a vector
        # and its scaled copy. Their mean is the least-squares fit on that ray.
        moderate, high = normalized_reads[1:]
        energy = np.sum(abs(moderate)**2 + abs(high)**2, axis=1)
        fit_error = np.linalg.norm(moderate - high, axis=1) / np.sqrt(2 * energy)
        print("  Best fixed-linear fit error on each ray, 100 and 1000 µW/tooth: "
              f"{fit_error[0]:.1%} aligned, {fit_error[1]:.1%} spread, "
              f"{fit_error[2:].min():.1%}..{fit_error[2:].max():.1%} signed", flush=True)

        # A fixed matrix has one response to a real perturbation of tooth zero,
        # independent of the background. Compare the four equal-power sign inputs.
        step = 1e-3
        perturbation = np.zeros(size)
        perturbation[0] = step
        field = math.sqrt(100e-6)
        inputs = field * np.vstack((signs + perturbation, signs - perturbation))
        output, _, _ = read_bank(inputs, pump1, pump2, steps, guard, eta)
        plus, minus = np.split(output, 2)
        columns = (plus - minus) / (2 * step * field)
        differential_loss = -10 * np.log10(np.sum(abs(columns)**2, axis=1))
        column_error = np.linalg.norm(columns - columns.mean(axis=0)) / np.linalg.norm(columns)
        print("  100 µW/tooth, same input tooth on four signed backgrounds: "
              f"{differential_loss.min():.2f}..{differential_loss.max():.2f} dB differential loss, "
              f"{column_error:.1%} field residual for their best common column")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--steps", type=int, default=64)
    parser.add_argument("--guard", type=int, default=0,
                        help="extra seed and idler teeth allowed per band edge inside each guide")
    parser.add_argument("--eta", type=float, nargs=2, default=(2.0, 2.0), metavar=("DFG1", "DFG2"),
                        help="whole-guide weak idler/(seed × pump) coefficients in inverse watts")
    parser.add_argument("--pumps-mw", type=float, nargs=2, metavar=("WEIGHT", "REFERENCE"),
                        help="run one pair of power caps inside the guides, in mW per occupied slot")
    parser.add_argument("--matrix", choices=("circulant", "random-unitary"), default="circulant",
                        help="weak-limit target to program before the power sweep")
    args = parser.parse_args()
    if args.steps < 1 or args.guard < 0:
        parser.error("steps must be positive and guard must be nonnegative")
    if any(not math.isfinite(v) or v <= 0 for v in [*args.eta, *(args.pumps_mw or [])]):
        parser.error("pump powers and efficiencies for these loss comparisons must be finite and positive")
    default_pumps = ((4, 7.887), (20, 40), (40, 200), (85, 85))
    run(args.steps, args.guard, args.eta, [args.pumps_mw] if args.pumps_mw else default_pumps, args.matrix)
