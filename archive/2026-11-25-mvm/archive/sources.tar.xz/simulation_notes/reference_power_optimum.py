"""Shared reference design at fixed power before a passive 127-line spectral shaper.

All scales s refer to sum H(b_m) H(conj(a_m)) = s F, without the common
1/128 temporal tap. The adaptive field in each slot has Euclidean norm <= 1.
"""

import argparse
import math

import numpy as np
from scipy.optimize import least_squares

if __package__:
    from . import matmul_power_budget as budget
    from .amplitude_reference import cyclic_pairs, slot_matrices
    from .layer_cascade_screen import matrix_power_targets, phase_ramp_encoding
else:
    import matmul_power_budget as budget
    from amplitude_reference import cyclic_pairs, slot_matrices
    from layer_cascade_screen import matrix_power_targets, phase_ramp_encoding


def periodic_weights(target, mask):
    """Exact conjugated weights for K periodic reference spectra, with mask[m, s % K]."""
    size = len(target)
    index = np.arange(size)
    changes = np.roll(target, -1, axis=0)[:, 1:] - target[:, :-1]
    jumps = np.linalg.solve(mask.T, changes)
    # The high-minus-low differences are fixed. The remaining freedom is a
    # mean for each pair and one unpaired center coefficient in each slot.
    endpoints = (target[-index % size, 0] + target[(-1 - index) % size, -1]) / 2
    response = np.fft.fft(mask, axis=1)[:, -index % size]
    spectrum = response.conj() * np.fft.fft(endpoints) / np.sum(abs(response)**2, axis=0)
    means = np.fft.ifft(spectrum, axis=1)
    return np.column_stack((means[:, :-1] - jumps / 2, means[:, -1], means[:, :-1] + jumps / 2))


def guaranteed_scale(mask):
    """Lower bound valid for every target of operator norm one using periodic_weights."""
    inverse_rows = np.linalg.inv(mask.T)
    response = np.fft.fft(mask, axis=1)
    total = np.sum(abs(response)**2, axis=0)
    jump_cost = 2 * np.sum(abs(inverse_rows)**2, axis=1)
    mean_cost = 2 * np.max(abs(response)**2 / total**2, axis=1)
    return 1 / math.sqrt(max(jump_cost + mean_cost))


def fit_spectral_phase(weights):
    """Equalize slot powers for a known target with one static 64-periodic reference phase."""
    size = len(weights)
    fourier = np.fft.fft(np.eye(size)) / math.sqrt(size)
    transformed = fourier.T @ weights
    mean_power = np.linalg.norm(weights)**2 / size
    gram = transformed @ transformed.conj().T / mean_power

    def powers_and_derivative(phase):
        mixer = fourier.conj() * np.exp(-1j * np.r_[0, phase])
        mixed_gram = mixer @ gram
        powers = np.sum(mixed_gram * mixer.conj(), axis=1).real
        derivative = 2 * np.imag(mixer * mixed_gram.conj())
        return powers, derivative[:, 1:]

    rng = np.random.default_rng(224)
    best_phase = np.zeros(size)
    best_peak = max(powers_and_derivative(best_phase[1:])[0])
    for _ in range(4):
        start = rng.uniform(-np.pi, np.pi, size - 1)
        result = least_squares(lambda x: powers_and_derivative(x)[0] - 1, start,
                               jac=lambda x: powers_and_derivative(x)[1],
                               ftol=1e-12, xtol=1e-12, gtol=1e-12, max_nfev=400)
        peak = max(powers_and_derivative(result.x)[0])
        if peak < best_peak:
            best_peak = peak
            best_phase = np.r_[0, result.x]
        if best_peak <= 1 + 1e-8:
            break
    return best_phase, (fourier * np.exp(1j * best_phase)) @ fourier.conj().T


def field_scale(weights):
    return 1 / np.linalg.norm(weights, axis=1).max()


def power_gain_before_lattice():
    # Same weak-conversion operating point as the identity power budget. The
    # 100 mW is now upstream of the mask. Shaper transmission is already in b.
    reference_w = 0.1 * budget.transmission(2) / budget.LANES
    pump_product = (2 * budget.WEIGHT_GUIDE_MW / 1000) * (2 * reference_w)
    return budget.transmission(4.5) * pump_product


def restoring_gain_db(scale):
    """Inverse common matrix power scale in dB, before the shuffle."""
    return -10 * math.log10(power_gain_before_lattice() * budget.transmission(7) * (scale / budget.TAPS)**2)


def read_tooth(slot_terms, scale, input_tooth, output_tooth, launch_w):
    """Power on one output frequency before the lattice, during the ideal read, and after excess loss."""
    fields = math.sqrt(launch_w * power_gain_before_lattice()) * scale * slot_terms[:, output_tooth, input_tooth]
    waveform = np.convolve(fields, np.full(budget.TAPS, 1 / budget.TAPS))
    read = waveform[budget.SLOTS:2 * budget.SLOTS]
    ideal_w = np.mean(abs(read)**2)
    return np.mean(abs(fields)**2), ideal_w, ideal_w * budget.transmission(7)


def report(input_tooth=0, output_tooth=0):
    size = budget.LINES
    count = budget.PUMP_LINES
    assert size == budget.SLOTS == 64 and count == 127
    index = np.arange(size)
    residues = np.arange(count) % size
    targets = matrix_power_targets(size)
    h4 = np.ones((4, 4)) - 2 * np.eye(4)
    hadamard = np.kron(np.kron(h4, h4), h4)
    binary = (1 + hadamard) / (2 * math.sqrt(count))
    np.testing.assert_array_equal(hadamard @ hadamard.T, size * np.eye(size))
    binary_refs = binary[:, residues]
    _, dense_weights = phase_ramp_encoding(targets[-1][1])
    phase, mixer = fit_spectral_phase(dense_weights)
    probe_w = 100e-6
    pair_rows = []
    identity_trace = None
    print("Normalized matrix restoring gain -10 log10(|g|²) (dB), before shuffle, 100 mW flat reference source")
    print("Target                  ramps    two teeth   binary mask   dense-fitted phase")
    for name, target in targets:
        ramp_refs, ramp_weights = phase_ramp_encoding(target)
        sparse_refs, sparse_weights = cyclic_pairs(target, flat_source=True)
        binary_weights = periodic_weights(target, binary)
        phase_refs = ramp_refs * np.exp(1j * phase[residues])
        phase_weights = mixer.conj() @ ramp_weights
        settings = ((ramp_refs, ramp_weights), (sparse_refs, sparse_weights),
                    (binary_refs, binary_weights), (phase_refs, phase_weights))
        losses = []
        pair_losses = []
        entry_power = abs(target[output_tooth, input_tooth])**2
        for setting, (refs, weights) in enumerate(settings):
            assert abs(refs).max() <= 1 / math.sqrt(count) + 1e-12
            terms = slot_matrices(refs, weights)
            np.testing.assert_allclose(terms.sum(axis=0), target, atol=1e-12)
            scale = field_scale(weights)
            loss = restoring_gain_db(scale)
            losses.append(loss)
            pre_w, ideal_w, output_w = read_tooth(terms, scale, input_tooth, output_tooth, probe_w)
            np.testing.assert_allclose(output_w / probe_w, budget.transmission(loss) * entry_power,
                                       rtol=1e-10, atol=1e-24)
            pair_losses.append(-10 * math.log10(output_w / probe_w) if entry_power else math.inf)
            if name == "identity" and setting == 0 and input_tooth == output_tooth:
                identity_trace = pre_w, ideal_w, output_w
        pair_rows.append((name, pair_losses))
        print(f"{name:22}{losses[0]:7.2f}{losses[1]:13.2f}{losses[2]:14.2f}{losses[3]:18.2f}")
    print(f"One input tooth {input_tooth} at 100 µW, one output tooth {output_tooth}: restoring gain (dB)")
    print("Target                  ramps    two teeth   binary mask   dense-fitted phase")
    for name, losses in pair_rows:
        print(f"{name:22}{losses[0]:7.2f}{losses[1]:13.2f}{losses[2]:14.2f}{losses[3]:18.2f}")
    if identity_trace is not None:
        pre_w, ideal_w, output_w = identity_trace
        print(f"Identity, phase ramps, same tooth: {pre_w * 1e9:.4f} nW before the lattice,"
              f" {ideal_w * 1e12:.2f} pW ideal read, {output_w * 1e12:.2f} pW with coupler excess")
    # The optimized phase reaches the total-energy lower bound on peak pump norm.
    np.testing.assert_allclose(field_scale(mixer.conj() @ dense_weights),
                               math.sqrt(size) / np.linalg.norm(dense_weights), rtol=1e-7)

    lag = np.arange(count)[None, :] - index[:, None]
    window = ((lag >= 0) & (lag < size)).astype(float)
    left, singular, _ = np.linalg.svd(window, full_matrices=False)
    ramp_floor = math.sqrt(size / count) * singular[-1]
    fourier = np.fft.fft(np.eye(size)) / math.sqrt(size)
    witness = fourier @ left[:, ::-1].T
    np.testing.assert_allclose(witness.conj().T @ witness, np.eye(size), atol=1e-12)
    np.testing.assert_allclose(field_scale(phase_ramp_encoding(witness)[1]), ramp_floor)
    width = size - 1
    max_difference_norm = size * math.sqrt(2 * width / count)
    flat_ceiling = max_difference_norm / (2 * width)
    positive_ceiling = size * math.sqrt(2 * (width**2 // 4) / (width * count)) / (2 * (width - 1))
    binary_floor = guaranteed_scale(binary)
    corner_bound = size / 2 * math.sqrt((count + 3) / count)
    np.testing.assert_allclose(field_scale(phase_ramp_encoding(np.eye(size))[1]), corner_bound)
    np.testing.assert_allclose(field_scale(phase_ramp_encoding(np.diag((-1)**index))[1]), flat_ceiling)
    print("Guaranteed worst-case field scale and upper bound for the best code")
    for name, floor, ceiling in (("Phase permitted", ramp_floor, flat_ceiling),
                                 ("Common phase, passive amplitude", binary_floor, positive_ceiling)):
        print(f"{name:32} {floor:.6f} <= optimum <= {ceiling:.6f}, {20*math.log10(ceiling/floor):.3f} dB gap")
    print(f"Mean binary reference power fraction {np.sum(abs(binary_refs)**2)/size:.4f}")
    dense_target = targets[-1][1]
    jumps = dense_target[1:, 1:] - dense_target[:-1, :-1]
    dense_ceiling = max_difference_norm / sum(np.linalg.svd(jumps, compute_uv=False))
    print(f"Dense example, unrestricted passive-mask headroom over ramps:"
          f" {20*math.log10(dense_ceiling/field_scale(dense_weights)):.2f} dB")

    rng = np.random.default_rng(825)
    improvements = []
    for _ in range(16):
        unitary, triangular = np.linalg.qr(rng.normal(size=(size, size)) + 1j*rng.normal(size=(size, size)))
        unitary *= np.diag(triangular) / abs(np.diag(triangular))
        _, weights = phase_ramp_encoding(unitary)
        improvements.append(20 * math.log10(field_scale(mixer.conj() @ weights)/field_scale(weights)))
        assert field_scale(periodic_weights(unitary, binary)) >= binary_floor - 1e-10
    print(f"Fixed fitted phase, 16 independent unitaries: mean {np.mean(improvements):+.2f} dB,"
          f" range {min(improvements):+.2f} to {max(improvements):+.2f} dB")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--probe", nargs=2, type=int, metavar=("INPUT", "OUTPUT"), default=(0, 0),
                        help="Indices of the single launched and observed teeth (default: 0 0)")
    args = parser.parse_args()
    if any(not 0 <= tooth < budget.LINES for tooth in args.probe):
        parser.error(f"tooth indices must be in 0..{budget.LINES - 1}")
    report(*args.probe)
