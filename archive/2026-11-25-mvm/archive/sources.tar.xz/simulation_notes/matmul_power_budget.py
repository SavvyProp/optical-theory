"""Forward Hankel matmul power budget for a programmed identity. CLI powers are active-slot mW."""

import argparse
import math


LINES = 64
PUMP_LINES = 2 * LINES - 1
SLOTS = 64
TAPS = 128
LANES = 8
SLOT_S = 10e-12
READ_S = SLOTS * SLOT_S
LAP_S = (SLOTS + 4) * SLOT_S
LAPS_PER_INPUT = 2
FRAME_S = LAPS_PER_INPUT * LAP_S
DATA_HZ = 193.35e12
INTERMEDIATE_HZ = 179.95e12
PHOTON_J = 6.62607015e-34 * DATA_HZ
DETECTOR_EFFICIENCY = 0.80
WEIGHT_GUIDE_MW = 4.0
READ_TAP_PERCENT = 10.0
WEIGHT_DELIVERY_LOSS_DB = 0.5 + 0.5  # tap excess and pump mux


def transmission(loss_db):
    """Power transmission for a positive insertion loss in dB."""
    return 10 ** (-loss_db / 10)


def report_signal_path(input_line_w, stages):
    """Trace the retained signal at each plane for one choice of efficiencies."""
    print("\nOne identity bank before amplification (intermediate powers averaged over slots and teeth)")
    print(f"{'Stage':36s} {'Power gain (dB)':>17s} {'Output (nW/tooth)':>20s}")
    power_w = input_line_w
    total_db = 0.0
    print(f"{'Data launch':36s} {'':17s} {power_w * 1e9:20.5g}")
    for name, gain in stages:
        gain_db = 10 * math.log10(gain) if gain > 0 else -math.inf
        total_db += gain_db
        power_w *= gain
        print(f"{name:36s} {gain_db:17.2f} {power_w * 1e9:20.5g}")
    print(f"Total one-bank signal power gain {total_db:.2f} dB.")


def report_delay_options(input_line_w):
    """Compare accepted identity power at a common A-band accumulator input."""
    static_gain = SLOTS / TAPS ** 2
    mixed_loss_db = 4 * 0.64 + 2 * 0.5
    options = [
        ("Binary, 0.50 dB per coupler", static_gain * transmission(14 * 0.5)),
        ("Binary, 0.20 dB per coupler", static_gain * transmission(14 * 0.2)),
        ("Passive 8 x 8 x 2", static_gain * transmission(mixed_loss_db)),
        ("Ideal passive 128 equal taps", static_gain),
        # Route the two disjoint 640 ps copies through a 1.5 dB switch.
        ("Binary with timed 640 ps arm switch",
         2 * static_gain * transmission(13 * 0.5 + 1.5)),
        ("8 x 8 x 2 with timed 640 ps arm switch",
         2 * static_gain * transmission(mixed_loss_db - 0.5 + 1.5)),
    ]
    for lap_loss_db in (0.0, 0.1, 0.2):
        q = transmission(lap_loss_db)
        # Equalized capture and release, with one propagation loss per slot.
        delay_sum = sum(q ** (-lag) for lag in range(SLOTS))
        gain = SLOTS * q / delay_sum ** 2
        options.append((f"Clocked loop, {lap_loss_db:.2f} dB per lap", gain))

    print("\nAlternative accumulators at the same comb-averaged filtered A power")
    print(f"{'Design':43s} {'Power gain (dB)':>15s} {'Output (pW/tooth)':>19s}")
    for name, gain in options:
        print(f"{name:43s} {10 * math.log10(gain):15.2f} {input_line_w * gain * 1e12:19.5g}")


def report_amplifier_placement(output_line_w, lattice_excess):
    """Quantum-limited phase-insensitive gain and a uniform heterodyne read on one tooth."""
    # An independent input noise slot contributes coherently to each read slot it reaches.
    # In the active burst it reaches the whole read. Continuous noise also enters on
    # either edge, where the overlap increases from one to SLOTS - 1 read slots.
    gated_transfer = lattice_excess * (SLOTS / TAPS) ** 2
    edge_sum = sum(overlap ** 2 for overlap in range(1, SLOTS))
    full_overlap_sum = (TAPS - SLOTS + 1) * SLOTS ** 2
    continuous_transfer = lattice_excess * (full_overlap_sum + 2 * edge_sum) / (SLOTS * TAPS ** 2)
    print("\nOne-bank signal gain and single-read relative RMS complex-field error")
    print(f"  Added-noise transfer to the read mode is {continuous_transfer:.5f} for continuous upstream gain,"
          f" {gated_transfer:.5f} for gated upstream gain and 1 for downstream gain.")
    if output_line_w == 0:
        print("  Zero coherent output at every gain. Relative field error is undefined.")
        return
    print("Gain (dB)   Coherent nW/tooth    Before (continuous)    Before (gated)    After")
    for gain_db in (0, 10, 15, 20, 30):
        gain = 10 ** (gain_db / 10)
        signal_w = gain * output_line_w
        detected_signal = DETECTOR_EFFICIENCY * signal_w * READ_S / PHOTON_J
        # Heterodyne vacuum variance is one. Each amplified input mode adds G - 1 photons.
        errors = [math.sqrt((1 + DETECTOR_EFFICIENCY * (gain - 1) * transfer) / detected_signal)
                  for transfer in (continuous_transfer, gated_transfer, 1.0)]
        print(f"{gain_db:9d} {signal_w * 1e9:19.5g} {errors[0]:22.1%} {errors[1]:17.1%} {errors[2]:8.1%}")


def report_reference_gain(first_order_gain, output_at_unity_gain_w):
    """Compare DFG 2 with a lossless, undepleted, phase-matched two-mode converter."""
    photon_energy_ratio = DATA_HZ / INTERMEDIATE_HZ
    interaction_strength = math.sqrt(first_order_gain / photon_energy_ratio)
    print(f"  DFG 2 first-order generated-A / incident-B power ratio {first_order_gain:.4g}.")
    try:
        coupled_gain = photon_energy_ratio * math.sinh(interaction_strength) ** 2
    except OverflowError:
        coupled_gain = math.inf
    if math.isfinite(coupled_gain):
        print(f"  Ideal matched-mode ratio {coupled_gain:.4g}, giving"
              f" {output_at_unity_gain_w * coupled_gain * 1e12:.4g} coherent pW per output tooth.")
    else:
        print("  The undepleted matched-mode gain exceeds floating-point range.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    default_loop_mw = WEIGHT_GUIDE_MW / (READ_TAP_PERCENT / 100 * transmission(WEIGHT_DELIVERY_LOSS_DB))
    parser.add_argument("--data-mw", type=float, default=6.4, help="one lane before its first mux")
    parser.add_argument("--loop-mw", type=float, default=default_loop_mw,
                        help=f"one circulating comb before its tap (default {default_loop_mw:.3f} mW)")
    parser.add_argument("--reference-mw", type=float, default=100,
                        help="occupied-slot power after reference shaping at one eight-lane tree root (default 100 mW)")
    parser.add_argument("--check-reference-gain", action="store_true",
                        help="also evaluate DFG 2 with one ideal pair of matched signal and idler modes")
    parser.add_argument("--compare-delays", action="store_true",
                        help="compare passive and clocked accumulators over the 640 ps read window")
    parser.add_argument("--compare-amplifier-placement", action="store_true",
                        help="compare phase-insensitive signal gain before and after the binary lattice")
    parser.add_argument("--tap-percent", type=float, default=READ_TAP_PERCENT,
                        help="percent of circulating power sent to the reader on each lap (default 10)")
    parser.add_argument("--extra-loop-loss-db", type=float, default=0,
                        help="additional passive loss per lap beyond the tap and hold switch")
    parser.add_argument("--eta", type=float, nargs=2, metavar=("DFG1", "DFG2"),
                        help="whole-section idler/(pump × seed) efficiencies in inverse watts, with a stage-by-stage trace")
    args = parser.parse_args()
    for value in (args.data_mw, args.loop_mw, args.reference_mw, *(args.eta or ())):
        if not math.isfinite(value) or value < 0:
            parser.error("powers and efficiencies must be finite and nonnegative")
    if not 0 <= args.tap_percent <= 100:
        parser.error("tap percentage must be between 0 and 100")
    if not math.isfinite(args.extra_loop_loss_db) or args.extra_loop_loss_db < 0:
        parser.error("additional loop loss must be finite and nonnegative")

    tap = args.tap_percent / 100
    data_w = args.data_mw * 1e-3
    weight_w = args.loop_mw * 1e-3 * tap * transmission(WEIGHT_DELIVERY_LOSS_DB)
    reference_w = args.reference_mw * 1e-3 * transmission(3 * 0.5 + 0.5) / LANES
    mux = transmission(0.5)
    seed_w = data_w * mux
    print("Guide inputs during an occupied slot             total, mW    flat tooth, µW")
    for name, power, lines in (("Data at DFG 1", seed_w, LINES),
                               ("Weight at DFG 1", weight_w, PUMP_LINES),
                               ("Reference at DFG 2", reference_w, PUMP_LINES)):
        print(f"{name:44s} {power * 1e3:12.5g} {power * 1e6 / lines:17.5g}")

    # Each reference ramp selects one orthogonal Fourier component of the data.
    # These B and A powers are averaged over the occupied slots and retained teeth.
    seed_line_w = seed_w / LINES
    b_filter = transmission(1.0)
    b_router = transmission(1.5)
    b_link = b_filter * b_router * mux
    a_filter = transmission(1.0)
    lattice_excess = transmission(14 * 0.5)
    ideal_sum_gain = SLOTS / TAPS ** 2
    watts_per_count = PHOTON_J / (DETECTOR_EFFICIENCY * READ_S)
    print(f"DFG 2 reference energy per 10 ps slot {reference_w * SLOT_S * 1e15:.4g} fJ,"
          f" ideal flat-comb peak {PUMP_LINES * reference_w:.4g} W.")
    print("\nFirst-order 64 × 64 identity with matched phase ramps. Powers per tooth.")
    print("DFG1, DFG2 (1/W)   generated B (nW)   filtered A (nW)   ideal sum (pW)"
          "   accepted output (pW)   detected photons")
    cases = [args.eta] if args.eta else [(0.05, 0.05), (0.5, 0.5), (2.0, 2.0)]
    for eta1, eta2 in cases:
        a_to_b_gain = eta1 * weight_w * LINES / PUMP_LINES
        b_line_w = seed_line_w * a_to_b_gain
        b_seed_line_w = b_line_w * b_link
        b_to_a_gain = eta2 * reference_w * LINES ** 2 / PUMP_LINES
        a_line_w = b_seed_line_w * b_to_a_gain * a_filter
        # Orthogonal slot outputs add in power across the full vector.
        # The passive lattice weights each field by 1/TAPS.
        ideal_sum_w = a_line_w * ideal_sum_gain
        output_line_w = ideal_sum_w * lattice_excess
        print(f"{eta1:5g}  {eta2:7g} {b_line_w * 1e9:18.5g} {a_line_w * 1e9:17.5g}"
              f" {ideal_sum_w * 1e12:16.5g} {output_line_w * 1e12:22.5g}"
              f" {output_line_w / watts_per_count:18.5g}")
        if args.compare_delays:
            report_delay_options(a_line_w)
        if args.compare_amplifier_placement:
            report_amplifier_placement(output_line_w, lattice_excess)
        if args.check_reference_gain:
            output_at_unity_gain_w = b_seed_line_w * a_filter * ideal_sum_gain * lattice_excess
            report_reference_gain(b_to_a_gain, output_at_unity_gain_w)
        if args.eta:
            report_signal_path(data_w / LINES, (
                ("Data input mux", mux),
                ("DFG 1, retained B", a_to_b_gain),
                ("B filter", b_filter),
                ("B routing switch", b_router),
                ("DFG 2 input mux", mux),
                ("DFG 2, generated A", b_to_a_gain),
                ("A filter", a_filter),
                ("Ideal temporal sum, comb average", ideal_sum_gain),
                ("Lattice coupler excess", lattice_excess),
            ))

    print("\nIdeal heterodyne field error        required incident nW/tooth")
    for error in (0.10, 0.03, 0.01):
        print(f"{error:12.0%} {watts_per_count * 1e9 / error ** 2:40.4g}")
    lap_through = (1 - tap) * transmission(0.5 + 1.5 + args.extra_loop_loss_db)
    if lap_through == 0:
        print("\nNo weight field returns. Sustained circulation requires a nonzero through path.")
        return

    gain_db = -10 * math.log10(lap_through)
    return_mw = args.loop_mw * lap_through
    restore_mw = args.loop_mw - return_mw
    restore_pj = restore_mw * 1e-3 * LAPS_PER_INPUT * READ_S * 1e12
    data_pj = data_w * READ_S * 1e12
    reference_pj = args.reference_mw * 1e-3 * READ_S * 1e12
    bank_pump_pj = LANES * restore_pj + reference_pj
    first_bank_pj = LANES * data_pj + bank_pump_pj
    two_bank_pj = first_bank_pj + bank_pump_pj
    frame_ns = FRAME_S * 1e9
    print(f"\nWeight loop with {args.tap_percent:g}% read tap and {args.extra_loop_loss_db:g} dB extra per lap")
    print(f"  Return {return_mw:.4g} mW to the holding amplifier. Required power gain +{gain_db:.4g} dB.")
    print(f"  Added signal power {restore_mw:.4g} mW in an occupied slot,"
          f" {restore_pj / frame_ns:.4g} mW averaged over the frame.")
    print(f"  Restore {restore_pj:.4g} pJ per loop over {LAPS_PER_INPUT} laps per input.")
    print(f"Gated data per input lane {data_pj:.4g} pJ. Reference per eight-lane bank {reference_pj:.4g} pJ.")
    print(f"Guided optical energy and mean power at one input every {frame_ns:g} ns")
    print(f"  First eight-lane bank: {first_bank_pj:.4g} pJ/input, {first_bank_pj / frame_ns:.4g} mW")
    print(f"  Two such banks, using the shuffled signal at bank 2:"
          f" {two_bank_pj:.4g} pJ/input, {two_bank_pj / frame_ns:.4g} mW")


if __name__ == "__main__":
    main()
