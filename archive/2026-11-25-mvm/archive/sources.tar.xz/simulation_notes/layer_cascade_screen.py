"""Compare optical restoration, programmed matrix gain and temporal readout at 64 teeth."""

import math
import numpy as np

if __package__:
    from . import matmul_power_budget as budget
    from . import fbg_accumulator as fbg
else:
    import matmul_power_budget as budget
    import fbg_accumulator as fbg


def loss_db(power_ratio):
    return -10 * math.log10(power_ratio)


def check_mode_mapping():
    size = budget.LINES
    indices = np.arange(size)
    tooth = np.add.outer(indices, indices)
    modes = np.fft.fft(np.eye(size)) / math.sqrt(size)
    rng = np.random.default_rng(716)
    inputs = rng.normal(size=(size, 3)) + 1j * rng.normal(size=(size, 3))
    slots = []
    for slot in range(size):
        weights = rng.normal(size=budget.PUMP_LINES) + 1j * rng.normal(size=budget.PUMP_LINES)
        reference = np.exp(-2j * np.pi * slot * tooth / size) / math.sqrt(budget.PUMP_LINES)
        intermediate = weights[tooth] @ inputs.conj()
        slots.append(reference @ intermediate.conj())
    slots = np.array(slots)
    # Sort each frequency vector, align its occupied coordinate with the other slots,
    # undo the frequency transform and release the aligned packet over the read window.
    coordinates = np.einsum("km,mkv->mv", modes.conj(), slots)
    held_field = (modes @ coordinates) / math.sqrt(size)
    expected_sum = slots.sum(axis=0)
    relative_error = np.linalg.norm(math.sqrt(size) * held_field - expected_sum) / np.linalg.norm(expected_sum)
    np.testing.assert_allclose(math.sqrt(size) * held_field, expected_sum, atol=1e-10)
    np.testing.assert_allclose(size * np.sum(abs(held_field)**2, axis=0),
                               np.sum(abs(slots)**2, axis=(0, 1)))
    # Adjoint on the occupied subspace: a normalized, held error vector returns
    # to one Fourier component in each of its original slots.
    error = rng.normal(size=size) + 1j * rng.normal(size=size)
    adjoint = (modes * (modes.conj().T @ error)).T
    np.testing.assert_allclose(np.vdot(held_field[:, 0], error) * math.sqrt(size),
                               np.vdot(slots[:, :, 0], adjoint))
    print(f"Joint time/frequency decoder, ideal relative field error {relative_error:.2e}")

    chirp = np.exp(1j * np.pi * np.arange(budget.PUMP_LINES)**2 / size) / math.sqrt(budget.PUMP_LINES)
    hankel = chirp[tooth]
    q = size / budget.PUMP_LINES
    np.testing.assert_allclose(hankel @ hankel.conj().T, q * np.eye(size), atol=1e-12)
    for _ in range(5):
        kernel = np.fft.ifft(np.exp(1j * rng.uniform(0, 2*np.pi, size)))
        weights = np.resize(kernel, budget.PUMP_LINES)
        hankel = weights[tooth] / np.linalg.norm(weights)
        scalar = 1 / (2 - abs(kernel[-1])**2)
        np.testing.assert_allclose(hankel @ hankel.conj().T, scalar * np.eye(size), atol=1e-12)
    print(f"Single dense chirp, squared singular value {q:.6f} in all {size} modes")


def check_guard_reflector(lattice_input_w):
    """Allow extra signed echoes at the two lags outside the 64-slot read."""
    size = budget.SLOTS
    taps = np.full(2 * size + 1, math.sqrt(0.8) / 82)
    taps[[0, -1]] *= -25.44
    dense_grid = 262144
    peak = max(abs(np.fft.fft(taps, dense_grid)))
    # Centering the response removes its carrier phase. The derivative bound
    # certifies passivity between samples as well as at the FFT grid points.
    slope_bound = np.sum(abs(taps) * abs(np.arange(taps.size) - size))
    assert peak + slope_bound * np.pi / dense_grid < 1
    grid = 8192
    target = np.fft.fft(taps, grid)
    assert fbg.read_error(np.fft.ifft(target)) < 1e-12
    delay = np.exp(-2j * np.pi * np.arange(grid) / grid)
    sites = fbg.peel_reflectors(target, delay, 512)
    print("Dark-slot echoes in a sampled FBG, no route or propagation loss")
    for length in (384, 512):
        impulse = np.fft.ifft(fbg.reflection_spectrum(sites[:length], delay))
        read_lags = size + np.subtract.outer(np.arange(size), np.arange(size))
        accepted_w = lattice_input_w * size * abs(impulse[read_lags].mean())**2
        print(f"{length} sites: {accepted_w*1e9:.4f} nW/tooth, {fbg.read_error(impulse):.3%} field RMS")


def matrix_power_targets(size):
    coordinate = np.arange(size)
    modes = np.fft.fft(np.eye(size)) / math.sqrt(size)
    rng = np.random.default_rng(716)
    gaussian = rng.normal(size=(size, size)) + 1j * rng.normal(size=(size, size))
    unitary, triangular = np.linalg.qr(gaussian)
    diagonal = np.diag(triangular)
    unitary *= diagonal / abs(diagonal)
    return (("identity", np.eye(size)), ("alternating signs", np.diag((-1)**coordinate)),
            ("Fourier", modes), ("seeded dense unitary", unitary))


def phase_ramp_encoding(target):
    """Return normalized references and conjugated pump coefficients for an exact map."""
    size = len(target)
    count = 2 * size - 1
    coordinate = np.arange(size)
    coefficient = np.arange(count)
    lag = coefficient[None, :] - coordinate[:, None]
    window = ((lag >= 0) & (lag < size)).astype(float)
    input_phase = np.exp(-2j * np.pi * np.outer(coordinate, coordinate) / size)
    weight_phase = np.exp(2j * np.pi * np.outer(coordinate, coefficient) / size)
    modes = input_phase / math.sqrt(size)
    # The reference slots select independent Fourier rows. A minimum-norm
    # solution for each row also minimizes the largest per-slot pump norm.
    rows = modes.conj().T @ target
    weights = ((rows * input_phase) @ np.linalg.pinv(window).T) * weight_phase * math.sqrt(count / size)
    return weight_phase.conj() / math.sqrt(count), weights


def check_matrix_power():
    """Largest common field gain for an exact phase-ramp target at unit peak pump norm."""
    size = budget.LINES
    count = budget.PUMP_LINES
    hankel_indices = np.add.outer(np.arange(size), np.arange(size))
    matched_identity_gain = size**2 / (count * budget.TAPS)
    print("Max calibrated field scale at unit per-slot pump norm, relative to matched identity")
    for name, target in matrix_power_targets(size):
        references, conjugate_weights = phase_ramp_encoding(target)
        terms = references[:, hankel_indices] @ conjugate_weights[:, hankel_indices]
        np.testing.assert_allclose(terms.sum(axis=0), target, atol=1e-12)
        max_norm = np.max(np.linalg.norm(conjugate_weights, axis=1))
        field_scale = 1 / (budget.TAPS * max_norm)
        power_db = 20 * math.log10(field_scale / matched_identity_gain)
        print(f"{name:20} {field_scale:.7f}   {power_db:+.2f} dB power")


def report_row_restoration_noise():
    """Phase-insensitive postgain with one accepted 640 ps signal mode per tooth."""
    print("Held row output, matched-mode relative RMS complex-field error")
    print("Launch µW  loss dB  preamp nW  photons  ideal 1/4/10 restorations  7 dB NF at 4")
    efficiency = budget.DETECTOR_EFFICIENCY
    noise_factor = 10**(7 / 10)
    for launch_uw, loss in ((10, 30), (100, 30), (10, 36.3)):
        gain = 10**(loss / 10)
        launch_photons = launch_uw * 1e-6 * budget.READ_S / budget.PHOTON_J
        ideal_ase = gain - 1
        ase_at_7_db = (noise_factor * gain - 1) / 2
        errors = [math.sqrt((1 / efficiency + depth * ideal_ase) / launch_photons)
                  for depth in (1, 4, 10)]
        nf_error = math.sqrt((1 / efficiency + 4 * ase_at_7_db) / launch_photons)
        print(f"{launch_uw:9.0f}  {loss:7.1f}  {1000*launch_uw/gain:9.2f}  "
              f"{launch_photons/gain:7.1f}  {errors[0]:6.1%}/{errors[1]:.1%}/{errors[2]:.1%}"
              f"  {nf_error:9.1%}")

    gain = 1000.0
    print("Four 30 dB restorations, launch µW/tooth for 10% RMS in the held mode")
    for name, ase in (("Ideal", gain - 1), ("7 dB NF", (noise_factor * gain - 1) / 2)):
        required = (1 / efficiency + 4 * ase) / 0.1**2
        print(f"{name:8s}: {required * budget.PHOTON_J / budget.READ_S * 1e6:.2f}")

    # A normalized row reads its own slot of a signal spread over SLOTS slots.
    # Noise occupying every slot independently couples SLOTS times more energy
    # into the next restored row than noise confined to the held waveform.
    launch_photons = 10e-6 * budget.READ_S / budget.PHOTON_J
    for modes in (1, budget.SLOTS):
        added = (gain - 1) * (1 + modes)  # First amplifier followed by one more restored bank.
        error = math.sqrt((1 / efficiency + added) / launch_photons)
        print(f"Two restored row banks, {modes} temporal noise modes/tooth, 10 µW: {error:.1%} RMS")


def report():
    size = budget.LINES
    pump = budget.WEIGHT_GUIDE_MW * 1e-3
    reference = 0.1 * budget.transmission(2) / budget.LANES
    eta = 2.0
    flat = size / budget.PUMP_LINES
    dfg1_loss = loss_db(eta * pump * flat)
    dfg2_loss = loss_db(eta * reference * size * flat)
    before_sum = 4.5 + dfg1_loss + dfg2_loss
    static_sum = loss_db(size / budget.TAPS**2) + 7
    projection = loss_db(1/size)
    matched_pair = 4.5 + projection + 2 * loss_db(0.8)
    cases = [
        ("Current two guides and nominal lattice", before_sum + static_sum),
        ("Ideal clocked per-tooth capture/release", before_sum + projection),
        ("Exact joint decoder, current guides", before_sum),
        ("Exact joint decoder, 80% photon conversion in each matched mode", matched_pair),
        ("One dense chirped Hankel factor, eta=2", 1.5 + dfg1_loss),
        ("One dense chirped Hankel factor, eta=0.05", 1.5 + loss_db(0.05 * pump * flat)),
    ]
    print("Required power gain per bank (dB), excluding new decoder hardware loss")
    print(f"{'Architecture':66} {'no shuffle':>10} {'3 dB route':>11} {'6 dB route':>11}")
    for name, loss in cases:
        print(f"{name:66} {loss:10.2f} {loss+3:11.2f} {loss+6:11.2f}")

    print("One dot product per slot, 3 dB shuffle and 1.5 dB mux/filter, before retiming")
    for matched_power in (eta * pump, 0.8):
        row_loss = loss_db(matched_power / size) + 3 + 1.5
        print(f"Matched-row power transfer {matched_power:.3f}: {row_loss:.2f} dB")

    check_guard_reflector(100e-6 * budget.transmission(before_sum))
    photons = 100e-6 * budget.READ_S / budget.PHOTON_J
    print("Scalar restored identity, max post-amplifier loss for 10% complex-field RMS")
    for depth in (1, 10, 24, 100):
        max_gain = 1 + (0.1**2 * photons - 1 / budget.DETECTOR_EFFICIENCY) / depth
        print(f"{depth:3} stages: {10*math.log10(max_gain):.2f} dB")
    report_row_restoration_noise()
    print("Optical pump per 1.36 ns frame for eight continuously pumped amplifiers")
    for pump_mw in (115, 245, 450):
        print(f"{pump_mw:3} mW each: {pump_mw*1e-3*budget.FRAME_S*budget.LANES*1e9:.3f} nJ")


if __name__ == "__main__":
    check_mode_mapping()
    check_matrix_power()
    report()
