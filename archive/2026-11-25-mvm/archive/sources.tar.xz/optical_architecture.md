# Early optical architecture ideas

These are exploratory notes. Use the [current TTT design point](hankel_monarch_delta/paper_design_point.md), [cell pathways](hankel_monarch_delta/cell_pathways.md) and [recirculating optical MLP proposal](hankel_monarch_mlp/README.md) for the selected eight-fiber, 512-wide architecture with two FFN stages and approximately 310M real learned parameters including the tied 16k embedding/readout. The current conditional schedule is 30.72 ns/layer over 24 layers, with dedicated query readers and sixteen approximately 150 m recurrent coefficient rings before additional timing allowances. Earlier dimensions, parameter totals and throughput estimates below are not the current design budget.

Main Matmul: SFG Hankel Matrix Matmul / Hankel Cubic nonlinear matmul.

Current shuffle selection: [integrated MZI interleaver trees with fixed cyclic waveguide routing](hankel_monarch_delta/mzi_shuffle.md). This supersedes the diffraction-grating/MPLC shuffle suggestions below. Their historical discussion does not specify the selected router; free-space FFN activation remains a separate proposal.

Memory stored as a comb that can be an evaluated model

Time dimension used as a parallel heads dimension (only connected layer to layer through time convolution)

Spatial fibers need to have some mixing.

Hankel matrix optimal SFG with some diffraction grating / MPLC for fixed spatial mixing.

A_i @ b_i.

Goal: SFG matrix is small based on limitations on controllable combs. Likely only 100 channels feasible in an initial experiment. Thus a larger matrix multiplication using multiple spatial channels before recombining with a fixed recombination.

Idea: Project input space upwards to multiple spatial modes, Apply SFG Hankel matrices, combine. n Input fibers.

Idea: Henkel, Shuffle, Henkel 

Problem: Very limited number of wavelengths that can be generated on silicon. At 10,000 components on a large silicon chip, say only 10,000 individual components can be modulated. To load 1 billion parameters:
10^9 / 10^5 = 10^4 timesteps => 10^{-11}*10^4 = 10^{-6} => 1 microsecond 1 MHz.

Can load 10^{15} weights in one second

An SLM can have 2*10^6 weights assuming each pixel.

At 100Hz:

2*10^8 weights in one second

2*10^15 weights assuming 1 GHz update.

Conclusion: weights should be encoded through frequency comb for the highest density of weights in silicon

Target a 1024 x 1024 matrix multiplication.

A Full rank multiplication with 40 wavelengths multiplication: 25 timesteps.

Say we stream vector $w_t$ $x_t$. The output is \sum_{i = t} H(w_i)x_i = y_t

A higher rank matrix can be implemented but by representing each y_t as a scanning block going from left to right on the matrix.

y_0 = H_0 x_0
y_1 = H_1 x_1 + H_0 x_0
...

Y =
[H_0            [x_0]
 H_0 H_1        [x_1]
 H_0 H_1 H_2 ]  [x_2]

When long running enough:

[H_0 H_1 H_2] [x_0 x_1 x_2]

The matrix multiplication is a large square matrix of H_i in column i. The middle n values around diagonal are nonzero.

Maybe reach lower triangle then zero out.

The time convolution is not super applicable as matrices are difficult to construct

(Have some kind of filtering over sum?)

Dot product is doable but the lower triangular toeplitz triangular is not 

Optical SRAM useful in making a large intermediate matrix?

Intermediate calculations can be discarded from the SRAM. 

Full Henkel matrix matmul for 40 * 40 matmul (40 timesteps).

Monarch matrix of 8 fibers for (4000 @ 4000) psuedo matmul.

Parallel fiber for parallel computation. Project out weight vector? No projection of input vector? Project weight vector only? Project input vector for more heads? Limitation for now?

Per layer:
8 * 40 * 40 * 100 = 1.28 * 10^6 parameters

Repeat over 100 head dimensions for 40 ns token prediction.

8 * 40 = 320 a second

12 m fiber. (Physically feasible to wind.)

Practically 

Same token pondering? Run with different weights over the same token repeated to add more parameters.

Example:

10 token pondering for 12.8 *10^6 parameters.

2.5*10^6 tokens per second?

100 layers for 1.28 B parameters

100 token pondering?

128*10^6 parameters.

Hypothetically

Able to generate 10,000 weight vectors.

10,000 / 320 = 31 times more weights

With 10 token pondering, 400 * 10^6 = 4 * 10^8 parameters a layer

100 layers: 4 * 10^10 parameters.

Conditional weight loading for MOE. 40 B active parameters.

At 5% active: 0.8 T parameters

Multiplex over 100 layers: 

2.5 * 10^4 tokens per second.

Single optical signal generator chip inferencing a 1B Active (small), 40 B Active (large) for 20B or 1T moe parameters.

To get larger parameter counts, couple chips together and have more spatial modes.

The full monach matrix can only really be handled by larger head sizes.

Gradient learning

For backprop, just need to do A^T g.

then just accumulate g and x at each point and sum over time digitally.

Core of the architecture: For efficient inference at 10^6 tokens per second, model architecture limitations means generally small matrices and hidden state vectors of 40 * spatial dim. 

n x n. Monach matrix 

Estimate of multiplier: 15 - 50 mm^2:

Full Hankel requires 15 to 50 mm^2 of die area

40 - 100 on an 800mm^2 die

2n^3 macs.

For an 100 multipliers with 100 wavelengths, 100 timesteps (1 ns)

One is 10^15 FLOPs, 1 Petaflop

Would need 100 multipliers for 100 Petaflops

One augmentation: use the multiplier as a cubic / quadratic polynomial for then onlinearity

PS FBG sram

NS fiber SRAM

General architecture of

MVM, diffraction routing,

MVM, loop, diffraction routing

Freespace / fiber memory

Route to diffraction shuffle grating for very short recirculation.

Route to SRAM. exponential binary SRAM loop?

Get repeating reciculating weights of the hidden neural memory weights for eval.

Query vector given to neural memory.

Setup some kind of hierarchical timesharing system

Diffractive short SRAM bank for monach matrices.

Output is every n cycles a burst of vectors over time.

For inference, the burst of vectors from SRAM, representing weights.

Should focus on inferencing over layers. Argue that optical SRAM should not run for too many cycles.

Critically, energy efficiency gains are not realized for full hankel due to common DAC readouts and DAC input encodings for mostly weights.

This means that 
1) Varying weight streaming (Constant digital weight generation) is inefficient. Thus updated weights such as a hidden state are needed and should not be used for general matmul. Either that or come up with a weight streaming system.

2) DAC reading of the final matmul is inefficient so needs to amortized.

Few things might be important to show to salvage the full Henkel concept. 1) Show the a(x)b(x) nonlinearity is critical to time series neural networks.

2) Create a weight streaming system that is good at repeating certain signals.

(Some kind of pulsed SLM system?)

3) Illustrate a very compute heavy neural network architecture versus a memory heavy neural network archtiecture. (Compute heavy by recurrences/)

Goal: Single Shot VLA model making use of reasoning tokens.

Hankel matrix multiplication (Competitive in compute density? Silicon photonics area is cheaper)

Simplified system.

n hankel blocks * k shuffles for nk time pulse of weights representing stored w. Repeated h times for h layers. nkh train of pulses 

Initial cycle for read.

Would need to be able to compute outer product for gradient descent.

Would need 4096 x 4096 raw matmul to amortize out the read cost.

Can allow smaller matrices to be more efficient.

Transpose then matmul might be too complicated.

Massive delta net seems more promising.

So the weight of each small hankel matrix is encoded as a series of frequencies over time.

Outer product 

Single frequency over time, fixed frequency comb, sfg to get outer product.

The outer product cannot be 

The linear attention product

The DeltaNet recurrent memory

Plan: Detail Full Hankel Shuffle Matmul. Detail how this can be use to implement a delta net / TTT recurrent core.

Argument: Strengths of optical system:

Neural networks require compute and memory

Low energy cost of individual computation.
Multiplexing in parts allow for high parts and compute efficiency (Critically). Optical components should be looked at not just for energy efficiency but compute density, and part count density for other forms of scaling. Part count is especially important in codesigning ML architectures and optical systems as fabrication needs to be cheap in order to be worth considering a specialized system.

Based off of the desire of other kinds of scaling for optical computing, we develop a full hankel monarch matmul, which can be multiplexed in many ways, is critically extremely parts and space efficient.

Optics provides very natural, cheap, and high capacity SRAM system.

However, modern neural networks are very DRAM memory heavy optical systems. Weight loading into optical systems are currently not yet scalable and competitive with digital electronics.

Physics based analog computing offers easier pathways to do certain computations than others. As such, there is a balancing act between implementing silicon operations, which offer compatibility with existing algorithms, and implementing new architectures which greatly leverage physical phenomena.

TTT and variants such as deltanet, with recurrent memories that can be scaled arbitrarily large, where compute cost is a concern with arbitrarily large memories, demonstrated scalability. They thus offer a way to scale with both compute and sram memory. Offers a framework to best utilize both optical computation and optical SRAM.

We adapt TTT to make use of the optical TTT core, and train it on complex tasks.

With digital weight injection, TTT can be shown to be extended to hundreds of thousands of tokens and other tasks.

With multiplexing, show our network is able to do millions of tokens per second with a small number of parts.

Calculate energy efficiency.

Optical: Hankel Multiplier
