# Early model architecture ideas

These are exploratory notes. The [current model specification](hankel_monarch_delta/research_model.md) and [paper design point](hankel_monarch_delta/paper_design_point.md) supersede their numerical examples: 24 layers, 16 logical heads, one physical head, eight fibers per head, 512-wide heads/residuals, unique two-layer head FFNs, a joint-error two-bank TTT update and dedicated query readers. Complex fixed-map factors contribute 301,989,888 real parameters; a tied real 16k vocabulary embedding/readout brings the selected subtotal to **310,181,888**, before ancillary weights. The earlier small-model and throughput estimates below are historical ideas.

Transformer Architecture? Single token prediction?

Mamba Architecture? Recurrent Network

Neural Memory and mamba hybrid architecture.
