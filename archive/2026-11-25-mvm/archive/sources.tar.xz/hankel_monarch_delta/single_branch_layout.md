# Conceptual silicon-photonics layout of one Hankel reader

Single passive binary lattice · 15 November 2026

**Numerical reference:** this floorplan illustrates the earlier \(K=R=32\), six-stage reader. The [selected paper design point](paper_design_point.md) uses \(K=R=64\) and requires a seventh delay cell. Its 16-reader die area has not been established by this 6 × 2 mm reference drawing.

A useful starting floorplan is a **6 × 2 mm tile**, with two straight nonlinear sections folded back-to-back across the upper part and six passive delay cells along the lower part. This implements the [single-branch reader](photonic_component.md): two DFG operations, fixed band selection and one coherent temporal accumulator. It retains the ideal 320 ps useful window every 640 ps, with no fast reader switch or output shutter.

The proposed platform is **SiN routing and delays with local periodically poled thin-film lithium-niobate (LN) nonlinear sections, on silicon**. The LN supplies the second-order nonlinearity. This is a proposed heterogeneous integration, not a selected foundry process or a completed mask layout.

![Conceptual 6 × 2 mm single-branch Hankel reader](figures/13_single_branch_floorplan.svg)

The die outline, straight 5 mm interaction lengths and approximate region placement use a common scale. Waveguide widths, couplers, filters, transitions, poling stripes and spiral turns are symbolic. In particular, tracing the drawn spirals does not recover the specified delays. The SVG is an editable placement and connectivity concept, not GDS or a design-rule-checked route.

## Optical path across the chip

1. **Upper left: input and adaptive-pump join.** The input comb in band A and a read tap of the stored coefficient comb \(a_m\) in band P enter a passive wavelength combiner. They transition together into DFG 1. The circulating memory itself bypasses the reader; only its tap enters this port.
2. **Upper rail: DFG 1, left to right.** A straight, approximately 5 mm poled-LN section converts A to the intermediate band B. Its exit transitions back into SiN.
3. **Right end: B selection and return.** A fixed filter passes the desired intermediate comb and rejects the original A light, residual P pump and unwanted idlers. A SiN bend returns B toward the second rail. The shared \(b_m\) reference enters from the right and joins B before the second SiN–LN transition.
4. **Second rail: DFG 2, right to left.** Another straight, approximately 5 mm poled-LN section converts B back into A. B and its pump co-propagate within this section. Reversing the rail on the drawing does not mean counter-propagating DFG; the crystal orientation and quasi-phase-matching design must support this direction.
5. **Left end: A selection.** After the fourth material transition, a fixed filter passes the desired A comb and removes B/P. It feeds the lower delay row.
6. **Lower row: six split–delay–recombine cells, left to right.** Their differential delays double at each stage. The selected output of each cell feeds the next; the complementary output terminates locally. The final raw comb exits at the lower right.

There are **four functional optical interfaces**: A input, adaptive-pump tap, shared-reference pump and A output. These are waveguide interfaces, not necessarily four separate packaged fibers per multiplier. An array can distribute the reference optically and connect reader outputs on chip. Pump/filter reject paths and unused coupler ports need low-reflection terminations; they do not require additional packaged ports in this concept.

Both band filters operate on the comb as a group. Neither Hankel operation requires a per-tooth demultiplexer here. Each filter box denotes a *filter function*: achieving the required passband, stopbands and extinction could require several physical elements.

## Placement reservations

Coordinates below are measured from the upper-left corner of the 6 × 2 mm outline.

| Region | Suggested placement | Purpose |
| --- | --- | --- |
| DFG 1 | \(x=0.5\)–5.5 mm, center \(y\approx0.27\) mm | Straight 5 mm interaction; symbolic 0.15 mm-wide corridor |
| DFG 2 | \(x=0.5\)–5.5 mm, center \(y\approx0.65\) mm | Second straight interaction, propagating leftwards |
| Left and right end regions | Approximately 0.5 mm horizontal allowance at each end | Material transitions, pump joins, band filters and SiN turns |
| Delay-cell row | Approximately 5.1 × 1.05 mm below the nonlinear rails | Six serial cells, their access routes, separation and clearance |
| Output route | Right edge of the delay row | Carry the full raw output to the next reader or capture interface |

The **end regions are the main unresolved fit**. The drawing does not establish that suitable high-rejection filters and broadband material transitions fit in these spaces. A longer taper or filter can require a wider tile or more vertical separation. Keeping bends in SiN avoids folding the nonlinear sections simply to satisfy the drawing.

The lower row reserves about **5.3 mm² including empty space and access**, not 5.3 mm² of tightly packed spiral waveguides. It uses otherwise available space beneath the two long nonlinear rails. This illustrates why summing component areas alone does not predict the final die outline.

## Physical form of a binary cell

Each cell is an unequal-path interferometer with two passive 50:50 couplers. One arm is a short reference; the other contains the extra delay, folded into a spiral. It has the geometry of an unbalanced Mach–Zehnder interferometer, but it is **not an electrically switched MZI shutter**. The selected port is set to add the two fields with a fixed calibrated phase.

![Two-arm passive binary delay cell](figures/14_binary_delay_cell_layout.svg)

In the ideal equal-amplitude, nondispersive model,

\[
E_{\mathrm{out}}(t)=\frac{E_{\mathrm{in}}(t)+E_{\mathrm{in}}(t-\Delta t)}{2},
\qquad
\Delta L=\frac{c\,\Delta t}{n_g}.
\]

Thus **one accumulator branch contains six two-arm cells and twelve couplers**. It does not mean a single unsplit waveguide. With \(\tau=10\) ps and assumed \(n_g=2\):

| Cell | Differential delay | Extra arm length, rounded | Illustrative spiral square envelope* |
| --- | ---: | ---: | ---: |
| 1 | 10 ps | 1.5 mm | 0.423 × 0.423 mm |
| 2 | 20 ps | 3 mm | 0.445 × 0.445 mm |
| 3 | 40 ps | 6 mm | 0.486 × 0.486 mm |
| 4 | 80 ps | 12 mm | 0.559 × 0.559 mm |
| 5 | 160 ps | 24 mm | 0.682 × 0.682 mm |
| 6 | 320 ps | 48 mm | 0.878 × 0.878 mm |
| **Total** | **630 ps** | **94.5 mm** | **2.16 mm² summed envelopes** |

\*For a packing estimate, take adjacent-track pitch \(p=10\) µm and an inner exclusion radius \(r_{\mathrm{ex}}=200\) µm. The approximate square side is

\[
s_j\simeq2\sqrt{r_{\mathrm{ex}}^2+\frac{p\,\Delta L_j}{\pi}}.
\]

This uses \(\Delta L_j\) as a first estimate of spiral length and reserves a larger central region than the earlier 100 µm calculation. **The exclusion radius is a layout allowance, not a specified minimum bend radius or a verified central-turn design.** The turns, reference arms and access paths must be routed before these envelopes can be accepted. Their sum excludes couplers and local access; it is not the complete row area.

The [initial footprint estimate](photonic_component.md#preliminary-footprint-estimate) gave 1.44 mm² for spiral envelopes with a 100 µm inner radius. Increasing that central allowance gives 2.16 mm² before routing. The earlier 1.5–2.5 mm² allowance for the complete lattice is therefore optimistic at its lower end. This floorplan reserves a larger lower strip while retaining **12 mm² as a working die envelope within the provisional 8–15 mm² planning range**. It does not establish a manufactured area or yield.

For an actual route, constrain the **whole long-arm length minus the whole short-arm length**, including couplers and connecting bends. Do not add a nominal 48 mm spiral to an already unequal pair of access routes and assume the delay remains 320 ps. Use the platform's group index and dispersion at the A-band wavelengths, rather than treating \(n_g=2\) as an exact material constant.

The six cells give

\[
H_{64}(D)=\prod_{j=0}^{5}\frac{1+D^{2^j}}2
=\frac1{64}\sum_{r=0}^{63}D^r.
\]

Here \(1/64\) is **the field weight of each temporal tap**. The ideal filter has unity gain for a constant, phase-aligned envelope; it is not a uniform 1/64 attenuator. For the scheduled 32-term computation, its useful output is the normalized sum specified in the component document. Losses and conversion efficiency remain additional factors.

## Timing and phase in this placement

The shared \(b_m\) pump supplies 32 populated 10 ps slots followed by 32 blank slots. Its amplitude blank prevents unwanted input transients from generating A-band terms at DFG 2. The passive lattice then exposes the completed sum during the scheduled 320–640 ps window, plus the actual common propagation delay through the chip.

**The output waveguide also carries the accumulation and decay transients.** Nothing in this floorplan clips them. The next reader accepts the completed window through its own timed reference burst. Pump distribution, inter-reader routes and any spatial shuffle must be included in that schedule; the 640 ps reader frame is not the recurrent network's token time.

No fast electrical switches or modulation electrodes are included in this reader. Its coherent operation nevertheless assumes stable relative phases, matched amplitudes and suitable comb spacing. A fabricated device would need a way to establish those phases, such as post-fabrication trimming or slow calibration, and sufficient thermal stability afterwards. This layout does not demonstrate maintenance-free passive phase alignment.

## Device precedents and remaining layout work

The 5 mm nonlinear lengths are motivated by a demonstrated **4.8 mm thin-film-LN DFG device**. This supports the length scale; it does not establish the conversion efficiency, poling pattern or phase-matching bandwidth for our combs. [Koyaz et al., DFG demonstration](https://arxiv.org/html/2410.08790v1)

Compact SiN routing has a commercial precedent: LIGENTEC publishes a **50 µm bend-radius specification** and low-loss delay-line specifications. Those are evidence for a compact routing platform, not validation of this combined poled-LN/SiN process or our full multi-band circuit. [LIGENTEC technology specifications](https://www.ligentec.com/technology/)

Turning this floorplan into a fabrication layout requires a selected process design kit, explicit band wavelengths, filter and pump-combiner designs, four material transitions, dispersion-aware delay routes and a phase-calibration strategy. The two DFG sections also need their polarization, crystal orientation, poling and conversion bandwidth designed together. These choices determine whether the 6 × 2 mm envelope survives detailed routing.

This tile excludes the recirculating fiber memory, comb generation, input encoding, optical writer and residual engine, replay and injection controls, inter-bank shuffle, electronics and packaging. It is **one full Hankel reader lane**, not a complete recurrent head or layer.
