# Integrated MZI interleaver shuffle

Selected paper architecture · 17 November 2026

Use fixed, wavelength-selective Mach–Zehnder interferometer (MZI) trees for the inter-bank shuffle. Each input lane is demultiplexed into wavelength residue groups, fixed waveguides route those groups to their destination lanes, and reverse trees multiplex them into the second bank. This replaces the free-space diffraction-grating shuffle in the current proposal. The same construction connects the two banks of each fixed optical map and the dedicated query reader.

This choice gives the paper a repeated circuit building block and an explicit routing rule. It is a proposed integrated implementation, not a fabricated router. Lower energy than free-space routing is a hypothesis to evaluate through insertion loss, coupling and stabilization power. The separate free-space saturable-absorber activation remains an independent design choice.

## Routing rule

For input lane \(b\in\{0,\ldots,7\}\) and wavelength index \(k\in\{0,\ldots,63\}\), select

\[
P:(b,k)\longmapsto((b+k)\bmod8,k).
\]

Each input tree has eight leaves. Leaf \(r\) carries the eight wavelengths

\[
\{r+8j\mid j=0,\ldots,7\},\qquad r=0,\ldots,7.
\]

Connect leaf \(r\) of input tree \(b\) to leaf \(r\) of the output multiplexer for lane \(a=(b+r)\bmod8\). Each output receives exactly one group of each residue. For example, input lane 3 sends wavelengths 5, 13, 21, 29, 37, 45, 53 and 61 to output lane 0. All 512 coordinates are routed bijectively without changing their optical frequencies.

[Historical sixteen-lane shuffle figure](figures/05_shuffle.svg). This figure predates the reduction to eight fibers per head and needs an eight-lane redraw; the routing rule and counts here define the current design.

The ideal inverse is \(P^{-1}(a,k)=((a-k)\bmod8,k)\). This cyclic route defines the selected unbalanced structured family. Each source/destination lane pair has eight intermediate coordinates, so each corresponding \(64\times64\) block of the complete two-bank map has rank at most eight. Full local matrix coverage does not remove that global restriction. Train and evaluate this exact permutation; the balanced square-Monarch equivalence does not automatically extend to \(n=8,K=64\).

## One three-level tree

Let the uniformly spaced data comb be \(f_k=f_0+k\Delta f\). An elementary interleaver uses two nominal 50:50 couplers and unequal arms. For level \(j=1,\ldots,3\), use differential group delay

\[
\Delta t_j=\frac{1}{2^j\Delta f}.
\]

A node at level \(j\) receives indices \(k=r\pmod{2^{j-1}}\). Set its static relative phase so that, at comb centers, the ideal arm phase difference is

\[
\theta_{j,r}(k)=\frac{2\pi(k-r)}{2^j}.
\]

Its complementary output powers are proportional to \(\cos^2(\theta/2)\) and \(\sin^2(\theta/2)\). They separate residues \(r\) and \(r+2^{j-1}\) modulo \(2^j\). The phase settings differ between branches; copying the same phase bias into every node would not implement the tree. The absolute carrier phase, coupler phase convention and dispersion must be included when calibrating a device.

For the **illustrative 100 GHz comb grid** and assumed group index \(n_g=2\):

| Level | MZIs at that level | Differential delay | Extra arm length, \(c\Delta t/n_g\) |
| --- | ---: | ---: | ---: |
| 1 | 1 | 5 ps | 0.750 mm |
| 2 | 2 | 2.5 ps | 0.375 mm |
| 3 | 4 | 1.25 ps | 0.1875 mm |

One tree contains 7 elementary MZIs and 14 couplers. An output tree uses the corresponding multiplexing direction. This is fixed spectral routing, with fabrication trimming or slow phase calibration as needed; no per-slot electrical switching is required. Ideal interference directs a resonant channel to its selected port, so a 50:50 coupler does not imply a 3 dB routing penalty at every node.

The 100 GHz grid is a design example, not a claim of 100 Gbaud vector throughput. It is commensurate with the reader's 10 ps delay lattice: \(\Delta f\tau=1\). The final grid must also satisfy the nonlinear conversion bands, dispersion and filtering requirements. The 64 carrier centers span 6.3 THz on this grid.

## Counts and footprint

| Resource | One 8-lane inter-bank shuffle |
| --- | ---: |
| Input demultiplexer trees | 8 |
| Output multiplexer trees | 8 |
| Elementary MZIs | 112 |
| Nominal 50:50 couplers | 224 |
| Fixed group connections between trees | 64 |
| MZIs traversed by each routed channel | 6 |

These counts describe elementary sinusoidal interleavers. Replacing a node with a higher-order flat-top filter increases the component count. Port access, phase correction, monitors, wiring and any duplicated backward router are additional.

The [current multifunction-cell budget](paper_design_point.md#physical-engines-and-activation) is 48 mm² per cell, or 768 mm² for the 16-cell prediction/update engine. Both are provisional. If \(A_{\rm tree}\) includes a complete tree and its local calibration hardware, then

\[
A_{\rm shuffle}=16A_{\rm tree}+A_{\rm links/access},
\qquad
\frac{A_{\rm shuffle}}{A_{\rm cells}}
=\frac{16A_{\rm tree}+A_{\rm links/access}}{768\ {\rm mm}^2}.
\]

For illustration, 1, 2 or 4 mm² per tree gives 16, 32 or 64 mm² before shared routing, equivalent to 2.1%, 4.2% or 8.3% of that cell array. These are sensitivity scenarios, not predicted footprints. A 5% total overhead allows 38.4 mm² for the complete shuffle. The read-only query and fixed-map cells need their own area comparison.

At 100 GHz and \(n_g=2\), each tree contains approximately 2.25 mm of summed differential arm length, or 36 mm across all 16 trees. This excludes common arms, couplers, bends and the 64 connecting routes and therefore is not an area estimate. Compact SiN routing has a commercial precedent in [LIGENTEC's published 50 µm-radius bending-loss specification](https://www.ligentec.com/technology/); a compatible process and routed layout remain to be selected.

Count a shuffle for each physically instantiated two-bank map. Under the dedicated-engine option, prediction/update, query and six fixed maps (two FFN maps plus K/Q/V/O) require eight forward-routing networks. Time-multiplexed heads and layers reuse them. Backward reuse of the prediction router requires explicit port access, phase correction and scheduling; a separate inverse router adds hardware if reuse is unsuitable.

## Coherent backward propagation and timing

Reciprocity supplies the inverse **connectivity**, but does not automatically supply the complex adjoint of an imperfect router. If the forward field transfer is \(R\), reciprocal reverse propagation gives \(R^T\) in matching port conventions; the gradient needs \(R^\dagger\). Even a lossless route can carry wavelength-dependent phases. The paper's ideal \(P\) therefore assumes calibrated route phases and a backward implementation consistent with those phases. Model residual phase, loss and crosstalk in both the forward and adjoint operations. Do not assume that reversing a device conjugates its phase response.

Match the group delays of all routes that form one vector, and include common propagation in the receiving reference-pump schedule. The elementary double-tree network has a differential delay span of 17.5 ps at 100 GHz, before common paths and connecting waveguides. This span is neither its complete latency nor a validated guard interval. Convolve the raw reader output, including its transients, with the filter response before selecting the next reader's accepted window. A long held result does not by itself establish that boundary transients are harmless. The current arithmetic-only timing totals do not include this physical validation.

## Energy comparison and paper wording

The integration benefit is avoiding the shuffle's chip-to-free-space launch, collection and grating assembly, where those interfaces are otherwise required. Both a diffraction grating and a fixed MZI router can route passively. The MZI network still incurs waveguide, coupler and crossing loss, and may consume steady heater and monitor power.

For equal useful output optical energy \(E_{\rm out}\), a simple router comparison is

\[
E_{\rm electrical/vector}
\simeq \frac{E_{\rm out}}{\eta_{\rm source}\eta_{\rm route}}
+\frac{P_{\rm trim/control}}{r_{\rm vector}},
\]

where \(\eta_{\rm route}\) includes the relevant interfaces, \(\eta_{\rm source}\) is electrical-to-optical efficiency and \(r_{\rm vector}\) is the actual serviced-vector rate. If gain compensates routing loss, account for its electrical power and noise explicitly. Use the same output fidelity, operating duty cycle and system boundary for both candidates. Static calibration power is amortized over active vectors; idle power remains part of system energy.

Suggested paper description:

> The two Hankel banks are connected by an integrated wavelength-preserving shuffle comprising MZI interleaver trees and fixed waveguide connections. Three binary interleaver levels separate each input comb into eight wavelength residue groups, which are routed according to the cyclic lane permutation and remultiplexed at the next bank. This repeated circuit construction provides a compact integration path and avoids the shuffle's free-space launch and collection optics. Its energy benefit remains conditional on routing loss and phase-stabilization power.

For device precedent, [Cherchi et al.](https://arxiv.org/abs/2002.07521) demonstrate flat-top interleavers using cascaded MZIs and MMI couplers. [Choi et al.](https://doi.org/10.1515/nanoph-2025-0288) demonstrate an eight-channel 100 GHz interleaver with broadband couplers. These support the component approach; neither establishes the loss, crosstalk, area, energy or adjoint fidelity of this complete eight-lane, 64-wavelength shuffle.
