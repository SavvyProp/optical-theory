# Optical Hankel Monarch memory with a joint TTT update

Working design draft · 17 November 2026

The proposed recurrent layer stores Hankel coefficients as coherent frequency combs in recirculating fiber. One logical head uses two adaptive banks of full Hankel multipliers, connected by a fixed wavelength-preserving spatial shuffle implemented with **MZI interleaver trees and fixed waveguide connections**. **One final target supervises the complete two-bank prediction.** Its error propagates through the old second-bank adjoint and inverse shuffle to update the first bank. Both updates are evaluated at the same pre-update state.

This **supersedes the separate-local-target architecture** originally described here. The joint recurrence is generally nonlinear in the combined state. The standalone affine-gradient derivation remains useful for a local-target comparison, but does not establish a global scan or a bank-by-bank sequence training algorithm for the selected model. This is a proposed structured TTT architecture, not the exact dense GatedDeltaNet recurrence.

The outer FFN, K/Q/V projections and output projection are now proposed optical Hankel–Monarch maps with recirculating fixed weights. The earlier ≤10M optical-weight cap is no longer imposed. The [research model](research_model.md), [fixed-weight optical MLP note](../hankel_monarch_mlp/README.md), and [sharing/deliberation note](parameter_sharing_and_deliberation.md) distinguish current choices from earlier budget studies. Train on conventional silicon and transfer weights to the device; the paper focuses on inference throughput/latency and online TTT updates, with no new hardware experiments planned. The repository currently contains algebra and timing checks, not a trained language model or a full validated device schedule.

The [selected design point](paper_design_point.md) uses **64 wavelengths × 8 lanes = 512 coordinates per head, a 512-wide residual stream, 16 logical heads, one physically simultaneous head, and 24 layers**. Each logical head has its own two-layer input FFN, separate K/Q/V maps and output projection. The recurrent hardware consists of **16 multifunction prediction/update cells and 16 separate read-only query readers**. Updated coefficients feed the query readers; these readers do not add independent adaptive state. Distinct layer/head coefficient frames persist in 16 bank/lane memory loops. All six fixed maps per head instantiated separately would add 96 local readers, for 128 local cell/reader instances overall.

With distinct learned weights in all 24 layers and complex matrix factors, those six fixed maps contribute **301,989,888 real scalar parameters**. A tied real 16,000 × 512 embedding/readout adds 8,192,000, giving **310,181,888 parameters (about 310M)** before gates, normalization and any learned initial memory. Adaptive TTT coefficients are inference state and are counted separately. The earlier 16-lane/four-FFN design is superseded; layer sharing remains an optional smaller-model variant rather than an assumption of this count.

The coefficient memory stores the adaptive comb **directly in the DFG pump band**, which is also the gradient cross-SFG output band. Each reader uses two DFG sections, fixed band filters and **one passive binary delay lattice**. With the current candidate \(R=64\) partner schedule, this becomes seven stages and 128 taps. The shared \(b_m\) source supplies 640 ps of reference slots followed by 640 ps of darkness. This accepts the previous optical stage's completed result while rejecting its temporal transients at DFG 2. The adaptive read tap may remain present continuously. There are **no reader routing switches and no output shutter**.

The ideal waveform model accepts a new read burst every **1.28 ns**, with first valid output after **0.64 ns per local bank**. With separate query hardware, an illustrative 5.12 ns prediction-to-query offset yields **30.72 ns/layer** including two input FFN maps, parallel K/Q/V, the 16-head recurrent sweep and output projection. It excludes unbudgeted propagation and electrical handoff. At that assumed schedule, 24 layers take **737.28 ns** and a matching coefficient ring is approximately **147–150 m** long, before accounting for other loop delays. These are conditional calculations, not validated full-system latency. See [timing and memory details](paper_design_point.md).

The [component design](photonic_component.md) and [floorplan](single_branch_layout.md) retain the earlier \(K=R=32\), read-only 6 × 2 mm example. They do not depict the current multifunction cell. **48 mm² per multifunction cell is a planning assumption**, not a fabricated or placed layout, and does not automatically apply to simpler read-only query/fixed-map hardware. Waveguide geometry, phase-matching bandwidth, coupler ratios, pump power, loop lifetime and device latency remain modeling inputs to substantiate from literature and simulation.

![Reference R=32 reader with one passive lattice; the current R=64 design adds a seventh binary stage](figures/08_binary_multiplier.svg)

## Reading guide

| Material | Purpose |
| --- | --- |
| [Shared weights and internal reasoning](parameter_sharing_and_deliberation.md) | Sharing options and inference deliberation; older ≤10M budgets retained as comparisons |
| [Research model](research_model.md) | Current optical FFN/TTT model, parameter accounting and digital simulation |
| [Nominal paper design point](paper_design_point.md) | Current 512-wide, 16-head/one-engine, 24-layer design; timing and memory length |
| [Four-die system diagram](figures/15_four_die_layer_multiplexing.svg) | Historical four-engine/eight-lane allocation; superseded |
| [Local recurrence](#local-coefficient-update) | The state, loss, and exact coefficient-gradient equations |
| [Two-bank architecture](#two-banks-with-one-learning-objective) | One target, old-state adjoint error propagation, joint update and separate query reader |
| [MZI interleaver shuffle](mzi_shuffle.md) | Selected integrated cyclic router, tree delays, component counts, phase calibration and area/energy accounting |
| [Fixed partner generation](#fixed-partner-generation-from-a-reference-comb) | A fixed comb with selectable phase ramps supplies the \(b_m\) slots |
| [Local optical circuit](#optical-update-circuit) | DFG filters, SFG convolution, optical residual, and coherent write |
| [Per-cell optical pathways](cell_pathways.md) | Current 64-slot reader, target MZI/subtraction, direct gradient writer, coefficient bypass and timing |
| [Photonic component design](photonic_component.md) | Fixed reader optics and reference-pump acceptance, with the earlier R=32 timing and footprint example |
| [Coefficient-loop gain and retention](coefficient_loop_gain.md) | Current amplification focus: P-band loss compensation, variable retention, frame control and repeated-pass noise |
| [Post-multiplier amplifiers](optical_amplifiers.md) | Background component comparison; output amplification is currently an assumed interface |
| [Binary lattice and timing diagram](figures/09_binary_lattice_timing.svg) | Earlier R=32 example: six balanced stages, 64 taps and 320 ps useful windows every 640 ps |
| [Footprint estimate](photonic_component.md#preliminary-footprint-estimate) | Delay packing, component reservations, standalone die area and array scaling |
| [Footprint illustration](figures/12_footprint_budget.svg) | Indicative 6 × 2 mm reader allocation with no EO routing devices |
| [Chip layout notes](single_branch_layout.md) | Two straight DFG rails, band-filter end regions, six delay cells, material interfaces and placement limits |
| [Single-branch floorplan](figures/13_single_branch_floorplan.svg) | Conceptual 6 × 2 mm placement with optical paths and four functional interfaces |
| [Binary delay cell close-up](figures/14_binary_delay_cell_layout.svg) | Two passive couplers, a short reference arm, a delayed arm and a discarded output |
| [Engineering margins](engineering_margins.md#design-the-margin-before-synthesizing-the-network) | Earlier dual-lattice 70-tap alternative with routing switches and finite timing budgets |
| [Coefficient memory](#recirculating-coefficient-memory) | Direct pump-band storage, read tap, and coherent gradient injection |
| [Head and layer memory schedule](#head-and-layer-multiplexing) | Current schedule and explicitly historical later-lap investigation |
| [Timing model](model_memory_schedule.py) | Historical serial/local-target, later-lap reference; does not simulate the current dedicated-query model |
| [Training](#digital-training) | Joint recurrent simulation; local affine solver is only a comparison |
| [Validation script](check_update_algebra.py) | Executable checks of the proposed update algebra |
| [Single-lattice checker](check_single_lattice.py) | Full raw-waveform chaining, continuous adaptive pumps, acceptance by \(b_m\), timing counterexamples and normalized gradient |
| [Earlier dual-lattice checker](check_binary_multiplier.py) | Reference checks for the configurable-margin alternative |
| [SVG index](figures/README.md) | Editable diagram files and their scope |

This design builds on the [native Hankel and full Hankel multiplier](../hankel_monarch/README.md), its [expressivity constructions](../hankel_monarch/limitations.md), and the [SFG/DFG field model](../SFG_DFG/OptimalSFG.md).

## Design choices

| Choice | Baseline |
| --- | --- |
| Fast recurrent state | The effective coefficients \(a_{p,h,\ell,f,m,s}\), stored separately for every layer/head |
| Local multiplier | \(c\sum_m H(b_m)H(\overline{a_m})\), with \(c=1/128\) |
| Fixed partners | Shared comb with the fixed phase-ramp sequence during active slots, then an amplitude blank; repeat the family each read |
| Online loss | One squared loss at the output of the complete two-bank prediction |
| Optical arithmetic | Forward reads, coherent subtraction, backward adjoint reads, SFG coefficient writes |
| Temporal summation | Two lattices per multifunction cell: forward and backward; seven stages/128 taps each; no gradient accumulator |
| Output acceptance | Raw output contains transients; the next reader's \(b_m\) burst enables DFG 2 only over the valid incoming interval |
| Ideal reader timing | At 10 ps slots: 640 ps reference burst plus 640 ps blank; accept 640–1280 ps relative to each 1280 ps frame, plus common latency |
| Electrical work | Intensity detection after optical O, head/residual sum, normalization, scalar/control functions and re-encoding |
| Coefficient encoding | Coherent field amplitudes; signed-real reference equations below, with the native complex convention for phase-ramped partners |
| Storage grid | \(2K-1\) frequency channels per coefficient slot, directly at the DFG pump / gradient output frequencies |
| Bank connection | Fixed MZI interleaver trees and waveguides implement the cyclic lane shuffle; wavelength is preserved |
| Hardware reuse | One 8-lane two-bank prediction/update engine plus a dedicated query engine; 16 head batches and 24 layers |
| Digital layer boundary | Stream head-output processing, then allow a gap for remaining all-head processing and next-layer encoding |
| Training requirement | Differentiate the joint nonlinear recurrence; standalone local affine algebra is not a global training shortcut |

The fixed optical frontend supplies keys, queries and the target from the current observed input. Electronics encodes the residual stream and supplies gates/control; it does not measure the adaptive state to calculate its update numerically. Stabilization instrumentation is a separate control function.

## Notation and optical read operation

Within one head there are \(n\) spatial channels and \(K\) data frequencies per channel, giving \(d=nK\) coordinates. The balanced Monarch layout has \(n=K\); the current \(n=8,K=64\) construction is unbalanced. The independent head count is \(H\); fibers coupled by the shuffle are not independent heads. Optical frontend/output projections connect this head to the 512-wide residual stream. The indices are:

| Symbol | Meaning |
| --- | --- |
| \(t\) | Token or recurrent update index |
| \(p\in\{1,\ldots,L\}\) | Network layer index |
| \(h\in\{1,\ldots,H\}\) | Independent recurrent head within a layer |
| \(\ell\in\{1,2\}\) | Bank index |
| \(f\in\{0,\ldots,n-1\}\) | Fiber or waveguide index |
| \(m\in\{0,\ldots,R-1\}\) | Hankel-pair slot within a local matrix |
| \(i,j\in\{0,\ldots,K-1\}\) | Data-channel indices |
| \(s\in\{0,\ldots,2K-2\}\) | Hankel-coefficient index |

The local equations below suppress \(p,h\). A bank's coefficient frame belongs to exactly one layer/head/token-state version, even when the hardware is shared.

Define \(H(a)_{ji}=a_{j+i}\). In signed real notation, one local block is

\[
F_f(x)=\sum_{m=0}^{R-1}H(b_{f,m})H(a_{f,m})x.
\]

The bank is \(B_\ell=\operatorname{diag}(F_{\ell,0},\ldots,F_{\ell,n-1})\). The reader is

\[
W=B_2PB_1,\qquad y=Wq.
\]

Here a full Hankel multiplier means the **sum of complete two-Hankel paths**, with filtering between interactions and coherent accumulation across slots. A single Hankel is not a general local matrix.

The actual DFG convention is

\[
\mathcal D(h,x)=H(h)\overline{x}.
\]

Consequently, a physical pair produces

\[
\mathcal D(b,\mathcal D(a,x))=H(b)H(\overline a)x.
\]

The real equations below assume calibrated conversion phases and a signed real encoding. For general complex amplitudes, retain this physical conjugation convention rather than identifying one DFG with an ordinary linear matvec. SFG/DFG support coherent phases, but arbitrary phases do not guarantee constructive addition of products. Real negative values themselves require a sign encoding, such as a controlled \(\pi\) field phase; that capability must be included in the implementation.

The equations immediately above and the preserved local-affine derivation use a unit-sum reference convention. The selected physical model instead includes \(c=1/L_F\) in every local reader, with \(L_F=128\) in the [current design point](paper_design_point.md), \(L_F=64\) in the [earlier R=32 example](photonic_component.md#binary-delay-lattice), and \(L_F=70\) in the separate margin example, before other conversion and propagation gains. The joint-update equations below include this factor explicitly. Training, targets and gradients must use one consistent normalization or a calibrated alternative. Absorbing a scale into parameters does not restore lost optical power.

## Local coefficient update

This section preserves the **standalone local-target derivation** underlying the writer. In the selected two-bank model, bank 1 instead receives the propagated output gradient specified below. Its evolving error depends on bank 2, so the affine conclusion of this section must not be applied to the combined state.

Suppress bank and fiber indices. Hold every \(b_m\) fixed during the recurrent sequence and concatenate the adaptive \(a_m\) into \(\theta\in\mathbb R^{R(2K-1)}\).

For one token, first decay the state:

\[
a^-_{m,t}=\alpha_t a_{m,t-1}.
\]

Read the key using that state and form a shared local residual:

\[
\widehat v_t=\sum_m H(b_m)H(a^-_{m,t})k_t,
\qquad e_t=v_t-\widehat v_t.
\]

The local objective is \(L_t=\tfrac12\|v_t-F(k_t)\|^2\). Its negative gradient in coefficient coordinates is

\[
r_{m,t}=H(b_m)e_t,
\qquad
g_{m,t}=k_t*r_{m,t},
\]

\[
\boxed{
a_{m,t}=a^-_{m,t}+\eta_t g_{m,t},
\quad
(g_{m,t})_s=\sum_{i+j=s}(k_t)_i(r_{m,t})_j.
}
\]

The convolution has length \(2K-1\). **All of it is written to memory.** Each slot uses the residual from the completed sum over all \(R\) pairs, not a separate target fit for that pair. Compute this residual before any coefficients used by that prediction are overwritten.

The physical complex-field counterpart is \(g_m=k*\mathcal D(b_m,e)\), with the same ordinary convolution in the unit-sum convention. At the chosen passive-reader scale, use \(g_m=c\,k*\mathcal D(b_m,e)\) and compute the residual from the correspondingly normalized reader. No electronic outer product or residual is required. The [existing gradient derivation and checks](../hankel_monarch/recurrent_update_checks.py) use that native conjugation convention.

### Why this recurrence is affine

With fixed partners, the prediction is linear in the stored coefficient vector:

\[
F(k_t)=J_t\theta,
\qquad J_t\in\mathbb R^{K\times R(2K-1)}.
\]

The operator \(J_t\) depends on the key and fixed partners, but not on the previous local state. The update is therefore

\[
\boxed{
\theta_t=\alpha_t(I-\eta_tJ_t^TJ_t)\theta_{t-1}
+\eta_tJ_t^Tv_t.
}
\]

Both gates must be independent of this bank's evolving state to preserve the stated affine form. They may depend on the bank's supplied input sequence. State-dependent normalization, clipping, or adaptive optimizers change the recurrence; key normalization and input-derived scalar gates do not have that problem.

The selected phase-ramp partner family generally uses complex fields. In that case use the physical prediction \(\sum_m H(b_m)H(\overline{a_m^-})k_t\) and update \(g_m=k_t*\mathcal D(b_m,e_t)\) given above. Stacking the real and imaginary parts of the state and output gives a real linear prediction operator and the same affine-gradient argument. The phase-ramped implementation must retain this DFG conjugation explicitly.

For an ideal ungated squared-loss step, a sufficient nonexpansive bound is \(0\le\eta_t\le2/\|J_t\|_2^2\). Null directions need not contract. Normalizing the key alone does not establish this bound because fixed-pump norms, slot count, and basis conditioning also affect \(J_t\).

### Relation to GatedDeltaNet

Dense GatedDeltaNet updates a directly stored matrix as

\[
S_t=\alpha_tS_{t-1}(I-\beta_t k_tk_t^T)+\beta_t v_tk_t^T.
\]

It applies error correction in independent matrix coordinates. The proposed rule instead applies error correction in shared Hankel-coefficient coordinates. These have different update geometry, even if the coefficient representation spans every local matrix. The scalar gates play analogous roles, but \(\eta\) is not automatically the same normalization as DeltaNet's \(\beta\). [GatedDeltaNet, formulation and training algorithm](https://arxiv.org/html/2412.06464v1#S3)

## Two banks with one learning objective

![The two-bank optical core for one selected layer and head](figures/01_system.svg)

The figure above is historical: its separate targets are superseded. The current frontend generates one \(k_t,q_t,v_t\) set for the complete two-bank operator. The target is a learned view of the observed input, available at inference, not a future token label.

After applying each bank's retention once, define

\[
z_t^-=PB_{1,t}^-k_t,\qquad
\widehat v_t=B_{2,t}^-z_t^-,\qquad
e_{2,t}=v_t-\widehat v_t,\qquad
L_t=\tfrac12\|e_{2,t}\|^2.
\]

Propagate the error using the **old** second bank:

\[
e_{1,t}=P^\dagger(B_{2,t}^-)^\dagger e_{2,t}.
\]

For local lane \(f\), apply the normalized complex writer to both banks:

\[
\Delta a_{1,f,m}=\eta_1c\,(k_t)_f*
 [H(b_{1,f,m})\overline{(e_{1,t})_f}],
\]
\[
\Delta a_{2,f,m}=\eta_2c\,(z_t^-)_f*
 [H(b_{2,f,m})\overline{(e_{2,t})_f}],
\qquad a_{\ell,f,m}^+=a_{\ell,f,m}^-+\Delta a_{\ell,f,m}.
\]

The bank-2 writer uses the saved **old-state prediction** \(z_t^-\), not a query output or a recomputation through updated bank 1. Compute both gradients from this common snapshot; physical injection can be staggered if the necessary old taps/operands remain available. No activation is inserted between the two adaptive banks. FFN activations are outside this operator.

The separate query engine then reads

\[
y_t=B_{2,t}^+PB_{1,t}^+q_t.
\]

It is a physical duplicate of the forward reader with access to the same updated state, not a third adaptive bank. Prediction and query bursts for different heads can overlap in their distinct engines. The post-update query convention must match digital training. The separation of the online self-supervised objective from the outer language-model objective follows the [TTT formulation](https://arxiv.org/html/2407.04620v1#S2.SS2); this optical factorization and schedule are proposed extensions.

### The spatial shuffle

The current 8-lane, 64-wavelength layout selects the cyclic route

\[
P:(f,j)\longmapsto((f+j)\bmod8,j).
\]

The destination lane changes; the frequency index does not. Eight three-level MZI trees separate the inputs by wavelength residue \(r=j\bmod8\). Fixed waveguides connect input \(f\), leaf \(r\), to output \((f+r)\bmod8\), leaf \(r\); eight reverse trees recombine the outputs. Each group contains eight wavelengths. The elementary implementation uses 112 MZIs, 224 couplers and 64 group connections; each signal traverses six MZIs. This replaces the free-space grating shuffle in the selected architecture.

The inverse connectivity is \((g,j)\mapsto((g-j)\bmod8,j)\). The selected online update **requires this inverse route** for the bank-2 error returning to bank 1. Reciprocal optics supply inverse connectivity, but a physical reverse transfer is a transpose rather than automatically a complex adjoint. Specify phase calibration, backward access and matched delays consistently with the ideal \(P^\dagger\).

![Earlier sixteen-lane MZI shuffle illustration; the selected eight-lane version uses the counts and routing rule above](figures/05_shuffle.svg)

The [existing balanced physical encoding](../hankel_monarch/README.md#8-arrays-of-full-hankel-matmuls-and-monarch) is equivalent to the square Monarch family up to a fixed output permutation **when each local block is arbitrary**. The cyclic router is not the canonical index-transpose permutation. For the current 8 × 64 unbalanced layout, each source/destination lane pair has eight intermediate routes, giving a rank-at-most-eight bound on each 64 × 64 spatial block of the complete map. Train this selected structured family explicitly; the square-case argument does not automatically prove equivalence. [Monarch definition](https://proceedings.mlr.press/v162/dao22a/dao22a.pdf)

The [MZI shuffle design](mzi_shuffle.md) gives an illustrative 100 GHz implementation, area scenarios and the physical validation requirements. Integrated routing simplifies the circuit description and can avoid launch/collection interfaces. An energy saving over passive free-space gratings remains conditional on total insertion loss and phase-trimming/control power. The FFN's proposed free-space saturable-absorber activation is a separate element.

## Local matrix coverage and memory size

Freezing one factor changes the representation question. The existing \(R=\lceil K/2\rceil\) dense-factor theorem allows **both factors** to vary with the target matrix; it cannot be reused unchanged for the affine recurrence.

For fixed \(b\), at most \(R(2K-1)\) real coefficients control a local \(K^2\)-entry matrix. For even \(K\) and \(R=K/2\),

\[
R(2K-1)=K^2-K/2<K^2,
\]

so arbitrary local matrices cannot be covered. Odd dimensions need a separate rank analysis; the even-dimensional obstruction is not a universal minimal-slot theorem.

A conservative full-coverage choice is **\(R=K\) fixed partners**. Let \(J_j=H(e_j)\), where \(e_j\) selects coefficient \(j\), \(j=0,\ldots,K-1\). The transposed telescoping construction in the [existing fixed-factor check](../hankel_monarch/recurrent_update_checks.py) represents any real matrix as

\[
F=\sum_{j=0}^{K-1}J_j H(a_j).
\]

Explicitly, let \(Z_{i,i+1}=1\) be the upward shift, set \(C=F^T-ZF^TZ^T\), and take \(a_j\) to be column \(j\) of \(C\) followed by \(K-1\) zeros. This initializes a representation of any target \(F\). Subsequent coefficient-gradient updates can populate all \(2K-1\) entries; the initialization's trailing zeros are not a constraint on the recurrent state.

These singleton pumps are a basis proof, not a requirement to abandon full combs. An orthogonal mixing of the fixed partners, accompanied by the same mixing of the adaptive vectors, preserves the span and yields fixed partners with multiple active lines. The new [algebra check](check_update_algebra.py) constructs and verifies this mixed basis. Full span does not establish favorable pump norms, conditioning, or energy efficiency; those are basis-design criteria. If the outer optimizer learns the fixed partners freely, preserve or recheck the encoding map's rank and conditioning.

A fixed-phase amplitude code also achieves full complex coverage. The 64-slot version cycles two equal, positive pump teeth and gives a power comparison at the existing timing. A separate construction covers two independent rows of diagonal differences per mask and attains the fixed-partner minimum of **33 masks for \(K=64\)**. The counts below use the paper's 64-slot schedule. [Construction, power bounds and checks](../simulation_notes/matmul_power_budget.md#fixed-phase-amplitude-references-for-arbitrary-local-matrices)

For one head's two banks, the stored adaptive field coefficients number

\[
N_{\rm state}=2nR(2K-1).
\]

Fixed partners and replay/accumulator buffers are additional resources. They may share a common fixed basis across fibers, but optical distribution still consumes power. Different coefficient states can represent the same matrix because this basis is redundant.

For the [selected paper design](paper_design_point.md), \(n=8\), \(K=R=64\) gives a **512-coordinate reader per head** and **130,048 adaptive complex field coefficients** across its two banks. With 16 logical heads and 24 layers, the total is **49,938,432 stored complex coefficients**, or **381 MiB per sequence snapshot** in complex64 during digital simulation. One physical head engine services 16 head batches. This is a mode count, not bit capacity, learned parameter count or throughput. The global two-bank map remains structured rather than an arbitrary \(512\times512\) matrix. The native 8,128 coefficients/local cell differ from its 4,096 effective matrix-factor entries.

## Fixed partner generation from a reference comb

**Selected implementation direction:** generate the fixed partners from one reference comb with a selectable linear spectral phase ramp. Keep the complete back-to-back Hankel multiplier. No line-by-line demultiplexing or independently programmed coefficient array is required to select a partner.

Let \(g_s\) be the fixed complex envelope of the reference comb. In slot \(m\), use

\[
b_{m,s}=g_s e^{-is\phi_m},\qquad s=0,\ldots,2K-2.
\]

A candidate schedule is \(R=K\), \(\phi_m=2\pi m/K\). The spectral envelope and per-slot phase settings stay fixed across tokens; the shared source repeats that schedule in each active burst. Prediction, error multiplication, backward reading and query reading must use the same calibrated \(b_m\) for each slot. This keeps the partner basis independent of the adaptive state, without making the joint two-bank recurrence affine.

For the single-lattice reader, multiply this sequence by a shared temporal envelope \(w(t)\): one during the \(R\) active slots and zero during the following \(R\) slots (currently 64 of each). Thus \(b_{\mathrm{pump},s}(t)=w(t)g_s e^{-is\phi_{m(t)}}\). The source supplies this amplitude blank as well as the phase schedule; phase changes alone do not stop conversion. Source generation and distribution are shared outside the fixed reader PIC. Each bank's burst phase is offset to match the useful output from the preceding optical stage, including propagation delay.

Here “phase shift” means a **phase increment between adjacent comb lines**. A common optical phase shift on the whole comb only multiplies every partner by a scalar and does not generate the required distinct Hankel factors.

For comb spacing \(\Delta f\), a whole-comb delay implements the ramp:

\[
g_s e^{-i2\pi(f_0+s\Delta f)\tau_m}
=e^{-i2\pi f_0\tau_m}g_s e^{-is\phi_m},
\qquad \tau_m=\frac{\phi_m}{2\pi\Delta f}.
\]

A switched delay network is one implementation. For an electro-optic reference-comb source, changing the RF drive phase is another way to set the ramp, with all participating RF drives shifted consistently. A static common optical phase shifter alone cannot do this. The source or delay selector must settle before the interaction window; relative pulse timing, the common carrier phase, and dispersion need calibration.

Treat \(b_m\) as a known reference generated from this common source, with no requirement to retain an unknown fixed weight array indefinitely in a passive fiber loop. The adaptive \(a_m\) remain the recurrent optical memory. This removes repeated arbitrary per-line synthesis of \(b_m\), but reference-comb power, distribution, switching, and stabilization still belong in the energy budget.

The actual envelope \(g_s\) is a design constraint: phase ramps do not flatten its amplitudes or remove its existing spectral phase. Check the matrix span and conditioning for the measured envelope and chosen phase schedule before claiming full local matrix coverage. Phase-coded products can also cancel, so this choice does not by itself establish the favorable coherent-summation energy scaling. The current signed-real algebra checks and functional SVGs do not yet validate this specific complex partner generator.

## Frequency arithmetic and filters

Use matching frequency spacing \(\Delta\) and distinct data bands A and B. The baseline stores coefficients directly in the pump band P.

| Role | Frequencies | Retained channels |
| --- | --- | --- |
| Keys, targets, residuals, local input/output | \(\omega_A+i\Delta\) | \(K\) |
| Intermediate DFG vectors | \(\omega_B+j\Delta\) | \(K\) |
| Effective pumps and SFG coefficient updates | \(\Omega_s=\omega_A+\omega_B+s\Delta\) | \(2K-1\) |
| Stored coefficients | The same \(\Omega_s=\omega_A+\omega_B+s\Delta\) pump grid | \(2K-1\) |

For DFG with a pump \(h_s\), the relation \(\Omega_s-(\omega_A+i\Delta)=\omega_B+(s-i)\Delta\) gives

\[
r_j=g_D\sum_i h_{j+i}\overline{x_i}.
\]

Before filtering, this interaction can generate \(3K-2\) lines with indices \(-(K-1),\ldots,2K-2\). Select exactly \(j=0,\ldots,K-1\) for the Hankel matvec. Repeat this selection after the second DFG. Unwanted intermediate lines must be removed before a subsequent nonlinear stage, because they can mix back into retained channels.

For cross-SFG of \(k_A\) and \(r_B\), every pair with \(i+j=s\) reaches \(\Omega_s\):

\[
(\Delta a)_s=g_S\sum_{i+j=s}k_i r_j.
\]

The output is the **full linear convolution**, not a circular convolution. Products add as coherent fields at the same frequency; there is no detector performing the sum and no requirement to sweep a single data frequency over time. Keep all \(2K-1\) lines after SFG.

Cross-SFG must be isolated from the two self-SFG contributions. Simply adding the inputs in the same band and squaring yields \(k*k+2k*r+r*r\). Carrier separation, polarization, spatial modes, and phase matching must jointly select the desired cross interaction.

Uniform complex conversion coefficients give the ideal equations. Pair-dependent phase mismatch instead gives a weighted convolution \(\sum_{i+j=s}g_{ij}k_i r_j\). Broadband tuning alone does not establish uniform simultaneous conversion for every comb pair. [DFG dispersion and phase-matching analysis](https://arxiv.org/html/2410.08790v1#S2)

## Optical update circuit

The [per-cell pathway specification](cell_pathways.md) gives the complete current circuit, including conjugations, filtering, normalization and alignment. A reusable cell receives a forward input and a backward output error, then supplies:

| Path | Operations | Result |
| --- | --- | --- |
| Forward | Adaptive-pump DFG, filter, fixed-pump DFG, filter, temporal accumulation | \(F_a(x)\) |
| Shared error transform | Fixed-pump DFG of supplied error, filter | \(r_m=H(b_m)\overline e\) |
| Backward | DFG of \(r_m\) with old adaptive pump, filter, temporal accumulation | \(F_{a^-}^\dagger e\) |
| Write | Cross-SFG of held local input and \(r_m\), retain all 127 lines, scale/phase trim, inject | \(\Delta a_m=\eta c\,x*r_m\) |

This is **four DFGs, one SFG and two temporal lattices per multifunction cell**. The intermediate error transform can supply both the backward reader and writer through calibrated taps. The dedicated query reader needs only two DFGs and one lattice per cell. Bank 1 uses the same multifunction package as bank 2 with additional delay for error arrival.

Only bank 2 has target subtraction. Match the target amplitude to the prediction tap using the incoming-value MZI, then calibrate the subtraction phase and coupler scaling. Internal errors remain complex fields; intensity-only detection is reserved for the electronic boundary after the optical output projection.

The 128-tap forward and backward lattices each have seven stages. A 640 ps active reference burst and 640 ps blank provide useful output at 640–1280 ps, plus real propagation latency. The next stage accepts only that useful interval. **There is no temporal accumulator in the coefficient writer or immediately after subtraction.** A later write needs explicit held/replayed error and input fields. Each gradient is retained separately for its own slot \(m\).

The old bank-2 coefficient tap must precede gradient injection so the backward error uses \(B_2^-\). Save \(z^-=PB_1^-k\) for its writer, and save \(k\) until the bank-1 error arrives. Both writes thereby implement one gradient step at a common pre-update state. Updated query coefficients are tapped after their writes. A query does not enable the writer.

The historical [local-update figure](figures/02_local_update.svg) and reader-only component drawings omit the backward path and dedicated query hardware; they are not complete schematics of this current cell. Reusing nonlinear sections across visits remains a possible area/latency tradeoff, but is not the selected concurrent arrangement.

## Recirculating coefficient memory

![Pump-band coefficient loop with a direct read tap and coherent gradient injection](figures/03_coefficient_memory.svg)

Store \(a_s\) directly at \(\Omega_s=\omega_A+\omega_B+s\Delta\). One selected bank frame contains \(R\) slots, each with \(2K-1\) coefficient channels. Slot timing selects \(m\); frequency selects \(s\). Larger loop frames can hold multiple head/bank frames. This does not serialize the entries of the key during the convolution.

A read tap supplies the coefficient pump directly to the first Hankel DFG. The persistent field bypasses the nonlinear compute sections, so data-dependent depletion of the tapped copy does not become an unintended state update. The tapped pump still needs enough power for the selected conversion regime; a tap does not supply free amplification.

The gradient cross-SFG already produces all coefficients at \(\Omega_s\). Select that complete band, calibrate its scalar field amplitude and phase, and coherently inject it into the matching memory slot. No fixed reference tone or additional frequency conversion is needed at this interface.

Pump-band storage requires fiber, couplers, gates, and any gain that support the full coefficient band. A lower-band loop with fixed-tone up/down conversion remains an alternative if a measured storage advantage justifies the additional conversion cost; it is no longer the baseline. Self-SFG of the stored coefficients would compute \(a*a\) and is not part of either readout.

The [current gain/retention note](coefficient_loop_gain.md) prioritizes amplification of these stored coefficients. A candidate uses steady loss-compensating gain plus a fast electro-optic retention element, applying the selected scalar forgetting factor once per logical update while compensating loss on passive laps. Output amplification is treated as an assumed interface. The current 127-tooth P-band, rather than the 64-tooth telecom output, sets the memory amplifier's spectral requirement.

The ideal recurrence must be mapped onto the actual loop equation. A simple per-channel description is

\[
a_{s,\rm next}^{\rm phys}
=\rho_s g_{\alpha,s}a_s^{\rm phys}
+\kappa_s g_{\rm write,s}(\Delta a)_s.
\]

The roundtrip coefficient \(\rho_s\) includes tap loss, propagation, switches, and phase. The injection coefficient \(\kappa_s\) and write-path field gain must be calibrated. A passive coupler cannot have unity retention and nonzero injection simultaneously. Any amplification used to restore scale adds its own noise and power cost. The desired \(\alpha\) is a field multiplier, not an intensity multiplier, and applies once per token; repeated memory laps contribute separate loss.

Persistent coefficient memory, temporary key/error replay, and the prediction accumulator have different lifetimes. The current passive FIRs drain their finite impulse responses; they have no active reset. Their clean output windows depend on frame spacing and gating. This drainage does not erase the recurrent coefficient frame. Keep the nonlinear conversion sections on tap/injection paths rather than making every stored coefficient traverse them on every lap.

The loop requires controlled relative phase across lines and between tokens. Dispersion, wavelength-dependent attenuation, phase drift, amplifier noise, and overwrite leakage must be included in the measured state transition. The preliminary [recirculating-memory note](../Recurrent_Memory/recurrent_memory.md) does not establish a usable lifetime for this design. Electrical refresh, if eventually required, changes the conversion and energy budget and is not assumed in the inner update above.

## Head and layer multiplexing

One physical head engine services 16 logical heads per layer and all 24 layers. Its 8 lanes remain parallel so the spatial shuffle can mix the full 512-coordinate vector. Every layer/head retains a distinct adaptive coefficient frame; sharing physical hardware does not share recurrent state or necessarily share learned FFN weights.

### Optical frontend and digital layer boundary

Each head has a two-layer optical input FFN, three parallel K/Q/V projections, the adaptive two-bank TTT operator, and an optical output projection. Each fixed map is itself a two-bank structured map. The earlier user diagram shows three FFN blocks; the selected numerical design now explicitly uses **two**, with one activation after each complete FFN map. The selected activation direction is frequency-demultiplexed saturable absorption, with the measured or assumed coherent field transfer represented during digital training; SHG depletion remains an alternative.

After the optical output projection, detect intensities, accumulate head features electronically, add the residual bypass and normalize before re-encoding the next layer input. One possible interface is

\[
x_{p+1,t}=\mathcal N_p\left(x_{p,t}+\sum_{h=1}^{16}
\left|O_{p,h}y_{p,h,t}\right|^2\right),
\]

with any learned scales/gates specified by the trained model. This sums detected features, not coherent head fields. The residual bypass is required even though the user's block diagram omitted its explicit wire. If the diagram's “BatchNorm” is used literally, specify causal training and fixed inference statistics; otherwise keep the normalizer generic until chosen. Internal complex arithmetic is retained even with intensity-only final detection.

This black next-layer path is distinct from the coefficient feedback loop, which preserves the same layer/head state across tokens. Head-output acquisition, electronic accumulation, normalization, re-encoding and settling contribute a real boundary delay. Only unfinished work after the final head belongs in the tail; earlier head processing can overlap the sweep.

### Dedicated-query illustrative timing

The 10 ps slot and 64-term burst give a 0.64 ns first-valid latency per bank and a 1.28 ns accepted-burst spacing. A complete two-bank map has 1.28 ns first-valid latency, not 2.56 ns. Common waveguide/free-space/filter/nonlinearity delays are additional.

For heads \(h=0,\ldots,15\), relative to the first prediction launch, use

\[
P_h=1.28h\ {\rm ns},\qquad Q_h=P_h+5.12\ {\rm ns}.
\]

Prediction and query use distinct hardware. The query offset allows 2.56 ns beyond the ideal whole-frame write readiness of 2.56 ns; actual writer/shuffle/transport delays must fit or the offset must increase. The last two-bank query output starts at

\[
15(1.28)+5.12+1.28=25.60\ {\rm ns}.
\]

Two input FFN maps take an ideal 2.56 ns; parallel K/Q/V add 1.28 ns; optical O adds 1.28 ns. Thus

\[
T_{\rm layer,ideal}=3.84+25.60+1.28=30.72\ {\rm ns}.
\]

This is the leading edge of the last head's projected output. Full-window intensity acquisition can add 0.64 ns if needed; account for it once within the electrical handoff. **30.72 ns is not an established physical layer period.** The [design-point note](paper_design_point.md) gives assumptions, omitted delays and resource dependencies. Previous 51.2 ns and shared-reader 48.64 ns calculations describe different or corrected assumptions; 33.28 ns used the superseded four-map FFN. None is the current baseline.

### Persistent memory organization

There are **16 bank/lane coefficient loops**, each storing 24 × 16 = 384 logical frames of 64 slots × 127 frequencies. Each loop therefore holds 3,121,152 complex coefficients; all loops hold 49,938,432. Dedicated query readers add access taps, not another persistent state copy.

A frame occupies 0.64 ns of coefficient slots, so 384 frames require 245.76 ns of occupied time. Giving each a 1.28 ns read interval uses 491.52 ns before additional gaps. These are storage/framing durations, not a complete token latency. Actual frames must be placed to meet layer-input readiness, reference windows and all tap phases.

The simplest proposed access order is:

```text
old-state prediction tap → old-state backward tap → matching gradient injection
  → updated-state query tap → remaining storage delay → next token's visit
```

The persistent frame remains on a bypass loop; tapped copies supply nonlinear compute. Physical tap spacing must preserve old bank-2 coefficients through backward propagation, align each gradient slot at injection, and make updated frames available for the separate query stream. The two banks may require different tap positions because bank 1 waits for the returned error. Fixed holds retain k, q, v and the old bank-1 prediction as required.

If one loop circulation equals the assumed 24-layer pass,

\[
T_{\rm rt}=24(30.72\ {\rm ns})=737.28\ {\rm ns},\qquad
L_{\rm fiber}=\frac{c_0}{n_g}\bigl(T_{\rm rt}-T_{\rm other}\bigr).
\]

Using \(n_g\approx1.47\) and neglecting other delays gives **150.4 m per ring**; the 5 ns/m rule gives **147.5 m**. This is ring circumference, with no factor of two. The 16 rings contain roughly **2.4 km aggregate fiber** under this estimate. The actual coefficient band is near 775 nm, so use its fiber's group-delay and dispersion specification rather than treating a telecom value as validated. Increased guards lengthen the required total delay; other loop components reduce the remaining fiber required at a fixed target period. The [design-point note](paper_design_point.md) records the physical group-delay assumption and source.

Logical forgetting applies once per token/state update. Additional propagation, taps, passive laps and injection losses require separate calibrated compensation. Amplification restores scale but not information lost to accumulated noise. A single access tap cannot silently revisit a frame after a few nanoseconds in a roughly 0.74 μs ring.

### Historical later-lap reference

The [global-ring timing script](model_memory_schedule.py) and [earlier memory diagram](figures/06_head_layer_memory.svg) model a serial bank/local-target arrangement with later-lap prediction, write and query visits. They are retained to investigate frame phases and missed deadlines, **not to validate the new joint-error/dedicated-query design**. The earlier four-engine/eight-lane [system diagram](figures/15_four_die_layer_multiplexing.svg) is also superseded.

The general frame-readiness lesson remains valid. A frame at read-port phase \(\phi\), with period \(T_{\rm rt}\), cannot be used before its input and engine are ready at \(t_*\):

\[
t_{\rm start}=\phi+T_{\rm rt}\max\!\left(0,
\left\lceil\frac{t_*-\phi}{T_{\rm rt}}\right\rceil\right).
\]

A missed intended visit can cost a whole roundtrip. Guard sizing must include the final optical/electrical tail and encoder settling. A causal dedicated-query event schedule with measured or literature-supported component delays remains to be implemented; old script outputs must not be cited as its verification.

## Token schedule and logical operation counts

For one selected layer/head, the current protocol is:

1. Apply each bank's intended decay once; preserve the resulting old state.
2. Predict through bank 1, shuffle, and predict through bank 2; save k and the old bank-1 prediction.
3. Form the single final error against v.
4. Propagate its adjoint through old bank 2 and the inverse shuffle; generate both banks' coefficient gradients from the common old state.
5. Inject the matching gradients, preserving old taps until their final use.
6. Read q through the updated two-bank state on the dedicated query engine, then optical O and the electronic boundary.

Gradient generation and injection can pipeline by slot once the relevant completed error is available. Conservative query timing waits for complete updated frames; any earlier slotwise streaming must prove that each query slot sees the correct version. The [historical token diagram](figures/04_training_schedule.svg) predates the joint update and dedicated query hardware.

| Logical operation, per local cell and selected head/token | Interactions |
| --- | --- |
| Old-state forward prediction | \(2R\) DFGs |
| Shared error transform | \(R\) DFGs |
| Remaining adjoint transform | \(R\) DFGs |
| Coefficient convolutions | \(R\) cross-SFGs |
| Updated query, on separate reader | \(2R\) DFGs |
| Memory-interface frequency translations | None in direct pump-band storage |

These are logical interaction counts, not fabricated sections or serial clocks. The first bank's outgoing input gradient may be unused by this online objective; the common package retains its backward capability. All paths require calibrated power, timing and version alignment.

## Digital training

Train the full model on conventional silicon, then transfer fixed weights to the hypothetical optical device. The paper's performance target is inference, including its online optical TTT updates; training speed is not a proposed hardware advantage.

The simulation reference must evaluate each token's two-bank prediction, shared loss, adjoint and simultaneous-snapshot gradients, followed by the updated query. Differentiate the outer language-model objective through that recurrence and the actual optical FFN/readout operators. Heads can be evaluated independently once their layer input sequence is supplied, but the jointly adaptive banks cannot generally be evaluated as two independent sequence scans. Include the selected complex conjugations, passive normalization, structured matrix family, activation transfer and intensity detection.

### Preserved local-affine comparison

For the earlier standalone local-target recurrence with fixed partner/input sequence, the affine derivation above remains valid. Omitting forgetting within a chunk, its pre-update residuals obey

\[
e_t+\sum_{i<t}\eta_i(J_tJ_i^T)e_i=v_t-J_t\theta_0.
\]

This is a block lower-triangular system with generally \(K\times K\) interactions. In dense DeltaNet the corresponding interaction simplifies to \((k_t^Tk_i)I\); generic Hankel coefficient tying does not preserve that simplification. Even for that local comparison, affinity alone does not establish a fast kernel. [GatedDeltaNet chunk formulation](https://arxiv.org/html/2412.06464v1#S3.SS2)

For the selected joint update, the two banks' prediction/error operators depend on each other's adaptive state. The local-affine identity and old bank-ordered evaluation check therefore do not prove a global affine scan. Frozen-gradient mini-batches remain an optional different update law, as in [mini-batch TTT](https://arxiv.org/html/2407.04620v1#S2.SS4); any such choice must be matched in optical inference rather than silently substituting token-refreshed gradients.

## Alternatives and their consequences

| Update design | Affinity | Optical implication | Status |
| --- | --- | --- | --- |
| One shared loss, both banks adaptive | Jointly nonlinear | Old-state adjoint, inverse shuffle, held forward inputs | Selected |
| Separate local losses, fixed partners | Per-bank affine given its input sequence | Local target/subtraction at each bank; no inner backward shuffle | Historical comparison |
| Alternate banks under the shared loss | Only conditionally affine with the other fixed | Still depends on the other evolving bank | Optional different update law |
| Fixed-reference first-order model | Globally affine in adaptive deviations | Additional reference/adaptive paths | Alternative if global affinity is required |
| Store self-SFG seeds | Generally nonlinear even locally | Different differentiation and state interface | Outside baseline |
| Input-only additive writes | Affine | Simpler injection | Loses error-corrective online objective |

The current choice prioritizes a single consistent target for the complete structured memory. Its language-model quality, useful retention and performance under optical imperfections require digital simulation rather than an appeal to local matrix coverage alone.

## Validation and remaining simulation work

Run the numerical checks from the repository root:

```bash
python3 hankel_monarch_delta/check_update_algebra.py
```

The script requires NumPy and prints JSON. It checks the local coefficient gradient against finite differences, the affine identity, the earlier local-target model's token-streaming/bank-ordered equivalence, the product reader, shuffle inversion and fixed-partner coverage. It also demonstrates why alternating shared-loss gradients are not jointly affine and why generic cross-token kernels are not scalar identities. These are ideal signed-field algebra checks, not validation of the current complex joint-gradient recurrence, complete schedule or model quality. A current joint-gradient reference and finite-difference check remain to be added.

Run the [single-lattice checker](check_single_lattice.py) for the selected reader topology with its earlier R=32 default:

    python3 hankel_monarch_delta/check_single_lattice.py
    python3 hankel_monarch_delta/check_single_lattice.py --output hankel_monarch_delta/results/single_lattice_checks.json

It propagates complete raw waveforms through two Hankel readers, a wavelength-preserving shuffle and a nonzero interconnect delay. The adaptive pump stays present; the second DFG's reference burst supplies acceptance. It checks successive frames without resets, the \(1/64\) normalization and coefficient gradient. Counterexamples detect insufficient spacing, a nonblank phase-only reference and a finite reference tail. The [saved baseline results](results/single_lattice_checks.json) report the 640 ps schedule. These are ideal field-algebra checks, not a full recurrent update schedule or device simulation.

The same checks pass with `run_checks(Schedule(terms=64))`, giving seven cells, 128 taps and a 1280 ps frame. The [current design-point note](paper_design_point.md) gives the invocation. The two-reader test uses small spectral vectors; it validates the extended temporal schedule, not a 64-wavelength physical device or the chosen phase-ramp reference family.

Run the [earlier binary multiplier checker](check_binary_multiplier.py) for the retained dual-lattice engineering option:

    python3 hankel_monarch_delta/check_binary_multiplier.py

For that engineering option, the network is selected from design-time margin requirements. For example:

```bash
python3 hankel_monarch_delta/check_binary_multiplier.py --extra-plateau-fraction 0.4
python3 hankel_monarch_delta/check_binary_multiplier.py --margin-before-ps 50 --margin-after-ps 50
```

These request 40% extra total plateau duration or at least 50 ps on each edge, selecting 76 and 73 taps respectively. The report includes timing, coupler ratios and differential delays. Tap selection does not optimize a foundry layout; nearby larger networks may permit easier coupler ratios. The passive network fixes the plateau width after fabrication.

It checks the synthesized two-way network against a uniform-tap reference, margin-driven tap selection, continuous distinct complex frames without resets, and the physically normalized coefficient gradient. The two-bank test passes the complete unblanked selector waveform through a delayed shuffle and explicit receiving DFG pump window; a pump-leakage counterexample demonstrates why acceptance timing matters. The [saved results](results/binary_multiplier_checks.json) cover the 70-tap/400 ps candidate and other margin requests. This is an ideal envelope model; the designed margins, pulse bandwidth, filter settling and memory retention remain physical validation tasks.

Run the **historical local-target/later-lap** memory timing investigation with standard Python:

```bash
python3 hankel_monarch_delta/model_memory_schedule.py
python3 hankel_monarch_delta/model_memory_schedule.py --layer-guard-ns 0
python3 hankel_monarch_delta/model_memory_schedule.py --layer-guard-ns 0 --grad-latency-ns 400
```

The model emits JSON containing frame phases, prediction/write/query visits, digital head processing, layer readiness and optical replay horizons for its earlier topology. It asserts readiness, complete writes before queries and serialized engine service **within that model**. It does not establish the current 30.72 ns schedule. All times below are hypothetical inputs with \(L=2,H=3,R=4,\tau=1\) ns; remaining assumptions are listed in the script/output.

| Example | Ring period | Final digital output for one token | Maximum residual replay horizon | Maximum optical inter-bank \(z\) lifetime |
| --- | ---: | ---: | ---: | ---: |
| Default, 40 ns layer guards | 140 ns | 4,888 ns | 139 ns | 424 ns |
| No layer guards | 60 ns | 2,188 ns | 59 ns | 184 ns |
| No layer guards, 400 ns gradient latency | 60 ns | 6,508 ns | 419 ns | 544 ns |

Removing guards changes the loop period as well as the phase of the next frame. These are different loop layouts, not evidence that digital deadlines disappear. The final example requires seven laps from prediction to write. The large service time relative to a roundtrip motivates investigating shorter rings or delayed access ports before treating the global-ring layout as practical. Neither this one-token calculation nor the coefficient algebra check establishes sustained throughput or usable optical retention.

The paper is planned as a theory/simulation proposal, with **no new hardware experiments**. The following work therefore concerns numerical checks, device models and literature-supported assumptions; hardware validation remains outside this paper's scope.

| Remaining simulation or modeling task | Question it must answer |
| --- | --- |
| Complex joint-gradient reference | Do finite differences/autodifferentiation agree with both writers and the old-state adjoint? |
| Small language/sequence model | Does the chosen structured memory, per-head optical FFN and readout support useful modeling and deliberation? |
| Reference-family coverage | Does the chosen complex \(g_s e^{-is\phi_m}\) basis have full local span and usable conditioning? |
| MZI shuffle | Do the selected cyclic tree connections preserve vector timing and coherent forward/adjoint fidelity across all 64 wavelengths, with acceptable loss and calibration power? |
| DFG/SFG/filter model | How do pair-dependent gain/phase, unwanted idlers and imperfect cross-SFG isolation alter the gradient? |
| Causal event schedule | Can old reads, writes and dedicated query taps satisfy all dependencies and layer boundaries with real propagation? |
| Activation and electronic interface | How do saturable-absorption/SHG transfer, intensity readout and normalization affect trained performance? |
| Fiber and replay model | What retention, dispersion, noise, loss compensation and coherence are required for the approximately 150 m rings and temporary holds? |
| End-to-end resource budget | Do encoding, conversion, fixed-weight refresh, memory gain, stabilization and detection leave a useful inference advantage? |

The favorable coherent-summation benchmark in [OptimalSFG](../SFG_DFG/OptimalSFG.md) assumes aligned phases and specified powers. Signed gradients may cancel. Energy claims for this architecture must use the actual coefficient/key/error distributions and count the complete read/write schedule, source distribution, memory losses, and any gain.
