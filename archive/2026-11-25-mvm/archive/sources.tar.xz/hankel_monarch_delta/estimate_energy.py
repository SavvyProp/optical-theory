"""Conditional throughput and optimistic electrical energy budget for optical TTT.

Run from the repository root:
    python3 hankel_monarch_delta/estimate_energy.py
    python3 hankel_monarch_delta/estimate_energy.py --power-w 50 100 200
    python3 hankel_monarch_delta/estimate_energy.py --extra-pass-ns 240

Architecture: paper_design_point.md and cell_pathways.md, 17 November 2026.
Power inputs are optimistic DESIGN TARGETS, not measured component parameters.
This accounting model does not establish optical conversion, noise, precision,
loop retention, gain saturation, activation, or complete scheduling feasibility.
It does not include off-device training or facility cooling. Vocabulary readout
and sampling are unspecified in the repo and require an additional budget.

The main denominator credits useful structured matvecs, including the bank-2
adjoint. Native coefficient writing consumes energy but receives no extra MAC
credit in that denominator. The expanded optical-algebra count is separate.
One complex MAC conventionally costs 8 real operations (4 multiplications and
4 additions). The 2-op/MAC column is a normalization, NOT real-op throughput
when the operands are complex. No digital INT8/FP16 accuracy is implied.
"""

from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass
import json
import math


@dataclass(frozen=True)
class OptimisticBudget:
    # Total stored-field energy per coefficient/10 ps slot, before read taps.
    coefficient_energy_fj: float = 20.0
    # Includes fiber, taps, injection and routing; no extra tap loss is added.
    loop_loss_db: float = 1.0
    # Incremental added optical watts / electrical watts. Bias is separate.
    memory_incremental_efficiency: float = 0.20
    # All teeth together, averaged over an active burst, not per tooth power.
    reference_comb_on_mw: float = 20.0
    # Includes comb preparation and distribution; reference timing is ideal.
    reference_wall_to_delivered_efficiency: float = 0.20
    # A cycle here is a USE of each stored frame, approximately one model pass.
    fixed_reload_uses: float = 1000.0
    # Includes both quadratures and electrical fetch/encoding, per coefficient.
    load_pj_per_complex_coefficient: float = 1.0
    # These three values are allocations, not component-derived predictions.
    memory_gain_baseline_w: float = 15.0
    signal_gain_activation_writer_w: float = 20.0
    io_control_calibration_thermal_w: float = 30.0


def architecture(extra_pass_ns: float = 0.0) -> dict:
    layers, heads, lanes, k, r = 24, 16, 16, 64, 64
    fixed_maps, slot_s = 8, 10e-12
    visits = layers * heads
    frame_s = r * slot_s
    pass_s = (798.72 + extra_pass_ns) * 1e-9
    u = visits * lanes * k**2
    fixed = fixed_maps * 2 * u
    predict, query, adjoint = 2 * u, 2 * u, u
    useful = fixed + predict + query + adjoint
    fixed_readers = fixed_maps * 2 * lanes
    all_forward_readers = fixed_readers + 4 * lanes
    error_dfg = 2 * lanes
    # Bank 1's propagated input error is unused; its final backward DFG is off.
    backward_second_dfg = lanes
    reference_paths = all_forward_readers + error_dfg
    coefficient_paths = all_forward_readers + backward_second_dfg
    recurrent_coefficients = 2 * visits * lanes * r * (2 * k - 1)
    fixed_coefficients = fixed_maps * recurrent_coefficients
    return {
        "layers": layers,
        "heads": heads,
        "lanes": lanes,
        "data_wavelengths": k,
        "term_slots": r,
        "pass_ns": pass_s * 1e9,
        "passes_per_second": 1 / pass_s,
        "active_burst_duty_per_path": visits * frame_s / pass_s,
        "useful_mac_per_pass": {
            "fixed_maps": fixed,
            "recurrent_prediction": predict,
            "updated_query": query,
            "bank_2_adjoint": adjoint,
            "total": useful,
        },
        "useful_tmac_per_second": useful / pass_s / 1e12,
        "tops_at_2_ops_per_mac": 2 * useful / pass_s / 1e12,
        "real_tops_at_8_ops_per_complex_mac": 8 * useful / pass_s / 1e12,
        # 2R per effective matvec, then 3R extra for both writers. One writer's
        # H(b) conj(e) is already counted in the bank-2 adjoint and is shared.
        "expanded_native_mac_per_pass": 2 * r * useful + 3 * r * u,
        "coefficient_additions_per_pass": recurrent_coefficients,
        "reference_dfg_paths": reference_paths,
        "coefficient_dfg_paths": coefficient_paths,
        "active_dfg_paths_total": reference_paths + coefficient_paths,
        "sfg_writer_paths": 2 * lanes,
        "fixed_coefficients": fixed_coefficients,
        "adaptive_coefficients": recurrent_coefficients,
        "total_coefficients": fixed_coefficients + recurrent_coefficients,
        "hypothetical_memory_loops": fixed_readers + 2 * lanes,
    }


def budget_w(a: dict, b: OptimisticBudget) -> dict:
    """Assume all fixed/adaptive storage rings have the full pass period.

    Fixed storage topology is unselected; 256 fixed rings are an explicit
    scenario, additional to the specified 32 adaptive rings. A measured total
    gain-device electrical power must replace BOTH memory terms below, since
    adding it to the replenishment term would double-count its supply.
    """
    period_s = a["pass_ns"] * 1e-9
    lost_fraction = 1 - 10 ** (-b.loop_loss_db / 10)
    stored_j = a["total_coefficients"] * b.coefficient_energy_fj * 1e-15
    return {
        "memory_loss_replenishment": (
            stored_j / period_s * lost_fraction / b.memory_incremental_efficiency
        ),
        "reference_generation_and_distribution": (
            a["reference_dfg_paths"] * a["active_burst_duty_per_path"]
            * b.reference_comb_on_mw * 1e-3
            / b.reference_wall_to_delivered_efficiency
        ),
        "amortized_fixed_weight_reload": (
            a["fixed_coefficients"] * b.load_pj_per_complex_coefficient * 1e-12
            / (b.fixed_reload_uses * period_s)
        ),
        "memory_gain_baseline_allocation": b.memory_gain_baseline_w,
        "signal_gain_activation_writer_allocation": b.signal_gain_activation_writer_w,
        "io_control_calibration_thermal_allocation": b.io_control_calibration_thermal_w,
    }


def efficiency(a: dict, power_w: float) -> dict:
    mac_rate = a["useful_tmac_per_second"] * 1e12
    pj = power_w / mac_rate * 1e12
    return {
        "electrical_power_w": power_w,
        "microjoules_per_pass": power_w * a["pass_ns"] * 1e-3,
        "pj_per_useful_complex_mac": pj,
        "tops_per_w_at_2_ops_per_mac": a["tops_at_2_ops_per_mac"] / power_w,
        "real_tops_per_w_at_8_ops_per_complex_mac": (
            a["real_tops_at_8_ops_per_complex_mac"] / power_w
        ),
        "pj_per_real_mac_equivalent_for_complex_arithmetic": pj / 4,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--power-w", nargs="+", type=float, default=[50, 100, 200])
    parser.add_argument("--extra-pass-ns", type=float, default=0.0)
    parser.add_argument("--coefficient-energy-fj", type=float, default=20.0)
    parser.add_argument("--loop-loss-db", type=float, default=1.0)
    parser.add_argument("--reference-comb-on-mw", type=float, default=20.0)
    args = parser.parse_args()
    values = [args.extra_pass_ns, args.coefficient_energy_fj,
              args.loop_loss_db, args.reference_comb_on_mw, *args.power_w]
    if any(not math.isfinite(x) or x < 0 for x in values):
        parser.error("all inputs must be finite and nonnegative")
    if any(x == 0 for x in args.power_w):
        parser.error("system power must be positive")
    a = architecture(args.extra_pass_ns)
    b = OptimisticBudget(
        coefficient_energy_fj=args.coefficient_energy_fj,
        loop_loss_db=args.loop_loss_db,
        reference_comb_on_mw=args.reference_comb_on_mw,
    )
    parts = budget_w(a, b)
    result = {
        "status": "optimistic target budget; not a validated physical prediction",
        "architecture": a,
        "optimistic_assumptions": asdict(b),
        "optimistic_electrical_budget_w": parts,
        "optimistic_budget_metrics": efficiency(a, sum(parts.values())),
        "power_sensitivity": [efficiency(a, p) for p in args.power_w],
        "unresolved": [
            "precision/accuracy and analog retention lifetime",
            "consistent multitone DFG/SFG conversion, losses and signal gain",
            "gain bandwidth, saturation, noise and baseline electrical power",
            "activation energy, interface delays and maintenance occupancy",
            "fixed-weight storage layout and reference-comb generation",
            "embedding, vocabulary readout and autoregressive feedback",
        ],
        "sources": [
            "hankel_monarch_delta/paper_design_point.md",
            "hankel_monarch_delta/cell_pathways.md",
            "hankel_monarch_mlp/README.md",
            "https://arxiv.org/html/2410.08790v1",
            "https://pmc.ncbi.nlm.nih.gov/articles/PMC12696117/",
        ],
    }
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
