"""Audit the binary-only, shutterless full-Hankel reader proposal.

Run from the repository root::

    python3 hankel_monarch_delta/check_binary_multiplier.py
    python3 hankel_monarch_delta/check_binary_multiplier.py --output \
        hankel_monarch_delta/results/binary_multiplier_checks.json
    python3 hankel_monarch_delta/check_binary_multiplier.py \
        --extra-plateau-fraction 0.4
    python3 hankel_monarch_delta/check_binary_multiplier.py \
        --margin-before-ps 50 --margin-after-ps 50

The reference reader uses R=32 coefficient slots, two L=70-tap passive
filters, and frame starts P=40 slots apart. Each slot is 10 ps; the numerical
sample interval is 5 ps. Each filter uses eight nested two-path MZI cells,
five balanced and three with fixed unequal couplers. Their differential
delays are 1, 2, 2, 4, 10, 10, 20, 20 slots: 69 slots total. No three-way
splitter is used. Each filter receives a frame every 800 ps, without reset.
The 320 ps useful output starts 345 ps after its coefficient frame, centered
inside the 310..700 ps completed plateau. Its 390 ps duration is 21.875%
larger than the useful burst. The 80 ps inter-output guard allows
15 ps margin, 50 ps selector transition, and 15 ps margin.

There is NO output shutter in the simulated chain. Its actual selected field
contains partial sums and coherent mixtures during selector transitions. A
subsequent first DFG consumes this entire field, using an explicit coefficient
pump waveform that is zero outside each scheduled 320 ps compute burst. The
ideal B-band filter rejects unconverted A-band input. A pump-leakage example
demonstrates why removing the shutter does not remove the acceptance constraint.

These are discrete complex-field algebra and timing checks, not a physical
photonic simulation. Samples denote slot-filling comb envelopes; short pulses
with dark gaps do not become a continuous plateau by this calculation. The
5 ps sample grid and plateau margins do not validate pump edges, bandwidth,
dispersion, filter settling, losses, noise, phase stability, or 50 ps selector
settling. Confining the coefficient pump is an assumption, not a free shutter.
The reported cadence concerns the reader, not a full recurrent update schedule.

Only NumPy is required. JSON is printed; files are written only with --output.
"""

from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass, replace
import json
import math
from pathlib import Path

import numpy as np


@dataclass(frozen=True)
class Schedule:
    terms: int = 32
    taps: int = 70
    frame_period: int = 40
    output_offset: float = 34.5
    slot_ps: float = 10.0
    samples_per_slot: int = 2
    selector_transition_ps: float = 50.0
    selector_guard_before_ps: float = 15.0
    selector_guard_after_ps: float = 15.0

    @property
    def sample_ps(self) -> float:
        return self.slot_ps / self.samples_per_slot

    def sample_count(self, slots: float) -> int:
        value = slots * self.samples_per_slot
        if not np.isclose(value, round(value), atol=1e-10, rtol=0):
            raise ValueError("timing must lie on the simulated sample grid")
        return round(value)

    def ps_samples(self, ps: float) -> int:
        return self.sample_count(ps / self.slot_ps)

    def clean_plateau(self) -> tuple[int, int]:
        """Inclusive slot bounds, or [first*tau, (last+1)*tau) in time.

        Include the current frame in full, and exclude previous and next
        frames on its branch, which is reused every 2P slots. The bound is
        valid for sub-slot times when coefficient envelopes fill their slots.
        """
        period = 2 * self.frame_period
        first = max(self.terms - 1, self.taps + self.terms - 1 - period)
        last = min(self.taps - 1, period - 1)
        return first, last

    def validate(self) -> None:
        for name in ("terms", "taps", "frame_period", "samples_per_slot"):
            if not isinstance(getattr(self, name), int) or getattr(self, name) < 1:
                raise ValueError(f"{name} must be a positive integer")
        if self.terms > self.frame_period or self.terms > self.taps:
            raise ValueError("coefficient frames must fit the core period and FIR")
        if not np.isfinite(self.slot_ps) or self.slot_ps <= 0:
            raise ValueError("slot_ps must be finite and positive")
        if not np.isfinite(self.output_offset) or self.output_offset < 0:
            raise ValueError("output_offset must be finite and nonnegative")
        self.sample_count(self.output_offset)
        first, last = self.clean_plateau()
        if not (first <= self.output_offset
                and self.output_offset + self.terms <= last + 1):
            raise ValueError(
                f"acceptance [{self.output_offset}, "
                f"{self.output_offset + self.terms}) does not fit the "
                f"uncontaminated plateau [{first}, {last + 1})")
        allowances = (self.selector_transition_ps, self.selector_guard_before_ps,
                      self.selector_guard_after_ps)
        if any(not np.isfinite(value) or value < 0 for value in allowances):
            raise ValueError("selector allowances must be finite and nonnegative")
        for value in allowances:
            self.ps_samples(value)
        guard_ps = (self.frame_period - self.terms) * self.slot_ps
        if sum(allowances) > guard_ps + 1e-9:
            raise ValueError("selector transition plus margins exceeds inter-frame guard")
        # No shutter opening/closing edges are imposed. The coefficient pump
        # must instead stay inside the accepted plateau at the next DFG.


def design_schedule(terms: int = 32, slot_ps: float = 10.0,
                    extra_plateau_fraction: float = 0.2,
                    margin_before_ps: float = 0.0,
                    margin_after_ps: float = 0.0) -> Schedule:
    """Choose the FIR length and acceptance timing from explicit margins.

    The requested fraction enlarges the TOTAL completed plateau, not each
    side separately. Explicit leading/trailing minima can increase it further.
    Choose the smallest integer tap count meeting these bounds on the 5 ps
    default sample grid, then center remaining slack. The frame period also
    accommodates the selector budget and 2P>=L, retaining the full plateau.
    This minimizes taps for these constraints, not foundry area or cell count.
    """
    if not isinstance(terms, int) or terms < 1:
        raise ValueError("terms must be a positive integer")
    if not np.isfinite(slot_ps) or slot_ps <= 0:
        raise ValueError("slot_ps must be finite and positive")
    for value in (extra_plateau_fraction, margin_before_ps, margin_after_ps):
        if not np.isfinite(value) or value < 0:
            raise ValueError("plateau extension and margins must be finite and nonnegative")
    required_slots = max(terms * (1 + extra_plateau_fraction),
                         terms + (margin_before_ps + margin_after_ps) / slot_ps)
    taps = terms - 1 + math.ceil(required_slots - 1e-12)
    base = Schedule(terms=terms, slot_ps=slot_ps)
    # A requested asymmetric edge may fall between simulation samples. Add
    # one tap if needed rather than silently reducing either requested margin.
    while True:
        first_ps = (terms - 1) * slot_ps
        extra_ps = (taps - 2 * terms + 1) * slot_ps
        earliest = math.ceil((first_ps + margin_before_ps) / base.sample_ps - 1e-12)
        latest = math.floor((first_ps + extra_ps - margin_after_ps) / base.sample_ps + 1e-12)
        if earliest <= latest:
            break
        taps += 1
    output_sample = (earliest + latest) // 2
    selector_budget = (base.selector_transition_ps + base.selector_guard_before_ps
                       + base.selector_guard_after_ps)
    period = max(terms + math.ceil(selector_budget / slot_ps - 1e-12),
                 math.ceil(taps / 2))
    result = replace(base, taps=taps, frame_period=period,
                     output_offset=output_sample / base.samples_per_slot)
    result.validate()
    return result


def complex_normal(rng: np.random.Generator, shape: tuple[int, ...]) -> np.ndarray:
    return (rng.normal(size=shape) + 1j * rng.normal(size=shape)) / np.sqrt(2)


def max_error(left: np.ndarray, right: np.ndarray) -> float:
    return float(np.max(np.abs(left - right)))


def binary_filter(signal: np.ndarray, taps: int,
                  samples_per_slot: int = 1,
                  cells: list | None = None) -> np.ndarray:
    """Actual matched-coupler two-path graph, including the 70-tap network.

    Each cell splits fields by sqrt(p), sqrt(1-p), then projects them through
    a matching output coupler. Its selected-port transfer is therefore
    p I + (1-p) D**delay F, with F a nested passive long-arm network. Optical
    port phases are assumed calibrated. There is no unnormalized ideal adder.

    Every positive integer length is supported. Even factors use
    H_(2m)(D)=H2(D) H_m(D**2); odd primes use
    H_n(D)=I/n + [(n-1)/n] D H_(n-1)(D). Integer factorization additionally
    uses H_(ab)(D)=H_a(D) H_b(D**a). In particular, 70 becomes
    H2(D) H5(D**2) H7(D**10), avoiding a highly unequal 1:34 splitter.
    Power-of-two lengths reduce to ordinary balanced binary cascades.
    """
    if not isinstance(taps, int) or taps < 1:
        raise ValueError("taps must be a positive integer")

    def cell(field: np.ndarray, delay_slots: int, short_power: float = 0.5,
             long_filter=None) -> np.ndarray:
        if cells is not None:
            cells.append({
                "differential_delay_slots": delay_slots,
                "short_arm_coupler_power_fraction": short_power,
                "long_arm_coupler_power_fraction": 1 - short_power,
                "matching_input_and_output_couplers": True,
                "two_path_cell": True,
            })
        short = np.sqrt(short_power) * field
        long = np.sqrt(1 - short_power) * field
        delay = delay_slots * samples_per_slot
        delayed = np.zeros_like(long)
        delayed[delay:] = long[:-delay]
        if long_filter is not None:
            delayed = long_filter(delayed)
        return np.sqrt(short_power) * short + np.sqrt(1 - short_power) * delayed

    def network(field: np.ndarray, length: int, spacing: int) -> np.ndarray:
        if length == 1:
            return field.copy()
        if length % 2 == 0:
            return network(cell(field, spacing), length // 2, 2 * spacing)
        for factor in range(3, math.isqrt(length) + 1, 2):
            if length % factor == 0:
                return network(network(field, factor, spacing), length // factor,
                               spacing * factor)
        return cell(field, spacing, 1 / length,
                    lambda long: network(long, length - 1, spacing))

    return network(signal, taps, 1)


def uniform_filter_reference(signal: np.ndarray, taps: int,
                             samples_per_slot: int) -> np.ndarray:
    """Independent direct boxcar reference, not the physical implementation."""
    output = signal / taps
    for tap in range(1, taps):
        delay = tap * samples_per_slot
        output[delay:] += signal[:-delay] / taps
    return output


def network_description(taps: int) -> dict:
    cells = []
    binary_filter(np.zeros((2 * taps, 1), dtype=complex), taps, cells=cells)
    delays = [cell["differential_delay_slots"] for cell in cells]
    balanced = sum(np.isclose(cell["short_arm_coupler_power_fraction"], 0.5)
                   for cell in cells)
    assert sum(delays) == taps - 1
    return {
        "cell_count": len(cells),
        "balanced_cells": int(balanced),
        "unequal_cells": len(cells) - int(balanced),
        "two_port_coupler_count": 2 * len(cells),
        "three_way_splitters": 0,
        "differential_delays_slots": delays,
        "total_differential_delay_slots": sum(delays),
        "maximum_individual_delay_slots": max(delays, default=0),
        "cell_trace": cells,
    }


def simulate_dual(terms: np.ndarray, schedule: Schedule,
                  start_samples: int = 0) -> tuple[np.ndarray, np.ndarray]:
    """Return observed windows and both free-running branch outputs.

    terms has shape (frames, coefficient_slots, ...comb/lane dimensions).
    Each coefficient envelope fills its slot. Observing final windows does
    not imply that this function's full branch outputs are optically gated.
    """
    schedule.validate()
    assert terms.shape[1] == schedule.terms
    frames = terms.shape[0]
    period = schedule.sample_count(schedule.frame_period)
    burst = schedule.sample_count(schedule.terms)
    horizon = start_samples + (frames - 1) * period + schedule.sample_count(
        schedule.taps + schedule.terms)
    routed = np.zeros((2, horizon, *terms.shape[2:]), dtype=complex)
    for frame in range(frames):
        first = start_samples + frame * period
        routed[frame % 2, first:first + burst] = np.repeat(
            terms[frame], schedule.samples_per_slot, axis=0)
    filtered = np.array([binary_filter(branch, schedule.taps,
                                      schedule.samples_per_slot) for branch in routed])
    return observe_windows(filtered, frames, schedule, start_samples), filtered


def observe_windows(filtered: np.ndarray, frames: int, schedule: Schedule,
                    start_samples: int = 0) -> np.ndarray:
    """Measure useful output intervals after all optical propagation."""
    result = []
    for frame in range(frames):
        first = start_samples + schedule.sample_count(
            frame * schedule.frame_period + schedule.output_offset)
        result.append(filtered[frame % 2, first:first + schedule.sample_count(schedule.terms)])
    return np.array(result)


def routing_weights(horizon: int, frames: int, schedule: Schedule,
                    first_window_sample: int) -> np.ndarray:
    """Two-port selector with nonzero coherent mixtures during its transition.

    Stable ports have a calibrated unit field transmission. During switching,
    arbitrary smooth phase motion accompanies the mixing. At every sample
    the squared magnitudes of the two weights sum to one: no hidden shutter.
    """
    weights = np.zeros((horizon, 2), dtype=complex)
    weights[:, 0] = 1
    period = schedule.sample_count(schedule.frame_period)
    burst = schedule.sample_count(schedule.terms)
    margin = schedule.ps_samples(schedule.selector_guard_before_ps)
    transition = schedule.ps_samples(schedule.selector_transition_ps)
    for frame in range(frames - 1):
        first = first_window_sample + frame * period + burst + margin
        last = first + transition
        old, new = frame % 2, (frame + 1) % 2
        weights[first:] = 0
        weights[last:, new] = 1
        if transition:
            progress = (np.arange(transition) + 0.5) / transition
            angle = progress * np.pi / 2
            weights[first:last, old] = np.cos(angle) * np.exp(0.7j * np.sin(np.pi * progress))
            weights[first:last, new] = np.sin(angle) * np.exp(-0.4j * np.sin(np.pi * progress))
    assert max_error(np.sum(abs(weights) ** 2, axis=1), np.ones(horizon)) < 1e-14
    return weights


def binary_and_stream_checks(rng: np.random.Generator,
                             schedule: Schedule) -> dict:
    spacing = schedule.samples_per_slot
    impulse = np.zeros((2 * schedule.taps * spacing, 3), dtype=complex)
    impulse[0] = np.array([1, 1j, 1 - 2j])
    expected_impulse = np.zeros_like(impulse)
    expected_impulse[:schedule.taps * spacing:spacing] = impulse[0] / schedule.taps
    impulse_error = max_error(binary_filter(impulse, schedule.taps, spacing), expected_impulse)
    assert impulse_error < 1e-14
    # This independent reference does not use the splitter graph or its
    # factorization; it directly convolves an arbitrary time-varying field.
    arbitrary = complex_normal(rng, (4 * schedule.taps * spacing, 3))
    reference_error = max_error(binary_filter(arbitrary, schedule.taps, spacing),
                                uniform_filter_reference(arbitrary, schedule.taps, spacing))
    assert reference_error < 1e-12

    frames, channels = 11, 5
    terms = complex_normal(rng, (frames, schedule.terms, channels))
    selected, filtered = simulate_dual(terms, schedule)
    expected = terms.sum(axis=1) / schedule.taps
    selected_error = max_error(selected, expected[:, None, :])
    first, last = schedule.clean_plateau()
    plateau_error = 0.0
    for frame in range(frames):
        origin = schedule.sample_count(frame * schedule.frame_period)
        plateau_error = max(plateau_error, max_error(
            filtered[frame % 2, origin + first * spacing:origin + (last + 1) * spacing],
            expected[frame]))
    assert max(selected_error, plateau_error) < 1e-12
    return {
        "binary_cascade_vs_boxcar_max_abs_error": impulse_error,
        "physical_two_path_graph_vs_direct_convolution_max_abs_error": reference_error,
        "continuous_stream_frames": frames,
        "complex_comb_channels": channels,
        "selected_windows_max_abs_error": selected_error,
        "full_clean_plateaus_max_abs_error": plateau_error,
        "branch_resets": 0,
    }


def hankel(coefficients: np.ndarray) -> np.ndarray:
    size = (coefficients.size + 1) // 2
    assert coefficients.size == 2 * size - 1
    indices = np.arange(size)
    return coefficients[indices[:, None] + indices[None, :]]


def paired_terms(adaptive: np.ndarray, fixed: np.ndarray,
                 signal: np.ndarray) -> np.ndarray:
    """Two ideal DFGs: H(b) conjugate(H(a) conjugate(x))."""
    return np.array([hankel(b) @ (hankel(a.conj()) @ signal)
                     for a, b in zip(adaptive, fixed)])


def wavelength_shuffle(signal: np.ndarray) -> np.ndarray:
    """Permute spatial lanes independently at each wavelength."""
    result = np.empty_like(signal)
    for lane in range(signal.shape[0]):
        for line in range(signal.shape[1]):
            result[(lane + line) % signal.shape[0], line] = signal[lane, line]
    return result


def shutterless_two_bank_check(rng: np.random.Generator, schedule: Schedule) -> dict:
    frames, lanes, lines = 7, 3, 4
    shape = (2, lanes, schedule.terms, 2 * lines - 1)
    adaptive = complex_normal(rng, shape) / 3
    fixed = complex_normal(rng, shape) / 3
    queries = complex_normal(rng, (frames, lanes, lines))
    first_terms = np.array([
        np.stack([paired_terms(adaptive[0, lane], fixed[0, lane], query[lane])
                  for lane in range(lanes)], axis=1)
        for query in queries
    ])
    _, first_filtered = simulate_dual(first_terms, schedule)
    first_expected = first_terms.sum(axis=1) / schedule.taps
    output_weights = routing_weights(first_filtered.shape[1], frames, schedule,
                                     schedule.sample_count(schedule.output_offset))
    # Crucially, this is the COMPLETE selector waveform, including partial
    # sums and mixed-branch transitions. Nothing blanks or slices it.
    first_raw = np.einsum("tb,btij->tij", output_weights, first_filtered)
    link_delay_slots = 13
    link_delay = schedule.sample_count(link_delay_slots)
    second_start = schedule.sample_count(schedule.output_offset) + link_delay
    horizon = (second_start + schedule.sample_count((frames - 1) * schedule.frame_period
                                                   + schedule.taps + schedule.terms))
    received = np.zeros((horizon, lanes, lines), dtype=complex)
    shuffled_raw = np.array([wavelength_shuffle(sample) for sample in first_raw])
    received[link_delay:link_delay + len(shuffled_raw)] = shuffled_raw

    # Explicit time-dependent coefficient pump. Its support, rather than an
    # upstream shutter, determines when DFG1 can generate the desired B band.
    a_pump = np.zeros((horizon, lanes, 2 * lines - 1), dtype=complex)
    b_reference = np.empty_like(a_pump)
    acceptance = np.zeros(horizon, dtype=bool)
    period = schedule.sample_count(schedule.frame_period)
    burst = schedule.sample_count(schedule.terms)
    for time in range(horizon):
        slot = ((time - second_start) // schedule.samples_per_slot) % schedule.terms
        b_reference[time] = fixed[1, :, slot]
    for frame in range(frames):
        start = second_start + frame * period
        acceptance[start:start + burst] = True
        for slot in range(schedule.terms):
            low = start + slot * schedule.samples_per_slot
            a_pump[low:low + schedule.samples_per_slot] = adaptive[1, :, slot]
            b_reference[low:low + schedule.samples_per_slot] = fixed[1, :, slot]
    assert np.max(abs(a_pump[~acceptance])) == 0

    input_weights = routing_weights(horizon, frames, schedule, second_start)

    def propagate(pump: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        b_band = np.zeros_like(received)
        core = np.zeros_like(received)
        # Evaluate every time sample, including all unwanted upstream light.
        # b_band is the ideal B-band projection after DFG1: unconverted A-band
        # light is not included and must be rejected by the physical filter.
        for time in range(horizon):
            for lane in range(lanes):
                b_band[time, lane] = hankel(pump[time, lane]) @ received[time, lane].conj()
                core[time, lane] = hankel(b_reference[time, lane]) @ b_band[time, lane].conj()
        routed = np.einsum("tb,tij->btij", input_weights, core)
        filtered = np.array([binary_filter(branch, schedule.taps,
                                          schedule.samples_per_slot) for branch in routed])
        return observe_windows(filtered, frames, schedule, second_start), b_band, core

    final, b_band, core = propagate(a_pump)
    final_expected = []
    for middle in first_expected:
        shuffled = wavelength_shuffle(middle)
        final_expected.append(np.array([
            paired_terms(adaptive[1, lane], fixed[1, lane], shuffled[lane]).sum(axis=0)
            / schedule.taps for lane in range(lanes)
        ]))
    error = max_error(final, np.array(final_expected)[:, None, :, :])
    assert error < 1e-12
    raw_outside = float(np.linalg.norm(received[~acceptance]))
    generated_outside = float(np.linalg.norm(b_band[~acceptance]))
    assert raw_outside > 1e-3 and generated_outside == 0
    assert np.max(abs(core[~acceptance])) == 0
    mixed = (abs(output_weights[:, 0]) > 1e-6) & (abs(output_weights[:, 1]) > 1e-6)
    mixed_energy = float(np.sum(abs(first_raw[mixed]) ** 2))
    assert np.count_nonzero(mixed) > 0 and mixed_energy > 1e-6

    # Negative control: a pump tail during a selector transition is converted
    # and enters the FIR. It corrupts later useful outputs even though no
    # upstream valid window was changed. This prevents the test from silently
    # assuming that arbitrary unwanted light is harmless.
    leaked_pump = a_pump.copy()
    guard = period - burst
    leak_start = second_start + burst + guard // 2
    leak_end = min(leak_start + 2, second_start + period)
    assert not np.any(acceptance[leak_start:leak_end])
    leaked_pump[leak_start:leak_end] = 0.1 * adaptive[1, :, 0]
    contaminated, leaked_b, _ = propagate(leaked_pump)
    contamination = max_error(contaminated, final)
    generated_leak = float(np.linalg.norm(leaked_b[~acceptance]))
    assert contamination > 1e-8 and generated_leak > 1e-6
    return {
        "frames": frames,
        "lanes": lanes,
        "comb_lines_per_lane": lines,
        "sample_interval_ps": schedule.sample_ps,
        "fixed_interconnect_delay_slots": link_delay_slots,
        "second_core_first_launch_ps": second_start * schedule.sample_ps,
        "second_bank_first_accepted_ps": (second_start + schedule.sample_count(
            schedule.output_offset)) * schedule.sample_ps,
        "no_output_shutter": True,
        "entire_raw_selector_waveform_consumed_by_next_DFG": True,
        "raw_received_field_l2_outside_pump_acceptance": raw_outside,
        "selector_mixture_sample_count": int(np.count_nonzero(mixed)),
        "selector_mixture_sampled_field_energy": mixed_energy,
        "generated_B_band_l2_outside_pump_acceptance": generated_outside,
        "two_bank_normalized_product_max_abs_error": error,
        "normalization_per_bank": 1 / schedule.taps,
        "leaking_pump_negative_control": {
            "pump_leak_field_scale": 0.1,
            "duration_ps": (leak_end - leak_start) * schedule.sample_ps,
            "generated_B_band_l2_outside_acceptance": generated_leak,
            "useful_output_contamination_max_abs": contamination,
            "contamination_detected": True,
        },
        "assumptions": [
            "coefficient pump has exactly confined support; no pump edges or tails modeled",
            "ideal intermediate B-band filter rejects unconverted A-band light",
            "flat slot-filling comb envelopes and calibrated selector port phases",
        ],
        "claim": "reader pipeline only; not recurrent token latency",
    }


def normalized_complex_gradient_check(rng: np.random.Generator,
                                      normalization: float) -> dict:
    terms, lines = 3, 4
    shape = (terms, 2 * lines - 1)
    adaptive = complex_normal(rng, shape) / 3
    fixed = complex_normal(rng, shape) / 3
    key, target = complex_normal(rng, (2, lines))

    def residual(a: np.ndarray) -> np.ndarray:
        return target - normalization * paired_terms(a, fixed, key).sum(axis=0)

    def loss(a: np.ndarray) -> float:
        error = residual(a)
        return float(np.vdot(error, error).real / 2)

    error = residual(adaptive)
    negative_gradient = normalization * np.array([
        np.convolve(key, hankel(b) @ error.conj()) for b in fixed
    ])
    epsilon = 1e-5
    numerical = np.empty_like(adaptive)
    for index in np.ndindex(shape):
        real_direction = np.zeros_like(adaptive)
        real_direction[index] = epsilon
        real = (loss(adaptive + real_direction) - loss(adaptive - real_direction)) / (2 * epsilon)
        imag_direction = 1j * real_direction
        imag = (loss(adaptive + imag_direction) - loss(adaptive - imag_direction)) / (2 * epsilon)
        numerical[index] = real + 1j * imag
    absolute = max_error(numerical, -negative_gradient)
    relative = float(np.linalg.norm(numerical + negative_gradient)
                     / max(np.linalg.norm(negative_gradient), 1e-15))
    assert absolute < 1e-8 and relative < 1e-5
    return {
        "loss": "0.5 * ||v - c sum_m H(b_m) H(conj(a_m)) k||^2",
        "field_normalization_c": normalization,
        "negative_gradient": "c * convolution(k, H(b_m) conj(e))",
        "finite_difference_max_abs_error": absolute,
        "finite_difference_relative_l2_error": relative,
    }


def timing_report(schedule: Schedule) -> dict:
    first, last = schedule.clean_plateau()
    return {
        "two_path_network": network_description(schedule.taps),
        "same_filter_period_ps": 2 * schedule.frame_period * schedule.slot_ps,
        "core_burst_ps": schedule.terms * schedule.slot_ps,
        "inter_frame_guard_ps": (schedule.frame_period - schedule.terms) * schedule.slot_ps,
        "clean_plateau_interval_ps": [first * schedule.slot_ps, (last + 1) * schedule.slot_ps],
        "accepted_output_interval_ps": [schedule.output_offset * schedule.slot_ps,
                                        (schedule.output_offset + schedule.terms) * schedule.slot_ps],
        "acceptance_margin_before_ps": (schedule.output_offset - first) * schedule.slot_ps,
        "acceptance_margin_after_ps": (last + 1 - schedule.output_offset - schedule.terms) * schedule.slot_ps,
        "clean_plateau_duration_ps": (last + 1 - first) * schedule.slot_ps,
        "clean_plateau_extra_fraction": (last + 1 - first) / schedule.terms - 1,
        "reader_result_cadence_ps": schedule.frame_period * schedule.slot_ps,
        "core_utilization": schedule.terms / schedule.frame_period,
        "full_standalone_plateau_preserved": 2 * schedule.frame_period >= schedule.taps,
        "selector_and_pump_timing_are_unverified_device_requirements": True,
    }


def comparison_checks(rng: np.random.Generator) -> dict:
    baseline = Schedule()
    previous = replace(baseline, taps=64, output_offset=31.5)
    no_guard = replace(previous, frame_period=32)
    try:
        no_guard.validate()
    except ValueError as error:
        guard_reason = str(error)
    else:
        raise AssertionError("zero guard accepted finite selector transition")
    faster = replace(baseline, frame_period=38,
                     selector_guard_before_ps=5, selector_guard_after_ps=5)
    faster.validate()
    wider = replace(baseline, taps=128, frame_period=52, output_offset=64)
    wider.validate()
    too_short = replace(wider, frame_period=38)
    try:
        too_short.validate()
    except ValueError as error:
        plateau_reason = str(error)
    else:
        raise AssertionError("contaminated 128-tap schedule accepted")
    witness = np.zeros((256, 1), dtype=complex)
    witness[:32] = 1
    witness[76:108] = 2
    contaminated = binary_filter(witness, 128)
    contamination = float(abs(contaminated[107, 0] - 64 / 128))
    assert contamination > 0.1
    return {
        "64_taps_previous_compact_design": {
            "configuration": asdict(previous),
            "timing": timing_report(previous),
            "stream_checks": binary_and_stream_checks(rng, previous),
            "shutterless_chain": shutterless_two_bank_check(rng, previous),
            "meets_twenty_percent_extra_plateau": False,
        },
        "64_taps_zero_selector_guard": {
            "frame_period_ps": 320,
            "rejected": True,
            "reason": guard_reason,
        },
        "70_taps_tighter_selector_margins": {
            "configuration": asdict(faster),
            "timing": timing_report(faster),
            "stream_checks": binary_and_stream_checks(rng, faster),
            "shutterless_chain": shutterless_two_bank_check(rng, faster),
        },
        "128_taps_more_arrival_margin": {
            "configuration": asdict(wider),
            "timing": timing_report(wider),
            "stream_checks": binary_and_stream_checks(rng, wider),
            "shutterless_chain": shutterless_two_bank_check(rng, wider),
            "margin_does_not_validate_arbitrary_pump_edges": True,
        },
        "128_taps_insufficient_clean_window": {
            "frame_period_ps": 380,
            "clean_plateau_inclusive_slots": list(too_short.clean_plateau()),
            "rejected": True,
            "reason": plateau_reason,
            "explicit_old_frame_contamination_abs": contamination,
        },
    }


def margin_design_checks(rng: np.random.Generator) -> dict:
    specifications = [
        ("twenty_percent", 0.2, 0, 0, 70),
        ("forty_percent", 0.4, 0, 0, 76),
        ("fifty_ps_each_edge", 0.2, 50, 50, 73),
        ("asymmetric_edges", 0.2, 60, 20, 71),
        ("asymmetric_minima_between_samples", 0.2, 51, 49, 74),
        ("zero_margin_mathematical_reference", 0.0, 0, 0, 63),
    ]
    profiles = {}
    for name, fraction, before, after, expected_taps in specifications:
        schedule = design_schedule(extra_plateau_fraction=fraction,
                                   margin_before_ps=before, margin_after_ps=after)
        assert schedule.taps == expected_taps
        timing = timing_report(schedule)
        assert timing["clean_plateau_duration_ps"] >= (
            schedule.terms * schedule.slot_ps * (1 + fraction) - 1e-9)
        assert timing["acceptance_margin_before_ps"] >= before
        assert timing["acceptance_margin_after_ps"] >= after
        profiles[name] = {
            "requested_extra_fraction": fraction,
            "requested_before_ps": before,
            "requested_after_ps": after,
            "configuration": asdict(schedule),
            "timing": timing,
            "network_and_stream_checks": binary_and_stream_checks(rng, schedule),
        }
    assert profiles["twenty_percent"]["timing"]["two_path_network"]["cell_count"] == 8
    assert profiles["twenty_percent"]["timing"]["two_path_network"]["balanced_cells"] == 5
    assert profiles["twenty_percent"]["timing"]["two_path_network"]["unequal_cells"] == 3
    assert sorted(profiles["twenty_percent"]["timing"]["two_path_network"][
        "differential_delays_slots"]) == [1, 2, 2, 4, 10, 10, 20, 20]
    assert (64 - 32 + 1) * 10 < 1.2 * 320 <= (70 - 32 + 1) * 10
    return profiles


def run_checks(schedule: Schedule | None = None,
               requested_margins: dict | None = None) -> dict:
    rng = np.random.default_rng(20261115)
    if schedule is None:
        schedule = design_schedule()
    schedule.validate()
    report = {
        "status": "passed",
        "scope": "discrete ideal complex-field algebra and timing; no physical device validation",
        "configuration": asdict(schedule),
        "requested_margins": requested_margins or {
            "extra_plateau_fraction": 0.2, "margin_before_ps": 0, "margin_after_ps": 0},
        "timing": timing_report(schedule),
        "binary_and_continuous_stream": binary_and_stream_checks(rng, schedule),
        "shutterless_two_bank_pipeline": shutterless_two_bank_check(rng, schedule),
        "normalized_coefficient_gradient": normalized_complex_gradient_check(rng, 1 / schedule.taps),
        "schedule_comparisons": comparison_checks(rng),
        "margin_design_profiles": margin_design_checks(rng),
    }
    small = Schedule(terms=4, taps=8, frame_period=6, output_offset=3.5,
                     selector_transition_ps=10,
                     selector_guard_before_ps=5, selector_guard_after_ps=5)
    small.validate()
    report["small_geometry"] = {
        "configuration": asdict(small),
        "binary_and_continuous_stream": binary_and_stream_checks(rng, small),
        "shutterless_chain": shutterless_two_bank_check(rng, small),
    }
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="also write the JSON report to this path")
    parser.add_argument("--extra-plateau-fraction", type=float, default=0.2,
                        help="minimum total plateau extension over the useful burst (default: 0.2)")
    parser.add_argument("--margin-before-ps", type=float, default=0.0,
                        help="minimum completed-plateau margin before pump acceptance")
    parser.add_argument("--margin-after-ps", type=float, default=0.0,
                        help="minimum completed-plateau margin after pump acceptance")
    args = parser.parse_args()
    requested = {"extra_plateau_fraction": args.extra_plateau_fraction,
                 "margin_before_ps": args.margin_before_ps,
                 "margin_after_ps": args.margin_after_ps}
    try:
        schedule = design_schedule(**requested)
    except ValueError as error:
        parser.error(str(error))
    report = json.dumps(run_checks(schedule, requested), indent=2)
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(report + "\n", encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
