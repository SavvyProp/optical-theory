"""Explore a conservative head/layer schedule for recirculating coefficients.

Run from the repository root::

    python3 hankel_monarch_delta/model_memory_schedule.py
    python3 hankel_monarch_delta/model_memory_schedule.py --layer-guard-ns 0

One global ring is replicated across the parallel spatial lanes. Its frame
order is layer, head, then bank 1 / bank 2. Each bank frame contains R temporal
coefficient slots. A head guard follows each bank-2 frame, and a layer guard
follows each layer, including the last layer before the ring wraps.

Only one bank is serviced at a time: prediction, residual/gradient latency,
aligned write, then a query on a later circulation. Other frames bypass the
processor, including while the serviced bank waits for its next arrival.
The engine is conservatively reserved through these waits. The reference
schedule replays the residual and key to launch each gradient slot just in
time for its write. ``gradient_ready_ns`` is the earliest possible FIRST
gradient-slot injection, not completion of a buffered gradient frame. A
gradient buffer is optional if updates are generated early instead. Token
inputs, residuals, and the shuffled interbank output z require optical
retention/replay over their scheduled use intervals.

The digital engine consumes completed heads serially while the optical
engine services later heads. A full-layer digital tail follows the final
head accumulation. Encoding/settling is charged only between layers; the
first layer's inputs are already available at time zero. The final digital
tail produces the reported token output, without a next-layer encoding.

This is a one-token causal timing calculation, not an optical simulation,
loss/noise model, optimized schedule, or sustained token-rate prediction.
All times are in ns. Output is JSON; no third-party packages are needed.
"""

from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass
import json
import math


@dataclass(frozen=True)
class Config:
    layers: int = 2
    heads: int = 3
    r_slots: int = 4
    slot_ns: float = 1.0
    head_guard_ns: float = 2.0
    layer_guard_ns: float = 40.0
    pred_latency_ns: float = 2.0
    grad_latency_ns: float = 3.0
    write_offset_ns: float = 1.0
    commit_latency_ns: float = 1.0
    switch_latency_ns: float = 1.0
    query_latency_ns: float = 2.0
    shuffle_latency_ns: float = 1.0
    digital_per_head_ns: float = 8.0
    digital_tail_ns: float = 20.0
    encode_ns: float = 3.0
    settle_ns: float = 1.0

    @property
    def frame_ns(self) -> float:
        return self.r_slots * self.slot_ns

    @property
    def round_trip_ns(self) -> float:
        return self.layers * (
            self.heads * (2 * self.frame_ns + self.head_guard_ns)
            + self.layer_guard_ns
        )

    def validate(self) -> None:
        for name in ("layers", "heads", "r_slots"):
            value = getattr(self, name)
            if not isinstance(value, int) or value < 1:
                raise ValueError(f"{name} must be a positive integer")
        for name, value in asdict(self).items():
            if name.endswith("_ns"):
                if not math.isfinite(value) or value < 0:
                    raise ValueError(f"{name} must be finite and nonnegative")
        if self.slot_ns == 0:
            raise ValueError("slot_ns must be strictly positive")
        if not math.isfinite(self.round_trip_ns):
            raise ValueError("the resulting ring round-trip time must be finite")
        if self.write_offset_ns >= self.round_trip_ns:
            raise ValueError("write_offset_ns must be less than one round trip")


def first_arrival(phase: float, ready: float, period: float) -> tuple[float, int]:
    """Return the first nonnegative-lap arrival at or after readiness."""
    lap = max(0, math.ceil((ready - phase) / period))
    return phase + lap * period, lap


def check_not_before(later: float, earlier: float) -> None:
    # Only tolerate floating-point roundoff, not a configurable timing margin.
    tolerance = 16 * math.ulp(max(abs(later), abs(earlier), 1.0))
    assert later + tolerance >= earlier, (later, earlier)


def frame_phases(config: Config) -> list[dict]:
    phases = []
    phase = 0.0
    for layer in range(1, config.layers + 1):
        for head in range(1, config.heads + 1):
            for bank in (1, 2):
                phases.append({
                    "layer": layer, "head": head, "bank": bank,
                    "first_slot_phase_ns": phase,
                })
                phase += config.frame_ns
            phase += config.head_guard_ns
        phase += config.layer_guard_ns
    assert math.isclose(phase, config.round_trip_ns, rel_tol=1e-12)
    return phases


def service_bank(config: Config, frame: dict, ready: float) -> dict:
    period = config.round_trip_ns
    duration = config.frame_ns
    offset = config.write_offset_ns
    phase = frame["first_slot_phase_ns"]
    prediction, prediction_lap = first_arrival(phase, ready, period)
    residual_ready = prediction + duration + config.pred_latency_ns
    # Earliest first injection if residual/key replay starts immediately.
    # Scheduled replay can instead produce the successive gradient slots
    # just in time for the selected write-pass frame.
    gradient_ready = residual_ready + config.grad_latency_ns

    # The write port lies `offset` ns downstream of the read port. Do not
    # overwrite during the prediction pass, even if an extreme configuration
    # would permit same-pass arrival at that port.
    write_laps = max(1, math.ceil(
        (duration + config.pred_latency_ns + config.grad_latency_ns - offset)
        / period
    ))
    write = prediction + write_laps * period + offset
    write_complete = write + duration + config.commit_latency_ns

    # Query only once the complete updated frame has committed and switching
    # has settled. q is measured in read-port laps after the write-pass lap,
    # not from the physical write-port time itself.
    query_laps = max(1, math.ceil(
        (offset + duration + config.commit_latency_ns + config.switch_latency_ns)
        / period
    ))
    query = prediction + (write_laps + query_laps) * period
    output = query + duration + config.query_latency_ns

    check_not_before(prediction, ready)
    if prediction_lap:
        assert prediction - period < ready
    check_not_before(write, gradient_ready)
    check_not_before(query, write_complete + config.switch_latency_ns)
    check_not_before(output, query + duration)
    assert write_laps >= 1 and query_laps >= 1
    return {
        **frame,
        "input_ready_ns": ready,
        "prediction_start_ns": prediction,
        "prediction_start_lap": prediction_lap,
        "prediction_end_ns": prediction + duration,
        "residual_ready_ns": residual_ready,
        "gradient_ready_ns": gradient_ready,
        "write_start_ns": write,
        "write_end_ns": write + duration,
        "write_complete_ns": write_complete,
        "write_laps_after_prediction": write_laps,
        "query_start_ns": query,
        "query_laps_after_write_pass": query_laps,
        "output_ready_ns": output,
        "wait_for_prediction_ns": prediction - ready,
        "wait_for_write_after_gradient_ns": write - gradient_ready,
        "wait_for_query_after_commit_and_switch_ns": (
            query - write_complete - config.switch_latency_ns
        ),
    }


def simulate(config: Config) -> dict:
    config.validate()
    phases = frame_phases(config)
    bank_events = []
    digital_events = []
    layer_events = []
    layer_input_ready = 0.0
    layer_ready = 0.0
    digital_free = 0.0
    phase_index = 0
    for layer in range(1, config.layers + 1):
        head_ready = layer_ready
        last_output = layer_ready
        for head in range(1, config.heads + 1):
            first_bank = service_bank(config, phases[phase_index], head_ready)
            phase_index += 1
            second_bank = service_bank(
                config, phases[phase_index],
                first_bank["output_ready_ns"]
                + max(config.shuffle_latency_ns, config.switch_latency_ns),
            )
            phase_index += 1
            bank_events.extend((first_bank, second_bank))
            last_output = second_bank["output_ready_ns"]
            digital_start = max(last_output, digital_free)
            digital_free = digital_start + config.digital_per_head_ns
            digital_events.append({
                "layer": layer, "head": head,
                "head_output_ready_ns": last_output,
                "digital_start_ns": digital_start,
                "digital_done_ns": digital_free,
            })
            head_ready = last_output + config.switch_latency_ns

        tail_start = max(last_output, digital_free)
        layer_output = tail_start + config.digital_tail_ns
        next_input = (
            layer_output + config.encode_ns + config.settle_ns
            if layer < config.layers else None
        )
        next_service = (
            max(next_input, last_output + config.switch_latency_ns)
            if next_input is not None else None
        )
        layer_events.append({
            "layer": layer,
            "first_head_input_ready_ns": layer_input_ready,
            "first_head_service_ready_ns": layer_ready,
            "last_head_output_ready_ns": last_output,
            "digital_tail_start_ns": tail_start,
            "layer_output_ready_ns": layer_output,
            "next_layer_input_ready_ns": next_input,
            "next_layer_service_ready_ns": next_service,
        })
        digital_free = layer_output
        if next_input is not None:
            layer_input_ready = next_input
            layer_ready = next_service

    # The conservative reservation extends through each output, rather than
    # counting unoccupied laps as opportunities for other banks' operations.
    for previous, following in zip(bank_events, bank_events[1:]):
        check_not_before(following["prediction_start_ns"],
                         previous["output_ready_ns"] + config.switch_latency_ns)
    for previous, following in zip(digital_events, digital_events[1:]):
        check_not_before(following["digital_start_ns"],
                         previous["digital_done_ns"])

    first_prediction = bank_events[0]["prediction_start_ns"]
    final_optical = bank_events[-1]["output_ready_ns"]
    final_output = layer_events[-1]["layer_output_ready_ns"]
    wait_fields = (
        "wait_for_prediction_ns", "wait_for_write_after_gradient_ns",
        "wait_for_query_after_commit_and_switch_ns",
    )
    return {
        "units": "ns",
        "model": "one token; serialized optical bank service; overlapping digital heads",
        "limitations": [
            "Illustrative input latencies, not measured hardware performance.",
            "No loss, dispersion, phase drift, amplifier noise, or pump-power model.",
            "Requires optical key/residual replay for just-in-time gradient slots; "
            "a full gradient-frame buffer is optional for early generation.",
            "gradient_ready_ns is the earliest FIRST gradient injection, not full-frame completion.",
            "Requires retention/replay of the shuffled interbank vector z through bank-2 service.",
            "Bypassed frames retain their state; physical loss is not algorithmic forgetting.",
            "All spatial lanes run in parallel with matching frame timing.",
            "Reported completion times are latency, not sustained token throughput.",
            "Replay horizons cover this token only; inter-token memory lifetimes are not modeled.",
        ],
        "parameters": asdict(config),
        "summary": {
            "frame_duration_ns": config.frame_ns,
            "ring_round_trip_ns": config.round_trip_ns,
            "frames_per_ring_per_spatial_lane": len(phases),
            "coefficient_slots_per_ring_per_spatial_lane": len(phases) * config.r_slots,
            "guard_duration_per_ring_ns": config.layers * (
                config.heads * config.head_guard_ns + config.layer_guard_ns
            ),
            "first_prediction_start_ns": first_prediction,
            "last_optical_head_output_ns": final_optical,
            "first_to_last_optical_service_ns": final_optical - first_prediction,
            "final_token_output_ns": final_output,
            "max_wait_ns": max(event[field] for event in bank_events for field in wait_fields),
            "max_write_laps_after_prediction": max(
                event["write_laps_after_prediction"] for event in bank_events
            ),
            "max_query_laps_after_write_pass": max(
                event["query_laps_after_write_pass"] for event in bank_events
            ),
            "max_residual_replay_horizon_ns": max(
                event["write_end_ns"] - event["residual_ready_ns"]
                for event in bank_events
            ),
            "max_interbank_z_lifetime_ns": max(
                bank_events[index + 1]["output_ready_ns"]
                - bank_events[index]["output_ready_ns"]
                for index in range(0, len(bank_events), 2)
            ),
        },
        "frame_phases": phases,
        "bank_events": bank_events,
        "digital_head_events": digital_events,
        "layer_events": layer_events,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    defaults = Config()
    for name in ("layers", "heads", "r_slots"):
        parser.add_argument("--" + name.replace("_", "-"), type=int,
                            default=getattr(defaults, name))
    for name, value in asdict(defaults).items():
        if name.endswith("_ns"):
            parser.add_argument("--" + name.replace("_", "-"), type=float, default=value)
    args = parser.parse_args()
    try:
        result = simulate(Config(**vars(args)))
    except ValueError as error:
        parser.error(str(error))
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
