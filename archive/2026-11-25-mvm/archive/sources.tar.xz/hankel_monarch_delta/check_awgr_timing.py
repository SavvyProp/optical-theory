"""Audit the R=64 reader's timing with an ideal cyclic AWGR envelope model.

Run: python3 hankel_monarch_delta/check_awgr_timing.py --output PATH

This is a timing feasibility/counterexample calculation, NOT a fabricated
AWGR model. It propagates complete, consecutive complex waveforms through
the accumulator and a multiport delayed-arm router, including transient
leakage to undesired ports. All 64 carrier labels are represented, but their
responses repeat every eight channels: broadband dispersion, static phase
errors, measured aperture weights, loss and noise are explicitly omitted.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

if __package__:
    from .check_binary_multiplier import binary_filter, uniform_filter_reference
    from .check_single_lattice import Schedule, run_checks
else:
    from check_binary_multiplier import binary_filter, uniform_filter_reference
    from check_single_lattice import Schedule, run_checks


N, K, R = 8, 64, 64
SLOT_PS, DT_PS = 10.0, 1.25
SAMPLES_PER_SLOT = 8


def extended_lattice(field: np.ndarray, taps: int) -> np.ndarray:
    """128+q uniform taps, q a power of two: seven balanced + one unequal cell.

    H_(128+q)(D) = H_q(D) [p I + (1-p) D^q H_(128/q)(D^q)],
    p=q/(128+q). The nested branch contains the original larger-delay cells.
    The unequal join uses two matched couplers with power fractions p,1-p.
    """
    if taps == 128:
        return binary_filter(field, taps, SAMPLES_PER_SLOT)
    q = taps - 128
    if q < 1 or q & (q - 1) or 128 % q:
        raise ValueError("extension must be a power of two dividing 128")
    common = binary_filter(field, q, SAMPLES_PER_SLOT)
    p = q / taps
    short = np.sqrt(p) * common
    long = binary_filter(np.sqrt(1 - p) * common, 128 // q,
                         q * SAMPLES_PER_SLOT)
    delay = q * SAMPLES_PER_SLOT
    result = np.sqrt(p) * short
    result[delay:] += np.sqrt(1 - p) * long[:-delay]
    return result


def cyclic_awgr(field: np.ndarray, arms: int, common_samples: int = 0,
                max_skew_samples: int = 0) -> np.ndarray:
    """Ideal equally weighted array, arm increment 1/800 GHz = 1.25 ps.

    h[q,j,k](t) = sum_r exp(2 pi i r (j+k-q)/8) delta(t-r*dt)/arms.
    Arms must be a multiple of 8, giving exact cyclic routing at carrier
    centers in steady state. Larger arrays here are synthetic test cases.
    """
    if arms < N or arms % N:
        raise ValueError("arms must be a positive multiple of eight")
    projected = np.fft.ifft(field, axis=1)
    branches = np.zeros_like(projected)
    for arm in range(arms):
        residue = arm % N
        phase = np.exp(2j * np.pi * residue * np.arange(K) / N)
        count = len(field) - arm
        branches[arm:, residue] += projected[:count, residue] * phase * N / arms
    routed = np.fft.fft(branches, axis=1)
    delayed = np.zeros_like(routed)
    for lane in range(N):
        shift = common_samples + round(max_skew_samples * lane / (N - 1))
        if shift:
            delayed[shift:, lane] = routed[:-shift, lane]
        else:
            delayed[:, lane] = routed[:, lane]
    return delayed


def shuffle(values: np.ndarray) -> np.ndarray:
    result = np.empty_like(values)
    for line in range(K):
        result[..., :, line] = np.roll(values[..., :, line], line % N, axis=-1)
    return result


def experiment(taps: int, arms: int, acceptance_ps: float,
               common_ps: float = 0, skew_ps: float = 0) -> dict:
    rng = np.random.default_rng(20261117)
    frames = 4
    terms = (rng.normal(size=(frames, R, N, K))
             + 1j * rng.normal(size=(frames, R, N, K))) / np.sqrt(2)
    period = taps * SAMPLES_PER_SLOT
    burst = R * SAMPLES_PER_SLOT
    common = round(common_ps / DT_PS)
    horizon = frames * period + taps * SAMPLES_PER_SLOT + common + 512
    incoming = np.zeros((horizon, N, K), complex)
    for frame in range(frames):
        incoming[frame * period:frame * period + burst] = np.repeat(
            terms[frame], SAMPLES_PER_SLOT, axis=0)
    raw = extended_lattice(incoming, taps)
    received = cyclic_awgr(raw, arms, common, round(skew_ps / DT_PS))
    expected = shuffle(terms.sum(axis=1) / taps)
    left = round((acceptance_ps + common_ps) / DT_PS)
    windows = np.stack([received[f * period + left:f * period + left + burst]
                        for f in range(frames)])
    error = windows - expected[:, None]
    max_error = float(np.max(abs(error)))
    relative_rms = float(np.sqrt(np.mean(abs(error) ** 2)
                                / np.mean(abs(expected) ** 2)))
    spread = (arms - 1) * DT_PS + skew_ps
    clean = [(R - 1) * SLOT_PS + spread + common_ps,
             taps * SLOT_PS + common_ps]
    return {
        "taps": taps, "frame_ps": taps * SLOT_PS,
        "synthetic_awgr_arms": arms, "spread_plus_skew_ps": spread,
        "common_propagation_ps": common_ps,
        "clean_received_interval_ps": clean,
        "clean_received_duration_ps": clean[1] - clean[0],
        "accepted_interval_ps": [acceptance_ps + common_ps,
                                 acceptance_ps + common_ps + R * SLOT_PS],
        "max_absolute_field_error": max_error,
        "relative_rms_field_error": relative_rms,
        "acceptance_is_clean": max_error < 1e-12,
    }


def check() -> dict:
    baseline = run_checks(Schedule(terms=64))
    rng = np.random.default_rng(17)
    arbitrary = rng.normal(size=(3000, 3)) + 1j * rng.normal(size=(3000, 3))
    extension_errors = {}
    for taps in (128, 132, 136, 144):
        error = float(np.max(abs(extended_lattice(arbitrary, taps)
                                - uniform_filter_reference(arbitrary, taps,
                                                           SAMPLES_PER_SLOT))))
        assert error < 1e-12
        extension_errors[str(taps)] = error
    cases = {
        "128_taps_8_arms": (128, 8, 640, 0, 0),
        "128_taps_40_arms_original_window": (128, 40, 640, 0, 0),
        "128_taps_40_arms_shifted_window": (128, 40, 680, 0, 0),
        "132_taps_40_arms": (132, 40, 680, 0, 0),
        "132_taps_40_arms_common_delay": (132, 40, 680, 130, 0),
        "132_taps_40_arms_extra_5ps_skew": (132, 40, 680, 0, 5),
        "136_taps_40_arms_extra_5ps_skew": (136, 40, 700, 0, 5),
    }
    results = {name: experiment(*args) for name, args in cases.items()}
    expected_pass = {"128_taps_8_arms", "132_taps_40_arms",
                     "132_taps_40_arms_common_delay",
                     "136_taps_40_arms_extra_5ps_skew"}
    for name, result in results.items():
        assert result["acceptance_is_clean"] == (name in expected_pass), name
    return {
        "status": "passed, including expected failure controls",
        "scope": "ideal envelope feasibility; not physical AWGR validation",
        "current_R64_existing_reader_checks": baseline["status"],
        "lattice_implementation_vs_direct_FIR_max_error": extension_errors,
        "sample_ps": DT_PS, "lanes": N, "carrier_labels": K,
        "carrier_response_repeats_every": N,
        "synthetic_router_cases": results,
        "omitted": ["measured complex AWGR response", "unequal aperture weights",
                    "broadband dispersion", "binary-lattice phase errors",
                    "finite pump edges and jitter", "loss and noise",
                    "full system feedback and memory schedule"],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = json.dumps(check(), indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(report + "\n")
    print(report)


if __name__ == "__main__":
    main()
