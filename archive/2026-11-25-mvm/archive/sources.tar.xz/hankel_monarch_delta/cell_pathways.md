# Optical pathways in one multifunction recurrent Hankel cell

Working circuit specification · 17 November 2026

One cell serves one spatial lane of one Monarch bank. It receives a coherent input vector from the forward direction and an output-error vector from the backward direction. Its forward reader, adjoint reader and coefficient writer supply the three local operations of the two-bank TTT update. The same package serves either bank; bank 1 needs additional alignment delay while it waits for the final error to propagate through bank 2 and the inverse shuffle.

The current setting is \(K=R=64\): 64 data frequencies, 127 coefficient frequencies, and 64 coefficient slots of 10 ps. Each multifunction cell contains **four DFG sections, one cross-SFG section, and two temporal accumulators**. The [current design point](paper_design_point.md) distinguishes these prediction/update cells from **separate physical query readers**. The [component floorplan](photonic_component.md) retains an earlier read-only 32-slot example, not a layout of this complete cell.

## Field conventions and ports

Call the input/output data band A, the intermediate DFG data band B, and the coefficient/pump band P. These **band names** differ from adaptive coefficient \(a_m\) and fixed partner \(b_m\).

For data near 1550 nm and sum-frequency pumps near 775 nm, **both A and B are near 1550 nm; P is near 775 nm**. A/B must remain distinguishable through carrier offsets, polarization or spatial modes as required by filtering and phase matching. A generic 1550 nm bandpass alone does not separate degenerate desired and residual fields. Pumps occupy \(\Omega_s=\omega_A+\omega_B+s\Delta\); cross-SFG writes into that same P-band grid.

For \(H(h)_{ji}=h_{i+j}\), an ideal DFG computes

\[
\mathcal D(h,x)=H(h)\overline{x}.
\]

After calibrating conversion phases, the local reader and adjoint are

\[
F_a(x)=c\sum_{m=0}^{63}H(b_m)H(\overline{a_m})x,
\qquad
F_a^\dagger(e)=c\sum_{m=0}^{63}H(a_m)H(\overline{b_m})e,
\qquad c=1/128.
\]

For local input \(x\) and supplied output-error field \(e\),

\[
r_m=\mathcal D(b_m,e)=H(b_m)\overline e,
\qquad g_m=c\,x*r_m,
\qquad a_m^+=a_m^-+\eta g_m.
\]

Here \(*\) is full linear convolution over frequency indices. The writer receives the negative loss-gradient with respect to the local output; \(e\) is a target-minus-prediction residual only at the final bank. Both the coefficient update and propagated error use the same pre-update state \(a^-\). Conversion, tap and injection gains belong in the calibration.

## Forward pathway

```text
64-line input x in A
  → pump combiner with old coefficient a_m^- in P
  → forward DFG 1 → filter selecting exactly 64 B-band lines
  → pump combiner with timed reference b_m in P
  → forward DFG 2 → filter selecting exactly 64 A-band lines
  → coherent 128-tap temporal lattice
  → completed local output F_a^-(x)
```

The lattice has seven split–delay–recombine stages, fourteen couplers, and differential delays of 10, 20, 40, 80, 160, 320 and 640 ps. Its transfer is

\[
\prod_{j=0}^{6}\frac{1+D^{2^j}}2
=\frac1{128}\sum_{r=0}^{127}D^r.
\]

The reference supplies a 640 ps active burst followed by 640 ps of darkness. The useful output is constant over 640–1280 ps relative to burst launch, plus common propagation latency. The raw output has transients outside that interval. Filters remove unwanted intermediate lines before further nonlinear interactions.

Prediction uses \(x=k\) in bank 1 and the shuffled **old-state prediction** \(z^-=PB_1^-k\) in bank 2. A separate read-only two-bank engine later computes \(B_2^+PB_1^+q\). It taps the same updated coefficient frames; it has no independent adaptive memory.

## Final target subtraction

Only the output of bank 2 is compared with the target:

```text
held target v → amplitude-matching MZI → relative-phase trim
  → subtraction combiner ← tap of complete two-bank prediction
  → e_2 = v − B_2^- P B_1^- k
```

If the prediction tap delivers \(t\widehat v\), supply \(tv\) to a balanced subtraction combiner. Its selected port carries \(t[v-\widehat v]/\sqrt2\), up to a calibrated common phase. Combining unscaled \(v\) with \(t\widehat v\) changes the objective. The target MZI is passive amplitude control, not an amplifier; calibrate its phase response and combiner port phases. Wavelength-dependent mismatch requires spectral compensation. A tunable subtraction MZI can alternatively combine amplitude-ratio and subtraction control. [Beam-splitter field relations, Lvovsky, section 4.8](https://users.physics.ox.ac.uk/~lvovsky/673/notes/phys673notes.pdf#page=56)

Bank 1 receives \(e_1=P^\dagger(B_2^-)^\dagger e_2\) through the backward path. It has **no separate learned target**. The subtraction circuit therefore belongs at the two-bank boundary rather than inside every reusable cell.

There is **no extra temporal summation filter after subtraction**. The completed prediction plateau supplies a constant residual for the write burst. A later write visit requires explicit residual hold/replay; a running-sum filter is not such a buffer.

## Backward pathway and shared error transform

```text
supplied output error e in A
  → pump combiner with delayed reference b_m in P
  → error DFG → filter selecting exactly 64 B-band lines
  → r_m = H(b_m) conjugate(e)
       ├─ tap to coefficient writer
       └─ pump combiner with matching OLD coefficient a_m^- in P
            → backward DFG → filter selecting exactly 64 A-band lines
            → coherent 128-tap temporal lattice
            → propagated input error (F_a^-)† e
```

The second DFG conjugates \(r_m\), giving

\[
\mathcal D(a_m^-,r_m)=H(a_m^-)H(\overline{b_m})e.
\]

The backward lattice sums these terms with normalization \(c\). This implements the complex adjoint without treating a single DFG as an unconjugated matvec. Account for splitter attenuation and phase when sharing \(r_m\) between backward reader and writer, and supply valid-window/reference timing for each.

Route bank 2's completed backward result through the inverse spatial shuffle to bank 1. The selected [MZI interleaver shuffle](mzi_shuffle.md) uses reciprocal tree connectivity, with backward access and phase calibration specified to implement the required adjoint; reversing an uncalibrated complex router alone gives its transpose. Each bank's old coefficients must remain available at its backward tap, even if another copy or later slots are being written. There is no activation between the adaptive banks; adding one would require its derivative in this path.

## Gradient writer pathway

```text
r_m in B
  → cross-SFG with delayed or held local input x in A
  → filter retaining all 127 gradient lines in P
  → write-amplitude and phase control, including ηc
  → injection combiner ← matching delayed old coefficient a_m^-
  → updated coefficient a_m^+
```

For bank 1 hold \(x=k\); for bank 2 hold \(x=z^-=PB_1^-k\), not a query result or an activation recomputed with updated bank-1 coefficients. Both writers thereby implement gradients of the same pre-update loss.

Keep all 127 gradient lines and preserve slot index \(m\); **do not sum gradients across slots**. The two temporal lattices belong to the forward and backward matvecs, not the writer. Isolate cross-SFG from self-SFG and other mixing products. Reject residual P-band reference pump before cross-SFG, because it could pass the final P filter and enter memory as an unwanted write.

The write transfer includes \(\eta c\), conversion efficiencies and injection-coupler factors. If the supplied error is \(E_e=s e\), its scalar is conjugated by the error DFG, so writer calibration includes \(\overline s\). Amplitude and phase controls are both needed. Enable the writer only for the matching update window, never for transients, unrelated memory frames or query reads.

## Persistent coefficient pathway and alignment

```text
P-band coefficient memory
  → loss compensation and phase / dispersion control
  → retention α, once per intended token update
  → old-state prediction tap
  → sufficient persistent bypass delay
  → old-state backward tap
  → gradient injection into matching old-state slots
  → delay and updated-state tap feeding dedicated query reader
  → remaining recirculating memory
```

This specifies access order, not a completed fiber layout. Position taps using actual forward, shuffle, subtraction, backward and writer delays. Persistent coefficients bypass nonlinear compute sections; only tapped copies supply pumps. Apply logical retention once, not again at injection or every passive lap. Compensate tap, propagation and injection-coupler loss separately. See [coefficient-loop gain and retention](coefficient_loop_gain.md).

In the ideal envelope model, relative to bank-1 prediction launch:

| Interval | Dependency |
| --- | --- |
| 0–0.64 ns | Bank-1 prediction; preserve its input and old coefficients. |
| 0.64–1.28 ns | Bank-2 prediction; preserve its old-state input \(z^-\). |
| 1.28–1.92 ns | Final error drives bank-2 backward and gradient-write bursts. |
| 1.92–2.56 ns | Inverse-shuffled backward result drives bank-1 backward/write bursts. |
| After full frame writes and actual path delays | Updated banks can supply the dedicated query reader. |

These intervals omit common propagation and calibration margins. Bank 1 needs a longer read-to-write hold than the earlier standalone local-target cell. The illustrative system schedule places each query **5.12 ns after its prediction**, giving 2.56 ns beyond ideal full-frame readiness. This is a scheduling allowance, not a measured device margin. The [design-point note](paper_design_point.md) gives the conditional 30.72 ns/layer calculation with two input FFN maps and the memory-loop estimate.

Fixed delays align already-held vectors and reference bursts; they do not stretch a short pulse into a 640 ps plateau. A single ring read tap cannot give arbitrary few-nanosecond reaccess to a roughly 0.74 μs memory loop. Separated taps and dedicated query hardware are part of the proposed implementation.

## Components and cell boundary

| Resource | Multifunction prediction/update cell |
| --- | --- |
| Nonlinear sections | Two forward DFGs, shared error DFG, backward DFG, cross-SFG |
| Spectral selection | After each DFG and SFG; retain 64 data or 127 coefficient lines as appropriate |
| Temporal accumulation | Two seven-stage lattices: forward and backward; none in the writer |
| Error interface | Complex output-error input and propagated input-error output |
| Alignment | Input, reference, old coefficient and error delays; bank 1 includes bank-2 backward wait |
| Memory access | Old-state prediction/backward taps, injection, updated query tap, gain and retention |
| Two-bank boundary | One matched target/subtraction circuit per final output lane; MZI interleaver shuffle with calibrated forward and inverse/adjoint access |
| Separate query reader | Two DFGs and one forward lattice per lane/bank; no writer or independent state |

For 8 lanes and two banks, the recurrent engine has **16 multifunction cells plus 16 dedicated read-only query readers**, supporting a 512-coordinate head. The chosen 48 mm² planning assumption gives **768 mm² for the prediction/update cells alone**; it is not an established area for the simpler reader. If all six fixed FFN/projection maps have dedicated engines, they add 96 read-only local readers, for 128 local cell/reader instances overall. These engines process 16 logical heads and 24 layers using distinct coefficient frames.

Internal predictions, errors, shuffle outputs and updates remain complex coherent fields. The selected electronic boundary follows the optical output projection: detect per-channel intensities and sum over heads with the residual. Train the square-law interface explicitly. Intensity-only final detection does not remove coherent subtraction and adjoint propagation inside TTT.
