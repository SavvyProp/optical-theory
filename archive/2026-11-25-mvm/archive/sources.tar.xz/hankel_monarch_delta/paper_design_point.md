# Optical TTT architecture and paper design point

Current proposal · 17 November 2026

The selected approximately **310M-parameter model** uses **24 logical layers, 16 independent heads per layer, a 512-wide residual stream, and one physically simultaneous head**. Each head has eight spatial fibers and its own two-layer optical input FFN, separate key/query/value projections, a two-bank adaptive memory, and an optical output projection. The prediction/update core and the query reader are **separate physical hardware** that access the same adaptive coefficient state. The count uses complex learned factors, distinct layer/head weights and a tied real 16,000-token embedding/readout.

The paper is a theory and simulation study, with no proposed in-house hardware experiments. Train the model on conventional silicon and transfer its fixed weights to optical storage. The performance focus is inference, including the sequence-dependent TTT updates. The fixed MLP implementation uses [recirculating Hankel/Monarch weights](../hankel_monarch_mlp/README.md), replacing the earlier hypothetical MLP and approximately 10M resident-weight ceiling.

The illustrative schedule gives **30.72 ns per layer and 737.28 ns for 24 layers**, before additional physical and electronic delays. Matching a coefficient-memory roundtrip to that full pass requires approximately **150 m of fiber per loop**. These are conditional design calculations, not measured device performance. This eight-fiber, two-FFN-stage design supersedes the previous sixteen-fiber, four-stage budget.

## Model dimensions and representation

| Quantity | Current value | Meaning |
| --- | ---: | --- |
| Logical layers, \(L\) | 24 | Reuse the same optical engines in time |
| Logical heads per layer, \(H\) | 16 | Distinct fast states and, in the current count, distinct fixed weights |
| Physically simultaneous heads | 1 | Sixteen successive head batches per layer |
| Spatial fibers or lanes per head per bank, \(n\) | 8 | Lanes operate in parallel |
| Data wavelengths per local cell, \(K\) | 64 | Head width \(nK=512\) |
| Residual width, \(d\) | 512 | Separate from the sum of all head widths |
| Adaptive banks per head | 2 | Fixed MZI-interleaver shuffle between banks; no intervening core activation selected |
| Input FFN depth | 2 | Two 512 × 512 maps, each followed by activation |
| FFN sharing across heads | None | Each logical head has its own FFN |
| Other fixed maps per head | 4 | Separate K, Q, V and O maps, each 512 × 512 |
| Learned factor type | Complex | Two real scalars per factor entry |
| Vocabulary and embedding/readout | 16,000; tied real matrix | \(16{,}000\times512=8{,}192{,}000\) parameters, counted once |
| Local Hankel-pair terms, \(R\) | 64 | Time slots inside each cell, not 64 physical cells |
| Coefficient channels per slot | 127 | \(2K-1\) |
| Slot duration, \(\tau\) | 10 ps | Ideal waveform assumption, not a specified comb spacing |
| Data / coefficient center wavelengths | About 1550 / 775 nm in the original budget | The [Hankel cell simulation grids](../simulation_notes/hankel_cell.md) compare wavelength selection near 803 nm with polarization selection near 775 nm for the coefficients. |

The earlier drawing shows three FFN map/activation pairs and needs revision to the now-selected **two-stage FFN**. Its query-path HM2 multiplier remains dedicated hardware. Earlier sixteen-lane MZI illustrations are also historical pending an eight-lane redraw.

Each 512 × 512 map has two banks of eight local 64 × 64 factors, joined by a specified permutation. This uses

\[
2nK^2=65{,}536
\]

factor entries instead of \(512^2=262{,}144\) entries for an unconstrained dense matrix. It is a structured map, not arbitrary dense coverage. Because \(n=8\ne K=64\), the balanced square-Monarch construction does not apply unchanged. The selected integrated MZI interleaver trees implement the unbalanced permutation explicitly. The backward route must implement its inverse connectivity with the calibrated complex adjoint response.

The selected shuffle is the wavelength-preserving cyclic route \((j,i)\mapsto((j+i)\bmod8,i)\). Each source/destination lane pair has eight intermediate routes. Each corresponding 64 × 64 spatial block of the complete map has rank at most eight. This is a concrete expressivity constraint to reproduce in training, not a dense-map parameterization.

Use eight three-level MZI demultiplexer trees, fixed waveguide connections and eight reverse multiplexer trees. Leaf \(r=i\bmod8\) carries eight wavelengths and connects input lane \(j\) to output lane \((j+r)\bmod8\). The elementary baseline has **112 MZIs, 224 couplers and 64 group connections per shuffle**, with six MZIs traversed by each signal. An illustrative 100 GHz grid gives stage delays of 5, 2.5 and 1.25 ps and is commensurate with the 10 ps accumulator slots; it does not specify the vector throughput. The [MZI shuffle design](mzi_shuffle.md) gives the phase settings, area scenarios, backward-path requirements and energy comparison. This replaces the free-space grating shuffle. Lower routing energy remains a hypothesis to test against optical loss and phase-stabilization power.

Locally, use the calibrated reader convention

\[
F_a(x)=c\sum_{m=0}^{R-1}H(b_m)H(\overline{a_m})x,
\qquad H(h)_{ji}=h_{i+j},\qquad c=1/128.
\]

Arbitrary complex local matrices are required in both fixed and adaptive banks. In the ideal flat-response model the phase-ramp and fixed-phase, amplitude-coded references both span these matrices. The latter admit an explicit construction using at most two active reference teeth per slot. Their usable gain depends on the matrix, per-slot pump power and actual device response. The counts below use \(R=64\). [Phase-ramp power comparison](../simulation_notes/matmul_power_budget.md#comparing-candidates-at-the-next-bank-input) · [Amplitude-coded construction and coverage proof](../simulation_notes/matmul_power_budget.md#fixed-phase-amplitude-references-for-arbitrary-local-matrices)

## One head and the shared final error

For layer input \(x_{\ell,t}\), head \(h\) computes

\[
f_{\ell h,t}=\phi_2(W_{2,\ell h}\phi_1(W_{1,\ell h}x_{\ell,t})),
\]
\[
k=W_Kf,\qquad q=W_Qf,\qquad v=W_Vf.
\]

Each \(W\) here is a fixed structured optical map. K, Q and V have separate weights and can run in parallel. Normalization and any small gains/gates must be specified consistently in training; their parameters are additional to the map counts.

Let \(B_1^-\) and \(B_2^-\) denote the two block-diagonal adaptive banks before this token's update, after any explicitly selected decay. Let \(\Pi\) be the fixed shuffle. The prediction and loss are

\[
z=\Pi B_1^-k,\qquad \widehat v=B_2^-z,\qquad
 e_2=v-\widehat v,\qquad \mathcal L=\tfrac12\|e_2\|^2.
\]

Propagate the final error to bank 1 through the old bank 2:

\[
e_1=\Pi^\dagger(B_2^-)^\dagger e_2.
\]

The second-bank writer uses \((z,e_2)\); the first-bank writer uses \((k,e_1)\). Both gradients refer to the **same pre-update forward pass**. In particular, save the old bank-1 prediction for the bank-2 gradient and preserve old bank-2 coefficients until its backward read is complete. Replacing either with an updated result changes the algorithm.

For one local cell, with \(e\) defined as target minus prediction and \(*\) the full convolution over frequency index,

\[
\Delta a_m=\eta c\,x*\left[H(b_m)\overline e\right],
\qquad a_m^+=a_m^-+\Delta a_m.
\]

Keep every one of the 127 coefficient channels and its term slot \(m\). There is **no temporal gradient accumulator** across slots: those slots are different stored coefficients. The multifunction cell's forward and backward sums each have their own temporal accumulator. The [cell pathways](cell_pathways.md) specify the conjugations and coherent write interfaces.

The dedicated query reader then evaluates

\[
y=B_2^+\Pi B_1^+q,\qquad o_h=W_{O,h}y.
\]

It reads the updated state for that same layer/head, rather than learning another independent state. Its physical duplication costs readers, taps and pump power, but does not double the learned model parameters or persistent memory count.

The proposed layer interface detects each projected head output and sums electrically:

\[
x_{\ell+1,t}=\mathcal N\!\left(x_{\ell,t}+
\sum_{h=1}^{16}\mathcal D(o_{\ell h,t})\right),
\qquad \mathcal D(o)=|o|^2
\]

for ideal intensity readout, with detector scaling included in the trained interface. The sum is over detected features from the 16 head slots for the **same token and layer**. It is not a sum over different tokens or a coherent optical sum of head amplitudes. Keep an explicit residual bypass into this sum. Complex fields and coherent errors remain necessary inside the optical core even when final detection is intensity-only.

The diagram's “BatchNorm” label is provisional. Literal BatchNorm requires fixed inference statistics and a training scheme that avoids future-token leakage. A per-token normalization such as RMSNorm is another choice. The red memory loop preserves one layer/head's state across tokens; the black layer-output connection advances to the next logical layer. Neither is an extra FFN recurrence within the same layer.

## Learned weights and stored coefficients

The selected approximately 310M starting model uses distinct fixed weights in all 24 layers and unique FFNs for all 16 heads per layer. Reusing physical engines does not itself share learned parameters. Alternating two learned layer sets remains an optional compression ablation, separate from this starting budget.

| Scope | Learned factor entries |
| --- | ---: |
| One 512 × 512 structured map | 65,536 |
| Two-layer input FFN, one head/layer | 131,072 |
| K, Q and V, one head/layer | 196,608 |
| O, one head/layer | 65,536 |
| All six maps, one head/layer | 393,216 |
| One layer, all 16 heads | 6,291,456 |
| All FFNs, all 24 layers | 50,331,648 |
| All K/Q/V maps, all 24 layers | 75,497,472 |
| All O maps, all 24 layers | 25,165,824 |
| Total fixed maps | **150,994,944** |

The selected complex factors therefore contain **301,989,888 real scalar parameters**. Add one tied real \(16{,}000\times512\) embedding/readout matrix:

\[
N_{\rm learned}=2(150{,}994{,}944)+8{,}192{,}000
=\boxed{310{,}181{,}888\text{ real parameters}}.
\]

This is the approximately **310M** model subtotal, before biases, gains, normalization, gates and any learned initial adaptive state. The tied vocabulary matrix is counted once. A 32,000-token vocabulary would instead give 318,373,888 parameters. Real-only optical factors are a separate ablation, with 159,186,944 parameters including the same 16k embedding. If native redundant optical coefficients are trained directly without constraints, report their parameter count rather than the factor-entry subtotal.

The optical-map subtotal is 37.5% of the previous sixteen-fiber/four-stage version, a 62.5% reduction. Optional comparisons: sharing each layer's FFN across heads gives 103,809,024 complex factor entries (215,810,048 real parameters including the embedding); alternating two learned layer sets with unique per-head FFNs gives 12,582,912 complex entries (33,357,824 real parameters including the embedding). These variants retain separate adaptive states across logical layers and heads.

A local coefficient frame stores \(R(2K-1)=8{,}128\) generally complex optical coefficients. Persistent adaptive state is

\[
N_{\rm state}=2LHnR(2K-1)=49{,}938{,}432.
\]

| Adaptive-state scope | Optical coefficients |
| --- | ---: |
| One local cell, one layer/head frame | 8,128 |
| One bank, one head/layer | 65,024 |
| Both banks, one head/layer | 130,048 |
| All heads, one layer | 2,080,768 |
| One physical bank/lane loop, all 384 frames | 3,121,152 |
| All 16 loops | **49,938,432** |

There are 6,144 logical local-cell frames and 25,165,824 local adaptive matrix-factor entries. The larger coefficient count reflects representation redundancy, not more independent dense matrix degrees of freedom. A complex64 state snapshot occupies 399,507,456 bytes, or **381 MiB per sequence**. Naively retaining 512 snapshots takes 190.5 GiB before other training memory; the smaller parameter count still requires an efficient recurrent training implementation.

Encoding all fixed optical maps in the same representation takes **299,630,592 optical coefficients**. Fixed plus adaptive storage is **349,569,024 coefficients**, excluding the electronic vocabulary matrix, fixed reference pumps, delay buffers, monitor copies and any replicated weight feeds. The query reader accesses the existing adaptive coefficients. These storage counts describe analog coherent fields, not bits.

## Physical engines and activation

| Resource | Instances under the dedicated-engine option |
| --- | ---: |
| Recurrent prediction/update cells | 16 = 2 banks × 8 lanes |
| Dedicated recurrent query readers | 16 = 2 banks × 8 lanes |
| Fixed-map local readers | 96 = 6 maps × 2 banks × 8 lanes |
| Total local arithmetic instances | **128** |
| Persistent recurrent coefficient loops | **16**, one per bank/lane |
| Activation channels per FFN stage | 512 = 8 lanes × 64 wavelengths |
| Activation channels for two instantiated stages | 1024 |

A full multifunction cell has four DFG sections, one cross-SFG writer and two temporal accumulators. A read-only local reader has two DFG sections and one accumulator. Fixed-map calibration needs writer access; whether that is duplicated in every fixed-map cell or shared is still an area/schedule choice. The 128 count is an arithmetic-instance count, not a count of equally sized full cells.

The provisional **48 mm² per multifunction cell** assumption gives **768 mm² for the 16 recurrent prediction/update cells alone**. It is not a fabricated floorplan. MZI shuffle trees and their connections, dedicated query readers, fixed-map engines, sources, controls, activation optics and packaging are additional. One complete shuffle serves the two-bank engine; the dedicated query engine and each of the six fixed maps require their own shuffle under this allocation, for eight forward shuffle networks. Backward reuse or duplication must also be counted. Do not assign 48 mm² automatically to read-only readers or retain the older four-die packaging claim.

Place each optical activation **after a complete two-bank FFN map and its temporal sums**. The tentative preference is free-space wavelength demultiplexing followed by saturable absorption and remultiplexing. A suitable training model is

\[
\phi(z)=\sqrt{T(|z|^2)}\,z,
\]

with increasing transmission \(T\), plus any measured or modeled nonlinear phase. The absorber's loss saturates; the transmitted amplitude need not saturate to a constant. Insufficient transmission contrast makes the operation nearly linear, while excessive weak-signal absorption can suppress gradients. The actual field transfer must be trained, rather than substituting a signed electronic ReLU without justification.

[Guo et al.](https://arxiv.org/abs/1912.12256) provide simulation precedent for saturable-absorption optical activations in image classification. That supports studying the activation, not a claim of superior language-model performance. SHG depletion remains an alternative to compare. Demultiplexing must isolate the intended per-coordinate nonlinearities, and activation recovery, power, loss and transit delay must fit the head schedule.

Fixed MLP coefficients circulate for reuse rather than being regenerated for every inference. The tentative maintenance proposal is corrective calibration every approximately 100 cycles and full reload every approximately 1000 cycles. Define whether a cycle is a useful read or a physical lap before assigning times. This maintenance preserves fixed weights; it is distinct from the sequence-derived TTT update. Reuse amortizes loading, while circulation gain, pumps and noise remain part of the energy/fidelity budget.

## Timing with a dedicated query reader

Use \(a=R\tau=0.64\) ns and the single-lattice reader frame interval \(I=2a=1.28\) ns. A local bank's useful output begins after **0.64 ns**, plus common propagation, and lasts 0.64 ns. Its next accepted burst starts 1.28 ns after the previous start. Thus a two-bank map has **1.28 ns first-valid latency** under ideal chaining, while maintaining 1.28 ns initiation spacing. Cadence and propagation latency are different quantities.

For the passive accumulator,

\[
H_{128}(D)=\prod_{j=0}^{6}\frac{1+D^{2^j}}2
=\frac1{128}\sum_{r=0}^{127}D^r.
\]

There are seven two-arm cells and fourteen couplers per accumulator, with differential delays 10, 20, 40, 80, 160, 320 and 640 ps. Here \(D\) is a one-slot delay. The summed differential waveguide length is approximately 190.5 mm at assumed group index 2, separate from common path length and footprint.

Relative to one head's prediction launch, ideal dependencies are:

| Interval | Operation |
| --- | --- |
| 0–0.64 ns | Bank-1 prediction |
| 0.64–1.28 ns | Bank-2 prediction |
| 1.28–1.92 ns | Final error available; bank-2 backward read and coefficient-gradient stream |
| 1.92–2.56 ns | Bank-1 receives backpropagated error and completes its coefficient-gradient stream |
| By 2.56 ns | Complete updated coefficient frames nominally available |

This table omits physical subtraction, routing and writer propagation. Actual readiness must be derived from those paths. The first bank needs a longer input/old-weight hold than the second bank. Slotwise streaming could use a finer schedule; the current example waits for whole coefficient frames.

Let \(h=0,\ldots,15\). Launch predictions at \(P_h=hI\) and launch queries on the separate reader at

\[
Q_h=P_h+5.12\,\mathrm{ns}.
\]

The 5.12 ns offset is four reader intervals, chosen here to leave 2.56 ns beyond the ideal full-frame write readiness. It is an illustrative scheduling allowance, not a measured writer delay. Prediction and query streams overlap because their readers are distinct. The final head's query output begins at

\[
15(1.28)+5.12+1.28=25.60\,\mathrm{ns}
\]

after the first prediction launch.

| Layer segment | Ideal first-valid time |
| --- | ---: |
| Two FFN maps and parallel K/Q/V | \(2(1.28)+1.28=3.84\) ns |
| Sixteen predictions and dedicated updated queries | 25.60 ns from first prediction to final query result |
| Final head's output projection | 1.28 ns |
| Total | **30.72 ns** |

This assumes all six fixed maps have separate engines and that successive heads can enter at 1.28 ns intervals. Halving the parallel lane count does not halve a map's latency: \(K,R\) and the head count are unchanged. Removing two serial FFN maps shortens the arithmetic layer path by 2.56 ns. FFN activations and their free-space paths, MZI shuffle propagation and settling, filter/waveguide common propagation, gain stages and coherent replay add delay unless explicitly hidden. The final detector/integrator, head sum, residual addition, normalization and next-layer encoding are also outside the 30.72 ns arithmetic total. If detection integrates the entire 0.64 ns output window, count that window once within the handoff delay.

Define \(\delta_\ell\) as additional unhidden delay inside layer \(\ell\), \(G_\ell\) as the electronic handoff after internal layer \(\ell\), and \(T_{\rm feedback}\) as the final vocabulary readout, sampling and next-token input preparation. Then an illustrative serial autoregressive pass is

\[
T_{\rm token}=24(30.72\,\mathrm{ns})+
\sum_{\ell=1}^{24}\delta_\ell+
\sum_{\ell=1}^{23}G_\ell+T_{\rm feedback}.
\]

The arithmetic-only value is **737.28 ns**, or **1.356 million complete passes/s**. It is not the 781.25 million reader frames/s or a demonstrated token-generation rate. Internal deliberation consumes complete passes too: 16 or 100 additional full passes per visible token reduce this ideal ceiling by factors of 17 or 101 respectively. All layers reuse the engines, so there is no spatial pipeline of 24 independent layer processors.

The previous four-FFN-stage dedicated-query budget was 33.28 ns/layer and 798.72 ns/pass. It is superseded by this two-stage budget. The older 12.8 ns/layer, 51.2 ns/layer derivation and 48.64 ns shared-reader schedule also belong to other assumptions.

## Memory organization and fiber length

The ring lengths in this section apply to the full TTT schedule. The initial fixed-weight matmul has a 680 ps loop for one local matrix including its dark margin and a 1.36 ns interval between independent inputs. [Standalone matmul timing](../simulation_notes/hankel_cell.md#fixed-weight-matmul-round-trip)

Use **16 independent recurrent coefficient rings**, one for each of two banks and eight lanes. Each ring stores \(LH=384\) layer/head frames. Each frame contains 64 occupied slots, with 127 coefficient frequencies together in each slot.

\[
T_{\rm occupied}=384(0.64\,\mathrm{ns})=245.76\,\mathrm{ns}.
\]

Reserving a full 1.28 ns reader interval per stored frame takes 491.52 ns. These are storage/framing durations, not a complete model-pass latency. A simple illustrative 30.72 ns layer allocation contains 24 reader intervals: 16 active prediction frames plus eight other intervals for the remaining ideal layer pipeline. Those eight intervals are not an additional budget for the electronic handoff omitted above. Across 24 layers this is 576 intervals, giving 737.28 ns. Different read taps see phase-shifted versions of that schedule.

The required coefficient access order is

```text
prediction tap using old coefficients
    → delayed old-coefficient access for backward propagation
    → aligned gradient injection
    → updated-coefficient tap for the dedicated query reader
    → remaining storage delay and next-token return
```

Bank-specific tap positions and delays must align the matching head, layer and coefficient slot. This topology allows same-pass prediction/write/query access; a single read tap with a later-lap query does not support the assumed 5.12 ns query offset. Input k, target v, query q and old bank-1 prediction need corresponding coherent holds. Persistent coefficient storage bypasses the nonlinear computation; taps feed the compute paths.

For the simplest fixed schedule, choose a ring period equal to the complete token/pass recurrence period, so each state frame returns for its next intended update. With the arithmetic-only period,

\[
T_{\rm loop}=24\times30.72\,\mathrm{ns}=737.28\,\mathrm{ns},
\qquad L_{\rm fiber}=\frac{c_0}{n_g}
\left(T_{\rm loop}-T_{\rm other\ loop\ components}\right).
\]

Ignoring other loop delays and assuming \(n_g=1.47\) gives **150.36 m per ring**. The familiar 5 ns/m approximation gives **147.46 m**, hence approximately 150 m. This is the complete circulating path length, with no factor of two. Reflective out-and-back storage would use a different physical-length convention.

[Corning's telecom-fiber specification](https://www.corning.com/media/worldwide/coc/documents/Fiber/product-information-sheets/PI-1424-AEN.pdf) gives a representative effective group index of 1.4682 at 1550 nm. The circulating coefficients here are near **775 nm**: their actual fiber must have suitable guidance, loss, dispersion and measured group delay at that wavelength. The telecom number only motivates the approximate scale; it does not select the coefficient fiber.

At the 1.47 assumption, 16 equal rings contain about **2.406 km of fiber in aggregate**. That excludes fixed-MLP storage and temporary replay paths. Add guards and token feedback to the chosen roundtrip period, and subtract time spent in other loop components when calculating fiber length. An added 1 ns at each of 24 layers adds about **4.89 m per ring**. A longer token period can instead require idle circulation and explicit rescheduling; forgetting must occur once per intended update, not once per passive lap.

The length is a delay requirement, not a demonstrated analog retention distance. Dispersion across 127 channels, 10 ps slot fidelity, relative phase stability, tap loss, gain noise and write alignment must be included in the model. Gain compensation restores field magnitude but does not reconstruct lost information.

## Scope of checks and remaining choices

The [ideal single-lattice checker](check_single_lattice.py) verifies temporal summation, timed reference-pump acceptance and two-reader chaining with small spectral vectors. Its default is the historical 32-term example; select 64 terms explicitly:

```bash
python3 - <<'PY'
from hankel_monarch_delta.check_single_lattice import Schedule, run_checks
report = run_checks(Schedule(terms=64))
print(report['status'])
print(report['timing_and_size']['frame_period_ps'])
PY
```

Those checks do not validate the complete joint-update/dedicated-query schedule, fixed reference-family coverage, 64-wavelength conversion physics, activation hardware or trained language-model quality. The [older global-ring script](model_memory_schedule.py) implements a different memory-access model. The earlier [figures](figures/README.md), component layouts and die counts are labeled historical where they differ from this design.

The remaining architecture choices are the MZI shuffle's process, filtering and calibration implementation, fixed-comb basis and scaling, normalization, nonzero adaptive initialization, optional sharing or real-factor ablations, calibration hardware allocation, and physical delays/power/noise. The starting parameter budget now selects complex fixed factors, distinct layer/head weights and a tied real 16k embedding/readout. In particular, initializing **both** adaptive banks to the zero operator makes both gradients of the bilinear prediction vanish; use a specified nondegenerate initialization and verify its encoding. Digital simulations must reproduce the same complex update, updated-state query and intensity interface. The [research-model note](research_model.md) specifies that evaluation, while the [sharing and deliberation note](parameter_sharing_and_deliberation.md) preserves optional compute-for-parameter experiments.
