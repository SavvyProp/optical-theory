# Optical weight sharing and internal reasoning

Research direction · updated 17 November 2026.

The current architecture uses a **512-wide residual stream, 24 logical layers, and 16 logical heads per layer**, with eight spatial lanes per head and one physical head processing successive head batches. Every head has its own two-layer optical FFN, separate \(K,Q,V\) maps, and an output map. A joint two-bank TTT update uses one final value target, followed by a **dedicated physical query reader** using the updated state. The [research model](research_model.md) defines these operations; the [design point](paper_design_point.md) gives physical counts and conditional timing.

The earlier **10M resident optical-weight cap has been superseded** by the proposed [recirculating Hankel–Monarch MLP](../hankel_monarch_mlp/README.md). Parameter sharing remains a useful family of ablations and a way to reduce coefficient storage/loading; it is not required to force the current baseline below 10M. The selected full baseline has **150,994,944 complex structured factor entries**, equivalent to 301,989,888 real parameters, plus a tied real 16,000-token embedding/readout with 8,192,000 parameters. The total is **310,181,888 real learned parameters**, before gates, normalization, biases, and any learned initial state.

Train on conventional silicon, then transfer learned weights to the proposed optical device. The paper combines an optical architecture proposal, a conditional timing/energy model, and digital evaluation. **No physical experiment is planned.** Training time, optical training, and faster RL rollout collection are outside the performance claims. RL and other training methods are ways to obtain deployed weights and policies on silicon. Online TTT updates and any internal deliberation remain inference work.

## Current baseline and optional sharing

Each \(512\times512\) structured map has two banks of eight local \(64\times64\) factors:

\[
N_{\mathrm{factor/map}}=2\times8\times64^2=65,536.
\]

There are six fixed maps per layer/head: two FFN maps and separate \(K,Q,V,O\) maps. The current baseline counts all 24 layer weight sets as distinct:

\[
24\times16\times6\times65,536
 =150,994,944\quad\text{complex factor entries}.
\]

The selected model has unrestricted complex factors, so the optical maps contain **301,989,888 real scalar parameters**. Including the tied real \(16{,}000\times512\) embedding/readout, counted once, gives the **approximately 310M baseline**. Native optical coefficient storage is a separate count because the Hankel representation is redundant. The complete distinct fixed-map encoding contains 299,630,592 generally complex coefficients, while each sequence has another 49,938,432 complex adaptive TTT coefficients. Physical reuse of a reader does not by itself tie the stored weights.

| Design choice | Current baseline | Optional ablation |
| --- | --- | --- |
| Learned layer weights | Distinct across all 24 logical layers | Alternate two learned sets across layers |
| Input FFN | Unique two-map FFN for every logical head | Share whole FFNs across head groups |
| FFN implementation | Two-bank Hankel–Monarch structured maps | Additional factorization or tying only as a separate experiment |
| Recurrent projections | Separate \(K,Q,V\) for every head/layer | Shared matrices with head-specific gains, grouped sharing, or low-rank interfaces |
| Output projection | Per-head optical \(O\) before intensity detection | Tie maps across head groups while preserving per-head detection |
| Layer specialization | Distinct weights in full baseline | Small layer-specific gains/gates for shared layers |
| Adaptive memory | Separate state for every layer/head/bank | Preserve this separation even when fixed weights are shared |
| Internal computation | Ordinary inference establishes the baseline | Explicit thoughts, pause steps, or continuous feedback |

The selected 310M baseline uses distinct weights across all 24 layers. The earlier alternating A/B proposal remains an optional sharing ablation. Two learned layer sets, with 16 unique heads in each set, require

\[
2\times16\times6\times65,536
 =\boxed{12,582,912}
\]

complex factor entries, or **25,165,824 real scalar parameters**. With the same tied real embedding/readout, this is **33,357,824 real parameters** before layer-specific gains or other additions. The adaptive state still belongs to all 24 logical layers. Here A/B denotes **learned layer sets**, not the two adaptive banks within a head.

The previous 9,019,392-weight example used a different model: 512-wide heads/residual stream, two shared dense SwiGLU networks, head-shared interfaces, and two local target views. It is a historical comparison, not the parameter count of the current optical-FFN architecture. A model should not be labeled “10M total parameters” when embeddings, readout, or other learned parameters are excluded.

## How head and layer sharing could be applied

A head-shared projection candidate uses

\[
p_{\ell h}
 =g^p_{\ell h}\odot W^p_{\ell,g(h)}u_{\ell h},
\qquad p\in\{k,q,v\},
\]

where \(g(h)\) selects a group of heads, \(g^p_{\ell h}\) is a head-specific elementwise gain, and \(u_{\ell h}\) is that head's FFN output. Use a separate matrix family for each of \(K,Q,V\); sharing across heads does not mean tying keys to queries or targets. A learned-layer-set index can replace \(\ell\) when alternating layer weights.

Because the selected FFNs are head specific, their outputs generally differ. Sharing a projection's weights therefore saves stored parameters but does **not** normally allow the projection to be computed once and broadcast. Broadcast becomes possible only when its input is shared too; fan-out power and scheduling still require accounting.

Input/output gain modulation, \(\operatorname{diag}(u)W\operatorname{diag}(v)\), uses a rank-one multiplicative mask, but the resulting matrix need not have low rank. An additive low-rank adapter is a different construction. A separate interface factorization \(W=UV\) also changes the operator class, hardware schedule, and parameter count, and should be tested on its own.

The current maps already have structured factors. The familiar dense sharing estimate \(Gsd+Hs\) instead of \(Hsd\) motivates head grouping, but actual savings here must be counted in the **structured factor representation** and its encoded coefficient frames. Do not apply a dense \(s\times d\) count to a 65,536-complex-entry structured map.

Output-map sharing also needs the correct readout semantics. With intensity detection,

\[
\sum_h\left|W^O y_h\right|^2
\ne
\left|W^O\sum_h y_h\right|^2
\]

in general. Tying \(W^O\) across heads can reduce its weight count while still applying it separately to each head before detection. Moving a common optical output map across the head sum would introduce cross terms and define a different model.

Separate adaptive allocation does not guarantee useful head diversity. Identical initial states, write inputs, and gates give identical state trajectories; query differences alone do not diversify the stored state. The current private FFNs and \(K,V\) projections can supply different write inputs. Sharing ablations should measure diversity and keep head-specific features or gates where needed. A positive scalar gain can disappear under normalization; vector gains are more expressive candidates.

The weights within one logical layer/head are reused across tokens and internal steps even in the full unshared baseline. Recirculation exploits that temporal reuse. More aggressive layer/head tying can further reduce information storage, but identical physical copies still consume hardware coefficients, and repeated use still consumes optical power.

## Literature supporting parameter sharing

- **MHE: Pit One Against Many**, Findings EMNLP 2023, is a close head-sharing precedent. It shares a matrix per Q/K/V family with head-specific embeddings, including multiplicative gains; its output projection remains dense. Its GPT2-base comparison reduces attention parameters from 28.32M to 8.88M, with WikiText-103 perplexity increasing from 43.0 to 53.8. This demonstrates a mechanism and a measured quality cost, not lossless compression. [Paper](https://aclanthology.org/2023.findings-emnlp.695/), [full text](https://arxiv.org/html/2310.07911v1).
- **Multi-Head Attention: Collaborate Instead of Concatenate** shares Q/K bases with head-dependent mixing coefficients. Its translation experiment reduces their dimension from 512 to 128 while retaining 27.40 BLEU; values/output remain separate. [Preprint](https://arxiv.org/html/2006.16362v2).
- **Relaxed Recursive Transformers**, ICLR 2025, studies repeated layer blocks with small layer-specific adaptations. Its low-rank adapters differ from diagonal gains. [Paper](https://arxiv.org/html/2410.20672v3).
- **SLlama**, EMNLP 2025, reports a 2.61M-parameter model in the constrained BabyLM setting. It motivates testing small shared models; it does not establish broad capability for this optical recurrence. Its extra internal MLP tying is outside the present baseline. [Paper](https://aclanthology.org/2025.emnlp-main.1198.pdf).

These mechanisms become proposed adaptations when applied to this joint two-bank TTT interface, complex optical operators, and intensity output boundary.

## Hypothesis: spend internal steps to improve the response

The research hypothesis is that a controller with reusable fixed weights and substantial adaptive memory can trade additional inference computation for better language reasoning. This can be tested at the full baseline and at smaller shared-weight variants. Capability is an empirical question: parameter count and memory size alone do not show that reasoning will emerge.

Sweep internal-step budgets such as 0, 4, 16, 64, 128, and 256. Distinguish thinking once before an answer from thinking before **each** visible token; their latency and visible-token throughput differ.

| Mechanism | Internal input/feedback | Main implication |
| --- | --- | --- |
| Explicit thought tokens | Sample vocabulary tokens and feed their embeddings back | Supplies a textual target, but requires vocabulary projection and sampling for every thought |
| Pause inputs | Feed a learned pause symbol while recurrent state evolves | Adds state-update opportunities without decoding a vocabulary item at each internal step |
| Continuous latent feedback | Feed a hidden vector, possibly through a projection, into the next step | Avoids vocabulary decoding during thought; feedback dimensions and normalization must be defined |

Equal numbers of tokens, recursive refinements, and core evaluations are not necessarily equal compute. Compare complete model evaluations and modeled end-to-end latency as well as task accuracy. Train with the intended internal-step mechanism and a range of budgets; additional inference-only steps need not help monotonically.

Relevant precedents are complementary:

- **Quiet-STaR** studies short thoughts before predicting subsequent text, using a pretrained 7B model and REINFORCE to reward improved future-token likelihood. Its C4 setting includes 16 thought tokens and four future true tokens. It provides a candidate objective, not evidence for the same result at this architecture's parameter budget. [Paper](https://arxiv.org/html/2403.09629v2).
- **Tiny Recursive Models / Less is More** demonstrates puzzle reasoning with a 7M-parameter network and repeated latent computation. It is supervised task-specific reasoning rather than a general autoregressive LM trained with RL; ARC results also involve augmentation and voting. [Paper](https://arxiv.org/html/2510.04871v1).
- **Coconut** feeds hidden states back as continuous thoughts and uses a curriculum starting with explicit traces. Its experiments use a pretrained GPT-2-class model of approximately 124M parameters. It supports the feedback mechanism, not guaranteed tiny-model feasibility; explicit CoT is stronger on some tasks. [Paper](https://arxiv.org/html/2412.06769v2), [official model configuration](https://github.com/facebookresearch/coconut/blob/main/args/gsm_coconut.yaml).
- **Pause Tokens**, ICLR 2024, studies 130M and 1B models trained to use extra computation before answering. Transformer pause positions are not identical to sequential steps of this recurrent core. [Paper](https://arxiv.org/html/2310.02226v3).

The prospective contribution is the tested combination of this optical TTT architecture, selected sharing constraints, and a modeled low cost of extra inference computation. Mini-thoughts and RL themselves are existing ideas.

## Memory policy and silicon training

TTT state can serve working memory, but durable retention under repeated reasoning must be tested. Every thought step can apply both forgetting and new writes. As a simple illustration, scalar decay 0.99 applied for 128 extra steps leaves about 27.6% of the original contribution, before considering write interference. This is not a prediction of the full nonlinear joint-update dynamics.

A candidate policy separates protected context heads from writable scratchpad heads. During thought, freeze context-head writes and algorithmic decay, or train slower gates; let scratchpad heads evolve. Setting retention to one and the write step size to zero for **both banks** preserves a head's adaptive state mathematically. Physical loss compensation still runs. Optionally learn a summary commit at answer boundaries, and compare against updating all heads on every thought step.

The current recurrence is a joint gradient update of \(B_2PB_1\) with one final target. It is **not affine in the combined adaptive state**, even when gates depend only on the current input or mode. A fast scan or standard DeltaNet training kernel cannot be assumed exact. Any frozen-bank, frozen-chunk, local-target, or detached-state alternative must be labeled as a changed algorithm and used consistently in the digital and optical models.

Initialization also changes from the earlier local-target proposal: setting **both** adaptive banks to zero makes both joint-loss gradients zero. Select and test a nondegenerate initial state, such as an appropriate fixed nonzero bank operator, and count any learned initialization parameters separately. Head diversity and thought-retention studies must use this same initialization policy.

The reduction from 16 to eight spatial lanes and from four to two FFN maps lowers the optical-map parameter count by 62.5% and halves the adaptive state. It makes a smaller silicon study possible without changing the 24-layer, 16-head logical organization, but does not guarantee practical single-GPU training. One complex64 native-state snapshot is still **381 MiB per sequence**; 512 naive full-state snapshots would require **190.5 GiB**. Establish exact checkpointing/recomputation and measure training memory and throughput before selecting the data and context budgets.

Suggested sequence:

1. Establish a functioning language model with the selected complex update, physical activation model, and intensity readout. Verify state retention and head specialization.
2. Train short trajectories with supervised/distilled examples and exact-answer tasks, such as arithmetic, context-defined rules, compositional retrieval, planning, or program execution. Evaluate broader language modeling separately.
3. Train across thought budgets. For latent thoughts, establish differentiable supervision or a curriculum before adding policy-gradient credit assignment.
4. Apply RL where rewards are informative and the model has some initial success. Compare verifier rewards and future-token objectives. More trajectories explore computational paths; they do not automatically supply missing knowledge or gradients from persistent failure.
5. Add a computation penalty or adaptive stopping after extra steps demonstrably help. Hold out task instances and generators to assess generalization.

All these stages run on silicon. Their purpose is to produce learned weights and a deployed reasoning policy. No optical training or faster rollout collection is required for the paper.

## Conditional inference latency

The current [dedicated-query timing model](paper_design_point.md) gives **30.72 ns per logical layer**, so

\[
\tau_{\mathrm{pass}}=24\times30.72\ \mathrm{ns}
 =737.28\ \mathrm{ns}=0.73728\ \mu\mathrm{s}.
\]

This is approximately **1.36M full model passes/s** under the illustrative assumptions. It is not a demonstrated token rate and does not establish tens of millions of complete autoregressive tokens/s. Additional unhidden optical propagation, full-window acquisition, digital head/residual summation, normalization, re-encoding, vocabulary output, and feedback must be included in the deployed latency. The calculation assumes two FFN maps, separate query hardware, the unchanged 5.12 ns prediction-to-query offset, and sufficiently provisioned fixed-map engines. The frontend takes 3.84 ns, the 16-head recurrent/query schedule 25.60 ns, and the output projection 1.28 ns; halving spatial lanes does not change the local 64-term temporal accumulation time.

If every thought and visible token took that same idealized pass time:

| Extra thought steps \(K\) before one visible token | Arithmetic time for \(K+1\) passes |
| ---: | ---: |
| 0 | 0.73728 μs |
| 16 | 12.53376 μs |
| 64 | 47.92320 μs |
| 128 | 95.10912 μs |
| 256 | 189.48096 μs |

For thinking once before a response, use

\[
T=T_{\mathrm{prefill}}
 +N_{\mathrm{thought}}\tau_{\mathrm{thought}}
 +N_{\mathrm{visible}}\tau_{\mathrm{visible}}.
\]

Each step time includes its actual non-overlapped work. Explicit thoughts may require vocabulary decoding/sampling that latent steps avoid. For \(K\) thoughts before **every** visible token, visible-token throughput is
\(1/(K\tau_{\mathrm{thought}}+\tau_{\mathrm{visible}})\). An output head excluded from the optical parameter subtotal still contributes to explicit-token latency.

Match the recurrent coefficient loop to the actual full-pass period, including any additional waits, so each layer/head state is revisited at the intended logical step. The 737.28 ns arithmetic period corresponds to approximately **147–150 m of fiber per loop**, with **16 bank/lane loops** in the resized architecture, at the representative group velocities discussed in the design note. At \(n_g=1.47\), this is about 150.36 m per ring and 2.41 km in aggregate. A different thought schedule cannot silently change state identity or apply extra forgetting on passive laps.

## Decisive comparisons and reporting

The main test is whether extra internal computation improves quality enough to justify its conditional latency at a declared parameter/storage budget. Include zero-thinking, explicit/pause/latent feedback, protected-context versus unrestricted writes, and sharing ablations. Compare the full baseline with alternating learned layers, head-group sharing, and interface gains/factorization, while keeping the actual model operators and data budget explicit.

Report language loss, task accuracy, retention after thinking, learned real scalar count, encoded optical coefficients, adaptive state, physical reader count, internal evaluations, response latency, and visible-token throughput separately. Use parameter-, inference-compute-, and latency-matched comparisons where useful. Document silicon training for reproducibility, without presenting training speed as the contribution.

A positive digital result would establish useful inference-time computation in this model. Physical robustness and the conditional optical timing/energy model are additional results to evaluate through analysis and simulation; an implemented optical device is not part of the planned evidence.
