# One full Hankel photonic multiplier

Ideal single-lattice design · 15 November 2026

**Numerical reference:** this document and its circuit diagrams retain the earlier \(K=R=32\) reader example. The [current paper design point](paper_design_point.md) selects \(K=R=64\), eight lanes per head and four parallel head engines serving 16 logical heads and 24 layers on four reader dies. Each reader needs seven binary stages, 128 taps and a 1.28 ns frame; the six-stage footprint below has not yet been resized.

The [per-cell optical pathways](cell_pathways.md) specify the current 64-slot reader, separate target-amplitude MZI and subtraction combiner, dedicated DFG/SFG gradient writer, and delayed coefficient bypass. The writer consumes the completed prediction plateau directly and needs no additional temporal summation filter.

The baseline reader uses **two DFG sections, fixed band filters and one passive binary delay lattice**. The shared reference comb \(b_m\) arrives in timed bursts and determines when the multiplier accepts its input. There are **no reader routing switches and no output shutter**.

The circuit is passive in the sense of having no locally switched electrical elements. Optical pumps supply energy and timing; their generation is a shared external resource. Perfect timing, fixed coherent phases and ideal filters are assumed for this theoretical description. The [earlier dual-lattice design with engineering margins](engineering_margins.md) is retained as a reference alternative.

![Single passive lattice with reference-pump acceptance](figures/08_binary_multiplier.svg)

## Ideal configuration

One component serves one spatial lane of one Monarch bank. Let \(R\) count Hankel-pair terms and \(L_F\) count temporal taps.

| Quantity | Baseline |
| --- | --- |
| Data comb | \(K\) simultaneous teeth; illustrative \(K=32\) |
| Coefficient comb | \(2K-1\) teeth |
| Terms per multiplication | \(R=32\) |
| Term slot | \(\tau=10\) ps |
| Accumulator | One six-stage balanced binary lattice, \(L_F=64\) taps |
| Reference \(b_m\) | 32 populated slots followed by 32 blank slots |
| Reader frame period | \(64\tau=640\) ps |
| Useful output window | 320–640 ps after the frame starts, plus common latency |
| Field normalization | \(1/64\), before conversion gains and losses |
| Reader EO switches / output shutters | **0 / 0** |

Each valid output is a 320 ps comb envelope. The next frame begins 640 ps after the previous one: the accepted tradeoff is half the ideal dual-lattice cadence, with one accumulator and no routing controls.

## Read path and acceptance by the reference comb

Data enter in band A. DFG 1 produces band B using a tapped adaptive coefficient comb in the sum-frequency band P. DFG 2 uses the reference comb in P to return to A. Persistent \(a_m\) coefficients circulate directly in P and bypass computation; only a read tap enters DFG 1.

Write \(H(h)_{ji}=h_{i+j}\). The ideal DFG operation is
\[
\mathcal D(h,x)=H(h)\overline{x}.
\]
The reference source supplies \(b_{\mathrm{pump}}(t)=w(t)b_m\), where \(w=1\) during the 32 intended slots and \(w=0\) during the following 32 slots. The complete path is:

1. **DFG 1:** \(u(t)=H(a(t))\overline{x_{\mathrm{raw}}(t)}\).
2. **B filter:** keep the \(K\) desired intermediate lines; reject the original A input, residual P pump and other idlers.
3. **DFG 2:** generate
   \[
   z(t)=w(t)H(b_m)H(\overline{a(t)})x_{\mathrm{raw}}(t).
   \]
4. **A filter:** keep the desired output band and reject B/P.
5. **One binary lattice:** accumulate the 32 generated terms into the completed output.

The adaptive read tap may remain present during blank intervals. DFG 1 can still generate unwanted B light then, but with \(b_m=0\), DFG 2 generates no desired A-band term for the accumulator. Its fixed output filter removes the unconverted B light. This is why no separate input or output switch is needed.

The **amplitude blank in \(b_m\)** is essential. A phase ramp alone does not turn conversion off. Within an active burst, the shared source supplies the established sequence of spectral phase ramps, synchronized to the corresponding \(a_m\) slots. It repeats that sequence for each reader frame. This scheduling does not change the fixed model parameters \(b_m\).

B-filter rejection is also essential: leaked original A light can reach the accumulator directly, and leaked adaptive pump P can drive unwanted conversion in DFG 2. Perfect rejection is assumed here. DFG 1's off-window conversion can still consume read-tap energy.

## Binary delay lattice

Each balanced split–delay–recombine stage has transfer \((1+D^d)/2\), where \(D\) delays the coherent envelope by one slot. Six passive stages give
\[
H_{64}(D)=\prod_{j=0}^{5}\frac{1+D^{2^j}}2
=\frac1{64}\sum_{r=0}^{63}D^r.
\]
Their differential delays are **10, 20, 40, 80, 160 and 320 ps**. There are six two-arm cells and twelve passive couplers. Unused coupler outputs are discarded; no stage switches between frames.

During the completed plateau, the reader output is
\[
F_{\mathrm{phys}}(x)=\frac1{64}
\sum_{m=0}^{31}H(b_m)H(\overline{a_m})x.
\]
All 32 terms are present from 310 to 640 ps after a frame starts. Use the simpler scheduled interval **320–640 ps**.

![Single lattice and two-stage pump timing](figures/09_binary_lattice_timing.svg)

## Timing and chaining

| Event | Frame 0 | Frame 1 | Frame 2 |
| --- | --- | --- | --- |
| This reader's \(b_m\) burst / generated terms | 0–320 ps | 640–960 ps | 1280–1600 ps |
| Useful output of its lattice | 320–640 ps | 960–1280 ps | 1600–1920 ps |
| Next reader's \(b_m\) burst | 320–640 ps | 960–1280 ps | 1600–1920 ps |
| Next reader's useful output | 640–960 ps | 1280–1600 ps | 1920–2240 ps |

The table omits fixed propagation latency; add the actual core, filter and link delays to the receiving pump schedule. Equalize paths through the Monarch shuffle so all components of a vector arrive together.

**The lattice output is raw and contains transients outside its useful windows.** The next reader's reference-pump burst accepts only the completed result. The current reader's \(b_m\) gates its generated terms before its own lattice; it does not erase that lattice's later output transients. A final detector or optical capture interface must likewise use the scheduled useful window.

The old frame's tail may overlap the next frame's accumulation, but it has cleared by the next useful output window. No reset is required. A single lattice cannot run these frames 320 ps apart: their sums would overlap during the supposed result window. At 640 ps spacing the ideal reader rate is **1.5625 billion frames/s per lane**, not a model token rate.

The envelopes fill their slots and the delayed comb teeth add with calibrated phase. In the nondispersive model, \(\Delta\nu\tau\) integral permits common carrier-phase alignment. Short separated pulses do not automatically produce a continuous plateau. Finite pulse edges, dispersion, filter settling and loss are outside this ideal schedule.

## Coefficient memory and local updates

The reader's active slots must coincide with the intended layer/head/bank's \(a_m\) coefficients. For the simplest memory framing, reserve a **640 ps service interval per read**, containing 320 ps of coefficient access followed by 320 ps with \(b_m\) absent. A ring may reserve that second half as idle capacity, or carry fields that are not serviced on that visit. It must not silently advance to another head every 320 ps while assuming every head is read.

Two optical banks may pipeline their read windows as shown above. The digital layer boundary, prediction/write/query ordering and memory revisits remain separate scheduling constraints. A 640 ps read interval does not imply one recurrent token per interval.

The local delta/TTT update remains
\[
e=v-F_{\mathrm{phys}}(k),\qquad
r_m=\mathcal D(b_m,e),\qquad
g_m=\frac1{64}(k*r_m),\qquad
a_m^+=a_m^-+\eta g_m.
\]
The residual stays optical; the cross-SFG writer produces all \(2K-1\) gradient coefficients directly in P. Its scalar normalization must match the reader.

A separate write visit can reuse DFG 1 and add one cross-SFG section. That extension needs operand selection, optical hold/replay and timed memory injection. Those interfaces are not specified as passive by this reader design. Finish prediction before changing its coefficients, and commit all writes before the updated query. The blank reader half-period alone does not prove that the complete write fits there.

## Preliminary footprint estimate

The proposed material stack remains SiN routing/delays and thin-film LN nonlinear sections on a silicon substrate. The reader removes one delay lattice and both long EO routing devices from the previous design.

Output gain is currently treated as an assumed interface; the [earlier output-amplifier comparison](optical_amplifiers.md) remains background. The active amplification question is [coefficient-loop loss compensation and variable retention](coefficient_loop_gain.md). Amplifiers and their pumps, filters, transitions, noise, and propagation delay are additional to the passive-reader footprint and timing below.

At assumed \(n_g=2\), the six inserted differential lengths are **1.5, 3, 6, 12, 24 and 48 mm**, totaling **94.5 mm**. Common paths, couplers and access routing add length.

For six spiral regions, with inner radius \(r_0\) and adjacent-waveguide pitch \(p\), a square-envelope packing estimate is
\[
A_{\mathrm{spirals}}\simeq24r_0^2+\frac{4p}{\pi}(94.5\,\mathrm{mm}).
\]
At \(r_0=100\) µm and \(p=10\) µm this gives **1.44 mm²** before couplers and access. Reserve **1.5–2.5 mm²** for the full lattice. This geometric estimate omits detailed turnaround routing and fabrication rules.

Compact SiN bends and long spirals have primary precedents: LIGENTEC lists a 50 µm bend-radius specification, and Liu et al. demonstrated a 1 m spiral in 6.6 mm². These support the packing assumptions without establishing our complete layout. [LIGENTEC specifications](https://www.ligentec.com/technology/), [SiN spiral demonstration](https://www.nature.com/articles/s41467-021-21973-z.pdf)

| Reader block | Assumed reservation | Area |
| --- | --- | ---: |
| One binary lattice | Six spirals, twelve couplers and local access | 1.5–2.5 mm² |
| Two DFG sections | Each approximately 5 mm × 0.10–0.20 mm | 1–2 mm² |
| Filters, pump combiners and material transitions | Provisional allocation | 1–2 mm² |
| Inter-block routes, calibration access and optical interfaces | Provisional allocation | 1–3 mm² |
| EO routing devices | None in this reader | **0** |
| Sum of block reservations | Before overall packing | **4.5–9.5 mm²** |

The nonlinear length is motivated by demonstrated 4.8 mm DFG devices; the corridor widths and other area allocations are our assumptions. [DFG demonstration](https://arxiv.org/html/2410.08790v1)

Adding approximately 20–50% for placement and die-edge clearance gives 5.4–14.25 mm². Use **8–15 mm² as a preliminary standalone reader budget**, with **12 mm²**, for example **6 × 2 mm**, as a working allocation. This is a conceptual reservation rather than a routed layout. Filters and hybrid integration remain the largest unresolved sizing assumptions.

![Single-lattice reader footprint reservation](figures/12_footprint_budget.svg)

The [physical placement study](single_branch_layout.md) develops this into a conceptual **6 × 2 mm floorplan**: two straight DFG rails above one row of six spiral-delay cells. It also shows the couplers and two arms inside a cell. Allowing a larger 200 µm central exclusion for spiral turnarounds raises the estimated spiral envelopes from 1.44 to **2.16 mm² before couplers and access**. The earlier full-lattice allowance is optimistic at its lower end; the placement study reserves about 5.3 mm² for the entire lower row, including gaps and routes. Filter and transition fit in the end regions remains unverified. The working 12 mm² die is a planning envelope, not a routed result.

A cross-SFG writer plus local gradient/residual optics adds roughly **1–2 mm² of arithmetic blocks** under the same length assumptions. Complete writer controls, replay and memory access require a separate area budget; the fixed reader does not establish a fully passive update engine.

External fiber memory/replay, comb sources, input encoders, electronic processing/driver dies, packaging and the inter-bank shuffle are excluded. For \(n\) spatial lanes in each of two banks, an independent-reader estimate is \(2nA_{\mathrm{reader}}\): at \(n=32\), the 12 mm² working value gives 768 mm² across 64 reader tiles, before writer/shuffle infrastructure. Shared peripheral space could reduce array area. Time-multiplexed heads do not multiply the tile count.

## Checks and implementation reference

Run the [single-lattice checker](check_single_lattice.py) from the repository root:

    python3 hankel_monarch_delta/check_single_lattice.py
    python3 hankel_monarch_delta/check_single_lattice.py --output hankel_monarch_delta/results/single_lattice_checks.json

The [saved results](results/single_lattice_checks.json) check the balanced filter, successive independent frames, full raw-field propagation through two Hankel banks and a shuffle, continuously present adaptive pumps, acceptance by the second DFG's \(b_m\), and the normalized coefficient gradient. Counterexamples cover overlapping frames, a nonblank reference and a reference-pump tail. No output shutter or hidden crop supplies acceptance.

These are ideal field-algebra checks. The [older checker](check_binary_multiplier.py) and [engineering-margin notes](engineering_margins.md) retain the dual-lattice alternative; their 70-tap defaults are not this baseline.
