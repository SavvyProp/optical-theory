# Research language-model target

Updated 17 November 2026.

The current proposal is a **512-wide residual language model with 24 logical layers and 16 logical heads per layer**. Each head has eight spatial lanes and its own two-layer optical FFN, separate key/query/value projections, a two-bank adaptive TTT memory, and an output projection. The selected baseline uses distinct complex learned factors across layers and a tied real 16,000-token embedding/readout, totaling **310,181,888 real learned parameters before gates, normalization, and any learned initial state**. One physical head engine processes the 16 logical heads in successive batches, and the hardware is reused across layers. A **dedicated physical query reader** reads the updated TTT coefficients separately from the prediction/update hardware.

The earlier 10M resident-weight limit is no longer the design constraint: the proposed [recirculating Hankel–Monarch MLP](../hankel_monarch_mlp/README.md) supplies the fixed FFN and projection operators. Reuse amortizes coefficient loading; it does not remove the continuing costs of circulation, gain, reference pumps, calibration, or readout. See the [design point](paper_design_point.md) for hardware counts, conditional timing, and memory-loop length, and [sharing and deliberation](parameter_sharing_and_deliberation.md) for optional compression and internal-computation experiments.

Train the numerical model on conventional silicon, then transfer learned weights to the proposed optical device. The paper is an architecture/theory proposal supported by digital simulation and language-model evaluation; **no hardware experiment is planned**. Training speed and optical training are outside its performance scope. Online TTT state updates remain inference operations and must be included in latency and energy accounting. The repository contains algebra and idealized component/schedule checks, not a trained implementation of this complete language model.

## Dimensions and block structure

| Quantity | Current choice |
| --- | ---: |
| Logical layers | 24 |
| Logical heads per layer | 16 |
| Physically simultaneous heads | 1 |
| Head batches per layer | 16 |
| Residual width | 512 |
| Spatial lanes per head | 8 |
| Data wavelengths per lane | 64 |
| Width of each head | 512 |
| Adaptive banks per head | 2 |
| Local factor size | \(64\times64\) |
| Hankel-pair terms per local factor | 64, time multiplexed |
| Coefficient wavelengths per term | 127 |
| Head-specific input FFN | Two \(512\times512\) structured maps, each followed by an optical activation |
| Additional fixed maps per head | Separate \(K,Q,V,O\), each \(512\times512\) |
| Fixed maps per logical layer/head | 6 |
| Learned factor convention | Unrestricted complex factors; count real and imaginary parts separately |
| Learned layer weight sets | 24 distinct sets; alternating two-set sharing is an optional ablation |
| Vocabulary / embedding | 16,000 tokens; tied real \(16{,}000\times512\) embedding/readout |

Each head receives the same residual input, but has a unique FFN and projection weights. The heads are full-width recurrent branches; they are not disjoint slices of the residual stream. Output vectors are projected and detected per head, then summed digitally. There is no concatenated 8,192-wide residual stream.

The earlier diagram draws three FFN map/activation pairs; it is historical and must be redrawn with the selected **two** pairs. The prior four-stage FFN and 1024-wide design have also been superseded. The diagram omits an explicit residual bypass; the current layer input must be routed directly to the final digital residual sum.

For layer \(\ell\), head \(h\), and token or internal step \(t\), let

\[
u^{(0)}_{\ell h t}=x_{\ell t},\qquad
u^{(j)}_{\ell h t}
 =\phi_j\!\left(W^{(j)}_{\ell h}u^{(j-1)}_{\ell h t}\right),
\quad j=1,2,
\]

\[
k_{\ell h t}=W^K_{\ell h}u^{(2)}_{\ell h t},\qquad
q_{\ell h t}=W^Q_{\ell h}u^{(2)}_{\ell h t},\qquad
v_{\ell h t}=W^V_{\ell h}u^{(2)}_{\ell h t}.
\]

All six fixed maps use the proposed two-bank structured implementation. This replaces the earlier dense electronic SwiGLU wrapper; a separate post-memory FFN is not part of the selected block. Input conditioning, biases, step-size/retention gates, and any additional normalization must be specified and counted if added.

## One target and a joint two-bank TTT update

There is **one value target \(v\) for the complete two-bank memory**, rather than separate local targets for the two banks. Suppress layer/head/time indices and write the block-diagonal bank operators as \(B_1,B_2\), with fixed shuffle \(P\) between them. There is currently **no activation between these adaptive banks**:

\[
F_{\theta}(u)=B_2P B_1u.
\]

The selected recurrence predicts with the pre-update state, backpropagates the final error through that same state, updates both banks, and then queries the updated state:

\[
z^-=P B_1^-k,\qquad
\widehat v=B_2^-z^-,\qquad
e_2=v-\widehat v,\qquad
\mathcal L_{\mathrm{TTT}}=\frac12\|e_2\|_2^2,
\]

\[
e_1=P^\dagger(B_2^-)^\dagger e_2.
\]

Here \(\dagger\) is the complex adjoint; the reverse shuffle is \(P^\dagger=P^{-1}\). Bank 1 receives input \(k\) and error \(e_1\). Bank 2 receives the **saved old-state prediction \(z^-\)** and error \(e_2\). Both coefficient gradients are evaluated at \((B_1^-,B_2^-)\). In particular, neither an updated Bank 2 nor the updated query output may replace the old quantities in the gradient calculation.

For a local lane, the calibrated native coefficient representation is

\[
B_{a}(u)=c\sum_{m=0}^{R-1}H(b_m)H(\overline{a_m})u,
\qquad K=R=64,\qquad c=\frac1{128}.
\]

The \(b_m\) are fixed reference partners, and the stored \(a_m\) are generally complex. With local input \(u_j\) and backpropagated error \(r_j\), the descent update in these stored coordinates is

\[
a_{j,m}^{+}
 =a_{j,m}^{-}
 +\eta_j c\,u_j*
   \left[H(b_{j,m})\,\overline{r_j}\right],
\]

where \(*\) is full linear convolution over frequency indices,
\((u_1,r_1)=(k,e_1)\), and
\((u_2,r_2)=(z^-,e_2)\), restricted to the corresponding lane. The expression uses the real-gradient convention for the real and imaginary parts of \(a\); an alternative Wirtinger step-size convention can absorb a factor of two into \(\eta_j\). Optical conversion phases, tap amplitudes, and injection gains must realize this calibrated update. No temporal sum over \(m\) is applied to the individual coefficient gradients.

This is gradient descent in the **native stored coefficients**. An unconstrained dense-factor update followed by re-encoding generally uses a different parameter-space metric and cannot silently replace it. The fixed partner family must supply the intended matrix coverage with acceptable conditioning.

If algorithmic retention is included, define the pre-update coefficients first, for example \(a_j^-=\alpha_j a_{j,\mathrm{previous}}^+\), and use that state consistently in prediction, backpropagation, and injection. Apply the selected retention once per logical update. Physical loss compensation during circulation is separate from algorithmic forgetting.

**Initialization must be nondegenerate.** If both adaptive bank operators are zero, then \(z^-=0\) and \(e_1=0\), so both bank gradients vanish and the joint update cannot leave that state. The former both-banks-zero initialization cannot be carried over from the local-target model. A representable fixed nonzero initialization for at least one bank, or a suitable learned initialization, must be specified and tested. Learned initial-state entries add to the learned parameter count; initialized optical coefficient frames consume storage whether fixed or learned.

The dedicated query hardware then evaluates

\[
y=F_{\theta^+}(q)=B_2^+P B_1^+q.
\]

It uses the **same updated adaptive coefficients**, not an independently trained query memory. The extra reader adds physical computation paths and tap losses, but not a second independent adaptive state. Coefficient routing must supply old Bank 2 to backpropagation before overwrite, and both updated banks to the query reader. Keys, queries, targets, and the old Bank 1 prediction require aligned coherent delays.

The reusable multifunction cell therefore provides forward prediction, reverse error propagation, and a coefficient writer. At each bank, the forward and reverse paths include their temporal accumulators; the per-slot gradient path does not need another accumulator. Bank 1 needs the additional hold time for the final error to return through Bank 2. Full pathway and schedule details belong in the [design point](paper_design_point.md) and [cell pathways](cell_pathways.md).

## Optical activation and electronic layer boundary

The tentative activation preference is **free-space wavelength demultiplexing followed by saturable absorption**, applied after each complete FFN map and its temporal accumulation. SHG depletion remains an alternative. Each of the eight lanes has 64 separately activated wavelength channels: 512 channels per FFN stage, or 1024 if both stages have separate hardware.

The numerical model should use the actual complex-field transfer, for example

\[
\phi(z)=\sqrt{T(|z|^2)}\,e^{i\psi(|z|^2)}z,
\]

with measured or explicitly assumed transmission \(T\) and phase \(\psi\). Saturable absorption becomes more transmissive at high intensity; it does not generally clamp the output field to a constant. Insufficient transmission contrast approaches a linear map, while excessive low-intensity loss can suppress gradients. Do not substitute a signed ReLU or GELU without establishing the corresponding physical transfer.

This preference is a training hypothesis, not a demonstrated comparison on this language model. Optical details and a simulation precedent are recorded in the [activation discussion](paper_design_point.md#physical-engines-and-activation), alongside the [MLP proposal](../hankel_monarch_mlp/README.md). Demultiplexing must isolate the nonlinear channels sufficiently to avoid shared-absorber or nonlinear frequency-mixing effects.

After the updated query read, the head's optical output projection acts **before detection**:

\[
s_{\ell h t}=W^O_{\ell h}y_{\ell h t},\qquad
d_{\ell h t}=\mathcal D(s_{\ell h t}),
\]

\[
x_{\ell+1,t}
 =\operatorname{Norm}_{\ell}\!\left(
 x_{\ell t}+\sum_{h=1}^{16}d_{\ell h t}
 \right).
\]

Here \(\mathcal D(s)\) is the calibrated intensity readout, such as a channelwise detector gain times \(|s|^2\). This is a digital sum of detected head features, not a coherent sum of head amplitudes and not a signed-real-quadrature readout. The entire numerical model must train with this interface. Complex fields and coherent errors are still required inside the optical recurrence; intensity-only detection at the boundary does not make its inner loss an intensity loss.

The diagram labels the final normalization “BatchNorm,” but the normalization choice remains provisional. If BatchNorm is retained, inference uses fixed statistics and the training protocol must avoid future-token information leakage. Token-local RMSNorm is an alternative. The diagram’s digital normalization, residual addition, detection, acquisition, and optical re-encoding all contribute to the layer handoff.

## Learned parameters, encoded coefficients, and adaptive state

One \(512\times512\) two-bank map contains

\[
N_{\mathrm{factor/map}}
 =2\times8\times64^2=65{,}536
\]

complex factor entries, or 131,072 real scalar parameters. This is the structured factor budget, not 262,144 independent dense-matrix entries. It assumes the chosen unbalanced shuffle and block construction; full local factor coverage does not imply an arbitrary dense global map.

The selected unbalanced shuffle is \(\Pi(j,i)=((j+i)\bmod8,i)\), implemented with [MZI interleaver trees and fixed waveguide connections](mzi_shuffle.md). Each source/destination spatial-lane pair has eight intermediate routes. The corresponding \(64\times64\) spatial block of the full map has rank at most eight. This restriction applies to the selected construction; it is not a claim about every Monarch construction. The simulation must implement this permutation explicitly and use its inverse in the ideal adjoint path. Device-aware evaluation must also include the trees' complex transfer, delay, loss, crosstalk and calibration power.

With distinct weights at every logical layer/head:

| Fixed learned component | Complex factor entries | Real scalar parameters |
| --- | ---: | ---: |
| Two FFN maps per head | 50,331,648 | 100,663,296 |
| Separate \(K,Q,V\) maps | 75,497,472 | 150,994,944 |
| Per-head output map \(O\) | 25,165,824 | 50,331,648 |
| **Optical maps: 24 layers × 16 heads × 6 maps** | **150,994,944** | **301,989,888** |
| Tied real 16,000-token embedding/readout | — | 8,192,000 |
| **Selected learned subtotal** | — | **310,181,888** |

The **approximately 310M baseline** counts the real and imaginary parts of each learned optical factor independently. Its tied real embedding and vocabulary readout share one matrix, counted once. Shared fixed reference partners do not add independently learned entries. Gains, gates, normalization, biases if used, and learned initial state if used are additional. Restricting the factors to real values would be a separate model variant, not the convention used for this total.

The earlier alternating pair of learned layer sets is retained as an **optional sharing ablation**. It would reduce the fixed-map subtotal to **12,582,912 complex factor entries, or 25,165,824 real scalar parameters**, while preserving unique heads within each set and separate adaptive state for all 24 layers. Including the same tied embedding/readout gives **33,357,824 real parameters** before other additions. The selected 310M baseline instead uses all 24 distinct layer weight sets. Sharing physical hardware across 24 layers alone does not tie their weights.

The coefficient encoding is larger than the factor-entry count. If the fixed maps are instead trained directly in unconstrained native coefficient coordinates, count those learned coefficients rather than treating the factor-entry subtotal as their trainable parameter count:

| Quantity | Count |
| --- | ---: |
| Native coefficients per local factor | \(64\times127=8,128\), generally complex |
| Local factors per map | \(2\times8=16\) |
| Native coefficients per fixed map | 130,048 |
| Fixed-map native coefficients, all distinct layer/head weights | 299,630,592 |
| Adaptive logical local-cell frames | \(24\times16\times16=6,144\) |
| **Adaptive coefficients per sequence** | **49,938,432 complex** |
| Fixed plus adaptive encoded coefficients | 349,569,024 |

The adaptive factor matrices contain 25,165,824 complex entries; their redundant native coefficient representation contains 49,938,432. Neither count alone establishes equivalence to a dense DeltaNet state or predicts language capability. Physical reference pumps, buffering, optical replicas, and guard slots are additional resources.

One complex64 copy of adaptive state occupies 399,507,456 bytes, **381 MiB per sequence**, before activations, learned weights, gradients, optimizer state, or checkpoints. Naively retaining 512 complete native-state snapshots would require **190.5 GiB**. The smaller parameter budget is intended to make the silicon study more manageable, but does not establish that training fits a local GPU. An appropriate exact implementation, checkpointing/recomputation strategy, and measured runtime/memory are still required.

## Digital implementation and evaluation

1. **Implement a small differentiable reference.** Reduce layers, heads, lanes, and \(K,R\), but preserve the complex native coefficient update, one final target, old-state backward propagation, updated-state query, actual activation transfer, and intensity boundary. Check the joint update and outer gradients against finite differences or automatic differentiation in real/imaginary coordinates.
2. **Check state identity and causality.** Each logical layer/head/bank owns its state. Compare streaming inference and reordered batching only when they preserve all data dependencies. Verify sequence resets, continuation across chunks, and any retention gates.
3. **Validate operator coverage and calibration.** Test the selected fixed-comb family’s rank and conditioning. The earlier real fixed-partner construction does not by itself validate the selected phase-ramp family. Include \(c=1/128\) and all declared optical gain compensation consistently.
4. **Build a practical silicon implementation.** Exploit Hankel/convolution structure without materializing enormous transition matrices. Compare outputs and gradients with the sequential reference. Training runtime and memory establish feasibility of the digital study, but training speed is not a paper contribution.
5. **Establish language quality before scaling deliberation.** Match tokenizer, data, token budget, context length, and optimizer policy to relevant baselines. Report language loss, retrieval, head specialization, retention, and task performance. Study extra internal steps separately from ordinary next-token prediction.
6. **Simulate hardware deviations.** Add loss, gain error, phase noise, conversion nonuniformity, filter leakage, finite update precision, read-tap effects, and drift/calibration schedules. Separate ideal structured-model quality from physical-error degradation.

The **joint two-bank recurrence is not an affine recurrence in the combined state**: each bank's gradient depends on both banks, and the complete update must preserve that dependence. Earlier notes on the conditional affinity of a single locally trained bank or on chunk interactions do not establish an exact parallel scan for this model. Using an unmodified DeltaNet kernel, detaching state at every token, freezing the other bank's state, or evaluating gradients over a frozen chunk changes the algorithm unless equivalence is separately proved. Mini-batch TTT can be a deliberate alternative, but it must be defined consistently in training, inference, and timing.

## Inference timing and unresolved conditions

The latest **illustrative dedicated-query schedule** gives **30.72 ns per logical layer**, or **737.28 ns for 24 layers**, before additional unhidden propagation, acquisition, digital handoff, normalization, re-encoding, and vocabulary feedback. The two FFN maps plus parallel \(K,Q,V\) projections take 3.84 ns; the 16-head recurrent/query schedule remains 25.60 ns; the output projection adds 1.28 ns. This corresponds to about **1.36M complete model passes/s** under those assumptions, not tens of millions of validated autoregressive tokens/s. See the [design point](paper_design_point.md) for the calculation, the unchanged 5.12 ns prediction-to-query offset, and assumptions about separate fixed-map engines. Halving spatial lanes does not halve the local 64-term temporal accumulation time.

A coefficient ring matched to that full pass is approximately **147–150 m per loop**, subject to the actual coefficient-band fiber group velocity and subtraction of delay already provided by other loop components. At representative \(n_g=1.47\), the estimate is 150.36 m per ring. The selected recurrent layout has **16 independent bank/lane loops**, about **2.41 km in aggregate** at this illustrative delay. Each loop still carries 384 distinct logical layer/head frames. Separate query hardware does not remove the need for correctly placed old-state, write, and updated-state taps.

Open conditions include the chosen optical nonlinearity and its transfer curve; normalization; gates and initial state; the selected MZI shuffle's physical transfer and coherent adjoint implementation; actual propagation and electrical interface delays; coefficient-band gain, phase stability and dispersion; and whether all fixed maps receive separate hardware. The nominal schedule is a target for those checks, not a demonstrated system. Update the historical block diagram to the selected two-stage FFN and eight spatial lanes.

## Published and historical comparisons

The public [DeltaNet 1.3B configuration](https://huggingface.co/fla-hub/delta_net-1.3B-100B/raw/main/config.json) uses 24 layers, width 2048, 16 heads, and unit key/value expansion: 128-dimensional keys/values per head and \(24\times16\times128^2=6,291,456\) recurrent matrix entries. Its untied embeddings and dense architecture require actual parameter accounting for a fair comparison. The [Gated DeltaNet experimental setup](https://arxiv.org/html/2412.06464v1#S4) and [TTT experiments](https://arxiv.org/html/2407.04620v3#A3) provide research comparators; their results do not establish performance for this structured recurrence.

Earlier repository baselines used 512-dimensional optical heads, four simultaneous physical heads, separate local targets, and a dense electronic SwiGLU wrapper of roughly 1.25B–1.9B parameters. A later sharing proposal imposed a 10M optical-weight cap. Those are historical alternatives, superseded by the architecture specified here; older local-target code and timing checks must not be presented as validation of the current joint-update, dedicated-query model.
