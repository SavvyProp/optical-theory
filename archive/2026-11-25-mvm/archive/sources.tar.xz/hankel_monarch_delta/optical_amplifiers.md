# Amplification after the Hankel multiplier

Component literature and design implications · 16 November 2026

**Scope update:** output amplification is now treated as an assumed interface. The active component question is [gain and variable retention in the coefficient-memory loop](coefficient_loop_gain.md). The telecom-band comparison below remains background and does not specify an amplifier for the stored P-band coefficients.

This note investigates amplification of the coherent output of a full Hankel multiplier, after its temporal accumulator. The existing component stack is SiN routing/delays plus thin-film lithium niobate (TFLN) nonlinear sections on a silicon substrate. Signal-band centers and comb spacing remain unspecified. The comparison below assumes output band A is near telecom wavelengths, approximately 1.55 μm. It does not select an amplifier for the stored coefficient comb in the sum-frequency pump band P, which could instead lie near 750–800 nm.

The paper remains an inference architecture and digital simulation study: train on silicon and transfer learned weights to the proposed device. Experimental amplifier papers supply component precedents; no physical experiment is added to this project's scope.

## Provisional selection

Prioritize two alternatives: a **phase-insensitive TFLN parametric amplifier** for broad bandwidth and low added noise on the existing nonlinear material platform, and a **heterogeneously integrated III–V semiconductor optical amplifier (SOA)** for a very short, electrically pumped gain section. Erbium-doped LN or SiN waveguides provide another credible option when their longer propagation delay is acceptable. No source below demonstrates this complete 64-channel Hankel/TTT system.

| Component precedent | Reported gain and operating details | Gain-section length | Estimated gain-section transit |
| --- | --- | ---: | ---: |
| [Haq et al., micro-transfer-printed III–V/SOI SOA, LPR 2020](https://doi.org/10.1002/lpor.201900364) | Two designs: 23 dB small-signal gain / 9.2 mW saturation power, or 17 dB / 15 mW; approximately 30 nm 3-dB gain width at 120 mA; estimated noise around 7–9 dB at cited operating points | 1.35 mm | 18 ps, assuming group index 4 |
| [Dean et al., TFLN parametric amplifier, Nature 2026](https://www.nature.com/articles/s41586-025-09959-z) | 12 dB phase-insensitive on-chip net gain below 200 mW coupled fundamental pump; 23 dB at 450 mW; 110 nm gain bandwidth; approximately quantum-limited phase-insensitive noise | 9 mm nonlinear section | 66 ps, assuming group index 2.2 |
| [Wang et al., Er:TFLN, Nature Communications 2025](https://www.nature.com/articles/s41467-025-65460-1) | 38 dB internal net gain at 1531.7 nm; over 20 dB across most of 1530–1565 nm; 4.7 dB noise figure | 9.16 cm | 0.67 ns, assuming group index 2.2 |
| [Bao et al., large-mode-area Er:TFLN, LPR 2025](https://doi.org/10.1002/lpor.202400765) | 113 mW on-chip output at 16 dB net gain with 210 mW on-chip pump; 7.1 dB fiber-to-fiber noise figure | 7 cm | 0.51 ns, assuming group index 2.2 |
| [Liu et al., Er:SiN, Science 2022](https://doi.org/10.1126/science.abo2631) | Approximately 30 dB on-chip small-signal net gain; 145 mW on-chip output at a separate higher-input operating point; demonstrated soliton-comb amplification | 21 cm main device; also 50 cm | 1.4 ns; 3.3 ns, assuming group index 2 |

Transit estimates are calculated as group index × optical path length / vacuum light speed. They exclude transitions, routing, filters, and any additional dispersion or resonance delay. Reported maximum gain, output power, noise, and bandwidth are not necessarily obtained simultaneously. On-chip, internal, and fiber-to-fiber quantities have different reference planes.

## What the demonstrations establish

**III–V SOAs.** Haq's devices establish transferable, electrically driven gain on SOI, not direct integration of that exact design into our SiN/TFLN stack. The [full paper](https://www.photonics.intec.ugent.be/download/pub_4562.pdf) reports gain/noise characterization but does not validate our multitone waveform. A separate [Van Gasse et al. Optics Express 2019 device](https://doi.org/10.1364/OE.27.000293) achieved 27 dB small-signal gain and output above 50 mW in a 1.45 mm hybrid III–V/silicon device, using approximately 540 mW electrical power. These are strong short-path precedents. Saturation, carrier-dependent phase changes, and channel interactions still require an operating-point model.

**TFLN parametric amplification.** Dean's design recirculates the second-harmonic pump while the signal/idler traverse once. Its headline phase-sensitive gain is not the arbitrary-complex gain used in the table. The measured spectrum has a few-dB ripple from facet reflections; a broad gain window is not a flat complex response. The [author manuscript](https://arxiv.org/html/2509.26425v1) distinguishes these operating modes and documents pump/coupling reference planes. Pump resonance need not impose signal storage, provided the pump is continuously established.

**Erbium-doped LN.** Wang's device also demonstrates 50 Gb/s OOK with integrated modulation. Its greater-than-14-dBm output capability uses a zero-net-gain definition of saturation, so it must not be substituted for a conventional 3-dB compression power. Bao's higher-power design occupies roughly 1 × 1 cm²; its fiber-to-fiber noise includes coupling losses. The [Bao author manuscript](https://arxiv.org/pdf/2405.16583) is useful for those details. Neither work establishes flat, distortion-free amplification of 64 independently encoded complex channels.

**Erbium-doped SiN.** Liu's [author manuscript](https://arxiv.org/html/2204.02202v2) demonstrates amplification of both 19.8 GHz and 100 GHz soliton combs, making it particularly relevant to coherent multichannel signals. The measured noise figure is about 7 dB including input coupling; the high-output point uses approximately 245 mW coupled pump. Its small spiral footprint should not obscure its centimetres-long optical path.

Additional useful comparisons:

- [Osornio-Martinez et al., Optics Express 2025](https://ris.utwente.nl/ws/portalfiles/portal/497855705/oe-33-11-23491.pdf): Er:Al₂O₃ integrated on SiN TriPleX, 16.33 dB internal net gain, 23.5 mW on-chip output, approximately 3.1 dB internal noise figure, and approximately 80 nm positive-net-gain width. The 30 cm path and 691 mW coupled pump are less attractive for this latency target. Positive gain across 80 nm does not mean constant 16 dB gain across it.
- [Kuznetsov et al., Nature 2025](https://www.nature.com/articles/s41586-025-08666-z): GaP parametric amplifier, 5.55 cm path, up to 35 dB parametric gain and greater than 10 dB fiber-to-fiber net gain over about 140 nm. It demonstrates coherent QPSK and comb amplification, but introduces another material and uses approximately 4 W external pump at high gain. Its comb measurements explicitly show additional four-wave-mixing products.
- [Riemensberger et al., Nature 2022](https://www.nature.com/articles/s41586-022-05329-1): continuous traveling-wave SiN parametric gain with a metre-scale path. Its reported group index 2.08 implies about 6.9 ns propagation per metre, making it a poor starting point for repeated low-latency stages despite a small chip footprint.

## Requirements imposed by the Hankel output

### Preserve complex values

A useful small-signal model is

\[
E_{j,\mathrm{out}}=g_jE_{j,\mathrm{in}}+n_j+\delta_j(\mathbf E),
\qquad g_j=\sqrt{G_j}\,e^{i\phi_j}.
\]

G is power gain, g is field gain, n is added optical noise, and delta represents signal-dependent distortion or mixing. Stable spectral amplitude/phase variation can be included in calibration and digital training. Input-dependent gain or mixing changes the operator and cannot generally be removed by one fixed scalar calibration.

A degenerate phase-sensitive amplifier amplifies one field quadrature and deamplifies the other. For our generally complex state, select phase-insensitive operation unless a separate encoding construction is provided. A nondegenerate parametric amplifier couples signal and idler: its classical mean contains terms proportional to E_signal and the complex conjugate of E_idler. Keep the idler input unoccupied by independent vector entries and remove generated idlers before subsequent computation. Spontaneous noise remains even with an empty idler input. The [linear-amplifier noise analysis by Caves](https://doi.org/10.1103/PhysRevD.26.1817) and the [phase-preserving amplifier formulation](https://doi.org/10.1103/PhysRevA.86.063802) explain why gain does not noiselessly restore numerical precision.

For a frequency comb, locate the entire signal band on a suitable side of parametric degeneracy and reserve spectral space for idlers and pumps. The quoted full gain bandwidth is not automatically the usable width for independently encoded signal channels.

### Cover the occupied spectrum

For K=64 teeth spaced by delta-nu, the carrier span is 63 × delta-nu, before modulation sidebands. Near 1550 nm this is approximately:

| Tooth spacing | Carrier span | Approximate wavelength span |
| ---: | ---: | ---: |
| 50 GHz | 3.15 THz | 25.2 nm |
| 100 GHz | 6.30 THz | 50.5 nm |

These are examples, not selected spacings. A 30–35 nm gain window does not cover the second example uniformly. Conversely, positive gain over a wide interval does not establish usable gain, phase flatness, or noise across every tooth. Spacing must also satisfy the delay-lattice phase conditions: the existing simple alignment construction uses integral delta-nu × slot-duration. Changing spacing to fit an amplifier can require revisiting those conditions.

### Remain linear under the full comb

Use total power across all teeth, their temporal beating, and out-of-window transients when checking gain compression. For K equal, phase-aligned tones, the peak-to-average power ratio can reach K; for 64 tones this is 18.1 dB. This arithmetic does not directly turn a CW saturation power into a pulse-power limit: pulse energy and amplifier gain dynamics also matter.

Carrier or excited-state recovery time is distinct from optical transit time. A continuously pumped amplifier can pass modulation much faster than its population recovery if the signal does not appreciably perturb its gain. Under saturation, recovery can instead couple successive frames. An optical gain-bandwidth number also does not by itself establish the temporal fidelity of the modulated comb.

A valid plateau shorter than the amplifier's propagation delay is not inherently a problem: the waveform can be delayed intact. The latency must still appear on the autoregressive critical path. Amplifier turn-on or gain switching is not required every coefficient slot in this proposal.

### Account for noise and actual required gain

Amplification increases signal power but also propagates existing noise and adds new noise. Include the amplifier noise over the accepted optical modes/temporal bandwidth in the digital inference study. Use the cascade's actual gains and losses rather than simply adding every noise figure in dB. Filters must reject pumps, idlers, and unnecessary noise without removing required signal sidebands.

The reader's 1/128 field coefficient does not independently establish a required 42.1 dB amplifier. A field gain of 128 would indeed undo that mathematical scale, but the reader output is a sum of 64 terms. If all terms equal z, its useful output is 64z/128=z/2. Determine gain from the chosen physical encoding, term powers, conversion efficiency, actual losses, required output power, and noise tolerance. Mathematical rescaling does not restore photons or signal-to-noise ratio.

## Placement and simulation baseline

A candidate path is: DFG pair → output-band cleanup → temporal accumulator → amplifier → pump/idler/noise cleanup as needed → shuffle or next interface. This amplifies a completed sum rather than adding separate amplifiers to every pair slot. However, the accumulator still emits invalid transients outside its useful window; downstream acceptance remains necessary, and those transients count toward amplifier loading.

With four physical heads and eight lanes each, amplifying only the final bank's output uses 32 physical gain paths. Amplifying both banks' outputs uses 64. Logical heads and 24 layers reuse those devices. This is separate from any amplifier needed in the coefficient-memory loops. Electrical bias or optical pump power must be multiplied by the installed/active gain paths, rather than quoted only per device.

For the first digital sensitivity study, compare a calibrated linear amplifier with noise against a version with gain compression and cross-channel error. Use literature operating points for each candidate rather than combining the best numbers from different devices. Include additional propagation and filtering in the timing schedule. If amplification changes the prediction used in the local TTT loss, include its calibrated gain in both the residual and gradient path; an unmodeled post-reader gain changes the intended update.

The remaining design inputs are the exact A/B/P bands, comb spacing and sidebands, input and output power per lane, acceptable complex-field error, required gain, and allowed added latency. The literature supports plausible components; these inputs determine which is suitable for this particular multiplier.
