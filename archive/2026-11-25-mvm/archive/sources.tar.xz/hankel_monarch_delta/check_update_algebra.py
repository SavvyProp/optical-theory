"""Numerical checks for two banks with separate local delta / TTT losses.

Run from the repository root::

    python3 hankel_monarch_delta/check_update_algebra.py

Each local block is B(a) = sum_m H(b_m) H(a_m), with fixed partners b_m
and independently stored, adaptive effective coefficients a_m.  The primary
convention here is real, signed field amplitudes.  For e = v - B(a_minus) k,
the coefficient negative gradient is convolution(k, H(b_m) e).  Forgetting
precedes the gradient update; the query read uses the updated state.

Both banks adapt, but each has a separate local loss.  Bank 2 receives the
shuffled output of bank 1; the local update of bank 1 has no dependence on
bank 2.  A whole-sequence computation in layer order must therefore agree
with the streaming computation.  Affinity is conditional on a layer's input
sequence, not a claim that the combined state of the stack is jointly affine.

The checks also distinguish universal fixed-partner coverage from a jointly
adaptive Hankel factorization.  K fixed partners suffice constructively for
an arbitrary K-by-K block.  This is a sufficient construction, not a minimal
slot count.  ceil(K/2) fixed partners cannot be universal for even K by a
parameter-count bound; odd K needs a separate rank argument.

These are small algebra diagnostics, not optical simulation, a trained model,
or an efficient chunkwise implementation.  The script only prints JSON.
"""

from __future__ import annotations

import json

import numpy as np


def hankel(coefficients: np.ndarray) -> np.ndarray:
    size = (coefficients.size + 1) // 2
    assert coefficients.size == 2 * size - 1
    indices = np.arange(size)
    return coefficients[indices[:, None] + indices[None, :]]


def block_matrix(adaptive: np.ndarray, fixed: np.ndarray) -> np.ndarray:
    size = (adaptive.shape[-1] + 1) // 2
    return sum((hankel(b) @ hankel(a) for a, b in zip(adaptive, fixed)),
               np.zeros((size, size)))


def block_apply(adaptive: np.ndarray, fixed: np.ndarray,
                signal: np.ndarray) -> np.ndarray:
    return sum((hankel(b) @ (hankel(a) @ signal)
                for a, b in zip(adaptive, fixed)), np.zeros_like(signal))


def negative_gradient(fixed: np.ndarray, key: np.ndarray,
                      residual: np.ndarray) -> np.ndarray:
    return np.array([np.convolve(key, hankel(b) @ residual) for b in fixed])


def block_step(adaptive: np.ndarray, fixed: np.ndarray, key: np.ndarray,
               target: np.ndarray, alpha: float, eta: float) -> np.ndarray:
    decayed = alpha * adaptive
    residual = target - block_apply(decayed, fixed, key)
    return decayed + eta * negative_gradient(fixed, key, residual)


def coefficient_jacobian(fixed: np.ndarray, key: np.ndarray) -> np.ndarray:
    shape = fixed.shape
    return np.column_stack([
        block_apply(basis.reshape(shape), fixed, key)
        for basis in np.eye(fixed.size)
    ])


def matrix_encoding_jacobian(fixed: np.ndarray) -> np.ndarray:
    return np.column_stack([
        block_matrix(basis.reshape(fixed.shape), fixed).ravel()
        for basis in np.eye(fixed.size)
    ])


def universal_fixed_encoding(target: np.ndarray, mixing: np.ndarray
                             ) -> tuple[np.ndarray, np.ndarray]:
    """Real orthogonal mixing of a telescoping fixed-partner representation.

    For Z the upward shift, set R = target.T - Z target.T Z.T.  Then
    target = sum_j H(e_j) H([R[:, j]; zeros(K-1)]).  Mixing both lists by
    the same orthogonal Q preserves this sum and makes the fixed patterns
    generically dense over their first K lines (remaining K-1 lines zero).
    """
    size = target.shape[0]
    assert target.shape == mixing.shape == (size, size)
    assert np.allclose(mixing.T @ mixing, np.eye(size))
    shift = np.eye(size, k=1)
    difference = target.T - shift @ target.T @ shift.T
    adaptive = np.pad(mixing @ difference.T, ((0, 0), (0, size - 1)))
    fixed = np.pad(mixing, ((0, 0), (0, size - 1)))
    return adaptive, fixed


def bank_apply(adaptive: np.ndarray, fixed: np.ndarray,
               signal: np.ndarray) -> np.ndarray:
    blocks = signal.reshape(adaptive.shape[0], -1)
    return np.concatenate([block_apply(a, b, x)
                           for a, b, x in zip(adaptive, fixed, blocks)])


def bank_step(adaptive: np.ndarray, fixed: np.ndarray, key: np.ndarray,
              target: np.ndarray, alpha: float, eta: float) -> np.ndarray:
    blocks = adaptive.shape[0]
    return np.array([block_step(a, b, k, v, alpha, eta)
                     for a, b, k, v in zip(adaptive, fixed,
                                           key.reshape(blocks, -1),
                                           target.reshape(blocks, -1))])


def bank_matrix(adaptive: np.ndarray, fixed: np.ndarray) -> np.ndarray:
    count = adaptive.shape[0]
    size = (adaptive.shape[-1] + 1) // 2
    matrix = np.zeros((count * size, count * size))
    for index, (a, b) in enumerate(zip(adaptive, fixed)):
        region = slice(index * size, (index + 1) * size)
        matrix[region, region] = block_matrix(a, b)
    return matrix


def shuffle(signal: np.ndarray, count: int, inverse: bool = False) -> np.ndarray:
    source = signal.reshape(count, -1)
    result = np.empty_like(source)
    for fiber in range(count):
        for line in range(source.shape[1]):
            destination = (fiber + line) % count
            if inverse:
                result[fiber, line] = source[destination, line]
            else:
                result[destination, line] = source[fiber, line]
    return result.ravel()


def relative_error(left: np.ndarray, right: np.ndarray) -> float:
    return float(np.linalg.norm(left - right)
                 / max(1.0, np.linalg.norm(left), np.linalg.norm(right)))


def local_checks(rng: np.random.Generator) -> dict:
    size, slots = 4, 3
    adaptive = rng.normal(size=(slots, 2 * size - 1)) / 5
    fixed = rng.normal(size=adaptive.shape) / 5
    key, target, other_key = rng.normal(size=(3, size))
    residual = target - block_apply(adaptive, fixed, key)
    gradient = negative_gradient(fixed, key, residual)
    step = 1e-6
    errors = []
    for index in np.ndindex(adaptive.shape):
        direction = np.zeros_like(adaptive)
        direction[index] = step
        plus = target - block_apply(adaptive + direction, fixed, key)
        minus = target - block_apply(adaptive - direction, fixed, key)
        numerical = (plus @ plus - minus @ minus) / (4 * step)
        errors.append(abs(numerical + gradient[index])
                      / max(1.0, abs(numerical), abs(gradient[index])))
    finite_difference_error = float(max(errors))
    assert finite_difference_error < 1e-7

    jacobian = coefficient_jacobian(fixed, key)
    jacobian_error = relative_error(gradient.ravel(), jacobian.T @ residual)
    assert jacobian_error < 1e-12

    other = rng.normal(size=adaptive.shape) / 5
    alpha, eta, weight = 0.93, 0.04, 0.37
    update = lambda a: block_step(a, fixed, key, target, alpha, eta)
    affine_error = relative_error(update(weight * adaptive + (1 - weight) * other),
                                  weight * update(adaptive) + (1 - weight) * update(other))
    explicit = (alpha * (np.eye(adaptive.size) - eta * jacobian.T @ jacobian)
                @ adaptive.ravel() + eta * jacobian.T @ target)
    explicit_error = relative_error(update(adaptive).ravel(), explicit)
    assert max(affine_error, explicit_error) < 1e-12

    kernel = jacobian @ coefficient_jacobian(fixed, other_key).T
    scalar_identity = np.trace(kernel) / size * np.eye(size)
    nonscalar_fraction = float(np.linalg.norm(kernel - scalar_identity)
                               / np.linalg.norm(kernel))
    assert nonscalar_fraction > 0.01
    return {"negative_gradient_finite_difference_error": finite_difference_error,
            "negative_gradient_jacobian_error": jacobian_error,
            "affine_mixture_error": affine_error,
            "explicit_affine_transition_error": explicit_error,
            "cross_token_kernel_nonscalar_fraction": nonscalar_fraction}


def sequence_checks(rng: np.random.Generator) -> dict:
    count, size, slots, length = 3, 3, 3, 9
    dimension = count * size
    shape = (count, slots, 2 * size - 1)
    fixed1, fixed2 = rng.normal(size=(2, *shape)) / 4
    initial1, initial2 = rng.normal(size=(2, *shape)) / 10
    keys, queries, targets1, targets2 = rng.normal(size=(4, length, dimension)) / 2
    alphas = rng.uniform(0.9, 0.99, size=(length, 2))
    rates = rng.uniform(0.01, 0.04, size=(length, 2))

    first, second = initial1.copy(), initial2.copy()
    streamed_first, streamed_second, streamed_outputs = [], [], []
    product_errors = []
    for time in range(length):
        first = bank_step(first, fixed1, keys[time], targets1[time],
                          alphas[time, 0], rates[time, 0])
        middle = shuffle(bank_apply(first, fixed1, queries[time]), count)
        second = bank_step(second, fixed2, middle, targets2[time],
                           alphas[time, 1], rates[time, 1])
        output = bank_apply(second, fixed2, middle)
        product_read = bank_matrix(second, fixed2) @ shuffle(
            bank_matrix(first, fixed1) @ queries[time], count)
        product_errors.append(relative_error(output, product_read))
        streamed_first.append(first.copy())
        streamed_second.append(second.copy())
        streamed_outputs.append(output)

    first = initial1.copy()
    layered_first, middles = [], []
    for time in range(length):
        first = bank_step(first, fixed1, keys[time], targets1[time],
                          alphas[time, 0], rates[time, 0])
        layered_first.append(first.copy())
        middles.append(shuffle(bank_apply(first, fixed1, queries[time]), count))
    second = initial2.copy()
    layered_second, layered_outputs = [], []
    for time in range(length):
        second = bank_step(second, fixed2, middles[time], targets2[time],
                           alphas[time, 1], rates[time, 1])
        layered_second.append(second.copy())
        layered_outputs.append(bank_apply(second, fixed2, middles[time]))

    errors = {"first_bank_trajectory_error": relative_error(
                  np.array(streamed_first), np.array(layered_first)),
              "second_bank_trajectory_error": relative_error(
                  np.array(streamed_second), np.array(layered_second)),
              "output_trajectory_error": relative_error(
                  np.array(streamed_outputs), np.array(layered_outputs)),
              "monarch_product_read_error": max(product_errors),
              "shuffle_inverse_error": relative_error(
                  shuffle(shuffle(queries[0], count), count, inverse=True), queries[0])}
    assert max(errors.values()) < 1e-12
    return {"tokens": length, "blocks_per_bank": count, "block_size": size, **errors}


def coverage_checks(rng: np.random.Generator) -> list[dict]:
    results = []
    for size in (1, 2, 3, 4, 6):
        mixing, _ = np.linalg.qr(rng.normal(size=(size, size)))
        target = rng.normal(size=(size, size))
        adaptive, fixed = universal_fixed_encoding(target, mixing)
        encoding_error = relative_error(block_matrix(adaptive, fixed), target)
        rank = int(np.linalg.matrix_rank(matrix_encoding_jacobian(fixed)))
        assert encoding_error < 1e-12 and rank == size * size
        compact_slots = (size + 1) // 2
        compact_fixed = rng.normal(size=(compact_slots, 2 * size - 1))
        compact_rank = int(np.linalg.matrix_rank(matrix_encoding_jacobian(compact_fixed)))
        if size % 2 == 0:
            assert compact_rank < size * size
        results.append({"block_size": size, "constructive_fixed_slots": size,
                        "encoding_error": encoding_error, "encoding_map_rank": rank,
                        "full_matrix_dimension": size * size,
                        "ceil_half_fixed_slots": compact_slots,
                        "ceil_half_parameter_count": compact_fixed.size,
                        "ceil_half_random_encoding_map_rank": compact_rank})
    return results


def alternating_global_nonaffinity() -> float:
    """Sequential coordinate steps do not make a shared global loss affine."""
    def step(state: np.ndarray) -> np.ndarray:
        p, q = state
        key, target, rate = 0.8, -0.4, 0.1
        p = p + rate * q * key * (target - q * p * key)
        q = q + rate * p * key * (target - q * p * key)
        return np.array([p, q])

    left, right = np.array([0.5, 0.9]), np.array([-0.3, 0.4])
    weight = 0.37
    mismatch = relative_error(step(weight * left + (1 - weight) * right),
                              weight * step(left) + (1 - weight) * step(right))
    assert mismatch > 1e-4
    return mismatch


def main() -> None:
    rng = np.random.default_rng(20261114)
    report = {"scope": "real-amplitude algebra; no physical or ML validation",
              "local_update": local_checks(rng),
              "streaming_vs_layer_order": sequence_checks(rng),
              "fixed_partner_coverage": coverage_checks(rng),
              "alternating_global_loss_affine_mixture_failure": alternating_global_nonaffinity()}
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
