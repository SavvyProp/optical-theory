"""Check the ideal single-lattice, optically timed full-Hankel reader.

Run from the repository root::

    python3 hankel_monarch_delta/check_single_lattice.py
    python3 hankel_monarch_delta/check_single_lattice.py --output \
        hankel_monarch_delta/results/single_lattice_checks.json

The baseline uses R=32 ten-picosecond coefficient slots, one six-stage
balanced binary lattice (64 taps), and a 640 ps frame period. The shared
b_m reference has a 320 ps amplitude burst followed by 320 ps of darkness.
There is no input router, output router, or output shutter. Adaptive a_m is
nonzero throughout: DFG1 continues generating B-band light between useful
windows; the absence of b_m prevents DFG2 from converting it into A-band
terms that would contaminate the lattice.

This script propagates complete complex-field waveforms through two full
Hankel readers, a wavelength-preserving lane shuffle, and a nonzero link
delay. Only final observations select output windows. It also demonstrates
failures from insufficient frame spacing, a phase-only reference that never
turns off, and a finite reference tail. No FIR is reset between frames.

The model assumes perfect timing, slot-filling comb envelopes, ideal band
selection, matched comb phases, and equal lossless delay paths. In particular,
the intermediate B-band filter must reject the original A-band input and
residual adaptive pump; otherwise light can bypass the reference gate.
Conversion efficiency, pump depletion, dispersion, finite edges, noise, and
filter extinction are not device-validated. The cadence is for reader frames,
not complete recurrent token updates. The PIC is passive in the sense of
having no local electrical switching; externally timed optical pumps remain.

NumPy is required. JSON is printed; files are written only with --output.
"""

from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass
import json
from pathlib import Path

import numpy as np

if __package__:
    from .check_binary_multiplier import (
        binary_filter, complex_normal, max_error, network_description,
        normalized_complex_gradient_check, paired_terms,
        uniform_filter_reference, wavelength_shuffle,
    )
else:
    from check_binary_multiplier import (
        binary_filter, complex_normal, max_error, network_description,
        normalized_complex_gradient_check, paired_terms,
        uniform_filter_reference, wavelength_shuffle,
    )


@dataclass(frozen=True)
class Schedule:
    terms: int = 32
    slot_ps: float = 10.0
    samples_per_slot: int = 2

    @property
    def taps(self) -> int:
        return 2 * self.terms

    @property
    def frame_period(self) -> int:
        return self.taps

    @property
    def output_offset(self) -> int:
        return self.terms

    @property
    def sample_ps(self) -> float:
        return self.slot_ps / self.samples_per_slot

    def samples(self, slots: int) -> int:
        return slots * self.samples_per_slot

    def validate(self) -> None:
        if not isinstance(self.terms, int) or self.terms < 2:
            raise ValueError("terms must be an integer of at least two")
        if self.terms & (self.terms - 1):
            raise ValueError("terms must be a power of two for balanced binary stages")
        if not np.isfinite(self.slot_ps) or self.slot_ps <= 0:
            raise ValueError("slot_ps must be finite and positive")
        if not isinstance(self.samples_per_slot, int) or self.samples_per_slot < 1:
            raise ValueError("samples_per_slot must be a positive integer")


def observe(field: np.ndarray, frames: int, schedule: Schedule,
            start: int = 0) -> np.ndarray:
    """Observe completed outputs only after the full waveform has propagated."""
    burst = schedule.samples(schedule.terms)
    period = schedule.samples(schedule.frame_period)
    offset = schedule.samples(schedule.output_offset)
    return np.array([field[start + frame * period + offset:
                           start + frame * period + offset + burst]
                     for frame in range(frames)])


def continuous_sum_check(rng: np.random.Generator, schedule: Schedule) -> dict:
    frames, lanes, lines = 9, 3, 4
    terms = complex_normal(rng, (frames, schedule.terms, lanes, lines))

    def propagate(period_slots: int) -> np.ndarray:
        horizon = schedule.samples((frames - 1) * period_slots
                                   + schedule.taps + schedule.terms)
        incoming = np.zeros((horizon, lanes, lines), dtype=complex)
        burst = schedule.samples(schedule.terms)
        for frame in range(frames):
            start = schedule.samples(frame * period_slots)
            incoming[start:start + burst] = np.repeat(
                terms[frame], schedule.samples_per_slot, axis=0)
        physical = binary_filter(incoming, schedule.taps, schedule.samples_per_slot)
        reference = uniform_filter_reference(incoming, schedule.taps,
                                             schedule.samples_per_slot)
        assert max_error(physical, reference) < 1e-12
        return physical

    filtered = propagate(schedule.frame_period)
    expected = terms.sum(axis=1) / schedule.taps
    error = max_error(observe(filtered, frames, schedule), expected[:, None])
    assert error < 1e-12

    impulse = np.zeros((schedule.samples(schedule.taps + 1), 1), dtype=complex)
    impulse[0] = 1
    response = binary_filter(impulse, schedule.taps, schedule.samples_per_slot)
    ideal = np.zeros_like(response)
    ideal[:schedule.samples(schedule.taps):schedule.samples_per_slot] = 1 / schedule.taps
    tap_error = max_error(response, ideal)
    assert tap_error < 1e-14

    # A single FIR cannot accept the next term burst while the current sum is
    # being read. Keep the requested observation offset, and explicitly show
    # the mixing when bursts arrive at the dual-lattice ideal cadence.
    fast = propagate(schedule.terms)
    burst = schedule.samples(schedule.terms)
    fast_observed = np.array([
        fast[schedule.samples(frame * schedule.terms + schedule.output_offset):
             schedule.samples(frame * schedule.terms + schedule.output_offset) + burst]
        for frame in range(frames)
    ])
    contamination = max_error(fast_observed, expected[:, None])
    assert contamination > 1e-3
    return {
        "frames_without_reset": frames,
        "sample_interval_ps": schedule.sample_ps,
        "balanced_coupler_graph_impulse_max_abs_error": tap_error,
        "continuous_stream_normalized_sum_max_abs_error": error,
        "normalization": 1 / schedule.taps,
        "insufficient_frame_spacing_negative_control": {
            "frame_period_ps": schedule.terms * schedule.slot_ps,
            "useful_output_contamination_max_abs": contamination,
            "contamination_detected": True,
        },
    }


def pump_waveforms(adaptive: np.ndarray, fixed: np.ndarray, horizon: int,
                   start: int, schedule: Schedule
                   ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Nonzero a and ungated b sequences, plus a separately modeled b envelope."""
    frames, lanes, _, coefficients = adaptive.shape
    time = np.arange(horizon)
    period = schedule.samples(schedule.frame_period)
    burst = schedule.samples(schedule.terms)
    frame = np.clip((time - start) // period, 0, frames - 1)
    slot = ((time - start) // schedule.samples_per_slot) % schedule.terms
    a = np.empty((horizon, lanes, coefficients), dtype=complex)
    b = np.empty_like(a)
    for lane in range(lanes):
        a[:, lane] = adaptive[frame, lane, slot]
        b[:, lane] = fixed[lane, slot]
    gate = np.zeros(horizon, dtype=bool)
    for frame_index in range(frames):
        left = start + frame_index * period
        gate[left:left + burst] = True
    assert np.all(np.linalg.norm(a, axis=-1) > 0)
    assert np.all(np.linalg.norm(b, axis=-1) > 0)
    return a, b, gate


def two_dfg(field: np.ndarray, adaptive_pump: np.ndarray,
            reference_pump: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Ideal B-band selection followed by the desired A-band DFG2 output.

    Every temporal sample is evaluated; no input or intermediate time crop is
    applied. The returned B field excludes unconverted input A and residual
    adaptive pump, which the physical intermediate filter must reject.
    """
    lines = field.shape[-1]
    indices = np.arange(lines)[:, None] + np.arange(lines)[None, :]
    b_band = np.einsum("tlij,tlj->tli", adaptive_pump[..., indices], field.conj())
    a_band = np.einsum("tlij,tlj->tli", reference_pump[..., indices], b_band.conj())
    return b_band, a_band


def two_bank_check(rng: np.random.Generator, schedule: Schedule) -> dict:
    frames, lanes, lines = 7, 3, 4
    adaptive = complex_normal(rng, (2, frames, lanes, schedule.terms,
                                    2 * lines - 1)) / 3
    fixed = complex_normal(rng, (2, lanes, schedule.terms, 2 * lines - 1)) / 3
    queries = complex_normal(rng, (frames, lanes, lines))
    period = schedule.samples(schedule.frame_period)
    burst = schedule.samples(schedule.terms)
    horizon = schedule.samples((frames - 1) * schedule.frame_period
                               + schedule.taps + schedule.terms)

    # Hold queries even during the rejected half-frame. Only the b reference
    # envelope is zero there; no zero input assumption hides DFG1 activity.
    query_index = np.minimum(np.arange(horizon) // period, frames - 1)
    query_waveform = queries[query_index]
    first_a, first_b, first_gate = pump_waveforms(
        adaptive[0], fixed[0], horizon, 0, schedule)
    first_B, first_core = two_dfg(query_waveform, first_a,
                                  first_b * first_gate[:, None, None])
    assert np.linalg.norm(first_B[~first_gate]) > 1e-3
    assert np.max(abs(first_core[~first_gate])) == 0
    first_raw = binary_filter(first_core, schedule.taps, schedule.samples_per_slot)
    first_expected = np.array([
        [paired_terms(adaptive[0, frame, lane], fixed[0, lane], queries[frame, lane])
         .sum(axis=0) / schedule.taps for lane in range(lanes)]
        for frame in range(frames)
    ])
    first_error = max_error(observe(first_raw, frames, schedule), first_expected[:, None])
    assert first_error < 1e-12

    # Forward the COMPLETE raw output, including rise/fall transients. The
    # spatial lane shuffle keeps each wavelength unchanged. Delay is a shift
    # of the whole field, not a valid-window extraction.
    link_slots = 13
    link = schedule.samples(link_slots)
    second_start = schedule.samples(schedule.output_offset) + link
    second_horizon = horizon + second_start
    received = np.zeros((second_horizon, lanes, lines), dtype=complex)
    received[link:link + len(first_raw)] = np.array([
        wavelength_shuffle(sample) for sample in first_raw
    ])
    second_a, second_b, second_gate = pump_waveforms(
        adaptive[1], fixed[1], second_horizon, second_start, schedule)

    def propagate_reference(reference: np.ndarray
                            ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        b_band, core = two_dfg(received, second_a, reference)
        filtered = binary_filter(core, schedule.taps, schedule.samples_per_slot)
        return observe(filtered, frames, schedule, second_start), b_band, core

    gated_reference = second_b * second_gate[:, None, None]
    final, second_B, second_core = propagate_reference(gated_reference)
    expected = np.array([
        [paired_terms(adaptive[1, frame, lane], fixed[1, lane],
                      wavelength_shuffle(first_expected[frame])[lane])
         .sum(axis=0) / schedule.taps for lane in range(lanes)]
        for frame in range(frames)
    ])
    error = max_error(final, expected[:, None])
    assert error < 1e-12
    raw_outside = float(np.linalg.norm(received[~second_gate]))
    b_outside = float(np.linalg.norm(second_B[~second_gate]))
    assert raw_outside > 1e-3 and b_outside > 1e-3
    assert np.max(abs(second_core[~second_gate])) == 0

    # Altering only phase cannot enforce zero conversion in rejected windows.
    phase = np.where(second_gate, 1 + 0j, np.exp(0.7j))
    phase_only, _, phase_core = propagate_reference(second_b * phase[:, None, None])
    phase_contamination = max_error(phase_only, final)
    assert phase_contamination > 1e-8

    # A weak one-slot b tail immediately after the first burst contributes
    # unwanted terms to the free-running FIR and changes accepted outputs.
    tail_left = second_start + burst
    tail_right = tail_left + schedule.samples_per_slot
    assert not np.any(second_gate[tail_left:tail_right])
    tailed_reference = gated_reference.copy()
    tailed_reference[tail_left:tail_right] = 0.1 * second_b[tail_left:tail_right]
    tailed, _, tailed_core = propagate_reference(tailed_reference)
    tail_contamination = max_error(tailed, final)
    assert tail_contamination > 1e-8

    return {
        "frames_without_reset": frames,
        "lanes": lanes,
        "comb_lines_per_lane": lines,
        "adaptive_state_changes_between_frames": True,
        "adaptive_pump_nonzero_in_all_slots": True,
        "no_routing_switches_or_output_shutter": True,
        "entire_raw_waveform_consumed_by_next_DFG": True,
        "wavelength_preserving_spatial_shuffle": True,
        "fixed_interconnect_delay_slots": link_slots,
        "fixed_interconnect_delay_ps": link_slots * schedule.slot_ps,
        "second_reference_first_burst_ps": second_start * schedule.sample_ps,
        "second_bank_first_accepted_output_ps": (
            second_start + schedule.samples(schedule.output_offset)) * schedule.sample_ps,
        "first_bank_product_max_abs_error": first_error,
        "two_bank_product_max_abs_error": error,
        "raw_received_field_l2_outside_reference_acceptance": raw_outside,
        "generated_B_band_l2_outside_reference_acceptance": b_outside,
        "generated_A_band_max_abs_outside_reference_acceptance": float(
            np.max(abs(second_core[~second_gate]))),
        "normalization_per_bank": 1 / schedule.taps,
        "phase_only_reference_negative_control": {
            "off_window_phase_radians": 0.7,
            "reference_amplitude_never_zero": True,
            "generated_A_band_l2_outside_acceptance": float(
                np.linalg.norm(phase_core[~second_gate])),
            "useful_output_contamination_max_abs": phase_contamination,
            "contamination_detected": True,
        },
        "finite_reference_tail_negative_control": {
            "tail_field_fraction": 0.1,
            "tail_duration_ps": schedule.slot_ps,
            "generated_A_band_l2_outside_acceptance": float(
                np.linalg.norm(tailed_core[~second_gate])),
            "useful_output_contamination_max_abs": tail_contamination,
            "contamination_detected": True,
        },
    }


def run_checks(schedule: Schedule | None = None) -> dict:
    schedule = schedule or Schedule()
    schedule.validate()
    rng = np.random.default_rng(20261116)
    network = network_description(schedule.taps)
    assert network["balanced_cells"] == (schedule.taps.bit_length() - 1)
    assert network["unequal_cells"] == 0
    differential_delay_ps = (schedule.taps - 1) * schedule.slot_ps
    # Use c≈3e8 m/s and assumed ng=2 to match the design's rounded lengths.
    length_mm = differential_delay_ps * 0.15
    report = {
        "status": "passed",
        "scope": "ideal discrete complex-field algebra and timing; no physical device validation",
        "configuration": {
            **asdict(schedule),
            "taps": schedule.taps,
            "frame_period_slots": schedule.frame_period,
            "output_offset_slots": schedule.output_offset,
            "passive_lattice_count": 1,
            "electrical_routing_MZI_count": 0,
            "output_shutter_count": 0,
        },
        "timing_and_size": {
            "reference_on_ps": schedule.terms * schedule.slot_ps,
            "reference_off_ps": schedule.terms * schedule.slot_ps,
            "frame_period_ps": schedule.frame_period * schedule.slot_ps,
            "ideal_reader_cadence_GHz": 1000 / (schedule.frame_period * schedule.slot_ps),
            "exact_rectangular_envelope_completed_plateau_ps": [
                (schedule.terms - 1) * schedule.slot_ps, schedule.taps * schedule.slot_ps],
            "selected_output_window_ps": [schedule.terms * schedule.slot_ps,
                                          schedule.taps * schedule.slot_ps],
            "binary_network": network,
            "total_differential_delay_ps": differential_delay_ps,
            "assumed_group_index": 2,
            "approximate_differential_waveguide_length_mm": length_mm,
            "length_excludes_common_paths_couplers_bends_and_routing": True,
        },
        "continuous_binary_sum": continuous_sum_check(rng, schedule),
        "two_bank_reference_gated_pipeline": two_bank_check(rng, schedule),
        "normalized_coefficient_gradient": normalized_complex_gradient_check(
            rng, 1 / schedule.taps),
        "physical_assumptions": [
            "b_m amplitude is exactly zero outside each scheduled burst; phase alone is insufficient",
            "a_m remains nonzero, so DFG1 need not be dark during rejected intervals",
            "intermediate B-band filter rejects original A input and residual adaptive pump",
            "slot-filling rectangular comb envelopes, perfect timing, matched phases, equal lossless paths",
            "optical pump generation and distribution are external to the passive reader PIC",
            "reader timing does not specify memory writing, replay, or complete recurrent token latency",
        ],
    }
    small = Schedule(terms=4)
    small.validate()
    report["small_geometry"] = {
        "configuration": asdict(small),
        "continuous_binary_sum": continuous_sum_check(rng, small),
        "two_bank_reference_gated_pipeline": two_bank_check(rng, small),
    }
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="also write the JSON report to this path")
    args = parser.parse_args()
    report = json.dumps(run_checks(), indent=2)
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(report + "\n", encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
