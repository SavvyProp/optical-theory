# Gain and retention in the coefficient-memory loop

Current amplification focus · 16 November 2026

Treat amplification of the multiplier output as an assumed interface for the present architecture study. The component to resolve is amplification of the **stored adaptive Hankel coefficients**: compensate physical circulation loss while controlling the model's retention factor. These coefficients are inference state, distinct from the learned projection/MLP weights trained on silicon.

The [earlier amplifier comparison](optical_amplifiers.md) addresses telecom-band output signals. Its erbium and telecom parametric examples are not direct replacements for a coefficient-loop amplifier at the sum-frequency band P.

## Loop transfer and variable gain

At a fixed reference plane, write one circulation as

\[
a_{s,r+1}=q_{s,r}a_{s,r}
 +\kappa_s g_{\mathrm{write},s}(\Delta a)_{s,r}+\xi_{s,r},
\qquad q_{s,r}=\rho_s h_s u_r.
\]

Here r counts physical laps, s identifies a coefficient frequency, rho is the complex passive loop transfer, h is the complex amplifier transfer, u is the controlled retention multiplier, and xi represents added noise. The passive transfer includes read-tap loss, injection-coupler loss, routing, gates, fiber propagation and phase. The amplifier's power gain is |h|². Phase is already included in rho and h, so it must not be counted twice.

The provisional implementation separates three functions:

| Function | Candidate implementation | Desired behavior |
| --- | --- | --- |
| Compensate unavoidable loss | Steadily biased/pumped gain section with slow stabilization and spectral calibration | rho × h approximately one during storage |
| Apply learned retention | Fast electro-optic amplitude control, for example a balanced push–pull LN Mach–Zehnder element | u=alpha on the selected update visit; u=1 on idle laps |
| Add the TTT update | Calibrated coherent injection of the SFG gradient comb | Add the specified eta-scaled gradient after the intended forgetting operation |

This is variable **net loop gain**, even when the amplifier itself stays at approximately constant bias. It avoids deliberately switching semiconductor carrier density for every frame. Constant bias does not prevent signal-induced gain compression, phase changes or coupling between successive frames: the amplifier must still operate in a sufficiently linear regime.

For passive roundtrip power transmission T=|rho|², loss compensation requires power gain G=1/T after phase calibration. The usual 0≤alpha≤1 forgetting gate then uses power transmission alpha². For example, a 3 dB passive roundtrip loss needs 3 dB of compensation; alpha=0.99 adds approximately 0.0873 dB attenuation on the intended update visit. Extra hardware insertion losses belong in T. If the model deliberately requires alpha>1, provide additional gain headroom and evaluate the resulting state dynamics.

Apply alpha **once per logical token/state update**, not on every passive lap. The existing scalar gate can be held across all 64 slots in a 640 ps coefficient burst and across all 127 coefficient frequencies. It does not require separately programming gain every 10 ps. Frame transitions still need guard time and a specified electrical driver. Per-slot or per-frequency retention would be a different control requirement.

Amplifier and modulator placement can also scale the injected update. Choose a reference plane and calibrate the write coefficient so the physical system implements decay followed by the intended additive correction. Do not assume that changing retention leaves the write path unchanged.

## Correct wavelength and bandwidth

The stored frequencies obey nu_P=nu_A+nu_B. For near-telecom A/B, P is approximately 750–800 nm; exact centers remain unselected. Retaining the current direct-P storage therefore calls for near-visible gain and compatible SiN/LN routing, rather than a C-band erbium amplifier.

There are 127 coefficient teeth, hence 126 frequency intervals. At 100 GHz spacing, the carrier span is 12.6 THz: approximately **25.2 nm around 775 nm**, or **26.9 nm around 800 nm**, before modulation sidebands. At 50 GHz these spans halve, but the delay-lattice phase-alignment conditions must then be reconsidered. Gain, filtering and electro-optic control all need to cover the occupied band.

## Component evidence

| Candidate | Primary-source evidence | What remains to establish |
| --- | --- | --- |
| Near-780-nm semiconductor amplifier | [Innolume's manufacturer table](https://www.innolume.com/innoproducts/semiconductor-optical-amplifiers-soa/) lists a 780 nm device with typical 31 dB small-signal gain, 16 nm 3-dB gain width, 12 dBm saturation output and 6.5 dB noise figure. [Superlum's A785.15.50 specification](https://www.superlumdiodes.com/pdf/A780ST_bst_rev01.pdf) gives typical 23 dB fiber-to-fiber gain and 15 nm width. | These are packaged components, not a completed integrated memory. Their full complex response and noise at the required lower compensation gain must be determined; the example 127-tooth band exceeds their quoted 3-dB widths. |
| GaAs gain integrated with SiN near 800 nm | [Billet et al., LPR 2025](https://doi.org/10.1002/lpor.202500956), [author manuscript](https://arxiv.org/html/2504.16993v1), integrates GaAs coupons with SiN lasers. A 1 mm reflective SOA has over 30 dB internal reflected small-signal gain and over 20 dB across 15 nm. | Reflective coupon gain is not net SiN-to-SiN through-amplifier gain. The study does not supply the required fast variable-gain response, noise figure or repeated multitone storage fidelity. |
| Ti:sapphire-on-insulator | [Yang et al., Nature 2024](https://www.nature.com/articles/s41586-024-07457-2), [author manuscript](https://arxiv.org/abs/2312.00256), demonstrates integrated amplification over 700–950 nm and 17 dB picosecond-pulse enhancement. | A broad-band alternative at the correct wavelengths, but adds a material platform and optical pump. Pulse amplification is not a demonstration of long-lived coefficient storage or fast gain programming. |
| Electro-optic retention element | [Celik et al., Optics Express 2022](https://doi.org/10.1364/OE.460119), [author manuscript](https://arxiv.org/abs/2204.03138), demonstrates an LN-on-sapphire Mach–Zehnder modulator at 780 nm with 2.7 GHz EO bandwidth and 4.2 V full-swing voltage. | Supports fast amplitude-control feasibility at the correct wavelength. Full-comb amplitude/phase response, driver settling, insertion loss and transfer to the proposed stack need a specified design. |

A further [780 nm SOA experiment by Clarke and Gould](https://arxiv.org/html/2110.14684v1) amplifies externally chirped optical pulses with a continuously biased commercial SOA. It supports controlled phase/frequency amplification at the relevant wavelength, but is not evidence for 127-channel storage or sub-nanosecond gain switching.

Do not use the 13 dB GaAs-on-SiN result in [APL 2026, DOI 10.1063/5.0308920](https://doi.org/10.1063/5.0308920) as a 780 nm demonstration: its gain maximum is at 972.5 nm. Likewise, a telecom TFLN parametric amplifier does not establish gain at P without a new pump/phase-matching design. Retaining coefficients in a different band with coherent frequency conversion remains an optional architecture change, not the present baseline.

## Retention is more than power balance

For a simple storage-only model with fixed q, initially noiseless state, and independent zero-mean additive noise of variance sigma² per lap,

\[
\operatorname{Var}(a_N)=\sigma^2\sum_{j=0}^{N-1}|q|^{2j}.
\]

At |q|=1 this becomes N sigma². At |q|<1 it becomes sigma²(1−|q|^(2N))/(1−|q|²), while the original signal also decays. This is an illustrative hold-state model, not a full noisy TTT calculation; phase noise, correlated noise, gain fluctuations and gradient writes add further effects. [Linear-amplifier noise limits](https://doi.org/10.1103/PhysRevD.26.1817) preclude treating phase-preserving gain as noiseless restoration.

Systematic gain errors also accumulate: an uncompensated power-transfer error of +0.01 dB per lap becomes +1 dB after 100 laps. Above-unity loop modes amplify noise toward saturation or oscillation. Saturation can stabilize total power while changing the encoded coefficients, so automatic power clamping is not coefficient refresh. Control unwanted spectral modes as well as the intended teeth.

A useful design study should therefore specify roundtrip loss, complex spectral transfer, linear power/energy range, additive and phase noise per pass, total physical laps across the target context/reasoning interval, and the maximum tolerable coefficient error. Slow stabilization should use suitable pilots or calibration signals; inferring gain correction from arbitrary state-dependent total optical power would itself change the memory rule.

The immediate candidate is a near-visible gain section for physical loss compensation plus an independently controlled EO retention element. The choice between a semiconductor gain section and a broader integrated gain medium should follow the complete coefficient-band and retention-noise budget, rather than maximum one-pass gain.
