# Optical architecture figures

These are standalone editable SVG schematics for the [design document](../README.md). They use native vector shapes and text; no image generation or external assets are required.

The [current paper design point](../paper_design_point.md) selects \(K=R=64\), eight lanes per head, one physically simultaneous head, sixteen head batches and 24 time-multiplexed layers, with two FFN stages per head. It uses one final target with backward error propagation and dedicated query readers. **Figure 05 retains the previous sixteen-lane MZI shuffle and needs an eight-lane redraw. Figure 15 is also historical:** it shows the superseded eight-lane, four-parallel-head, four-die design. Figures 01–04 predate the current joint-error update. Use the current architecture and cell-pathway notes for selected connectivity and timing until those drawings are revised.

Figures 08, 09, 12 and 13 retain the earlier \(K=R=32\), six-stage reader example; figure 14's six-cell table also belongs to that example. The current local reader requires seven binary cells, a 0.64 ns first-valid offset and a 1.28 ns service interval. The old timing, area and die-allocation labels are reference values, not updated specifications.

| Figure | Content |
| --- | --- |
| [01 System](01_system.svg) | The optical core for one selected layer/head: two banks, local memories, and forward shuffle |
| [02 Local update](02_local_update.svg) | Full Hankel prediction, optical error, DFG error multiplication, and full SFG coefficient write |
| [03 Coefficient memory](03_coefficient_memory.svg) | One selected bank frame: direct pump-band storage, read tap, and coherent gradient injection |
| [04 Training schedule](04_training_schedule.svg) | Online update/read order and sequence evaluation in bank order |
| [05 MZI shuffle](05_shuffle.svg) | Historical 16-lane, 64-wavelength cyclic shuffle: 16 demultiplexer trees, 256 static grouped links, 16 multiplexer trees and an expanded four-level MZI tree |
| [06 Head and layer memory](06_head_layer_memory.svg) | Earlier global-ring reference: shared engine, persistent layer/head frames, digital gap, buffers, and later-lap writes |
| [07 Earlier photonic overview](07_photonic_component.svg) | Historical three-section reuse concept; its generic accumulator is superseded by figures 08 and 09 |
| [08 Single-lattice full multiplier](08_binary_multiplier.svg) | R=32 reference for the selected topology: two DFG sections, band filters and one balanced 64-tap lattice; externally timed bₘ bursts accept valid inputs without reader EO routers or an output shutter |
| [09 Single binary lattice and timing](09_binary_lattice_timing.svg) | Six balanced stages, 320 ps generation bursts every 640 ps, raw output transients and the next reader's timed bₘ acceptance window |
| [10 Engineered-margin multiplier](10_margin_multiplier.svg) | Preserved 70-tap variant with unequal two-way couplers, finite routing transitions and timed receiving pump windows |
| [11 Margin synthesis and timing](11_margin_lattice_timing.svg) | Margin-design formula, nested two-way 70-tap network, 400 ps frames, 80 ps selector interval and 35 ps plateau margins |
| [12 Preliminary footprint](12_footprint_budget.svg) | Scaled area reservations inside an illustrative 6 × 2 mm reader die; 8–15 mm² reader planning range, no EO switch corridors and separate unresolved writer controls |
| [13 Single-branch chip floorplan](13_single_branch_floorplan.svg) | Two straight 5 mm DFG rails, band-filter end regions, four functional optical interfaces and six serial spiral-delay cells in a nominal 6 × 2 mm outline |
| [14 Binary delay cell layout](14_binary_delay_cell_layout.svg) | A passive two-coupler, two-arm cell, its selected and discarded ports, field transfer and six-stage differential-length table |
| [15 Four-die layer multiplexing](15_four_die_layer_multiplexing.svg) | Historical: two die pairs, four parallel eight-lane heads, four head batches, 24 time-multiplexed layers and the electronic boundary |

In the earlier functional diagrams, teal denotes optical data, violet denotes coefficient storage or pumps, amber denotes electronic control, and red denotes residual signals. Figure 15 instead labels its memory panels in orange and electronic boundary in violet. Figure 05 uses teal for wavelength-preserving optical routing; its leaf numbers identify wavelength residue groups.

Figure 05 replaced the original three-fiber conceptual shuffle with the then-selected sixteen-lane integrated implementation. Its labels remain historical. The **current eight-lane design** instead uses leaf groups \(\{r,r+8,\ldots,r+56\}\), \(r=0,\ldots,7\), routed from input lane \(b\) to output lane \((b+r)\bmod8\). Each input/output tree has three binary levels and seven elementary MZIs. The complete shuffle has **112 MZIs, 224 couplers and 64 grouped links**, with six MZIs traversed per signal; the illustrative 100 GHz stage imbalances are 5, 2.5 and 1.25 ps. See the [updated MZI specification](../mzi_shuffle.md) for the current route, phase settings and physical caveats. These counts exclude extra flat-top filtering, phase correction and any separately implemented backward router.

The circuit drawings specify functional connectivity, not fabrication geometry. Their delays, loop sizes, waveguide lengths, and port spacing are not to scale. Figure 12 scales rectangular area reservations only. Figure 13 scales the die outline, 5 mm nonlinear lengths and approximate placement, but its tracks, filters, transitions, poling and spiral turns are symbolic. Figure 14 expands one delay cell without a physical scale. None is a routed mask layout. SVG text remains editable in a vector editor.

The [layout notes](../single_branch_layout.md) explain figures 13 and 14. One accumulator branch still contains two arms per delay cell. The six cells have twelve passive couplers and 94.5 mm total differential arm length, with no fast EO switch or output shutter. Local reject terminations do not imply additional packaged ports. The lower row reserves extra space for turns and access; the filter/material-transition fit at the ends of the DFG rails remains unresolved. In these layout figures, red stubs denote rejected light rather than a prediction residual.

Figures 08 and 09 and the [component design](../photonic_component.md) present the selected circuit topology using the earlier R=32 example: one balanced six-stage binary lattice with 64 taps and externally synchronized bₘ pump bursts. The 32 coefficient slots occupy 320 ps, followed by 320 ps with bₘ absent. Accepted output windows last 320 ps and repeat every 640 ps, with field normalization 1/64. The raw output contains unaccepted transients; the next reader accepts only its valid input window through its own bₘ burst. A spectral phase ramp alone does not provide this blanking. Common propagation latency is omitted. The lattice contains 94.5 mm of differential delay waveguide at group index 2; this is not its total waveguide length or footprint. No reader EO router or output shutter is included. The fixed reader optics still consume optical pump power, and memory writing, replay and injection controls remain separate.

Figures 10 and 11 preserve the configurable engineering variant. Its 20% extension example uses two 70-tap networks with nested unequal two-way couplers, giving 390 ps plateaus and 400 ps reader frames. The 35 ps plateau margins remain a design budget to validate, separate from the 50 ps routing transition. These are design schedules, not measured rates or model token rates.

The [single-lattice checker](../check_single_lattice.py) validates the main reader's field summation, frame isolation and chaining with timed bₘ acceptance. It retains the full raw interstage stream, including transients. The [binary checker](../check_binary_multiplier.py) retains the dual-lattice comparison, margin-driven synthesis and normalized gradient checks. Its finite-switching variant uses a raw selector field and explicitly timed receiving pumps. Neither variant establishes device-level loss, dispersion, extinction or timing tolerance.

Figure 06 retains the earlier single-engine global-ring investigation. Figure 15 shows the superseded four-parallel-head arrangement. Neither shows the current separate prediction/update and query readers. The [timing model](../model_memory_schedule.py) checks older conservative global-ring visits and input-readiness constraints; it does not implement the current dedicated-query schedule or establish optical memory fidelity or throughput.

To render a figure locally with Inkscape:

```bash
inkscape hankel_monarch_delta/figures/01_system.svg \
  --export-type=png --export-filename=/tmp/hankel_monarch_system.png
```
