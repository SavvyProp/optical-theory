# Engineering margins for the full Hankel photonic multiplier

Engineering implementation option · 15 November 2026

The [main component description](photonic_component.md) now uses one balanced binary lattice, externally timed reference-pump bursts and no reader routing switches, with a 640 ps ideal read interval. This companion preserves the earlier dual-lattice alternative with configurable margins, two routing MZIs and finite switching budgets. Its 70-tap, 400 ps example is a separate design, not the current baseline. The margin-synthesis mathematics remains useful for future implementations.

The engineering component option is a hybrid silicon-substrate photonic circuit with **two nonlinear DFG sections, fixed band filters, two passive binary delay lattices, and two electro-optic MZI cells for input and output routing**. The dedicated output shutter is removed. The output carries a valid result during a scheduled interval and arbitrary transients outside it; the receiving nonlinear interaction or capture circuit must accept only the valid interval. An optional coefficient writer adds one cross-SFG section and reuses the first DFG in separate write windows. Persistent coefficients circulate in external fiber directly in the nonlinear pump band.

The delay network is now **designed from an explicit plateau-margin requirement**. All splitters remain two-way, but selected couplers have unequal ratios and their cells contain nested delay sections. This permits non-power-of-two tap counts. For a plateau at least 20% longer than a 320 ps input burst, the worked candidate uses **70 equal temporal taps**, giving a **390 ps plateau and 35 ps margin at each edge**. Each lattice contains eight two-arm cells; the reader-frame period remains 400 ps. These are engineering targets to validate against measured envelopes, settling and jitter.

This is a component specification and functional floorplan, not a fabrication-ready mask layout. One component serves one spatial lane of one Monarch bank; an array supplies the other lanes. Heads share their layer's array over time. The wavelength-dependent Monarch shuffle connects arrays and is outside this individual multiplier.

![Shutterless binary-lattice multiplier, receiving-window requirement, optional coefficient writer and material partition](figures/10_margin_multiplier.svg)

## Reference configuration and boundaries

Here \(R\) counts Hankel-pair terms, \(L_F\) counts FIR taps, and \(P\) is the interval between successive reader frames in slot units. \(L_F\) is not the number of neural-network layers, and \(P\) is distinct from optical band P.

| Quantity | Reference choice |
| --- | --- |
| Data channels | \(K\) simultaneous comb teeth; \(K=32\) is an illustrative interface size |
| Coefficients per term | \(2K-1\) simultaneous teeth |
| Hankel-pair terms | \(R=32\) |
| Coefficient slot | \(\tau=10\) ps, a hypothetical timing target |
| Passive accumulators | Two independent lattices, labeled 0 and 1 |
| Plateau design requirement | At least 20% extra total duration around the 320 ps accepted burst |
| Two-arm cells per lattice | 8: five balanced and three with unequal couplers |
| Taps per lattice | \(L_F=70\), selected from the margin requirement |
| Successive reader frame starts | \(P\tau=400\) ps |
| Revisit of the same lattice | \(2P\tau=800\) ps |
| Core operand burst / blank interval | 320 ps / 80 ps |
| Receiver acceptance interval | 345–665 ps relative to its source frame, plus common latency |
| Valid plateau / accepted duration | 390 ps / 320 ps |
| Plateau margin around acceptance | 35 ps before and 35 ps after |
| Ideal field normalization | \(1/70\), before device gains and excess losses |

The \(R=32\) example does not establish the rank or conditioning of the chosen fixed phase-ramp partner family. Its matrix coverage remains an independent model-design question.

The module accepts encoded optical operands, a synchronized reference-comb sequence, and a tapped copy of the optical state. Lasers, arbitrary input encoders, the main fiber memory, long replay buffers, and electronic drivers are package or system resources unless explicitly integrated. Their area and energy are not included in the nonlinear-section count.

## Optical ports and carrier arithmetic

| Interface | Frequencies | Contents |
| --- | --- | --- |
| Data A | \(\omega_A+i\Delta,\ i=0,\ldots,K-1\) | Key, query, target, optical residual and result |
| Intermediate B | \(\omega_B+j\Delta,\ j=0,\ldots,K-1\) | First-DFG idler or transformed residual |
| Coefficient band P | \(\Omega_s=\omega_A+\omega_B+s\Delta,\ s=0,\ldots,2K-2\) | Adaptive \(a_m\), fixed \(b_m\), gradient |
| Timing/control | Electrical reference and local settings | Frame identity, routing, gates, phase/bias trims |
| Discard ports | Isolated optical terminations | Rejected pumps, idlers, unused interferometer outputs and transients |

A and B must be distinguishable bands. Their separation, nonlinear phase matching, modulation sidebands, and unwanted cross/self-SFG products must be designed together. Near-telecom A/B put P approximately around 750–800 nm. Exact wavelengths and poling periods remain device-design parameters.

For the selected-mode, field-bilinear model,

\[
\mathcal D(h,x)=H(h)\overline{x},\qquad H(h)_{ji}=h_{i+j}.
\]

The two read interactions therefore give

\[
u_m=\mathcal D(a_m,x),\qquad
z_m=\mathcal D(b_m,u_m)
    =H(b_m)H(\overline{a_m})x.
\]

The two conjugations restore linearity in \(x\). The ideal normalized reader is

\[
F_{\rm phys}(x)=\frac{1}{L_F}\sum_{m=0}^{R-1}z_m.
\]

The frequency of a first-stage idler is
\(\Omega_s-(\omega_A+i\Delta)=\omega_B+(s-i)\Delta\).
Before filtering, the possible indices extend from \(-(K-1)\) to \(2K-2\): retain only \(j=0,\ldots,K-1\). Apply the corresponding selection after DFG 2 as well.

## Read path, from input to a valid output interval

1. **Input and pump interfaces.** Hold the entire key or query comb over the \(R\)-slot burst. A read tap supplies the matching \(a_m\) slots from fiber memory. A wavelength combiner overlaps A and P at DFG 1. Fixed reference \(b_m\) is supplied from a shared source with a known envelope and selected spectral phase ramp.
2. **DFG 1: A to B.** A traveling-wave periodically poled thin-film LN section produces the first Hankel transform. The persistent memory bypasses this device; only the tapped copy is used.
3. **B-band cleanup.** Remove P, the original A seed, and unwanted B idlers; retain the \(K\)-tooth B comb and its required sidebands.
4. **DFG 2: B to A.** A second pump combiner introduces \(b_m\). The second poled LN section produces the complete two-Hankel term \(z_m\).
5. **A-band cleanup.** Isolate the desired A-band pair result and remove B/P and unwanted idlers.
6. **Input selector \(S_{\rm in}\).** A balanced EO MZI sends the complete \(R\)-slot burst into lattice 0 or 1. Switch only in the blank interval. The inactive lattice must receive no new term burst except finite leakage included in the error budget.
7. **Passive summation.** The selected binary lattice forms delayed replicas and supplies a completed, normalized plateau after its initial transient.
8. **Output selector \(S_{\rm out}\).** A second balanced EO MZI selects the valid lattice; its other output goes to a discard termination. Its selected output goes directly to the next component. During changeover it may contain a coherent mixture of both lattice outputs.
9. **Receiving acceptance.** The next DFG's compute pump is absent outside its scheduled burst. Its B-band cleanup rejects unconverted A light. Other destinations must similarly restrict conversion, capture or injection to the valid interval. This is a receiving-interface requirement, not an additional output shutter.

The B filter's rejection of the original A seed is essential: any A leakage that survives into the final stage occupies the same band as the desired result and cannot be removed by the final A bandpass alone.

Both wavelength filters are assemblies: coarse pump rejection and sharp nearest-idler rejection may need separate devices. No per-tooth demultiplexer is required inside this multiplier.

## Active MZI cells and passive optical filters

Each of the two reader switching cells uses two broadband nominally 50:50 couplers, approximately equal-length arms, and differential Pockels phase control. A hybrid thin-film LN/SiN push–pull implementation is the starting candidate. A differential \(\pi\) phase change exchanges the selected ports. Coherent recombination avoids a fundamental 3 dB selected-port splitting penalty, although real devices have excess loss.

| Cell | Connected inputs | Function |
| --- | --- | --- |
| \(S_{\rm in}\) | Pair-result comb; other input dark | Route the entire frame into lattice 0 or 1 |
| \(S_{\rm out}\) | Both lattice outputs | Select one lattice and discard the other |

A two-input selector cannot guarantee a dark output for arbitrary fields on both inputs. The design accepts that limitation: its output is not blanked during invalid times.

The controller changes the output selector while the receiver is inactive, then leaves it settled throughout the next acceptance window. Bias settings and branch-dependent phase/amplitude offsets are calibrated. Push–pull drive reduces phase chirp, but does not by itself guarantee identical complex transfer across the comb. Input selection changes while the pair-result input is dark.

The temporal lattices use unbalanced interferometers with fixed couplers. They require no slot-rate electrical drive; slow trims may stabilize phase and tap balance. Wavelength cleanup uses fixed spectral-filter assemblies, with apodized contra-directional Bragg filters as one candidate. These functions are separate from the EO gates.

## Receiver acceptance replaces the output shutter

Let \(x_{\rm raw}(t)\) be the unblanked field from the output selector. The next reader's first DFG obeys the ideal relation

\[
u_{\rm next}(t)=H(a_{\rm tap,next}(t))\,\overline{x_{\rm raw}(t)}.
\]

If the compute-tap pump \(a_{\rm tap,next}\) is zero outside the accepted coefficient burst, no desired B idler is generated there. The existing B filter rejects the unconverted A field. The persistent memory bypasses this interaction and keeps circulating; it is not switched off.

This saves a gate only when the receiving pump is already supplied as a suitably confined burst. A continuously illuminated compute pump needs its own access control, with a real driver, loss and extinction budget. Moving a gate to the pump does not make it free. The same rule applies to optical residual processing: invalid residual light may exist, but replay capture, writer conversion and memory injection must not accept it. A sampled detector must also tolerate the out-of-window light without saturation or response tails contaminating its samples.

The assumed 50 ps selector transition takes place while the receiving pump is absent. It is **not** a 50 ps pump turn-on/off allowance. Plateau margins budget arrival error, input settling and the required optical support. Extra converted terms outside the nominal coefficient burst must still be included in the arithmetic model; a longer correct input plateau does not make such terms disappear.

## Binary delay lattice

Let \(D\) delay the coherent envelope by one slot and define the normalized uniform filter

\[
H_n(D)=\frac1n\sum_{r=0}^{n-1}D^r.
\]

For powers of two, the usual cascade is \(H_{2^p}(D)=\prod_{\ell=0}^{p-1}(1+D^{2^\ell})/2\). Requiring every cell to have fixed 50:50 couplers and ordinary power-of-two delays would force a jump from 64 to 128 taps. To make margins selectable more finely, allow these two-path constructions:

\[
H_{2m}(D)=H_2(D)H_m(D^2),
\qquad
H_{2m+1}(D)=\frac1{2m+1}
 +\frac{2m}{2m+1}D\,H_{2m}(D).
\]

The odd-length construction is one two-arm interferometer: a direct arm and a delayed arm containing a smaller filter. Both its input and output couplers use power fractions \(1/(2m+1)\) and \(2m/(2m+1)\). The selected field contributions multiply two coupling amplitudes, giving those same fractions; phase trims align their signs. Unused outputs are terminated. There is no three-way splitter and no free unnormalized addition.

Factorization can improve the largest coupler imbalance:

\[
H_{ab}(D)=H_a(D)H_b(D^a).
\]

For the 70-tap example use

\[
H_{70}(D)=H_2(D)\,H_5(D^2)\,H_7(D^{10}),
\]
\[
H_5(z)=\frac15+\frac45 zH_4(z),\quad H_4(z)=H_2(z)H_2(z^2),
\]
\[
H_7(w)=\frac17+\frac67 wH_6(w),\quad
H_6(w)=H_2(w)H_3(w^2),\quad
H_3(v)=\frac13+\frac23 vH_2(v).
\]

These identities describe nested filters, not eight ordinary first-order stages in series. The unequal two-way coupler power ratios are **1:4, 1:6 and 1:2**. The remaining five cells are balanced.

![Nested two-way delay network, selectable plateau margins and 400 ps frame timing](figures/11_margin_lattice_timing.svg)

At \(\tau=10\) ps and assumed SiN group index \(n_g=2\):

| Product section | Two-arm cells | Inserted differential delays | Differential length |
| --- | ---: | --- | ---: |
| \(H_2(D)\) | 1 | 10 ps | 1.5 mm |
| \(H_5(D^2)\) | 3 | 20, 20, 40 ps | 12 mm |
| \(H_7(D^{10})\) | 4 | 100, 100, 200, 200 ps | 90 mm |
| One lattice | 8 | 690 ps total | 103.5 mm |
| Pair of lattices | 16 | Independent networks | 207 mm |

There are 16 couplers per lattice: ten nominally balanced and six unequal. Both lattices together have 32 passive-filter couplers, separate from the two active routing cells. Compared with 64 taps, the pair adds two cells per lattice and 18 mm total differential waveguide; it avoids the 381 mm delay budget of two standard 128-tap lattices.

Keep the two lattices independent. Fold long arms into low-loss spirals and match bypass paths to the common propagation through nested filters. The tabulated lengths count intentionally inserted delays; additional common-path matching, bends, couplers and access routing remain to be laid out. The longest individual inserted delay is 200 ps, corresponding to 30 mm. Folding saves area but does not shorten a specified delay in seconds.

The delayed carrier phases must add correctly on every tooth. In the nondispersive approximation, choose \(\Delta\nu\tau\) integral and trim the common carrier phase of each stage. Residual dispersion and wavelength-dependent losses require a full complex-response budget.

Unequal long/short-arm losses also matter: they produce unequal taps and can destroy the flat plateau. Static coupler-ratio adjustment or attenuation can match the arm amplitudes, with a reduced overall field gain. One scalar output correction cannot repair arbitrary unequal taps or channel-dependent phase errors.

A constant plateau means constant complex envelopes on the comb teeth. The coefficient envelopes must fill their slots, or overlap so that their shifted envelopes sum to a constant. Short separated pulses retain dark gaps after integer-slot delays. Optical beating between comb teeth is a separate effect.

## Compact dual-lattice schedule

Send one \(R\)-slot term burst into a lattice, followed by zero input. Its completed plateau occupies

\[
(R-1)\tau\le t<L_F\tau,
\]

relative to that burst's arrival, after subtracting common device latency. It lasts \((L_F-R+1)\tau\). With \(R=32,L_F=70\), this is **310–700 ps**, or **390 ps**.

For alternating bursts starting every \(P\tau\), a simple sufficient condition to preserve the entire plateau of every frame is

\[
P\ge R,\qquad 2P\ge L_F.
\]

Choose \(P=40\): a new reader burst every **400 ps**, with **80 ps of blank pair-result input** after each 320 ps burst. The same lattice is revisited every 800 ps, preserving the full 390 ps plateau. The raw output is not blanked between frames.

Center the receiving 320 ps burst inside that plateau, at **345–665 ps** relative to the source frame. The half-slot offset is permitted for the assumed constant complex envelope; it does not change the 10 ps coefficient-slot spacing.

| Event | Frame 0, lattice 0 | Frame 1, lattice 1 | Frame 2, lattice 0 |
| --- | --- | --- | --- |
| Pair terms enter selector | 0–320 ps | 400–720 ps | 800–1120 ps |
| Complete raw plateau | 310–700 ps | 710–1100 ps | 1110–1500 ps |
| Receiver accepts result | 345–665 ps | 745–1065 ps | 1145–1465 ps |

An illustrative output-selector changeover uses:

| Operation between frame 0 and frame 1 | Time |
| --- | --- |
| Receiver inactive; hold previous selector | 665–680 ps |
| Change output selector | 680–730 ps |
| Selector settled; receiver remains inactive | 730–745 ps |

Input selection can similarly change at 335–385 ps inside the 320–400 ps blank input interval. The 50 ps transition and 15 ps margins are unverified device/driver requirements. There is no close-shutter/open-shutter sequence. A low event rate does not by itself establish analog bandwidth or driver power.

This schedule gives **80% reader-core duty** and an ideal **2.5 billion independent read frames per second per lane**, 1.6 times the previous 640 ps reference cadence. These are reader figures, not a token rate, demonstrated device rate, or read/write/query schedule.

The receiving burst has 35 ps of plateau margin before and after its nominal 320 ps support. The 80 ps selector gap is a separate budget. The 35 ps margins are requested design allowances, not established safe tolerances: allocate them to bounded relative arrival error, dispersion, filter settling and pulse-envelope requirements, then verify the combined budget.

More generally, let \(Q=2P\) be the same-lattice revisit interval. For arbitrary successive frames, the uncontaminated completed-sum interval, in slot units relative to a frame's start, is

\[
[S,E)=
\left[\max(R-1,L_F+R-1-Q),\ \min(L_F,Q)\right).
\]

The interval is empty when \(E\le S\). Previous frames have disappeared by \(S\). The window ends when the current sum first loses a term or the next frame arrives. A useful window \([O,O+R)\), with upstream-field validity margins \(g_L,g_R\), must satisfy

\[
O-g_L\ge S,\qquad O+R+g_R\le E.
\]

Selector changeover independently requires \(P-R\ge g_{\rm before}+g_{\rm select}+g_{\rm after}\), in slots. The 70-tap example uses \(O=34.5\), \(g_L=g_R=3.5\), and selector allowances of 1.5, 5 and 1.5 slots. Validity margins describe when the upstream result is correct; they do not authorize extra nonzero coefficient terms.

## Design the margin before synthesizing the network

Specify the input coefficient count \(R\), slot duration \(\tau\), accepted output duration \(W\tau\), required total extra plateau fraction \(\mu\), and minimum leading/trailing margins \(g_L\tau,g_R\tau\). For the present reader \(W=R\). Choose the plateau width in slots and the minimum tap count from

\[
B=\left\lceil\max\!\left((1+\mu)W,\ W+g_L+g_R\right)\right\rceil,
\qquad L_{F,\min}=R-1+B.
\]

Here 20% means **20% extra total duration**, not 20% at each edge. With \(R=W=32,\mu=0.2\), the requested 384 ps rounds up to a 390 ps plateau: \(B=39,L_F=70\). The actual total extension is 21.875%, distributed as 35 ps per edge when centered. Per-edge specifications can be asymmetric and take precedence if they require more width.

| Margin request for the 320 ps example | Minimum taps | Standalone plateau | Margins with centered acceptance |
| --- | ---: | ---: | --- |
| No extra margin: mathematical reference only | 63 | 320 ps | 0 / 0 ps |
| 20% extra total plateau | 70 | 390 ps | 35 / 35 ps |
| At least 50 ps on each side | 73 | 420 ps | 50 / 50 ps |
| 40% extra total plateau | 76 | 450 ps | 65 / 65 ps |

The recursive two-way construction supports these integer tap counts. One may choose more than the minimum taps to obtain easier coupling ratios or a better layout; the margin is a requirement, not a hardcoded 70-tap choice. A standard balanced binary cascade would instead round 70 or 73 up to 128. That additional restriction is no longer imposed.

These are **design-time parameters**: the fabricated path lengths, coupler ratios and topology set the plateau width. Timing controls can move the acceptance window within that plateau. Changing the width at runtime would require additional reconfigurable paths or other hardware. Prime tap counts can require strongly unequal couplers under this synthesis; for example, the minimal 73-tap construction includes a 1:72 power ratio. Compare nearby larger tap counts before choosing a physical layout.

Next choose a frame period that preserves both switching allowances and the required plateau. A simple sufficient two-lattice rule is

\[
P\ge\left\lceil\max(R+G_{\rm in},\ W+G_{\rm out},\ L_F/2)\right\rceil,
\]

where \(G_{\rm in/out}\) are the respective selector transition plus guard durations, expressed in slots. With 80 ps for each selector and \(L_F=70\), this gives \(P=40\). If a shorter revisit interval is considered, recompute the actual clean interval \([S,E)\) above and require it to contain the entire accepted duration and margins.

Place the acceptance window using

\[
\delta=E-S-W-g_L-g_R\ge0,\qquad
O=S+g_L+\delta/2.
\]

This preserves the specified asymmetric margins and divides remaining slack evenly. Launch timing must be realizable at the selected phase resolution; rounding may require an extra tap to preserve both minimum margins. Increasing the frame period cannot widen a filter's standalone plateau; increase \(L_F\) when the width requirement changes.

The synthesis rules give an ideal sum of inserted differential delays of \((L_F-1)\tau\). They do not predict die area, coupler tolerance, excess loss or common-path matching. The [design/check script](check_binary_multiplier.py) exposes the total extension and per-edge margins as parameters and reports the resulting tap count, factorization, timing and cell/delay budget.

| Option | Frame interval | Acceptance relative to frame | Clean plateau | Differential waveguide total |
| --- | ---: | --- | --- | ---: |
| Two 70-tap lattices: 20% margin candidate | 400 ps | 345–665 ps | 310–700 ps | 207 mm |
| Earlier two-64-tap compact candidate | 400 ps | 315–635 ps | 310–640 ps | 189 mm |
| Two 128-tap lattices: more timing margin | 520 ps | 640–960 ps | 550–1040 ps | 381 mm |
| One 64-tap lattice: smaller, lower throughput | 640 ps | 315–635 ps | 310–640 ps | 94.5 mm |
| Previous two-128-tap shuttered reference | 640 ps | 640–960 ps | 310–1280 ps | 381 mm |

The 128-tap alternative retains only balanced passive couplers and two routing MZIs, with 90/80 ps of plateau margin around acceptance. It is a possible choice if avoiding nested unequal-coupler cells outweighs its delay and power cost. Extra pump tails remain extra computational terms even on a valid upstream plateau. The one-64-tap-lattice alternative needs neither accumulator branch selector, but does not meet the 20% margin requirement.

Sharing initial stages between the two alternating lattices trades delay savings for a shorter routing gap. A shared \(M\)-tap prefix broadens a routed burst to \(R+M-1\) slots, leaving \(P-R-M+1\) blank slots for its selector. Sharing the initial two-tap factor of the 70-tap design saves only 1.5 mm and leaves 70 ps, below the selected 80 ps selector budget. Keep two independent complete networks.

The adjustable-margin circuit uses nested, weighted **two-arm** cells and two complete lattices. Its additional complexity is unequal couplers and matching nested paths; it does not require a three-way split or a third accumulator.

## Module synchronization and chaining

Each module receives a shared clock and a calibrated local frame phase. The timing controller tracks the head, bank, token-state version and visit type; it does not measure comb values. Distribute schedules in advance, with local drivers beside the gates.

If a stage starts at \(s\), has fixed common propagation delay \(d_0\), and its output link adds \(d_{\rm link}\), the raw plateau arrives at the next component over

\[
[s+d_0+(R-1)\tau+d_{\rm link},\
 s+d_0+L_F\tau+d_{\rm link}).
\]

Use the accepted flat interval inside this window to align the next component's coefficient burst. For schedules that preserve only part of a plateau, use the clean bounds \([S,E)\) above. The raw link carries partial sums and selector-transition mixtures at other times. The receiving compute pump must reject them, and its filtering must suppress unconverted input leakage. Both the electrical clock-path delay and the optical data-path delay enter calibration. Large fixed delays shift the schedule and its integer frame identity; clock phase alone is not enough to identify a frame delayed by multiple periods.

Where a Monarch shuffle combines frequencies from several lanes, equalize paths or shift upstream launches so the same head/token components arrive together. A downstream gate cannot correct differential timing between components that must coexist in one vector. Clock synchronization is separate from optical carrier-phase stabilization.

The next stage must have matching reader capacity or parallel lanes. A continuous optical pipeline does not remove recurrent dependencies: a query using updated state must wait for all its writes and for the matching memory slots to return.

## Optical writer and persistent memory

The multiplier reader above uses two nonlinear sections. To support the local delta/TTT update, retain the compact three-section option:

| Section | Read window | Write window |
| --- | --- | --- |
| DFG 1 | Key/query in A, tapped \(a_m\) in P | Optical residual \(e\) in A, fixed \(b_m\) in P |
| DFG 2 | First idler in B, fixed \(b_m\) in P | Inactive |
| Cross-SFG writer | Inactive | Replayed key in A and transformed residual in B, producing P |

In write mode, select the B-filter output toward cross-SFG instead of DFG 2. A P-band filter retains all \(2K-1\) gradient coefficients, followed by a calibrated scalar gain/phase setting and coherent injection into the corresponding memory slot. Input, pump and B-route selectors are **additional controls beyond the two reader routing MZIs**. Query/prediction destinations, scalar gates and memory initialization/access may require further routing; two MZIs is not the total active-component count of an updating memory engine.

With physical reader coefficients \(c_m\), including the FIR normalization and calibrated gains,

\[
\widehat v=\sum_m c_m H(b_m)H(\overline{a_m^-})k,\qquad
e=v-\widehat v,
\]
\[
g_m=c_m\,[k*\mathcal D(b_m,e)],\qquad
a_m^+=a_m^-+\eta g_m.
\]

For the equal-tap 70-tap network, \(c_m=1/70\). In general the ideal factor is \(1/L_F\), even when the internal couplers are unequal. The writer must include this factor, for example through its pump/scalar gain; replaying the unscaled partner without adjusting the gradient would implement a different update. In this conjugated-state convention the displayed complex factor is \(c_m\), not \(\overline{c_m}\). Additional residual-combiner, replay and injection scales must be included consistently.

The cross-SFG is a full linear convolution. Retain every coefficient line; isolate the desired A+B interaction from A+A/B+B self-products through carrier selection, modes/polarization and phase matching. The gradient is already in the memory band, so no write translator is required.

The target and completed prediction form the residual with a coherent subtraction coupler. Its known attenuation and unused-port power must be accounted for. Without the output shutter, the residual is valid only in its acceptance window. Replay capture, writer conversion and memory injection must enforce that timing; an ungated storage interface would retain unwanted partial sums. Residual and key hold/replay remain optical interfaces; no electrical residual computation is substituted.

**Reader/writer scheduling is explicit.** Frame 0's acceptance window at 345–665 ps overlaps DFG 1's read work for frame 1. DFG 1 cannot also transform the residual throughout that window. Reserve separate write bursts and later updated-query bursts, or add a dedicated error DFG. The read-frame checker does not prove a complete online update cadence.

Finish the full prediction before writing any coefficient used by it. Align each write with the correct head/bank/term slot, finish all writes, then read the updated state. A useful output plateau may supply a suitably scheduled error/write window directly, but does not constitute indefinite replay storage.

The persistent fiber carries the actual \(a_m\) field in P. It bypasses the nonlinear sections; a tap feeds the compute branch. Coherent write injection, the once-per-token forgetting factor, read-tap loss, idle-lap losses and any gain are all separate terms in the memory budget. A passive coupler cannot provide unit retention and nonzero injection simultaneously.

Reuse also requires the measured complex device responses to implement the appropriate transpose/gradient operations. DFG symmetry alone does not make two fabricated sections equivalent. A separate error DFG permits independent calibration but does not eliminate this matching requirement.

## Material partition and functional floorplan

| Region | Proposed contents |
| --- | --- |
| Optical interface edge | A/P inputs, fiber-memory read/write connections, result port and isolated discard ports |
| Nonlinear strip | Two traveling-wave PPLN DFG sections, pump combiners, B/A cleanup; optional cross-SFG writer and P cleanup alongside |
| Passive center | Two independent SiN delay networks, each with eight nested two-arm cells for the 70-tap example |
| Electrical edge | \(S_{\rm in},S_{\rm out}\) in hybrid LN/SiN; additional pump-access/write/memory controls when required; nearby drivers and RF access |
| Calibration | Slow phase/bias trims, small monitor taps or reserved pilots, temperature control as required |
| Package/system | Shared comb sources and encoders, long fiber storage and replay, clock distribution and power delivery |

Use SiN for pump-band routing and delay waveguides; use poled LN for the nonlinear sections and suitable LN sections for Pockels control. The silicon substrate is the integration platform. Ordinary silicon waveguides should receive only suitable lower-band light after rejection of the visible/near-visible pump.

The two DFG sections can sit alongside each other with a filtered connecting path. Put the long delay arms in separate spiral regions, route the two active cells near electrical access, and isolate discard light from the memory interfaces. The drawings show this partition without specifying lithographic dimensions.

At the reference group index, the sum of inserted arm-delay lengths in each lattice is 103.5 mm. Nested bypass matching and common optical paths through LN devices, switches and couplers add latency and area. A reported meter-long SiN spiral is not a license to scale its area linearly into sixteen interferometers. No validated die area or claim that delays dominate total cost is made here.

## Component and energy budget

| Item | Reader only | Compact reader + writer |
| --- | ---: | ---: |
| Physical DFG sections | 2 | 2, first reused |
| Cross-SFG sections | 0 | 1 |
| Data-band filter assemblies | 2 | 2, B reused |
| Gradient-band selector | 0 | 1 |
| Binary FIR lattices | 2 | 2 |
| Fixed two-arm filter cells | 16 | 16 |
| Passive-filter couplers | 32: 20 balanced, 12 unequal | Same |
| Reader routing MZIs | 2 | 2 |
| Dedicated output shutters | 0 | 0 |
| Receiver acceptance | Required; use scheduled pump burst | Required; also restrict replay capture and injection |
| Reuse controls | None | A-input selection, P-pump selection, B-route selection; implementation-dependent count |
| Residual, replay and write interfaces | Not required for a stand-alone read | Required; buffers and loss/gain budget are additional |

A dedicated error path changes the nonlinear count to three DFG sections plus one cross-SFG, and adds B filtering/routing. Per-layer arrays multiply these per-lane costs by the lane and bank counts; source sharing does not make distribution power free.

The passive normalization has a real energy cost. For \(R=32\) identical aligned pair fields \(z\), the example raw plateau has amplitude \(32z/70\). Counting only the accepted 32-slot interval, its useful energy relative to the 32 incident term slots is

\[
\frac{E_{\rm useful}}{E_{\rm incident}}=
\left(\frac{R}{L_F}\right)^2=
\left(\frac{32}{70}\right)^2\approx20.90\%.
\]

This is an aligned-input benchmark before excess loss, not an efficiency guarantee for signed terms that may cancel. The full 39-slot plateau contains about 25.47% of that incident energy. Other light still leaves the unshuttered output but does not count as useful computation. Choosing 70 instead of 64 taps costs about 0.78 dB of useful power while increasing the per-edge margin from 5 to 35 ps. Compared with 128 taps, 70 taps provides about 5.24 dB more useful power for the same term fields and acceptance duration, before extra cell/routing losses. Model rescaling does not recover photons or signal-to-noise ratio.

Budget separately: pump conversion, source fanout, every coupling/transition, MZI insertion and extinction, delay propagation, memory/replay losses, detector power, clock distribution, drivers and thermal control. A Pockels phase shifter's low static device current does not imply zero driver or termination power.

## Evidence and validation boundaries

Relevant primary demonstrations provide component precedents:

- [Rao et al.](https://arxiv.org/abs/1609.09117): 4 mm nonlinear LN waveguides bonded on silicon and loaded with SiN, demonstrating SHG/SFG.
- [Koyaz et al.](https://arxiv.org/html/2410.08790v1): 4.8 mm poled DFG waveguides. A signal sweep at fixed pump does not establish our full simultaneous pump-comb × signal-comb response.
- [Churaev et al.](https://pmc.ncbi.nlm.nih.gov/articles/PMC10264395/): heterogeneous LN–SiN integration and low-loss telecom transitions; not a pump-band loss specification for this layout.
- [Ruan et al.](https://doi.org/10.1002/lpor.202200327): a 7 mm LN–SiN MZM with reported 37 GHz bandwidth, 4.3 V half-wave voltage and 1 dB overall insertion loss. This does not establish our full-comb switch settling or driver energy.
- [Yun et al.](https://doi.org/10.1364/OL.44.004929): flat-top grating add–drop filters; the required nearest-idler and sideband response remains to be designed.
- [Liu et al.](https://www.nature.com/articles/s41467-021-21973-z): a 1 m SiN spiral occupying 6.6 mm² with measured 2.4 dB/m loss, illustrating dense delay integration rather than determining this component's area.

Run the [binary multiplier checker](check_binary_multiplier.py) to verify ideal binary tap construction, successive independent complex frames, acceptance timing, raw-stream two-stage composition and normalized update algebra:

    python3 hankel_monarch_delta/check_binary_multiplier.py

For a 40% total extension, or minimum 50 ps margins on both edges, respectively:

```bash
python3 hankel_monarch_delta/check_binary_multiplier.py --extra-plateau-fraction 0.4
python3 hankel_monarch_delta/check_binary_multiplier.py --margin-before-ps 50 --margin-after-ps 50
```

These select 76 and 73 taps. The checker currently uses equal input and acceptance durations (\(W=R\)) and a 5 ps timing grid. It prints JSON; add `--output PATH` to save a report.

The [saved ideal-check results](results/binary_multiplier_checks.json) cover the 70-tap/400 ps candidate, margin-driven synthesis and timing alternatives. The synthesized nested network is checked against a uniform-tap reference. The chaining check retains raw transients and selector mixtures, applies an explicit receiving pump window, and includes a pump-leakage counterexample. It must not silently crop the output before the next DFG. The [original coefficient checker](check_update_algebra.py) covers the broader local-update identities. The [earlier global-ring timing model](model_memory_schedule.py) remains a separate reference and does not implement this reader or a complete per-layer update schedule.

Next physical models must include the two-dimensional mixing response, pump/data walk-off, all filter impulse responses, actual pulse envelopes, dispersion, coherent leakage, switching edges, and memory access. The perturbative field-bilinear regime or another verified linear range is required; an undepleted pump alone does not guarantee linear dependence on stored pump amplitude at high gain. A 100 GHz comb spacing and a 10 ps slot are distinct requirements, and their sidebands cannot be assumed compatible without a bandwidth model.

The old [three-section overview](figures/07_photonic_component.svg) remains a historical view of the nonlinear reuse concept. Figures 10 and 11 illustrate this engineering option; the ideal baseline is described in the [main component document](photonic_component.md).
