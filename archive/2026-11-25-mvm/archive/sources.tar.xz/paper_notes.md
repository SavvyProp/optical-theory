This readme highlights the thoughts and plan to complete the paper.

The paper is a theory and simulation study with no in-house hardware experiments. The [current model](hankel_monarch_delta/research_model.md) and [architecture budget](hankel_monarch_delta/paper_design_point.md) specify the latest dimensions and timing. Offline training takes place on conventional silicon; the hardware performance study concerns inference, including online adaptive-state updates.

Plan is to submit to neighbor comm due to good impact, multidisciplinary, familiarity with Nature Comm format and writing.

https://www.nature.com/articles/s41467-026-75602-8

Show an optical matrix multiplier with all multiplexing along with natural gradient updates. (Hankel monarch multipliers)

Use the [integrated MZI interleaver shuffle](hankel_monarch_delta/mzi_shuffle.md) between Hankel banks. Eight three-level input trees separate wavelength residues modulo eight, fixed waveguides perform the cyclic lane routing, and eight output trees recombine the groups. This replaces the free-space diffraction-grating shuffle and gives the paper a repeated circuit building block. Evaluate the expected energy benefit through optical insertion loss, avoided launch/collection interfaces and phase-stabilization power; do not claim a demonstrated saving. Free-space saturable absorption remains the separate tentative FFN activation.

Illustrate how optical weights can allow for efficient weight loading through an optical MLP with gradient descent built in. Illustrate the energy efficiency through multilayer 

Show how hankel monarch multipliers can build a TTT network to leverage recurrence and high compute frequencies in optical computing.

Test whether the structured TTT model can use additional internal passes for reasoning. The selected starting design has 24 layers, 16 logical heads, eight fibers per head, a 512-wide residual stream and unique two-layer FFNs per head. Distinct complex layer/head factors contribute 301,989,888 real parameters, and the tied real 16,000 × 512 embedding/readout gives a **310,181,888-parameter subtotal** before gates, normalization and any learned initial state. Alternating two learned layer sets remains an optional approximately 33.36M-parameter ablation including the same embedding. The illustrative 737.28 ns arithmetic-only pass corresponds to about 1.356 million passes/s before propagation, electronic handoff and token feedback. Reasoning quality and visible-token throughput must be evaluated rather than inferred from the parameter count or reader cadence. Local GPU feasibility also depends on differentiating through the adaptive state, which occupies 381 MiB per sequence snapshot in complex64.

5 Figures in the nature comm paper.
1st figure, introducing hankel multiplier:
a) Hankel multiplier Unit Cell
b) Hankel multiplier with the recurrent weights, illustrating weight injection and stabilization.
c) Timing diagram (Combine with b?)


2nd figure, introducing MLPs, all optical networks and fiber memory.
a) Monarch Stages
b) Free Space Saturable Absorbtion.

3rd figure, simulated results on MLPs highlighting simple task accuracy and accuracy degredation.

4th figure, introducing TTT network.
a) Simplified TTT diagram (ML)
b) TTT diagram (physical components)
c) Timing diagram

5th figure, simulated language-model and internal-deliberation results for the specified structured TTT model, with actual learned-parameter count and inference-pass budget reported.

Start the Photontorch simulations with one fixed-weight forward matmul. A local loop replays one matrix on the reader schedule. The later TTT run uses the approximately 150 m loop to revisit adaptive state across the full model. The [Hankel cell simulation notes](simulation_notes/hankel_cell.md) give the carrier grids, short-loop timing and forward checks. The [optical component gain budget](simulation_notes/component_gains.md) gives the path losses for each run.
