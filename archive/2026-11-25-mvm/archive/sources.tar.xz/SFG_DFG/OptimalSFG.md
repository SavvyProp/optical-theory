# SFG–DFG nonlinear feature map on an optical frequency comb

The proposed operation combines two inputs on the same frequency comb, performs sum-frequency generation (SFG, including second-harmonic terms), and uses a tapped copy of the first input as the reference for difference-frequency generation (DFG). A final filter selects the original frequency channels so the result can feed another optical layer.

The intended encoding is **nonnegative field amplitudes with aligned spectral phases**. Frequency channels may mix: the goal is a nonlinear feature map for an optical neural network.

For flat, phase-aligned combs, an ideal weak-conversion calculation predicts:

- Retained generated power initially scales as $N^2$ at fixed total average SFG-input and reference powers.
- The fraction of generated DFG power surviving the final frequency filter approaches $9/11\approx81.8\%$.
- These are conditional scaling and filtering results, not a demonstrated overall conversion efficiency or a universal optimum for arbitrary input vectors.

## 1. Architecture, encoding, and power accounting

Use $N$ distinct angular frequencies

$$
\omega_j=\omega_0+j\Delta\omega,
\qquad j=0,\ldots,N-1,\qquad \Delta\omega>0.
$$

Spacing is uniform in frequency, not wavelength. Let $x_j$ and $y_j$ denote complex field amplitudes, normalized so their squared magnitudes represent channel powers. Encoding a numerical value in amplitude means its optical power is proportional to the square of that value.

The favorable phase convention is

$$
x_j=\xi_j e^{i(\phi_0+j\theta)},\qquad
y_j=\upsilon_j e^{i(\phi_0+j\theta)},
\qquad \xi_j,\upsilon_j\ge0.
$$

A common linear spectral phase $j\theta$ corresponds to a time shift and preserves constructive summation. An arbitrary spectral chirp shared by both inputs does not generally do so. The reference must be synchronized with the SFG field.

```mermaid
flowchart LR
    X["Input x"] --> Tap["Tap reference"]
    Tap --> Add["Coherent addition"]
    Y["Input y"] --> Add
    Add --> SFG["SFG, including SHG"]
    SFG --> Isolate["Isolate sum-frequency band"]
    Isolate --> DFG["DFG"]
    Tap --> Ref["Reference delay and mode matching"]
    Ref --> DFG
    DFG --> Separate["Separate generated output mode"]
    Separate --> Filter["Filter original N frequencies"]
    Filter --> Output["Nonlinear feature comb"]
```

For algebra, write the fields actually entering the two nonlinear stages as

$$
u_j=\alpha x_j+\beta y_j,\qquad r_j=\gamma x_j.
$$

Adjust the combiner phase so $\alpha$ and $\beta$ can be taken as nonnegative real coefficients in this convention. A fixed phase in $\gamma$ contributes only a common output phase under the uniform-coupling model.

The shorthand $u=x+y$, $r=x$ describes the desired operation; actual tap and combiner coefficients must be included in an energy budget. These coefficients are constrained by the physical optical network.

For example, tapping a fraction $f$ of the source power in $x$ and then using a balanced combiner gives, with its relative phase adjusted for addition,

$$
r=\sqrt f\,x,\qquad
u=\frac{\sqrt{1-f}\,x+y}{\sqrt2},\qquad
v=\frac{\sqrt{1-f}\,x-y}{\sqrt2},
$$

where $v$ is the other combiner output. For lossless optics,

$$
\|u\|^2+\|v\|^2+\|r\|^2=\|x\|^2+\|y\|^2.
$$

This prevents counting the same source power twice. Define $P_u=\sum_j|u_j|^2$ and $P_r=\sum_j|r_j|^2$ as the actual powers delivered to the nonlinear stages.

With a fixed tap coefficient $\gamma$, reference power varies with $\|x\|^2$ and the layer remains cubic in its input fields. Normalizing each reference to constant power, $r\propto x/\|x\|$, changes the feature map. The fixed-power comparisons below refer to controlled input norms, not an implicit normalization operation inside the layer.

## 2. Why use an evenly spaced comb?

Every SFG pair has frequency

$$
\omega_i+\omega_j=2\omega_0+(i+j)\Delta\omega.
$$

The possible outputs therefore occupy only $2N-1$ lines,

$$
\Omega_s=2\omega_0+s\Delta\omega,
\qquad s=0,\ldots,2N-2.
$$

This is the minimum possible number of distinct pair sums for $N$ distinct real input frequencies when doubling terms are included. Sorting any input frequencies gives the strictly increasing chain

$$
2\omega_0<\omega_0+\omega_1<\cdots<\omega_0+\omega_{N-1}
<\omega_1+\omega_{N-1}<\cdots<2\omega_{N-1},
$$

which already contains $2N-1$ values. An arithmetic progression attains the bound. Excluding all doubling terms gives a minimum of $2N-3$ for $N\ge2$. See [Bukh's sumset notes](https://www.borisbukh.org/DiscreteMath14/notes_additive_inequalities.pdf).

Frequency coincidence permits interference. Constructive interference additionally requires the input phases and nonlinear coupling phases to align.

DFG **between SFG lines alone** would cancel the carrier and produce frequencies $\Delta\omega,\ldots,(2N-2)\Delta\omega$. The original-band reference is what returns the proposed operation to the input carrier band:

$$
\Omega_s-\omega_k=\omega_0+(s-k)\Delta\omega.
$$

## 3. The computed feature map

First assume weak conversion, negligible depletion, and uniform nonlinear coupling across all participating frequencies. Let $g_S$ and $g_D$ be the SFG and DFG field-conversion coefficients.

The SFG amplitudes are the discrete convolution

$$
b_s=g_S\sum_{i+j=s}u_i u_j,
\qquad s=0,\ldots,2N-2.
$$

This sum uses ordered pairs: cross terms $u_i u_j$ with $i\ne j$ appear twice, as required by squaring the total field. An unordered-pair implementation must include that factor explicitly.

The generated DFG field at $\omega_0+m\Delta\omega$ is

$$
c_m=g_D\sum_{k=0}^{N-1}b_{m+k}r_k^*
=\kappa\sum_{i+j-k=m}u_i u_j r_k^*,
\qquad \kappa=g_Sg_D,
$$

with $b_s=0$ outside its support. All three input indices lie between $0$ and $N-1$.

Before filtering, the possible output indices span

$$
-(N-1)\le m\le2N-2,
$$

giving up to $3N-2$ lines. The final filter retains $m=0,\ldots,N-1$. Negative indices here designate frequencies below $\omega_0$, not negative optical frequencies. Assume the comb bandwidth is small enough that all these optical frequencies remain positive.

For the nominal operation $u=x+y$, $r=x$,

$$
\boxed{
c_m=\kappa\sum_{i+j-k=m}(x_i+y_i)(x_j+y_j)x_k^*,
\qquad 0\le m<N.
}
$$

In terms of envelopes $X(t)=\sum_jx_j e^{-ij\Delta\omega t}$ and $Y(t)$ defined similarly, this is

$$
C(t)=\kappa\,\mathcal P_N\!\left[(X(t)+Y(t))^2X^*(t)\right],
$$

where $\mathcal P_N$ projects onto the original frequency channels. Before that projection,

$$
(X+Y)^2X^*=|X|^2X+2|X|^2Y+X^*Y^2.
$$

The layer is therefore a **cubic feature map** with self and cross terms and mixing between frequency channels. With nonnegative input amplitudes, aligned phases, and uniform coupling phase, each retained spectral coefficient is a nonnegative sum up to a common phase. That common phase can be compensated between layers.

## 4. Exact flat-comb benchmark

Set the common spectral phase to zero and take

$$
u_j=\sqrt{P_u/N},\qquad r_j=\sqrt{P_r/N}.
$$

This is the benchmark where both source combs have flat, aligned profiles, with tap and combiner factors already reflected in $P_u$ and $P_r$.

The SFG amplitudes have a triangular profile:

$$
b_s=g_S\frac{P_u}{N}t_s,
\qquad t_s=N-|s-(N-1)|.
$$

Here $t_s$ is defined on $0\le s\le2N-2$ and is zero outside that interval.

At retained output $m$, the number of contributing ordered triples is

$$
T_m=\sum_{k=0}^{N-1}t_{m+k}
=\frac{N(N+1)}2+m(N-1-m),
\qquad 0\le m<N.
$$

Consequently,

$$
c_m=\kappa\frac{P_u}{N}\sqrt{\frac{P_r}{N}}\,T_m.
$$

Summing the squared amplitudes gives

$$
\boxed{
P_{\rm kept}=|\kappa|^2P_u^2P_r
\frac{27N^2+25+8/N^2}{60}
}
$$

and, summing over all generated DFG indices,

$$
\boxed{
P_{\rm all}=|\kappa|^2P_u^2P_r
\frac{11N^2+5+4/N^2}{20}.
}
$$

The finite sums behind these expressions are

$$
\sum_{m=0}^{N-1}T_m^2=\frac{N(27N^4+25N^2+8)}{60},
\qquad
\sum_{m=-(N-1)}^{2N-2}T_m^2=\frac{N(11N^4+5N^2+4)}{20},
$$

where the second expression uses the full triple count outside the retained band as well.

Define the filtering retention as

$$
\boxed{
\eta_{\rm filter}=\frac{P_{\rm kept}}{P_{\rm all}}
=\frac{27N^4+25N^2+8}{3(11N^4+5N^2+4)}
\longrightarrow\frac9{11}\approx81.8\%.
}
$$

| Lines $N$ | $P_{\rm kept}/(|\kappa|^2P_u^2P_r)$ | Generated DFG power retained |
|---:|---:|---:|
| 1 | 1.000 | 100.00% |
| 2 | 2.250 | 90.00% |
| 4 | 7.625 | 84.14% |
| 6 | 16.620 | 82.87% |
| 8 | 29.219 | 82.42% |
| 16 | 115.617 | 81.97% |
| 32 | 461.217 | 81.86% |

The middle column is a normalized response coefficient, not a conversion efficiency. Values greater than one do not imply energy gain beyond the supplied optical energy. The perturbative model must be used only where depletion remains negligible.

These percentages apply to the flat-comb benchmark. Nonuniform data change the relative strengths of retained and discarded terms; nonnegative encoding alone does not guarantee $81.8\%$ retention.

## 5. Scaling and comparison with a single reference tone

For the flat benchmark, the total SFG power is

$$
P_{\rm SFG}=|g_S|^2P_u^2\frac{2N^2+1}{3N}
\sim\frac23|g_S|^2P_u^2N.
$$

With the flat reference comb, retained cascade power scales as

$$
P_{\rm kept}\sim\frac9{20}|\kappa|^2P_u^2P_rN^2.
$$

At fixed spacing $\Delta\omega$, aligned teeth form a periodic pulse train. Its period stays $2\pi/\Delta\omega$, its pulse width decreases approximately as $1/(N\Delta\omega)$, and its peak power grows approximately as $N$ at fixed average power. Both nonlinear stages benefit from synchronized peaks. The increase is a temporal concentration effect, not an unrestricted efficiency improvement from counting mixing paths. The importance of temporal amplitude structure in broadband conversion is discussed by [Band et al.](https://doi.org/10.1103/PhysRevA.49.517).

If bandwidth is held fixed instead, adding teeth reduces their spacing and lengthens the repetition period. Fixed average power then corresponds to more energy per period. Holding pulse energy fixed removes that particular apparent gain. Energy per inference therefore requires a specified timing convention as well as a line count.

A single reference tone at index $q$ gives $c_m=g_D b_{m+q}r_q^*$, so filtering keeps a translated window of $N$ SFG lines. For the triangular SFG profile, the best tone is an on-grid index nearest $(N-1)/2$. At the same total reference power,

$$
P_{\rm kept,single}=|\kappa|^2P_u^2P_r
\frac{7N^2+\epsilon_N}{12N},
\qquad
\epsilon_N=\begin{cases}5,&N\text{ odd},\\2,&N\text{ even}.\end{cases}
$$

The large-$N$ comparison is:

| Reference | Retained power divided by $|\kappa|^2P_u^2P_r$ | Filtering retention |
|---|---:|---:|
| Best single tone | $\sim7N/12$ | $\to7/8$ |
| Flat copy of $x$ | $\sim9N^2/20$ | $\to9/11$ |

Thus the flat reference comb gives asymptotically $(27/35)N\approx0.77N$ times the retained generated power of the best single tone, while the single tone has higher asymptotic filtering retention. These compare different feature maps: a single fixed reference does not implement the same cubic operation as an input-dependent copy of $x$.

A copy of $x$ is also not guaranteed to be the reference that maximizes power for every pair of data vectors. For a fixed SFG field, define $H_{mk}=g_D b_{m+k}$ over the retained outputs. Then $c=Hr^*$, and at fixed reference power the maximizing $r^*$ is the dominant right singular vector of $H$. The proposed architecture instead constrains $r\propto x$ to obtain the specified feature map.

## 6. Physical assumptions and limits

The closed-form benchmark assumes:

1. **Weak conversion in both stages.** The fields supplying each stage remain approximately unchanged. Once depletion or back-conversion matters, solve the coupled propagation equations; the $N^2$ law cannot continue indefinitely.
2. **Broad, nearly uniform phase matching and mode overlap.** In a device, the more general equations are $b_s=\sum_{i+j=s}g^S_{ij}u_i u_j$ and $c_m=\sum_k g^D_{mk}b_{m+k}r_k^*$. Frequency-dependent phases can reduce constructive addition. Group-velocity mismatch can separate the pulses as they propagate.
3. **Synchronized coherent inputs.** The reference delay and spectral phase must track the SFG-driving field. The phase-aligned result does not extend to arbitrary independent phase encoding.
4. **A distinct generated output mode.** The reference occupies the same frequency grid as the desired output. Frequency filtering alone cannot separate reference light from generated light in the same spatial and polarization mode. The physical design must provide mode separation or explicitly model the reference background as part of the layer output.
5. **An $x$-only reference tapped before addition.** The residual fundamental after combined SFG generally contains $x+y$. Reusing that residual would implement a different map, proportional to $|X+Y|^2(X+Y)$ before filtering.

The coefficients also assume a sufficiently narrow fractional optical bandwidth for a common power-normalized coupling to be a useful approximation. Real frequency weights, propagation losses, tap losses, and filter transmission must be included when predicting device efficiency. A coupled-mode framework for frequency conversion, including group velocities and high conversion, is developed by [Reddy et al.](https://arxiv.org/abs/1305.2165).

Keep three objectives distinct:

- **Filtering retention:** $P_{\rm kept}/P_{\rm all}$ for newly generated light in the designated DFG output mode.
- **Useful generated power:** $P_{\rm kept}$ at fixed actual input and reference powers.
- **System efficiency:** For a reference tapped from $x$, $\eta_{\rm system}=P_{\rm kept}/(P_x+P_y)$, where $P_x=\|x\|^2$ and $P_y=\|y\|^2$ are the supplied source powers. Reference power, unused-port power, and optical losses are already accounted for within that budget and must not be added again to the denominator. Any independent reference source would add to the supplied power. Electrical energy per inference additionally includes source and modulation overheads.

DFG also transfers energy into the reference mode: an event $\Omega_s\to\omega_m+\omega_k$ produces one photon in each lower-frequency mode. If the reference and useful output are distinct modes near $\omega_0$, roughly half of the depleted SFG energy enters each. Collecting only the designated output therefore differs from collecting both lower-frequency outputs. The filtering-retention result does not account for that partition or establish a laser-to-output efficiency.

## 7. Reproducible weak-conversion model

The following NumPy function evaluates the spectral feature map. Pass the **actual** post-combiner field `u` and post-tap reference `r`; for the nominal map these are proportional to `x + y` and `x`, respectively. The returned arrays contain generated light only.

```python
import numpy as np


def sfg_dfg(u, r, g_s=1.0, g_d=1.0):
    u = np.asarray(u, dtype=complex)
    r = np.asarray(r, dtype=complex)
    if u.ndim != 1 or r.shape != u.shape or u.size == 0:
        raise ValueError("u and r must be nonempty 1D arrays of equal length")

    n = u.size
    b = g_s * np.convolve(u, u)
    c_all = g_d * np.convolve(b, np.conj(r[::-1]))
    # c_all indices correspond to m = -(n - 1), ..., 2*n - 2.
    c_kept = c_all[n - 1 : 2 * n - 1]
    return b, c_all, c_kept
```

Use `np.vdot(c_kept, c_kept).real` for retained generated power and the analogous expression for `c_all` to calculate filtering retention. Setting both coupling coefficients to one evaluates normalized polynomial coefficients; it does not simulate a high-efficiency physical device.

The next modeling steps are to evaluate representative nonnegative data, optimize the reference tap fraction under a fixed source-power budget, introduce measured or calculated phase-matching coefficients, and then model depletion. Compare computational task performance as well as optical power: concentrating energy alone does not establish a useful neural-network representation.

## References

- [Boris Bukh, *Sumset inequalities*](https://www.borisbukh.org/DiscreteMath14/notes_additive_inequalities.pdf): minimum sumsets and arithmetic progressions.
- [Y. B. Band, C. Radzewicz, and J. S. Krasinski, *Sum- and difference-frequency generation for broadband input fields*, Physical Review A 49, 517 (1994)](https://doi.org/10.1103/PhysRevA.49.517): broadband conversion, amplitude modulation, and photon versus energy efficiency.
- [D. V. Reddy et al., *Temporal mode selectivity by frequency conversion in second-order nonlinear optical waveguides*, Optics Express 21, 13840–13863 (2013)](https://arxiv.org/abs/1305.2165): coupled propagation, mode structure, and conversion beyond the perturbative limit.
- [I. Ricciardi et al., *Frequency comb generation in quadratic nonlinear media*, Physical Review A 91, 063839 (2015)](https://doi.org/10.1103/PhysRevA.91.063839): experimental and theoretical context for cascaded quadratic interactions with effective cubic behavior.

The finite-$N$ formulas and comparisons in this document are derived from the stated discrete weak-conversion model; the references provide the mathematical and physical background rather than experimental validation of this proposed architecture.
