https://arxiv.org/abs/2610.01059?utm_source=chatgpt.com

Demonstrates SFG with 13915 frequencies. The optimal use of SFG is through representing a Hankel matrix 6000 parameters in input and weight dimension