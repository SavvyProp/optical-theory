"""Compile small matrices into sums of ceil(n/2) Hankel products.

Run: python3 hankel_monarch/hankel_pair_sum_checks.py

The Vandermonde basis is an offline compilation device, not an extra optical
component. These diagnostics check a constructive algebraic proof; they do not
establish pump realizability, efficiency, or numerically stable scaling to large n.
Signed or complex independently programmable Hankel coefficients are assumed.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np


def hankel_basis(n: int) -> np.ndarray:
    indices = np.add.outer(np.arange(n), np.arange(n))
    return np.array([indices == k for k in range(2*n-1)], dtype=float)


def compile_hankel_pairs(target: np.ndarray, *, seed: int = 0,
                         real_factors: bool = False,
                         max_attempts: int = 60) -> tuple[list, dict]:
    """Return ([(H2, H1), ...], diagnostics), with target = sum(H2 @ H1).

    Random generic nodes avoid incompatible pairings and ill-conditioned solves.
    Failure of this finite numerical procedure is not a mathematical obstruction.
    Both-negligible cross coefficients are treated as zero only provisionally;
    every returned decomposition must pass a complete reconstruction check.
    """
    target = np.asarray(target)
    if target.ndim != 2 or target.shape[0] != target.shape[1] or not target.size:
        raise ValueError("target must be a nonempty square matrix")
    if not np.all(np.isfinite(target)):
        raise ValueError("target must have finite entries")
    if real_factors and np.any(np.imag(target) != 0):
        raise ValueError("real factors require a real target")
    n = target.shape[0]
    dtype = float if real_factors else complex
    target = np.real(target).astype(float) if real_factors else target.astype(complex)
    scale = float(np.linalg.norm(target))
    if scale == 0:
        pairs = [(np.zeros((n, n), dtype=dtype), np.zeros((n, n), dtype=dtype))
                 for _ in range((n+1)//2)]
        return pairs, {"attempts": 0, "relative_error": 0.0,
                       "vandermonde_condition": 1.0, "max_pair_condition": 1.0}
    normalized = target/scale
    basis = hankel_basis(n)
    rng = np.random.default_rng(seed)
    for attempt in range(1, max_attempts+1):
        if real_factors:
            nodes = np.linspace(-1.15, 1.15, n) + rng.uniform(-.2, .2, n)/n
        else:
            nodes = np.exp(2j*np.pi*(np.arange(n)+rng.uniform(-.3, .3, n))/n)
        v = nodes[None, :]**np.arange(n)[:, None]
        try:
            u = np.linalg.solve(v, normalized.T).T
        except np.linalg.LinAlgError:
            continue
        cross = v.T @ u  # Bilinear transpose, not Hermitian transpose.
        zero_tol = 1e-11*max(1.0, float(np.linalg.norm(cross)))
        pairs, max_condition, failed = [], 1.0, False
        for i in range(0, n, 2):
            columns = list(range(i, min(i+2, n)))
            if len(columns) == 2:
                a, b = cross[i+1, i], cross[i, i+1]
                near_zero = np.abs([a, b]) < zero_tol
                if np.any(near_zero) and not np.all(near_zero):
                    failed = True
                    break
                coefficients = (np.ones(2, dtype=dtype) if np.all(near_zero)
                                else np.array([a, b])/max(abs(a), abs(b)))
            else:
                coefficients = np.ones(1, dtype=dtype)
            selected = v[:, columns]
            wanted = u[:, columns]/coefficients[None, :]
            design = np.array([(h @ selected).ravel() for h in basis]).T
            generator, _, rank, singular = np.linalg.lstsq(
                design, wanted.ravel(), rcond=None)
            if rank != min(design.shape):
                failed = True
                break
            max_condition = max(max_condition, float(singular[0]/singular[-1]))
            h2 = np.einsum("k,kij->ij", generator, basis)
            h1 = (selected*coefficients[None, :]) @ selected.T
            norm1, norm2 = np.linalg.norm(h1), np.linalg.norm(h2)
            if norm1 and norm2:
                balance = np.sqrt(norm2/norm1)
                h1, h2 = h1*balance, h2/balance
            pairs.append((h2*scale, h1))
        if failed:
            continue
        reconstructed = sum((h2 @ h1 for h2, h1 in pairs),
                            np.zeros_like(target))
        error = float(np.linalg.norm(reconstructed-target)/scale)
        if np.isfinite(error) and error < 1e-8:
            return pairs, {"attempts": attempt, "relative_error": error,
                           "vandermonde_condition": float(np.linalg.cond(v)),
                           "max_pair_condition": max_condition}
    raise ArithmeticError("No sufficiently accurate decomposition in the retry budget")


def main() -> None:
    rng = np.random.default_rng(20261104)
    records = []
    for n in range(2, 9):
        e = np.eye(n)
        real_cases = {
            "zero": np.zeros((n, n)), "identity": e,
            "diagonal": np.diag(np.arange(n)),
            "sparse_rank_one": np.outer(e[n//2], e[-1]),
            "dense_rank_one": np.outer(rng.normal(size=n), rng.normal(size=n)),
            "random_real": rng.normal(size=(n, n)),
        }
        for real_factors in (True, False):
            cases = dict(real_cases)
            if not real_factors:
                cases["random_complex"] = (rng.normal(size=(n, n))
                                           + 1j*rng.normal(size=(n, n)))
            for name, target in cases.items():
                pairs, stats = compile_hankel_pairs(
                    target, seed=int(rng.integers(2**31)), real_factors=real_factors)
                assert len(pairs) == (n+1)//2
                for h2, h1 in pairs:
                    for h in (h2, h1):
                        assert np.allclose(h[1:, :-1], h[:-1, 1:],
                                           rtol=1e-10, atol=1e-10)
                        if real_factors:
                            assert not np.iscomplexobj(h)
                reconstructed = sum(h2 @ h1 for h2, h1 in pairs)
                assert np.linalg.norm(reconstructed-target) <= (
                    1e-8*max(1.0, np.linalg.norm(target)))
                records.append({"n": n, "target": name,
                                "real_factors": real_factors,
                                "terms": len(pairs), **stats})
        # Sharp even-n lower-bound witness: diagonal difference is I_(n-1).
        witness = np.diag(np.arange(n))
        difference = witness[1:, 1:]-witness[:-1, :-1]
        assert np.array_equal(difference, np.eye(n-1))
    result = {
        "scope": "Small-n algebra diagnostics; unrestricted signed/complex Hankels",
        "optical_basis_transform_required": False,
        "cases_passed": len(records),
        "max_relative_error": max(r["relative_error"] for r in records),
        "cases": records,
    }
    path = Path(__file__).parent/"results"/"hankel_pair_sum_checks.json"
    path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps({key: value for key, value in result.items() if key != "cases"},
                     indent=2))


if __name__ == "__main__":
    main()
