"""Algebra diagnostics for coherent sums of complete Hankel/shuffle cores.

Run: python3 hankel_monarch/temporal_sum_checks.py
These checks establish no device bandwidth, optical efficiency, or ML accuracy.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy.linalg import block_diag

from single_shuffle_checks import cyclic_shuffle, hankel


def selected_entries(w: np.ndarray, k: int) -> np.ndarray:
    """Select the common central-coefficient product from each fiber block."""
    return np.array([[w[a*k + k-1-(a-b) % k, b*k + k-1-(a-b) % k]
                      for b in range(k)] for a in range(k)])


def raw_bank(pumps: np.ndarray) -> np.ndarray:
    return block_diag(*[hankel(np.convolve(u, u)) for u in pumps])


def main() -> None:
    rng = np.random.default_rng(20261104)
    results = []
    for k in (3, 4):
        d = k*k
        p = cyclic_shuffle(k, k)
        theta = rng.normal(size=k)
        phase = np.diag(np.repeat(np.exp(1j*theta), k))
        reversal = np.kron(np.eye(k), np.eye(k)[::-1])
        q = reversal @ p @ reversal
        record = {"fibers": k, "wavelengths": k, "temporal_sums": []}

        def complex_bank():
            return block_diag(*[hankel(rng.normal(size=2*k-1)
                                      + 1j*rng.normal(size=2*k-1))
                                for _ in range(k)])

        for slots in (1, 2):
            largest_tail = 0.0
            smallest_linear_margin = smallest_quadratic_margin = np.inf
            for _ in range(10):
                total = np.zeros((d, d), dtype=complex)
                positive = np.zeros((d, d))
                for _ in range(slots):
                    b1, b2 = complex_bank(), complex_bank()
                    total += b2 @ p @ phase.conj() @ b1.conj()
                    # Strip the common source phase when testing positivity.
                    r1 = raw_bank(rng.uniform(0, 1, size=(k, k)))
                    r2 = raw_bank(rng.uniform(0, 1, size=(k, k)))
                    positive += rng.uniform(0, 1) * (r2 @ p @ r1)
                extracted = selected_entries(total, k)
                singular = np.linalg.svd(extracted, compute_uv=False)
                assert np.linalg.matrix_rank(extracted) == slots
                largest_tail = max(largest_tail, float(singular[slots]))
                for b in range(k):
                    v = positive[b*k:b*k+3, b*k:(b+1)*k]
                    smallest_linear_margin = min(smallest_linear_margin,
                                                 float(np.min(v[0]+v[2]-v[1])))
                    smallest_quadratic_margin = min(smallest_quadratic_margin,
                                                    float(np.min(4*v[0]*v[2]-v[1]**2)))
            assert largest_tail < 1e-10
            assert min(smallest_linear_margin, smallest_quadratic_margin) >= -1e-12

            direction = np.tile(np.eye(k)[-1], k)
            target = np.outer(direction, direction)
            assert np.linalg.matrix_rank(target) == 1
            assert np.array_equal(selected_entries(target, k), np.eye(k))
            lower_bound = float(np.sqrt(k-slots) / np.linalg.norm(target))
            assert np.isclose(lower_bound, np.sqrt(k-slots)/k)
            record["temporal_sums"].append({
                "slots": slots, "random_trials": 10,
                "max_extracted_matrix_singular_tail": largest_tail,
                "raw_positive_min_linear_cone_margin": smallest_linear_margin,
                "raw_positive_min_quadratic_cone_margin": smallest_quadratic_margin,
                "rank_one_witness_relative_error_lower_bound": lower_bound,
            })

        # Rank-factor the gain table; reversal Hankels implement each outer product.
        gains = rng.normal(size=(k, k)) + 1j*rng.normal(size=(k, k))
        left, singular, right = np.linalg.svd(gains)
        diagonal_sum = np.zeros((d, d), dtype=complex)
        for t in range(k):
            output = left[:, t] * np.sqrt(singular[t])
            first = right[t].conj() * np.sqrt(singular[t]) * np.exp(-1j*theta)
            b1 = block_diag(*[s*np.eye(k)[::-1] for s in first])
            b2 = block_diag(*[s*np.eye(k)[::-1] for s in output])
            diagonal_sum += b2 @ p @ phase.conj() @ b1.conj()
        diagonal = np.array([gains[(b+k-1-j) % k, b]
                             for b in range(k) for j in range(k)])
        gain_error = float(np.max(np.abs(q.T @ diagonal_sum - np.diag(diagonal))))
        assert gain_error < 1e-10
        assert np.allclose(selected_entries(diagonal_sum, k), gains)

        # Raw pumps isolate each routed coordinate: P diag(g), with known phase.
        positive_gains = rng.uniform(0, 2, size=d)
        raw_sum = np.zeros((d, d), dtype=complex)
        for b in range(k):
            for line in range(k):
                a = (b+line) % k
                first = np.zeros((k, k))
                second = np.zeros((k, k))
                first[b, line] = 1
                second[a, line] = np.sqrt(positive_gains[b*k+line])
                raw_sum += raw_bank(second) @ p @ phase.conj() @ raw_bank(first)
        raw_error = float(np.max(np.abs(raw_sum-p @ np.diag(positive_gains) @ phase.conj())))
        assert raw_error < 1e-10
        record.update({"complex_gain_slots": k, "complex_gain_max_error": gain_error,
                       "raw_positive_gain_slots": d, "raw_positive_gain_max_error": raw_error})
        results.append(record)

    # A positive convolution violates the raw positive-sum cone for every T.
    gaussian_segment = np.array([0.25, 1., 0.25])
    assert gaussian_segment[1] > gaussian_segment[0] + gaussian_segment[2]
    closest = np.array([1/3, 2/3, 1/3])
    assert np.isclose(np.linalg.norm(closest-[0, 1, 0]), 1/np.sqrt(3))
    result = {"scope": "Ideal algebra; scalar taps, balanced cyclic router, no device or ML claim",
              "cases": results, "raw_positive_selector_error_lower_bound": float(1/np.sqrt(3)),
              "positive_gaussian_q_025_violates_raw_cone": True}
    path = Path(__file__).with_name("results") / "temporal_sum_checks.json"
    path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
