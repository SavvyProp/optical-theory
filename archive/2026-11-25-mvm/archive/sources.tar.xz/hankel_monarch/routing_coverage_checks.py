"""Reachability checks for specified wavelength-preserving permutations.

These count possible paths through dense local mixing banks, not independent
matrix coefficients or demonstrated physical grating implementations.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np


def route_counts(fibers: int, lines: int, stride: int) -> np.ndarray:
    counts = np.zeros((fibers, fibers), dtype=np.int64)
    for source in range(fibers):
        for wavelength in range(lines):
            counts[(source + stride * wavelength) % fibers, source] += 1
    return counts


def main() -> None:
    fibers, lines = 64, 32
    first = route_counts(fibers, lines, 1)
    inverse = route_counts(fibers, lines, -1)
    alternative = route_counts(fibers, lines, 2)
    cases = [
        ("one_cyclic_router", first, 32),
        ("two_identical_routers", first @ first, 63),
        ("inverse_second_router", inverse @ first, 63),
        ("stride_two_second_router", alternative @ first, 64),
    ]
    report = {"fibers": fibers, "lines": lines, "cases": []}
    for name, paths, expected in cases:
        reachable = np.count_nonzero(paths, axis=1)
        assert np.all(reachable == expected)
        report["cases"].append({
            "name": name,
            "reachable_input_fibers_per_output": expected,
            "reachable_input_coordinates_per_output": expected * lines,
            "all_fiber_pairs_connected": bool(np.all(paths > 0)),
        })
    # Independently verify the exact two-core identity setting, including
    # physical conjugations, for a smaller cyclic layout.
    fibers = lines = 3
    permutation = np.zeros((fibers * lines, fibers * lines))
    for source in range(fibers):
        for wavelength in range(lines):
            permutation[((source + wavelength) % fibers) * lines + wavelength,
                        source * lines + wavelength] = 1
    bank = np.kron(np.eye(fibers), np.eye(lines)[::-1])
    first_core = bank @ permutation @ bank.conj()
    second_core = bank @ permutation.T @ bank.conj()
    error = np.linalg.norm(second_core @ first_core - np.eye(fibers * lines))
    assert error == 0
    report["inverse_router_identity_error"] = float(error)
    report["scope"] = "Topology and carrier-level algebra; no device or ML simulation."
    output = Path(__file__).parent / "results" / "routing_coverage_checks.json"
    output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
