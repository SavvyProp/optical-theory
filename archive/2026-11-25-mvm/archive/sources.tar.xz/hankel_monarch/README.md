# Hankel optical multipliers: native core and full Hankel matmul

This folder is a starting point for investigating a shallow, rapidly programmable structured matrix multiplier. It now has three documents:

| Document | Purpose |
|---|---|
| [Requirements](requirements.md) | Physical constraints, useful ML capabilities and evaluation criteria |
| **This README** | The native structure, full Hankel matmul, hardware implementation and footprint |
| [Limitations and constructions](limitations.md) | Proven restrictions and temporal-sum constructions, with their assumptions |

The baseline uses local SFG-generated weight pumps, two banks of DFG interactions, fixed uniform fiber phases and a fixed wavelength-preserving shuffle. It has no assumed dense optical mixer. The analysis is an ideal model, not a demonstrated device or a 100-GHz throughput result.

The **full Hankel matmul** defined in section 7 combines two consecutive Hankel multipliers with coherent temporal summation. Banks of these components connected by the balanced shuffle give a Monarch family up to a fixed output permutation, under the coefficient assumptions stated below.

For the proposed integrated implementation, see [hardware, accumulation/replay loops and footprint](#9-hardware-implementation-of-one-full-hankel-multiplier).

## 1. Inputs, weights and local Hankel action

There are \(n\) spatial fibers or waveguides, each carrying \(K\) wavelength channels: \(d=nK\) input coordinates. Values are encoded in coherent field amplitudes. Initially nonnegative data is allowed, but the interface must preserve any phases/signs produced by the multiplier.

A local pump with \(2K-1\) coefficients \(h_0,\ldots,h_{2K-2}\) drives the selected DFG output

\[
b_j=\sum_{k=0}^{K-1}h_{j+k}\,\overline{x_k},
\qquad b=H(h)\bar x.
\]

For \(K=3\),

\[
H(h)=
\begin{pmatrix}
h_0&h_1&h_2\\
h_1&h_2&h_3\\
h_2&h_3&h_4
\end{pmatrix}.
\]

A single DFG conjugates its data input. Two such stages restore an ordinary complex-linear map.

**SFG prepares the weight pump independently of the data.** If the data also determines the SFG pump, the overall operation is data-dependent and generally nonlinear; that is a different service from the fixed-weight matvec studied here.

## 2. One complete mixing block

The data path is:

1. First local DFG bank, then filter to the designated intermediate comb.
2. Fixed phase shifter on each fiber, uniform across its wavelengths.
3. Fixed diffraction routing that redistributes wavelengths between fibers.
4. Second local DFG bank, then filter back to the designated output comb.

Let \(B_1,B_2\) be block-diagonal banks with one \(K\times K\) Hankel per fiber,

\[
D=\operatorname{diag}(e^{i\theta_b}I_K),\qquad
P:(b,l)\mapsto(\pi_l(b),l).
\]

Here \(P\) is a routing permutation: it changes spatial destination while preserving wavelength. It is not an arbitrary coherent dense transform. The complete operation is

\[
x\mapsto B_1\bar x\mapsto DB_1\bar x
\mapsto PDB_1\bar x\mapsto Wx,
\qquad
\boxed{W=B_2P\bar D\,\overline{B_1}.}
\]

For a measured complex routing transfer \(R_{\rm route}\), use
\(W=B_2\overline{R_{\rm route}}\bar D\,\overline{B_1}\).
The proofs in [limitations.md](limitations.md) specify their ideal permutation assumptions.

A useful balanced test layout has \(n=K\) and
\(\pi_l(b)=(b+l)\bmod n\): one intermediate route connects every source/destination fiber pair. Other layouts must be analyzed with their actual route counts.

## 3. Weight coefficients: baseline versus expressivity bound

| Model | Available coefficients | Interpretation |
|---|---|---|
| Raw amplitude-only self-SFG | \(h_s=(u*u)_s=\sum_{r+t=s}u_ru_t,\ u_r\ge0\) | Original physical primitive; \(K\) real controls generate \(2K-1\) constrained, nonnegative coefficients |
| Independent complex Hankel coefficients | Arbitrary \(h_s\in\mathbb C\) | Optimistic mathematical relaxation; requires a separately specified and costed pump encoder |

A uniform fiber phase does not turn the raw coefficient set into arbitrary complex weights. The relaxation is useful because an impossibility proved there also holds for the raw design. A construction possible only in the relaxation is not automatically available from the raw pump.

The family uses shared coefficients across many pairwise products. It can have far fewer programmable parameters than a dense matrix while transmitting a full-dimensional signal: if the local Hankels and router are invertible, so is the complete matrix. Rank, independent programmability and energy efficiency must be evaluated separately.

## 4. Carrier bands and filtering

Use distinct, nonoverlapping data bands \(A\) and \(B\), with matching spacing \(\Delta\):

\[
\omega_{A,k}=\omega_A+k\Delta,\quad
\omega_{B,j}=\omega_B+j\Delta,\quad
\Omega_s=\omega_A+\omega_B+s\Delta.
\]

The first DFG combines the pump at \(\Omega_{j+k}\) with input \(A_k\) to generate \(B_j\). The second combines its independently programmed pump with \(B_k\) to generate \(A_j\). Input and final output therefore share the original carrier grid. A self-SFG weight comb centered at \((\omega_A+\omega_B)/2\) generates the required pump grid.

After **each** DFG, wavelength filtering must retain exactly the designated \(K\) channels and reject the seed, pump and unwanted idlers. Intermediate filtering matters: an unwanted intermediate idler can otherwise mix back into a retained final channel. Distinct bands provide a wavelength-based separation path without assuming a device that separates coincident seed and generated fields.

Band offsets, nonlinear phase matching, filter passbands and modulation sidebands must be designed together. The Hankel equation assumes sufficiently uniform coupling and the weak-conversion selected-mode approximation. Stronger conversion, nonuniform coupling, depletion or leaked modes can change the transfer. Input and weight envelopes must overlap with suitable path matching. Nonlinear response speed alone does not establish a usable 100-GHz update rate.

## 5. Baseline physical cost

For one core with independent raw self-SFG pumps:

| Resource | Count |
|---|---:|
| Spatial data paths | \(n\), with no projected data copies |
| Serial data DFG interactions | 2 |
| Data DFG sections | \(2n\) |
| Parallel pump SFG sections | \(2n\) |
| Programmable weight vectors | \(2n\), each with \(K\) amplitude channels |
| Independent weight amplitude controls | \(2nK\) |
| Fixed routing stages | 1 |
| Uniform fiber phase settings | \(n\), fixed during fast updates |

The pump-generation SFG sections are outside the serial data path. Filters, phase shifters, pump distribution, modulators, coupling loss and control hardware are additional costs. Replacing raw pumps with a richer encoder changes the weight-source cost.

## 6. Temporal accumulation variant

Hold the same coherent input vector over `T` synchronized settings of both Hankel banks and accumulate their completed outputs with a fixed optical field filter:

\[
W_T=\sum_{t=1}^T c_t B_{2,t}P\bar D\,\overline{B_{1,t}},
\qquad y=W_Tx.
\]

This reuses the spatial multiplier across time. The coefficients `c_t` are fixed scalar temporal taps, assumed to act identically on all WDM channels up to declared fixed phase gauges. Wavelength-dependent filter responses define a different family. Positive taps preserve extra restrictions of raw self-SFG pumps; signed or complex taps are an additional resource.

Both banks must vary to escape the general single-core Hankel-product family; with one bank fixed, the sum collapses into one effective Hankel bank. For raw pumps, that collapse can still enlarge the attainable pump coefficient set.

Nonlinear depth and data-path count stay unchanged, while each independent result consumes `T` weight slots and requires coherent delay/filtering and output framing. Chaining requires a timing protocol that supplies the same intermediate vector over the next layer's window. The [temporal capability assessment](limitations.md#6-which-requirements-temporal-sums-repair) distinguishes proven improvements, remaining obstructions and constructions needing many slots.

A distinct variant removes the shuffle and sums consecutive local pairs, `A=sum_t H_(2,t) H_(1,t)`. For Hankels acting on an entire `N`-coordinate vector, **every real or complex matrix is representable in `ceil(N/2)` terms with unrestricted signed/complex coefficients**. For even `N`, this worst-case count is optimal. The [construction and its limits](limitations.md#7-sums-of-local-hankel-product-pairs-an-exact-dense-construction) use only offline weight compilation, with no additional optical dense mixer. This does not supply arbitrary coefficients from raw amplitude-only self-SFG, create missing connections between fibers, or reduce the universal coefficient budget below quadratic.

## 7. Full Hankel matmul: the reusable local component

Call the following an **`N by N` full Hankel matmul**, abbreviated `FHM_N`:

\[
\boxed{\operatorname{FHM}_N[A](x)=Ax
=\sum_{t=0}^{T-1}H_{2,t}H_{1,t}x,
\qquad T=\lceil N/2\rceil.}
\]

Its data path is **Hankel multiplier → intermediate filter → Hankel multiplier → output filter → coherent temporal sum**. The same two multipliers are reprogrammed across slots. Each pair returns the original carrier grid and restores complex linearity after the two DFG conjugations; program the conjugate of the algebraic first factor as explained in [the proof](limitations.md#7-sums-of-local-hankel-product-pairs-an-exact-dense-construction). Fixed scalar tap normalization can be included in the compiled weights or retained as a known output scale.

“Full” means arbitrary local matrix coverage, including singular matrices; it does not mean only full-rank targets. The guarantee requires independent signed or complex Hankel coefficients. The original amplitude-only self-SFG encoder does not yet supply that guarantee. Fixed uniform fiber phases alone do not close this gap.

| Local resource | `FHM_N` |
|---|---|
| Input/output | One coherent `N`-line data comb, same carrier grid at the output |
| Programmable Hankel stages | 2, with no internal spatial shuffle |
| Worst-case sufficient temporal terms | `ceil(N/2)`; sharp for even `N` |
| Pump coefficient slots per compiled matrix | `2 ceil(N/2)(2N-1)` signed/complex values |
| Data interface | Coherently held input; framed output from a calibrated temporal field sum |
| Additional optical elements | Band filters and either a temporal tapped-delay filter or the framed accumulation/replay loops in section 9; pump encoder and losses require separate accounting |

This replaces an arbitrary local dense block by a shallow programmable optical computation. It does not reduce that block's generic quadratic weight budget. The compiler is offline and does not introduce a dense optical mixer.

## 8. Arrays of full Hankel matmuls and Monarch

Return to the folder's notation: `n` fibers, `K` wavelengths per fiber, `d=nK`. A bank contains one `FHM_K` per fiber. Define arbitrary local-block banks

\[
R=\operatorname{diag}(R_0,\ldots,R_{n-1}),\qquad
L=\operatorname{diag}(L_0,\ldots,L_{n-1}).
\]

The architecture is **first full-Hankel bank → fixed frequency-dependent spatial routing → second full-Hankel bank**. Unlike the baseline, temporal accumulation completes the local blocks themselves. Its effective operator is `W=B_2 P B_1`, where each block of `B_1,B_2` is now arbitrary. There are four serial data DFG interactions, two per full-Hankel bank.

### Exact relation in the balanced layout

Take `n=K`, hence `d=K²`. The square Monarch definition is

\[
M=Q L Q R,\qquad Q:(b,l)\mapsto(l,b),\qquad Q^2=I,
\]

with unrestricted `K by K` diagonal blocks in `L,R`. See [Dao et al., Definition 3.1](https://proceedings.mlr.press/v162/dao22a/dao22a.pdf).

The physical cyclic router preserves wavelength: `P(b,l)=(b+l,l)` modulo `K`. It is not `Q`. Nevertheless define local permutations

\[
S(b,l)=(b,l-b),\qquad T(a,q)=(a,a-q).
\]

Direct substitution gives `T P S=Q`. Program the first bank as `B_1=S R` and the second as `B_2=L T`. These are still arbitrary local blocks, so their permutations can be compiled into the full-Hankel weights. Then

\[
\boxed{W=B_2 P B_1=L Q R=Q M.}
\]

Thus the physical one-shuffle family is **exactly a fixed output permutation of the square Monarch family**, not a Hankel-restricted subset. This equivalence is our derivation from the router and the local full-matrix theorem. It is not a claim that passive diffraction changes optical wavelengths. An array with only one full-Hankel bank followed by routing remains a permuted block-diagonal operation; both banks matter.

The output permutation is an encoding convention only when the consumer accepts that ordering. The native physical output is on the original WDM grid and can feed another native bank directly, but it is `Wx`, not canonically ordered `Mx`. If exact canonical Monarch order is physically required, one explicit identity is

\[
M=T P (S L T) P (S R).
\]

This requires two routing stages and three local banks; the last bank implements a fixed local permutation `T`. It can be absorbed into a subsequent arbitrary local bank when the interface allows. The added routing and any wavelength conversion inside that local operation are real costs. General unbalanced arrays or different routing graphs need their own comparison.

### Capabilities and physical scale

For one balanced native array, each physical source/destination block is

\[
W_{ab}=B_{2,a}[:,\ell_{ab}]\,B_{1,b}[\ell_{ab},:],
\qquad \ell_{ab}=(a-b)\bmod K.
\]

These outer-product factors are now independent across fiber pairs. Consequently the physical family is exactly all matrices with rank at most one in each `K by K` fiber block. This permits every global rank-one map, dense full-rank matrices, and every logical diagonal after the fixed Monarch output convention. It still excludes arbitrary global dense matrices and general unitary coverage for `K>1`. The generic dimension is `K²(2K-1)=2d^(3/2)-d`, from `K²` independent rank-one blocks.

| Resource for two balanced full-Hankel banks | Count |
|---|---:|
| Data fibers per bank | `K=sqrt(d)` |
| Local full-Hankel components | `2K` |
| Data DFG sections / serial interactions | `4K` / 4 |
| Programmable Hankel pump combs | `4K`, each with `2K-1` effective coefficients |
| Temporal field filters | `2K`, each with `T=ceil(K/2)` taps |
| Effective dense-block coefficient slots | `2K³=2d^(3/2)` |
| Compiled Hankel coefficient slots | `4K T(2K-1)=O(d^(3/2))` |
| Internal routing stages | 1; canonical output restoration costs extra as above |

There is no branching into one nonlinear data waveguide per global matrix entry. An explicit split-delay-combine implementation of the temporal filters can nevertheless use `O(KT)=O(d)` tap paths; a distributed grating implementation has its own footprint and fabrication cost. Neither the temporal filter nor the richer pump encoder is free.

The paper assigns some transform guarantees to products of Monarch factors. Proposition 3.2 places convolution, Toeplitz and AFDF in `MM*`, and DST/DCT, Fastfood and ACDC in `(MM*)²`; these are not all guarantees for one `M`. Hadamard is also available in a single `M` through its butterfly inclusion (appendix, proof of Proposition 3.2). [Monarch paper](https://proceedings.mlr.press/v162/dao22a/dao22a.pdf)

Here `MM*` means products `M_1 M_2*` of two independently chosen Monarch matrices, with `*` denoting conjugate transpose; the factors need not be equal. Implementing these larger families requires the corresponding additional banks, routing and boundary encodings. Algebraically `MM*` merges to three arbitrary local banks separated by two transpose shuffles, with boundary permutations; `(MM*)²` merges to five banks and four shuffles. This counts merged logical banks, not an uncosted physical permutation or a proof that one native array supplies every listed transform.

### Chaining the two temporal sums without a quadratic slot count

Let the programmed physical banks be `B_1=sum_p B_(1,p)` and `B_2=sum_q B_(2,q)`, including any compiled local permutations. Each term is one complete Hankel-pair bank. Hold the same coherent input `x` while each bank cycles periodically through its own term list. Use equal coherent temporal taps, normalized by fixed scalars `alpha_1,alpha_2`. After aligning propagation delays, the first filter output is

\[
s[k]=\alpha_1\sum_{a=0}^{T_1-1}B_{1,(k-a)\bmod T_1}x
=\alpha_1 B_1 x,\qquad k\ge T_1-1.
\]

Every full window contains each first-bank term once. Therefore the second bank receives a constant completed intermediate vector throughout its accumulation window:

\[
y[k]=\alpha_2\sum_{b=0}^{T_2-1}
B_{2,(k-b)\bmod T_2}P s[k-b]
=\alpha_1\alpha_2 B_2 P B_1 x
\]

at frame endpoint `k=T_1+T_2-2`. There are **`T_1+T_2-1` held-input slots**, or `2T-1` for equal lengths. At subsequent frames, read only after both windows have flushed the previous frame. No intermediate optical register is assumed. Applying only a final temporal sum to synchronized pairs would instead give `sum_t B_(2,t) P B_(1,t)`, which omits the cross terms of the desired product.

This protocol requires equal complex tap responses across the WDM lines, coherent phase stability, input holding, propagation alignment and output framing. Nonuniform tap weights do not generally give the constant intermediate above. A fixed split-delay-combine filter is an implementation path; a Bragg grating would need the same calibrated transfer. Passive normalization reduces amplitude: an equal-tap single-channel filter has `|alpha|<=1/T` for a nonamplifying transfer. Known scaling can be encoded or compensated, but power and noise costs remain.

For `d=1024`, choose 32 fibers and 32 wavelengths: each local block needs at most 16 terms, and the ideal two-bank frame is 31 slots. There are 128 data DFG sections with serial depth four. At a *hypothetical achieved* 100-GHz slot rate, 31 slots occupy 310 ps, excluding propagation and implementation overhead. This is a schedule calculation, not measured throughput or an energy-efficiency prediction.

[full_hankel_monarch_checks.py](full_hankel_monarch_checks.py) verifies the routing and compiles both local banks for block sizes 2–5. Its [recorded results](results/full_hankel_monarch_checks.json) cover 16 frames, including changed inputs and weights without resetting filter histories and unequal bank periods. The largest normalized output error is `2.85e-13`; these are ideal algebra checks.

## 9. Hardware implementation of one full Hankel multiplier

This is a candidate hybrid photonic implementation of one `FHM_N` on one spatial data path. It combines real component types, but the complete device, its analog accuracy and operation at 100-GHz slot rates have not been demonstrated. The baseline uses fixed couplers, clocked electroabsorption modulators (EAMs), and calibrated temporal weights. Fast tunable MZI coupling is an optional alternative.

### 9.1 Signal path and material platform

```mermaid
flowchart TD
    X["Repeated coherent input x, band A"] --> C1["WDM pump combiner"]
    W1["Encoded weight comb 1"] --> S1["SFG pump generator 1"]
    S1 --> C1
    C1 --> D1["DFG Hankel 1"]
    D1 --> F1["Remove pump; select band B"]
    F1 --> C2["WDM pump combiner"]
    W2["Encoded weight comb 2"] --> S2["SFG pump generator 2"]
    S2 --> C2
    C2 --> D2["DFG Hankel 2"]
    D2 --> F2["Remove pump; select band A"]
    F2 --> A["Coherent accumulation loop"]
    A --> G["Tap coupler and timed output gate"]
    G --> R["Replay loop"]
    R --> Y["Repeated result for the next multiplier"]
```

The two SFG sections prepare independent pumps outside the data path. At slot \(k\), physical DFG pump generators \(p_{1,k},p_{2,k}\) give

\[
b_k=H(p_{1,k})\bar x,\qquad
v_k=H(p_{2,k})\overline{H(p_{1,k})}x.
\]

For compiled algebraic factors \(H_{1,k}=H(h_{1,k})\), \(H_{2,k}=H(h_{2,k})\), set \(p_{1,k}=\bar h_{1,k}\), \(p_{2,k}=h_{2,k}\), if those pump coefficients are available. Two DFG stages restore linearity and the original carrier band. One SFG-pump/DFG stage alone does not implement the full Hankel product.

Use a second-order nonlinear platform such as periodically poled thin-film lithium niobate for SFG/DFG, with silicon or SiN routing and control sections. SHG/SFG has been demonstrated in LN films bonded onto silicon substrates with SiN-loaded waveguides. This establishes a hybrid integration path, not a completed multiplier. [Rao et al.](https://arxiv.org/abs/1609.09117)

Near a 1500-nm fundamental, the sum-frequency pump is approximately 750 nm. Ordinary silicon absorbs this wavelength; keep the pump in the LN/SiN-compatible region and separate it before transferring telecom data into silicon circuitry. Keep the nonlinear sections and pump-rejection filters outside the recirculating paths.

The raw nonnegative self-SFG encoder still produces constrained coefficients \(p=u*u\). This hardware diagram does not resolve the arbitrary signed/complex pump-encoding requirement in section 3; a richer encoder needs its own implementation and cost.

### 9.2 Bandpass filtering

A concrete whole-comb filter is an **apodized contra-directional Bragg coupler**: a patterned grating couples a selected wavelength band between adjacent waveguides into a drop port. It retains the desired comb together without requiring a separate filter per line or an external circulator. Silicon devices have demonstrated flat-top drop bands exceeding 30 nm with greater than 50-dB sidelobe suppression and less than 0.85-dB excess loss in cascaded configurations. [Yun et al.](https://opg.optica.org/ol/abstract.cfm?uri=ol-44-20-4929)

Coarse separation of the visible pump and precise selection of the retained DFG band are distinct filtering tasks. After each DFG, pass all \(N\) designated lines **and their modulation sidebands**, while rejecting the residual seed and unwanted idlers. The intermediate filter is necessary to prevent unwanted lines from mixing back into the final output.

Use nonoverlapping bands \(A\) and \(B\): a spectral filter cannot distinguish seed and generated light at the same frequency. Design the spectral edges, amplitude ripple and group delay for the actual comb. The cited broadband response does not establish sufficiently sharp rejection of the nearest unwanted idler or preservation of 10-ps pulses.

Reserve spectral guard bands after accounting for modulation and nonlinear multiplication of the pump/data envelopes. A 100-GHz line spacing and a 100-GHz update target are not by themselves evidence that the modulated channels remain separable.

### 9.3 Coherent accumulation with a fixed loop

The accumulator contains an injection coupler, a one-slot delay, fixed phase trim and a reset EAM. With initially empty state \(a_0=0\), common roundtrip field coefficient \(r\), injection coefficient \(\kappa\), and one completed Hankel-pair result per slot,

\[
a_k=r a_{k-1}+\kappa v_k,\qquad
a_T=\kappa\sum_{k=1}^{T}r^{T-k}v_k.
\]

The fixed loop therefore supplies a **weighted coherent sum**. Its roundtrip coefficient includes propagation loss, EAM transmission, coupling losses, extraction leakage and phase. A passive injection coupler cannot have both unity field retention and nonzero injection.

If \(r\) is stable and common across all channels, offline compilation can compensate: program physical terms \(s\,v_k/(\kappa r^{T-k})\), obtaining \(s\sum_k v_k\). The common output scale \(s\) can keep pump settings within range. Earlier terms need greater relative weight; compensating attenuation does not recover lost energy or eliminate noise and dynamic-range costs. Align the common phase with fixed trims before treating this as amplitude-only compensation. Wavelength-dependent \(r\) generally requires a different operator model, not one scalar correction per slot.

To reset, disable injection and put the in-loop EAM into its absorbing state for at least one roundtrip, with additional clearing time if required by its extinction and switching response. Finite extinction leaves residual state. Its transmitting-state loss is incurred on every lap.

An EAM is an attenuator, not a tap: **extract through a directional/MMI coupler and gate the extracted branch with an EAM**. Closing that output gate does not remove the fixed tap's loss from the loop. A clocked \(2\times2\) MZI switch could instead route the completed state out and dump residual light, but requires fast electro-optic routing control.

Such a switch is an additional resource relative to fixed phase settings. Its phase-shifter arms may also force a roundtrip longer than 10 ps; the compact EAM-loop sizing below cannot automatically be assigned to an MZI-loop design.

### 9.4 Replay for the next multiplier

Load the extracted vector into a second delay loop. For loaded state \(b_0\), output tap coefficient \(d\), and roundtrip field coefficient \(q\), a fixed tap emits

\[
y_j=d\,q^j b_0,\qquad j=0,\ldots,R-1.
\]

These are decaying copies of the same vector if \(q\) is common across wavelengths. A reset gate terminates the frame; it does not flatten the copies. Include this known decay in the next multiplier's compiled weights, along with its accumulation weights and the extraction/loading scale.

For equal copies without geometric pre-emphasis, a time-varying output coupler is an alternative: in an ideal lossless loop, extracting the power fraction \(1/(R-j)\) on step \(j\) gives \(R\) copies of field \(b_0/\sqrt R\). It needs clocked coupling control; it is not implemented by an EAM alone. Loss and modulation-induced phase must still be accounted for.

One loop can accumulate and then replay sequentially with suitable coupling/gating. Two loops permit overlap between replay and accumulation of a subsequent frame, subject to the complete scheduling constraints.

### 9.5 Timing, coherence and chaining

For the framed loop implementation:

1. Clear the accumulator and supply the same coherent input over \(T\) weight slots, or calibrated replay copies with their decay included in the weights.
2. Align both pumps with the corresponding data slot through the two DFG stages.
3. Extract only the completed sum, then replay it over the next layer's required slots.
4. Clear or fully empty each loop before its next frame; include gate/reset and loading overhead in throughput.

This is a different schedule from the equal-tap feedforward FIR plateau protocol in section 8. **The FIR result of \(T_1+T_2-1\) slots, including the 31-slot example, does not automatically apply to fixed recirculating loops.** A loop frame has \(T\) accumulation slots followed by replay for downstream processing; pipelining and independent-vector throughput need a separate schedule.

In an ideal nondispersive loop, choose line spacing \(\Delta f\) and roundtrip delay \(\tau\) such that \(\Delta f\,\tau\) is an integer. Delay-induced carrier phase is then common to the comb lines. Stabilize that common phase and control dispersion, wavelength-dependent loss and pulse distortion. A 100-GHz comb spacing is commensurate with a 10-ps delay; comb spacing and weight-update rate remain separate specifications.

The total roundtrip delay is \(\tau=\int n_g(s)\,ds/c\), including EAMs, couplers and transitions. For a uniform-waveguide approximation:

| Assumed platform | Group index | Path for \(\tau=10\) ps | Equivalent circular diameter |
|---|---:|---:|---:|
| Silicon | 4 | 0.75 mm | 0.24 mm |
| Silicon nitride | 2 | 1.5 mm | 0.48 mm |

Increasing \(T\) reuses this path rather than requiring a \(T\)-times-longer loop, but increases storage time and accumulated loss. A several-millimetre nonlinear section can have transit time exceeding one slot while remaining pipelined; pump/data walk-off and slot alignment determine whether the programmed operation is preserved.

### 9.6 Preliminary footprint and component budget

For **one spatial path**, allocate roughly **15–50 mm²** to an integrated hybrid optical core; **10 mm × 5 mm** is a useful initial planning envelope. This is an engineering allowance, not a validated layout, a physical size bound or a demonstrated device specification.

| Part | Count | Sizing assumption |
|---|---:|---|
| Nonlinear sections | 2 SFG + 2 DFG | About 4–5 mm interaction length each |
| DFG band-selection filters | 2 | Allow 0.1–1 mm longitudinally per assembly, including access/tapers/cascading |
| Accumulation and replay loops | 2 | Roughly 0.05–0.2 mm² each in silicon, or 0.2–0.5 mm² each in suitable SiN, excluding RF pads |
| Reset and valid-output EAMs | At least 3 in the two-loop baseline | 20–40 µm active length is a literature scale, not the complete electrical footprint |
| Pump combiners/separators, hybrid transitions, phase trims and routing | Layout-dependent | Included as allowance in the overall core estimate |

Four 5-mm nonlinear sections give about 20 mm of total interaction path, but can be placed alongside each other. A relevant DFG experiment fabricated several 4.8-mm PPLN waveguides on a 5 mm × 5 mm die. It does not establish uniform response for all simultaneous Hankel pump–signal combinations. [Koyaz et al.](https://arxiv.org/html/2410.08790v1)

GeSi EAMs with 20- and 40-µm active lengths have demonstrated greater than 110-GHz and approximately 100-GHz small-signal bandwidths respectively, near 1580 nm. These figures exclude RF access and do not demonstrate a high-extinction 10-ps gate across the proposed comb near 1500 nm. [Monolithic electro-optic platform on silicon](https://doi.org/10.1038/s41467-025-66566-2)

The area estimate assumes already encoded input and weight combs. It excludes lasers/comb sources, per-line modulator banks and their demultiplexers/remultiplexers, RF drivers, external amplification, packaging, and any extra hardware needed for arbitrary signed/complex pump coefficients. For the raw two-\(N\)-line self-SFG encoders, weight loading needs \(2N\) independently modulated channels; loading the input on-chip adds \(N\). At \(N=40\), those are 80 weight channels plus 40 input channels. Their electrical access and wavelength routing may dominate the complete system footprint.

The main sizing uncertainty is the nonlinear length needed for acceptable conversion, power consumption and full-comb uniformity. The main loop uncertainties are roundtrip loss, coherent stability and usable reset/gate performance. Neither component dimensions nor small-signal bandwidth alone establish system throughput.

## 10. Starting point for further exploration

Evaluate this actual family as a learned projection before adding hardware. Use [requirements.md](requirements.md) to select the role and measurements, and [limitations.md](limitations.md) to identify which capabilities are already ruled out.

The main open questions are task accuracy, usable conditioning, physical conversion efficiency, sensitivity to channel layout, and whether a second complete core or a small explicit addition improves the measured quality/cost tradeoff. Any extension needs a stated operator, compatible optical interfaces and a component count.

The retained Python files and result files include earlier exploratory calculations; their presence does not endorse an optical architecture. The checks directly supporting this baseline are:

- [single_shuffle_checks.py](single_shuffle_checks.py): structural identities, counterexamples and exceptions.
- [temporal_sum_checks.py](temporal_sum_checks.py): temporal-sum invariants, gain constructions and surviving raw-pump restrictions.
- [hankel_pair_sum_checks.py](hankel_pair_sum_checks.py): constructive decompositions into `ceil(N/2)` consecutive Hankel products in the unrestricted coefficient model.
- [full_hankel_monarch_checks.py](full_hankel_monarch_checks.py): compiled local blocks, cyclic-to-Monarch equivalence and framed two-bank temporal composition.
- [routing_coverage_checks.py](routing_coverage_checks.py): reachability under the actual cyclic permutation.
- [ml_operator_diagnostics.py](ml_operator_diagnostics.py): rank and approximation distinctions.

Run the main algebra checks from the repository root:

    python3 hankel_monarch/single_shuffle_checks.py

No model-quality or fabricated-device benchmark is included.
