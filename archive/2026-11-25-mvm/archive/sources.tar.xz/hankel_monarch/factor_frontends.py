"""Five fixed Fourier ports synthesize two complex SFG factor combs.

All five inputs have nonnegative, independently programmed WDM amplitudes. The
fixed mixer creates the complex factors before either two self-SFG sections or
one isolated cross-SFG section. No phase setting changes with the target.

Run: python3 hankel_monarch/factor_frontends.py
This checks field algebra and passive normalization, not device propagation.
"""

from __future__ import annotations

import json

import numpy as np

from constant_branch import factor_generator, relative_error


THETA = 2 * np.pi * np.arange(5) / 5
FIXED_FIVE_PORT = np.exp(-1j * np.outer(np.arange(5), THETA)) / np.sqrt(5)


def joint_amplitude_rails(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Encode arbitrary complex a,b as five nonnegative amplitude-only rails.

    The fixed Fourier outputs are (r, a, b, conjugate(b), conjugate(a)). The
    offset r is the smallest coefficientwise offset for these five samples.
    """
    a, b = np.asarray(a, complex), np.asarray(b, complex)
    if a.ndim != 1 or a.shape != b.shape:
        raise ValueError("a and b must be equal-length one-dimensional arrays")
    samples = 2 * np.real(np.exp(1j * THETA[:, None]) * a
                          + np.exp(2j * THETA[:, None]) * b)
    offset = np.maximum(0.0, -np.min(samples, axis=0))
    return (offset + samples) / np.sqrt(5)


def mix_joint_rails(rails: np.ndarray) -> np.ndarray:
    """Apply the fixed, unitary five-port spatial mixer at every wavelength."""
    rails = np.asarray(rails)
    if rails.ndim != 2 or rails.shape[0] != 5:
        raise ValueError("rails must have shape (5, K)")
    return FIXED_FIVE_PORT @ rails


def selected_factor_retention(rails: np.ndarray) -> float:
    """Fundamental-band power in ports 1,2 divided by five-rail input power."""
    outputs = mix_joint_rails(rails)
    incident = float(np.sum(np.abs(rails) ** 2))
    selected = float(np.sum(np.abs(outputs[1:3]) ** 2))
    return selected / incident if incident else 0.0


def self_sfg_from_factors(p: np.ndarray, q: np.ndarray,
                          *, normalized_combiner: bool = True) -> tuple:
    """Use two self-SFG sections, with a=(p+q)/2, b=(p-q)/2.

    The physical balanced difference port is (a*a-b*b)/sqrt(2)=p*q/sqrt(2).
    Returns output pump, encoded input rails, and high-band combining retention.
    Coupling constants and conversion efficiency are not modeled.
    """
    p, q = np.asarray(p, complex), np.asarray(q, complex)
    rails = joint_amplitude_rails((p + q) / 2, (p - q) / 2)
    outputs = mix_joint_rails(rails)
    first, second = np.convolve(outputs[1], outputs[1]), np.convolve(outputs[2], outputs[2])
    difference = first - second
    incident = float(np.vdot(first, first).real + np.vdot(second, second).real)
    retention = float(np.vdot(difference, difference).real / (2 * incident)) if incident else 0.0
    pump = difference / np.sqrt(2) if normalized_combiner else difference
    return pump, rails, retention


def cross_sfg_from_factors(p: np.ndarray, q: np.ndarray) -> tuple:
    """Feed the two selected factor ports into ONE isolated cross-SFG section.

    Both desired factor fields are programmable. This differs from a strong
    fixed-CW translator. Self-SFG terms must be suppressed or separated.
    """
    rails = joint_amplitude_rails(p, q)
    outputs = mix_joint_rails(rails)
    return np.convolve(outputs[1], outputs[2]), rails


def verification_report(seed: int = 314159) -> dict:
    rng = np.random.default_rng(seed)
    maximum_joint_error = 0.0
    maximum_power_error = 0.0
    maximum_self_error = 0.0
    maximum_cross_error = 0.0
    maximum_compiler_error = 0.0
    minimum_factor_retention = 1.0
    maximum_factor_retention = 0.0
    minimum_difference_retention = 1.0
    cases = 0
    for k in (1, 2, 3, 4, 8, 16):
        for _ in range(25):
            p = rng.normal(size=k) + 1j * rng.normal(size=k)
            q = rng.normal(size=k) + 1j * rng.normal(size=k)
            target = np.convolve(p, q)
            cross_pump, cross_rails = cross_sfg_from_factors(p, q)
            outputs = mix_joint_rails(cross_rails)
            joint_error = relative_error(outputs[1:3], np.stack((p, q)))
            input_power = float(np.sum(np.abs(cross_rails) ** 2))
            output_power = float(np.sum(np.abs(outputs) ** 2))
            power_error = abs(input_power - output_power) / input_power
            assert np.min(cross_rails) >= 0
            assert joint_error < 1e-12
            assert power_error < 1e-12
            assert np.allclose(outputs[3], q.conj())
            assert np.allclose(outputs[4], p.conj())
            self_pump, self_rails, difference_retention = self_sfg_from_factors(p, q)
            self_error = relative_error(np.sqrt(2) * self_pump, target)
            cross_error = relative_error(cross_pump, target)
            assert max(self_error, cross_error) < 1e-11
            for rails in (cross_rails, self_rails):
                retention = selected_factor_retention(rails)
                assert 0.1 - 1e-12 <= retention <= 0.4 + 1e-12
                minimum_factor_retention = min(minimum_factor_retention, retention)
                maximum_factor_retention = max(maximum_factor_retention, retention)
            maximum_joint_error = max(maximum_joint_error, joint_error)
            maximum_power_error = max(maximum_power_error, power_error)
            maximum_self_error = max(maximum_self_error, self_error)
            maximum_cross_error = max(maximum_cross_error, cross_error)
            minimum_difference_retention = min(minimum_difference_retention, difference_retention)
            cases += 1

        # Separately verify arbitrary target coefficients through offline roots.
        for _ in range(10):
            target = rng.normal(size=2 * k - 1) + 1j * rng.normal(size=2 * k - 1)
            p, q = factor_generator(target, k)
            pump, _, _ = self_sfg_from_factors(p, q)
            error = relative_error(np.sqrt(2) * pump, target)
            assert error < 1e-8
            maximum_compiler_error = max(maximum_compiler_error, error)
            cases += 1

    # Tight endpoints of the selected-factor power bound.
    low = selected_factor_retention(joint_amplitude_rails(np.array([-1.0]), np.array([-1.0])))
    high = selected_factor_retention(joint_amplitude_rails(np.array([1.0]), np.array([1.0])))
    assert np.isclose(low, 0.1) and np.isclose(high, 0.4)
    zero = np.zeros(4)
    assert np.all(joint_amplitude_rails(zero, zero) == 0)
    assert np.all(cross_sfg_from_factors(zero, zero)[0] == 0)

    return {
        "seed": seed,
        "model": "fixed ideal five-port mixer; parallel amplitude-only rails; undepleted flat-coupling SFG",
        "n_nonzero_cases": cases,
        "max_joint_factor_relative_error": maximum_joint_error,
        "max_passive_power_relative_error": maximum_power_error,
        "max_known_factor_self_sfg_error": maximum_self_error,
        "max_known_factor_cross_sfg_error": maximum_cross_error,
        "max_offline_compiled_target_error": maximum_compiler_error,
        "observed_min_factor_port_retention": minimum_factor_retention,
        "observed_max_factor_port_retention": maximum_factor_retention,
        "proved_factor_port_retention_interval": [0.1, 0.4],
        "tight_endpoint_checks": [low, high],
        "observed_min_self_sfg_difference_port_retention": minimum_difference_retention,
        "physical_self_sfg_output_normalization": "target/sqrt(2) before pump rescaling",
        "warning": "Retention concerns specified passive ports, not total conversion or wall-plug efficiency; factor compilation is offline.",
    }


if __name__ == "__main__":
    print(json.dumps(verification_report(), indent=2))
