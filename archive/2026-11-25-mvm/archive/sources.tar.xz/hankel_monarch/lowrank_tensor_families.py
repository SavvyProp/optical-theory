"""Single-shot low-rank DFG maps with spatial or wavelength-packed latents.

This is a field-coefficient model with explicit frequency differences and
conjugation. It does not model phase matching, dynamics, noise, or conversion
efficiency. Every group is a simultaneous spatial branch, never a time slot.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
from pathlib import Path

import numpy as np

from pump_frontends import combine_trine, trine_rails


def sparse_dfg(pump: dict[int, complex], data: dict[int, complex]) -> dict[int, complex]:
    """All generated integer-frequency offsets: pump minus conjugated data."""
    generated: dict[int, complex] = {}
    for pump_index, pump_value in pump.items():
        for data_index, data_value in data.items():
            output_index = pump_index - data_index
            generated[output_index] = generated.get(output_index, 0j) + (
                pump_value * np.conj(data_value)
            )
    return generated


def _encode_pump(coefficients: np.ndarray, encode_amplitudes: bool) -> np.ndarray:
    if encode_amplitudes:
        # The same three fixed phases encode every target. Balanced combiner
        # attenuation is excluded here, so this isolates the data-path scaling.
        return combine_trine(trine_rails(coefficients))
    return coefficients


@dataclass(frozen=True)
class LowRankPlan:
    """U V^dagger, with U,V shaped (n_fibers, n_lines, rank)."""

    left: np.ndarray
    right: np.ndarray
    latent_group_size: int

    def __post_init__(self) -> None:
        if self.left.shape != self.right.shape or self.left.ndim != 3:
            raise ValueError("left/right must have matching (n, K, rank) shapes")
        if min(self.left.shape) < 1 or self.latent_group_size < 1:
            raise ValueError("all sizes must be positive")

    @property
    def n_groups(self) -> int:
        return (self.left.shape[2] + self.latent_group_size - 1) // self.latent_group_size

    @property
    def balanced_field_scale(self) -> float:
        return 1 / (self.left.shape[0] * self.n_groups)

    def dense(self) -> np.ndarray:
        rank = self.left.shape[2]
        return self.left.reshape(-1, rank) @ self.right.reshape(-1, rank).conj().T

    def resources(self) -> dict[str, int | float]:
        n, k, rank = self.left.shape
        groups = self.n_groups
        return {
            "fibers": n,
            "input_lines_per_fiber": k,
            "rank": rank,
            "latent_groups": groups,
            "peak_nonlinear_data_paths": n * groups,
            "serial_data_dfgs": 2,
            "total_data_dfgs": 2 * n * groups,
            "max_programmable_pump_lines_per_bank": min(rank, self.latent_group_size) * k,
            "complex_pump_coefficients": 2 * n * k * rank,
            "three_phase_weight_vectors": 6 * n * groups,
            "three_phase_amplitude_controls": 6 * n * k * rank,
            "cw_pump_sfg_sections": 2 * n * groups,
            "balanced_data_path_field_scale": self.balanced_field_scale,
        }

    def apply(
        self,
        inputs: np.ndarray,
        *,
        normalized_data_optics: bool = False,
        encode_amplitudes: bool = True,
    ) -> np.ndarray:
        """Use all frequency products, filter latents, then filter final WDM.

        Frequency bases are omitted: first-stage pump offsets are measured from
        nu_0 + omega_0, input offsets from omega_0, and latent offsets from nu_0.
        Stage two swaps the input/output bases. Carrier choices must make each
        intended process physically available and mode isolated.
        """
        n, k, rank = self.left.shape
        inputs = np.asarray(inputs, dtype=complex)
        if inputs.shape != (n, k):
            raise ValueError("inputs must have shape (n, K)")
        outputs = np.zeros((n, k), dtype=complex)
        for start in range(0, rank, self.latent_group_size):
            stop = min(start + self.latent_group_size, rank)
            width = stop - start
            latents = np.zeros(width, dtype=complex)
            for fiber in range(n):
                coefficients = self.right[fiber, :, start:stop].T.ravel()
                coefficients = _encode_pump(coefficients, encode_amplitudes)
                generated = sparse_dfg(dict(enumerate(coefficients)), dict(enumerate(inputs[fiber])))
                latents += np.array([generated.get(ell * k, 0j) for ell in range(width)])
            # Filtering before the next nonlinear stage is essential. Keeping
            # intermediate off-grid idlers changes the operator.
            selected_latents = {ell * k: value for ell, value in enumerate(latents)}
            for fiber in range(n):
                coefficients = self.left[fiber, :, start:stop].T.ravel()
                coefficients = _encode_pump(coefficients, encode_amplitudes)
                generated = sparse_dfg(dict(enumerate(coefficients)), selected_latents)
                outputs[fiber] += [generated.get(line, 0j) for line in range(k)]
        if normalized_data_optics:
            outputs *= self.balanced_field_scale
        return outputs


def compile_low_rank(matrix: np.ndarray, rank: int, n_fibers: int, group_size: int) -> LowRankPlan:
    """Balanced truncated-SVD factors, compiled offline."""
    matrix = np.asarray(matrix, dtype=complex)
    if matrix.ndim != 2 or matrix.shape[0] != matrix.shape[1]:
        raise ValueError("matrix must be square")
    dimension = matrix.shape[0]
    if dimension % n_fibers or not 1 <= rank <= dimension:
        raise ValueError("n_fibers must divide dimension and rank must lie in [1,d]")
    left, singular_values, right_h = np.linalg.svd(matrix, full_matrices=False)
    roots = np.sqrt(singular_values[:rank])
    shape = (n_fibers, dimension // n_fibers, rank)
    return LowRankPlan(
        (left[:, :rank] * roots).reshape(shape),
        (right_h[:rank].conj().T * roots).reshape(shape),
        group_size,
    )


def fixed_basis_toeplitz_bank(left_basis: np.ndarray, right_basis: np.ndarray, kernels: np.ndarray) -> np.ndarray:
    """Sum_s u_s v_s^dagger tensor T_s: a fixed-basis operator family."""
    n, length = kernels.shape
    if length % 2 != 1 or left_basis.shape != (n, n) or right_basis.shape != (n, n):
        raise ValueError("expected two (n,n) bases and n odd-length kernels")
    k = (length + 1) // 2
    indices = np.arange(k)
    out = np.zeros((n * k, n * k), dtype=complex)
    for s in range(n):
        toeplitz = kernels[s, k - 1 + indices[:, None] - indices[None, :]]
        out += np.kron(np.outer(left_basis[:, s], right_basis[:, s].conj()), toeplitz)
    return out


def _relative_error(observed: np.ndarray, expected: np.ndarray) -> float:
    return float(np.linalg.norm(observed - expected) / max(np.linalg.norm(expected), 1e-15))


def verification_report(seed: int = 26535) -> dict:
    rng = np.random.default_rng(seed)
    def random_complex(shape):
        return rng.normal(size=shape) + 1j * rng.normal(size=shape)

    errors = []
    for n in (1, 2, 4):
        for k in (1, 3, 5):
            for rank in sorted({1, min(3, n * k), min(6, n * k)}):
                left, right = random_complex((n, k, rank)), random_complex((n, k, rank))
                inputs = random_complex((n, k))
                for group_size in sorted({1, 2, rank}):
                    plan = LowRankPlan(left, right, group_size)
                    expected = (plan.dense() @ inputs.ravel()).reshape(n, k)
                    errors.append(_relative_error(plan.apply(inputs), expected))
                    errors.append(_relative_error(
                        plan.apply(inputs, normalized_data_optics=True),
                        expected * plan.balanced_field_scale,
                    ))

    n, k, rank = 3, 4, 3
    dimension = n * k
    target = random_complex((dimension, dimension))
    plan = compile_low_rank(target, rank, n, rank)
    singular_values = np.linalg.svd(target, compute_uv=False)
    residual_norm = np.linalg.norm(target - plan.dense())
    svd_error = abs(residual_norm - np.linalg.norm(singular_values[rank:]))

    # A product of four arbitrary complex Householder reflectors has a rank<=4
    # deviation from identity, so it can be recompiled into a single module.
    reflectors = np.eye(dimension, dtype=complex)
    for _ in range(4):
        vector = random_complex(dimension)
        reflector = np.eye(dimension) - 2 * np.outer(vector, vector.conj()) / np.vdot(vector, vector)
        reflectors = reflector @ reflectors
    residual_plan = compile_low_rank(reflectors - np.eye(dimension), 4, n, 4)
    reflector_error = _relative_error(np.eye(dimension) + residual_plan.dense(), reflectors)
    unitarity_error = _relative_error(reflectors.conj().T @ reflectors, np.eye(dimension))

    # Check fixed-basis tensor expression against its direct block factorization.
    left_basis, _ = np.linalg.qr(random_complex((n, n)))
    right_basis, _ = np.linalg.qr(random_complex((n, n)))
    kernels = random_complex((n, 2 * k - 1))
    block_diagonal = np.zeros((dimension, dimension), dtype=complex)
    indices = np.arange(k)
    for s in range(n):
        block_diagonal[s*k:(s+1)*k, s*k:(s+1)*k] = kernels[s, k-1+indices[:, None]-indices[None, :]]
    direct = np.kron(left_basis, np.eye(k)) @ block_diagonal @ np.kron(right_basis.conj().T, np.eye(k))
    tensor_error = _relative_error(fixed_basis_toeplitz_bank(left_basis, right_basis, kernels), direct)

    # Flat rank-one compression illustrates generated light discarded by the
    # latent filter, independently of spatial splitter/combiner normalization.
    flat_compression = []
    for lines in (1, 2, 4, 8, 32):
        generated = sparse_dfg(dict(enumerate(np.ones(lines))), dict(enumerate(np.ones(lines))))
        retained_fraction = abs(generated[0]) ** 2 / sum(abs(value) ** 2 for value in generated.values())
        expected_fraction = 3 * lines / (2 * lines**2 + 1)
        assert abs(retained_fraction - expected_fraction) < 1e-14
        flat_compression.append({
            "lines": lines,
            "retained_generated_power_fraction": float(retained_fraction),
            "predicted_fraction": expected_fraction,
        })

    report = {
        "seed": seed,
        "low_rank_action_checks": len(errors),
        "max_low_rank_relative_error": max(errors),
        "truncated_svd_frobenius_tail_error": float(svd_error),
        "four_reflectors_one_residual_module_relative_error": reflector_error,
        "reflector_product_unitarity_error": unitarity_error,
        "fixed_basis_tensor_identity_relative_error": tensor_error,
        "flat_rank_one_compression_filter_examples": flat_compression,
        "example_packed_resources_n64_K32_rank8": LowRankPlan(
            np.zeros((64, 32, 8)), np.zeros((64, 32, 8)), 8
        ).resources(),
    }
    assert max(errors) < 1e-12
    assert svd_error < 1e-12
    assert max(reflector_error, unitarity_error, tensor_error) < 1e-12
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = verification_report()
    rendered = json.dumps(result, indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered + "\n")
    print(rendered)
