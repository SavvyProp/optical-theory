"""Check full Hankel blocks, cyclic routing and coherent temporal framing.

Run: python3 hankel_monarch/full_hankel_monarch_checks.py

The model uses independently programmable complex Hankel generators and exact
equal-tap field filters. It checks algebra, not a physical pump encoder, filter
fabrication, conversion efficiency or a high-speed device demonstration.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from hankel_pair_sum_checks import compile_hankel_pairs


def block_diagonal(blocks: list[np.ndarray]) -> np.ndarray:
    n = blocks[0].shape[0]
    result = np.zeros((n*len(blocks), n*len(blocks)), dtype=complex)
    for i, block in enumerate(blocks):
        result[i*n:(i+1)*n, i*n:(i+1)*n] = block
    return result


def permutation(n: int, route) -> np.ndarray:
    result = np.zeros((n*n, n*n))
    for b in range(n):
        for k in range(n):
            a, j = route(b, k)
            result[a*n+j, b*n+k] = 1
    assert np.array_equal(result.T @ result, np.eye(n*n))
    return result


def compile_bank(bank: np.ndarray, n: int, slots: int,
                 rng: np.random.Generator) -> tuple[list[np.ndarray], float]:
    local_terms = []
    worst_error = 0.0
    for b in range(n):
        block = bank[b*n:(b+1)*n, b*n:(b+1)*n]
        pairs, stats = compile_hankel_pairs(
            block, seed=int(rng.integers(2**31)))
        assert len(pairs) == (n+1)//2 <= slots
        worst_error = max(worst_error, stats["relative_error"])
        for h2, h1 in pairs:
            for h in (h2, h1):
                assert np.allclose(h[1:, :-1], h[:-1, 1:], atol=1e-9)
        terms = [h2 @ h1 for h2, h1 in pairs]
        terms.extend(np.zeros((n, n), dtype=complex)
                     for _ in range(slots-len(terms)))
        local_terms.append(terms)
    bank_terms = [block_diagonal([terms[t] for terms in local_terms])
                  for t in range(slots)]
    assert np.allclose(sum(bank_terms), bank, atol=1e-8, rtol=1e-8)
    return bank_terms, worst_error


def relative_error(actual: np.ndarray, wanted: np.ndarray) -> float:
    return float(np.linalg.norm(actual-wanted)/max(1.0, np.linalg.norm(wanted)))


def main() -> None:
    rng = np.random.default_rng(20261105)
    records = []
    for n in range(2, 6):
        # Fixed, wavelength-preserving cyclic routing; Q is logical transpose.
        p = permutation(n, lambda b, k: ((b+k) % n, k))
        s = permutation(n, lambda b, k: (b, (k-b) % n))
        t = permutation(n, lambda a, k: (a, (a-k) % n))
        q = permutation(n, lambda b, k: (k, b))
        assert np.array_equal(t @ p @ s, q)

        for extra_left_slot in (0, 1):
            tr = (n+1)//2
            tl = tr+extra_left_slot
            frame_slots = tr+tl-1
            alpha_r, alpha_l = 1/tr, 1/tl
            # Deliberately retain FIR state when BOTH data and weights change.
            right_history, left_history = [], []
            for frame in range(2):
                def random_bank():
                    return block_diagonal([
                        (rng.normal(size=(n, n))
                         + 1j*rng.normal(size=(n, n)))/np.sqrt(n)
                        for _ in range(n)])

                left, right = random_bank(), random_bank()
                b1, b2 = s @ right, left @ t
                right_terms, right_error = compile_bank(b1, n, tr, rng)
                left_terms, left_error = compile_bank(b2, n, tl, rng)
                w = b2 @ p @ b1
                monarch = q @ left @ q @ right
                assert np.allclose(q @ w, monarch, atol=1e-10)
                # One physical wavelength route per source/destination pair
                # implies every physical fiber-to-fiber subblock has rank <=1.
                max_second_singular = 0.0
                for a in range(n):
                    for b in range(n):
                        sv = np.linalg.svd(w[a*n:(a+1)*n, b*n:(b+1)*n],
                                           compute_uv=False)
                        max_second_singular = max(max_second_singular,
                                                  float(sv[1]))
                assert max_second_singular < 1e-10

                x = rng.normal(size=n*n)+1j*rng.normal(size=n*n)
                stable_first_errors = []
                for k in range(frame_slots):
                    right_history.append(right_terms[k % tr] @ x)
                    first_sum = alpha_r*sum(right_history[-tr:])
                    if k >= tr-1:
                        stable_first_errors.append(
                            relative_error(first_sum, alpha_r*b1 @ x))
                    left_history.append(left_terms[k % tl] @ p @ first_sum)
                    output = alpha_l*sum(left_history[-tl:])
                target = alpha_r*alpha_l*w @ x
                error = relative_error(output, target)
                logical_error = relative_error(q @ output,
                                                alpha_r*alpha_l*monarch @ x)
                assert error < 1e-7 and logical_error < 1e-7
                assert max(stable_first_errors) < 1e-7
                records.append({
                    "block_size": n, "total_dimension": n*n,
                    "right_period": tr, "left_period": tl,
                    "frame_slots": frame_slots, "frame": frame,
                    "fir_normalization": alpha_r*alpha_l,
                    "relative_output_error": error,
                    "relative_logical_error": logical_error,
                    "max_compiler_error": max(right_error, left_error),
                    "max_first_bank_stable_error": max(stable_first_errors),
                    "max_second_subblock_singular_value": max_second_singular,
                })

    result = {
        "scope": "Algebra only; independent complex Hankels and equal coherent FIR taps",
        "routing_cases_passed": 4,
        "temporal_frames_passed": len(records),
        "consecutive_frames_reset_filter_state": False,
        "physical_device_validation": False,
        "max_relative_output_error": max(r["relative_output_error"] for r in records),
        "cases": records,
    }
    path = Path(__file__).parent/"results"/"full_hankel_monarch_checks.json"
    path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps({key: value for key, value in result.items() if key != "cases"},
                     indent=2))


if __name__ == "__main__":
    main()
