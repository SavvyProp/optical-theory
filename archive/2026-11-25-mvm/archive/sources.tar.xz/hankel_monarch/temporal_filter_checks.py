"""Deterministic algebra checks for fixed temporal filters and WDM feature maps.

This is not a fiber-Bragg-grating propagation model. It assumes synchronized
complex envelopes, fixed discrete tap coefficients, and isolated generated-idler
DFG maps. Arbitrary matrices below verify identities; they are not a claim that
arbitrary dense optical feature mixers are available.

Run from the repository root:
    python3 hankel_monarch/temporal_filter_checks.py
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np


def causal_fir(samples: np.ndarray, taps: np.ndarray) -> np.ndarray:
    """Channelwise causal FIR, retaining the input-length output prefix.

    samples has shape (time, channels), taps has shape (lag, channels).
    History before the first sample is zero.
    """
    samples = np.asarray(samples)
    taps = np.asarray(taps)
    if samples.ndim != 2 or taps.ndim != 2:
        raise ValueError("Samples and taps must both be two-dimensional.")
    if samples.shape[1] != taps.shape[1]:
        raise ValueError("Sample and tap channel counts must match.")
    output = np.zeros_like(samples, dtype=np.result_type(samples, taps))
    for time in range(samples.shape[0]):
        for lag in range(min(time + 1, taps.shape[0])):
            output[time] += taps[lag] * samples[time - lag]
    return output


def block_toeplitz(kernels: np.ndarray, length: int) -> np.ndarray:
    """Finite causal block-Toeplitz matrix for kernels[lag, output, input]."""
    taps, outputs, inputs = kernels.shape
    matrix = np.zeros((length * outputs, length * inputs), dtype=kernels.dtype)
    for time in range(length):
        for source_time in range(time + 1):
            lag = time - source_time
            if lag < taps:
                matrix[time * outputs:(time + 1) * outputs,
                       source_time * inputs:(source_time + 1) * inputs] = kernels[lag]
    return matrix


def relative_error(actual: np.ndarray, expected: np.ndarray) -> float:
    denominator = max(float(np.linalg.norm(expected)), np.finfo(float).tiny)
    return float(np.linalg.norm(actual - expected) / denominator)


def hankel_bank(generators: np.ndarray, lines: int) -> np.ndarray:
    fibers = generators.shape[0]
    bank = np.zeros((fibers * lines, fibers * lines), dtype=generators.dtype)
    indices = np.arange(lines)[:, None] + np.arange(lines)[None, :]
    for fiber in range(fibers):
        block = slice(fiber * lines, (fiber + 1) * lines)
        bank[block, block] = generators[fiber][indices]
    return bank


def cyclic_shuffle(fibers: int, lines: int) -> np.ndarray:
    routing = np.zeros((fibers * lines, fibers * lines))
    for fiber in range(fibers):
        for line in range(lines):
            destination = (fiber + line) % fibers
            routing[destination * lines + line, fiber * lines + line] = 1
    return routing


def diagnostics(seed: int = 20261103) -> dict:
    rng = np.random.default_rng(seed)

    def complex_array(shape: tuple[int, ...]) -> np.ndarray:
        return rng.standard_normal(shape) + 1j * rng.standard_normal(shape)

    results = {}
    scalar_errors = []
    for length in (1, 5, 12):
        for tap_count in (1, 3, 8):
            samples = complex_array((length, 1))
            taps = complex_array((tap_count, 1))
            streaming = causal_fir(samples, taps)[:, 0]
            convolution = np.convolve(samples[:, 0], taps[:, 0])[:length]
            matrix = block_toeplitz(taps[:, :, None], length)
            dense_output = matrix @ samples[:, 0]
            np.testing.assert_allclose(streaming, convolution, atol=1e-12)
            np.testing.assert_allclose(streaming, dense_output, atol=1e-12)
            scalar_errors.extend((relative_error(streaming, convolution),
                                  relative_error(streaming, dense_output)))
    results["scalar_fir_is_temporal_toeplitz"] = {
        "cases": 9,
        "maximum_relative_error": max(scalar_errors),
        "boundary": "Zero initial history; retain causal output prefix.",
    }

    # A and B here are arbitrary algebraic operands, not supplied optical mixers.
    length, lag_count, inputs, channels, outputs = 11, 4, 5, 6, 3
    a = complex_array((channels, inputs))
    b = complex_array((outputs, channels))
    samples = complex_array((length, inputs))
    taps = complex_array((lag_count, channels))
    intermediate = (a @ samples.T).T
    direct = (b @ causal_fir(intermediate, taps).T).T
    kernels = np.stack([b @ np.diag(tap) @ a for tap in taps])
    dense_output = (block_toeplitz(kernels, length) @ samples.ravel()).reshape(
        length, outputs
    )
    np.testing.assert_allclose(direct, dense_output, atol=1e-11)
    results["static_feature_maps_give_block_toeplitz"] = {
        "inputs": inputs, "intermediate_channels": channels, "outputs": outputs,
        "tap_count": lag_count,
        "relative_error": relative_error(direct, dense_output),
        "kernel": "K_l = B diag(h_l) A",
    }

    shared = complex_array((lag_count,))
    shared_taps = np.repeat(shared[:, None], channels, axis=1)
    direct = (b @ causal_fir(intermediate, shared_taps).T).T
    feature_projection = (b @ a @ samples.T).T
    collapsed = causal_fir(feature_projection,
                           np.repeat(shared[:, None], outputs, axis=1))
    np.testing.assert_allclose(direct, collapsed, atol=1e-11)
    results["identical_filters_do_not_add_feature_expressivity"] = {
        "relative_error": relative_error(direct, collapsed),
        "kernel": "K_l = h_l (B A)",
    }

    # Actual native primitive: H1 DFG -> real WDM shuffle -> fixed FIR -> H2 DFG.
    fibers, lines, length, lag_count = 3, 2, 9, 4
    dimension = fibers * lines
    h1 = np.stack([hankel_bank(complex_array((fibers, 2 * lines - 1)), lines)
                   for _ in range(length)])
    h2 = np.stack([hankel_bank(complex_array((fibers, 2 * lines - 1)), lines)
                   for _ in range(length)])
    routing = cyclic_shuffle(fibers, lines)
    fiber_taps = complex_array((lag_count, fibers))
    taps = np.repeat(fiber_taps, lines, axis=1)
    samples = complex_array((length, dimension))

    def native_action(data: np.ndarray) -> np.ndarray:
        first = np.stack([routing @ h1[t] @ data[t].conj()
                          for t in range(length)])
        filtered = causal_fir(first, taps)
        return np.stack([h2[t] @ filtered[t].conj() for t in range(length)])

    direct = native_action(samples)
    expected = np.zeros_like(direct)
    for time in range(length):
        for lag in range(min(time + 1, lag_count)):
            expected[time] += (h2[time] @ np.diag(taps[lag].conj()) @ routing
                               @ h1[time - lag].conj() @ samples[time - lag])
    np.testing.assert_allclose(direct, expected, atol=1e-10)
    multiplier = 0.3 - 0.8j
    np.testing.assert_allclose(native_action(multiplier * samples), multiplier * direct,
                               atol=1e-10)
    results["native_two_dfgs_with_fixed_temporal_filter"] = {
        "fibers": fibers, "lines": lines,
        "weights": "Both Hankel banks change independently at every time step.",
        "kernel": "K_(t,l) = H2_t conjugate(D_l) P conjugate(H1_(t-l))",
        "relative_error": relative_error(direct, expected),
        "complex_linearity_error": relative_error(native_action(multiplier * samples),
                                                    multiplier * direct),
    }

    # Uniform-per-fiber FIR commutes through a STATIC local Hankel bank.
    # Consequently the filter after P can be moved after the complete native
    # core, conjugating its coefficients, without adding spatial expressivity.
    first_static = np.stack([routing @ h1[0] @ sample.conj() for sample in samples])
    filtered_static = causal_fir(first_static, taps)
    inside_output = np.stack([h2[0] @ sample.conj() for sample in filtered_static])
    native_matrix = h2[0] @ routing @ h1[0].conj()
    unfiltered_output = (native_matrix @ samples.T).T
    outside_output = causal_fir(unfiltered_output, taps.conj())
    np.testing.assert_allclose(inside_output, outside_output, atol=1e-10)
    results["fiber_uniform_fir_commutes_with_static_local_hankel"] = {
        "relative_error": relative_error(inside_output, outside_output),
        "identity": "H2 conjugate(D_l) P conjugate(H1) = conjugate(D_l) W",
        "conditions": "Static local Hankel banks; same FIR for all lines in each fiber.",
        "implication": "An interior post-shuffle filter is an output filter, not a new spatial mixer.",
    }

    # Fiber-uniform filters supply n temporal basis functions, not nK of them.
    lag_count = 8
    fiber_taps = complex_array((lag_count, fibers))
    a = routing @ h1[0].conj()
    b = h2[0]
    kernels = np.stack([b @ np.diag(np.repeat(tap.conj(), lines)) @ a
                        for tap in fiber_taps])
    unfolding = kernels.reshape(lag_count, -1).T
    basis_matrices = []
    for fiber in range(fibers):
        selector = np.zeros(dimension)
        selector[fiber * lines:(fiber + 1) * lines] = 1
        basis_matrices.append((b @ np.diag(selector) @ a).ravel())
    factorization = np.stack(basis_matrices, axis=1) @ fiber_taps.conj().T
    np.testing.assert_allclose(unfolding, factorization, atol=1e-11)
    unfolding_rank = int(np.linalg.matrix_rank(unfolding))
    assert unfolding_rank <= fibers
    results["fixed_per_fiber_temporal_basis"] = {
        "lag_count": lag_count, "fibers": fibers, "lines": lines,
        "lag_unfolding_rank": unfolding_rank,
        "rank_upper_bound": fibers,
        "factorization_error": relative_error(unfolding, factorization),
    }

    # Time-varying write weights remain attached to stored samples.
    length = 5
    a_stream = np.arange(1, length + 1, dtype=float)
    samples = np.arange(1, length + 1, dtype=float)[:, None]
    taps = np.array([[1.0], [0.5]])
    actual = causal_fir(a_stream[:, None] * samples, taps)
    incorrectly_reprojected_history = a_stream[:, None] * causal_fir(samples, taps)
    temporal_matrix = block_toeplitz(taps[:, :, None], length) @ np.diag(a_stream)
    np.testing.assert_allclose(actual[:, 0], temporal_matrix @ samples[:, 0])
    assert not np.allclose(np.diag(temporal_matrix), np.diag(temporal_matrix)[0])
    assert not np.allclose(actual, incorrectly_reprojected_history)
    results["changing_write_weights_is_not_time_invariant"] = {
        "main_diagonal": np.diag(temporal_matrix).tolist(),
        "actual_output": actual[:, 0].tolist(),
        "incorrect_current_weight_on_entire_history":
            incorrectly_reprojected_history[:, 0].tolist(),
        "relative_difference": relative_error(incorrectly_reprojected_history, actual),
        "interpretation": "Stored history uses A_(t-l), not current A_t.",
    }

    return {
        "seed": seed,
        "scope": "Discrete complex-envelope identities only; not a physical FBG simulation.",
        "diagnostics": results,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).parent / "results" / "temporal_filter_checks.json")
    args = parser.parse_args()
    results = diagnostics()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(results, indent=2) + "\n")
    print(f"Passed {len(results['diagnostics'])} algebraic diagnostics; wrote {args.output}")


if __name__ == "__main__":
    main()
