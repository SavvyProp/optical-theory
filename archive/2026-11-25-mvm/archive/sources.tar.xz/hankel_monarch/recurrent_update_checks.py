"""Check rank-one Hankel terms, optical gradients, and Monarch nonclosure.

Run from the repository root::

    python3 hankel_monarch/recurrent_update_checks.py

The physical primitive is DFG(h, x) = H(h) conjugate(x).  One FHM is
sum_l DFG(b_l, DFG(a_l, x)), so its complex-linear matrix is
sum_l H(b_l) H(conjugate(a_l)).  For an optical residual e = v - FHM(x),
the negative real-loss gradients, encoded as complex vectors, are

    g_b,l = convolution(e, DFG(a_l, x))
    g_a,l = convolution(x, DFG(b_l, e)).

Thus every coefficient write uses an SFG convolution of optical fields;
the conjugations needed for the complex gradient occur in the native DFGs.
An adjoint FHM uses the same pairs in reversed order.  Applying these local
gradients through two FHM banks and the inverse shuffle gives the exact
parameter gradient of a full-Hankel Monarch fast-weight memory.

An independent identity represents any bilinear outer product by two pairs:
P(u) = H([zeros(N-1), u]), shift(u) = [0, u[:-1]],
outer(u, v) = P(u) P(v) - P(shift(u)) P(shift(v)).  This permits exact
append-only delta writes but does NOT update a fixed number of existing
factors, and the subtraction does not establish an optical energy benefit.

A separate fixed-first construction uses N full-comb first pumps to span
every N-by-N matrix by varying only the second pumps.  The construction is
a coverage proof, not the proposed online writer: online writes use the
convolution gradient directly.  With first pumps fixed, the coefficient
recurrence is linear in the previous state for given keys and scalar gates.

These are updates in Hankel coefficient coordinates, NOT the usual dense
DeltaNet state update.  All gradient operands use the frozen old state,
after any forgetting.  Scaling all second-pump coefficients of the final
bank by alpha scales the complete matrix by alpha, exactly once.

The checks assume independent effective complex pump coefficients as the
stored state.  They do not establish an encoder using constrained self-SFG
front ends, conversion efficiency, noise performance, or a physical device.
The only output is JSON on stdout; no result files are written.
"""

from __future__ import annotations

import json
from collections.abc import Callable, Sequence

import numpy as np


def hankel(coefficients: np.ndarray) -> np.ndarray:
    n = (len(coefficients) + 1) // 2
    assert len(coefficients) == 2 * n - 1
    return coefficients[np.arange(n)[:, None] + np.arange(n)[None, :]]


def dfg(pump: np.ndarray, signal: np.ndarray) -> np.ndarray:
    return hankel(pump) @ signal.conj()


def rank_one_physical_pairs(left: np.ndarray, right: np.ndarray
                            ) -> tuple[np.ndarray, np.ndarray]:
    """Two physical (first, second) pump pairs for left @ right.T.

    This is a bilinear transpose even for complex operands.  For a Hermitian
    outer product, pass right.conj().  Conjugating the first pumps compensates
    the native DFG convention.  No pump encoder or optical conjugator is
    implied by this algebraic construction.
    """
    assert left.ndim == right.ndim == 1 and left.shape == right.shape
    n = len(left)
    padded = lambda vector: np.pad(vector, (n - 1, 0))
    shift = lambda vector: np.r_[0, vector[:-1]]
    first = np.stack([padded(right).conj(), padded(shift(right)).conj()])
    second = np.stack([padded(left), -padded(shift(left))])
    return first, second


def fixed_first_dense_encoding(target: np.ndarray
                               ) -> tuple[np.ndarray, np.ndarray]:
    """Explicit universal linear encoding with N predetermined first pumps.

    Let J_j=H(e_j), Z be the upward shift, and R=S-Z S Z.T.  Telescoping
    gives S=sum_j H([R[:,j]; zeros(N-1)]) J_j.  An invertible Fourier mixing
    of the J_j makes each predetermined first pump an N-line comb.  Mix
    the second-pump columns by the inverse transpose to preserve the sum.
    Only the second pumps depend on S.  Online gradient writes do NOT need
    to evaluate R or re-run this encoder.
    """
    n = target.shape[0]
    assert target.shape == (n, n)
    shift = np.eye(n, k=1)
    difference = target - shift @ target @ shift.T
    fourier = np.exp(2j * np.pi * np.outer(np.arange(n), np.arange(n)) / n)
    fourier /= np.sqrt(n)
    first = np.pad(fourier.conj().T, ((0, 0), (0, n - 1)))
    second = np.pad((difference @ fourier.conj()).T, ((0, 0), (0, n - 1)))
    return first, second


def fhm_apply(first: np.ndarray, second: np.ndarray,
              signal: np.ndarray) -> np.ndarray:
    return sum((dfg(b, dfg(a, signal)) for a, b in zip(first, second)),
               np.zeros_like(signal, dtype=complex))


def fhm_matrix(first: np.ndarray, second: np.ndarray) -> np.ndarray:
    n = (first.shape[-1] + 1) // 2
    return sum((hankel(b) @ hankel(a.conj())
                for a, b in zip(first, second)),
               np.zeros((n, n), dtype=complex))


def fhm_adjoint(first: np.ndarray, second: np.ndarray,
                signal: np.ndarray) -> np.ndarray:
    return fhm_apply(second, first, signal)


def fhm_negative_gradients(first: np.ndarray, second: np.ndarray,
                           signal: np.ndarray,
                           error: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    grad_first = np.array([np.convolve(signal, dfg(b, error)) for b in second])
    grad_second = np.array([np.convolve(error, dfg(a, signal)) for a in first])
    return grad_first, grad_second


def bank_apply(first: np.ndarray, second: np.ndarray,
               signal: np.ndarray) -> np.ndarray:
    blocks = signal.reshape(first.shape[0], -1)
    return np.concatenate([fhm_apply(a, b, x)
                           for a, b, x in zip(first, second, blocks)])


def bank_adjoint(first: np.ndarray, second: np.ndarray,
                 signal: np.ndarray) -> np.ndarray:
    return bank_apply(second, first, signal)


def bank_negative_gradients(first: np.ndarray, second: np.ndarray,
                            signal: np.ndarray,
                            error: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    nblocks = first.shape[0]
    gradients = [fhm_negative_gradients(a, b, x, e)
                 for a, b, x, e in zip(first, second,
                                       signal.reshape(nblocks, -1),
                                       error.reshape(nblocks, -1))]
    return (np.array([g[0] for g in gradients]),
            np.array([g[1] for g in gradients]))


def cyclic_shuffle(signal: np.ndarray, n: int, inverse: bool = False) -> np.ndarray:
    source = signal.reshape(n, n)
    result = np.empty_like(source)
    for fiber in range(n):
        for line in range(n):
            destination = (fiber + line) % n
            if inverse:
                result[fiber, line] = source[destination, line]
            else:
                result[destination, line] = source[fiber, line]
    return result.reshape(-1)


def monarch_apply(parameters: Sequence[np.ndarray],
                  signal: np.ndarray) -> np.ndarray:
    first1, second1, first2, second2 = parameters
    n = first1.shape[0]
    middle = cyclic_shuffle(bank_apply(first1, second1, signal), n)
    return bank_apply(first2, second2, middle)


def monarch_negative_gradients(parameters: Sequence[np.ndarray],
                               signal: np.ndarray,
                               error: np.ndarray) -> tuple[np.ndarray, ...]:
    first1, second1, first2, second2 = parameters
    n = first1.shape[0]
    middle = cyclic_shuffle(bank_apply(first1, second1, signal), n)
    grad2 = bank_negative_gradients(first2, second2, middle, error)
    error1 = cyclic_shuffle(bank_adjoint(first2, second2, error), n, inverse=True)
    grad1 = bank_negative_gradients(first1, second1, signal, error1)
    return (*grad1, *grad2)


def dense_operator(apply: Callable[[np.ndarray], np.ndarray], n: int) -> np.ndarray:
    return np.column_stack([apply(x) for x in np.eye(n, dtype=complex)])


def loss(output: np.ndarray, target: np.ndarray) -> float:
    return float(np.vdot(output - target, output - target).real / 2)


def finite_difference_error(parameters: Sequence[np.ndarray],
                            negative_gradients: Sequence[np.ndarray],
                            objective: Callable[[], float],
                            step: float = 1e-6) -> tuple[float, int]:
    """Check both real coordinates of every complex coefficient in place."""
    worst = 0.0
    coordinates = 0
    for parameter, gradient in zip(parameters, negative_gradients):
        for index in np.ndindex(parameter.shape):
            original = parameter[index]
            try:
                for direction, component in ((1.0, gradient[index].real),
                                              (1.0j, gradient[index].imag)):
                    parameter[index] = original + step * direction
                    plus = objective()
                    parameter[index] = original - step * direction
                    minus = objective()
                    finite_difference = (plus - minus) / (2 * step)
                    # Complex g stores the negative derivatives in its real/imag parts.
                    scaled_error = abs(finite_difference + component) / max(
                        1.0, abs(finite_difference), abs(component))
                    worst = max(worst, float(scaled_error))
                    coordinates += 1
            finally:
                parameter[index] = original
    return worst, coordinates


def descent_check(parameters: Sequence[np.ndarray],
                   gradients: Sequence[np.ndarray],
                   objective: Callable[[Sequence[np.ndarray]], float]) -> dict:
    # A conservative test step; this is not a proposed learned gate or bound.
    gradient_norm_squared = sum(float(np.vdot(g, g).real) for g in gradients)
    rate = 0.01 / (1.0 + gradient_norm_squared)
    before = objective(parameters)
    updated = [p + rate * g for p, g in zip(parameters, gradients)]
    after = objective(updated)
    assert after < before
    return {"loss_before": before, "loss_after": after, "test_step_size": rate}


def main() -> None:
    rng = np.random.default_rng(20261114)

    def random_complex(shape, scale=1.0):
        return scale * (rng.normal(size=shape) + 1j * rng.normal(size=shape))

    rank_one_cases = []
    fixed_first_cases = []
    # A separate seed keeps the gradient checks reproducible as this list grows.
    rank_rng = np.random.default_rng(4241)
    for dimension in (1, 2, 3, 4, 8, 16, 32):
        left, right, probe = [rank_rng.normal(size=dimension)
                              + 1j * rank_rng.normal(size=dimension)
                              for _ in range(3)]
        rank_first, rank_second = rank_one_physical_pairs(left, right)
        desired = np.outer(left, right)
        matrix_error = float(np.linalg.norm(fhm_matrix(rank_first, rank_second)
                                            - desired) / np.linalg.norm(desired))
        read_error = float(np.linalg.norm(fhm_apply(rank_first, rank_second, probe)
                                          - desired @ probe)
                           / max(1.0, np.linalg.norm(desired @ probe)))
        assert matrix_error < 1e-12 and read_error < 1e-12
        rank_one_cases.append({"dimension": dimension,
                               "matrix_relative_error": matrix_error,
                               "physical_read_relative_error": read_error})
        dense = (rank_rng.normal(size=(dimension, dimension))
                 + 1j * rank_rng.normal(size=(dimension, dimension)))
        fixed_first, encoded_second = fixed_first_dense_encoding(dense)
        dense_error = float(np.linalg.norm(fhm_matrix(fixed_first, encoded_second)
                                           - dense) / np.linalg.norm(dense))
        same_first, _ = fixed_first_dense_encoding(np.zeros_like(dense))
        assert np.array_equal(fixed_first, same_first)
        assert dense_error < 1e-12
        fixed_first_cases.append({"dimension": dimension,
                                  "temporal_pairs": dimension,
                                  "matrix_relative_error": dense_error})

    n, slots = 4, 2
    first = random_complex((slots, 2 * n - 1), 0.2)
    second = random_complex((slots, 2 * n - 1), 0.2)
    signal, target = random_complex(n), random_complex(n)
    output = fhm_apply(first, second, signal)
    matrix = fhm_matrix(first, second)
    forward_error = float(np.linalg.norm(output - matrix @ signal))
    adjoint_error = float(np.linalg.norm(fhm_adjoint(first, second, target)
                                        - matrix.conj().T @ target))
    gradients = fhm_negative_gradients(first, second, signal, target - output)
    gradient_error, coordinates = finite_difference_error(
        [first, second], gradients,
        lambda: loss(fhm_apply(first, second, signal), target))
    assert forward_error < 1e-12 and adjoint_error < 1e-12
    assert gradient_error < 1e-7
    fhm_descent = descent_check(
        [first, second], gradients,
        lambda p: loss(fhm_apply(p[0], p[1], signal), target))

    n, slots = 3, 2
    parameters = [random_complex((n, slots, 2 * n - 1), 0.25)
                  for _ in range(4)]
    signal, target = random_complex(n * n), random_complex(n * n)
    matrix_before_decay = dense_operator(lambda x: monarch_apply(parameters, x), n * n)
    alpha = 0.73
    parameters[3] *= alpha  # Forget once: final bank's second pumps only.
    matrix = dense_operator(lambda x: monarch_apply(parameters, x), n * n)
    forgetting_error = float(np.linalg.norm(matrix - alpha * matrix_before_decay))
    assert forgetting_error < 1e-12
    output = monarch_apply(parameters, signal)
    gradients = monarch_negative_gradients(parameters, signal, target - output)
    monarch_gradient_error, monarch_coordinates = finite_difference_error(
        parameters, gradients, lambda: loss(monarch_apply(parameters, signal), target))
    assert monarch_gradient_error < 1e-7
    monarch_descent = descent_check(
        parameters, gradients,
        lambda p: loss(monarch_apply(p, signal), target))

    # In the balanced physical encoding every fiber-to-fiber block has rank 1.
    # A usual complex delta update adds delta k^dagger, generically giving rank 2.
    key = random_complex(n * n)
    key /= np.linalg.norm(key)
    value = random_complex(n * n)
    beta = 0.4
    correction = beta * (value - matrix @ key)
    updated_matrix = matrix + np.outer(correction, key.conj())
    old_ranks, new_ranks = [], []
    for a in range(n):
        for b in range(n):
            index = np.s_[a * n:(a + 1) * n, b * n:(b + 1) * n]
            old_ranks.append(int(np.linalg.matrix_rank(matrix[index], tol=1e-10)))
            new_ranks.append(int(np.linalg.matrix_rank(updated_matrix[index], tol=1e-10)))
    assert old_ranks == [1] * (n * n)
    assert new_ranks == [2] * (n * n)

    print(json.dumps({
        "scope": "Ideal complex field algebra; independent effective pump state",
        "physical_device_validation": False,
        "exact_dense_delta_equivalence_of_coefficient_gradient": False,
        "exact_rank_one_two_pair_construction": {
            "fixed_size_update_of_existing_factors": False,
            "energy_advantage_established": False,
            "cases": rank_one_cases,
        },
        "universal_fixed_first_hankels": {
            "online_writer": "Second-pump convolution gradient; no re-encoding",
            "coefficient_update_equals_dense_delta": False,
            "cases": fixed_first_cases,
        },
        "fhm": {
            "dimension": 4,
            "temporal_pairs": 2,
            "forward_matrix_error": forward_error,
            "reversed_pair_adjoint_error": adjoint_error,
            "finite_difference_scaled_max_error": gradient_error,
            "real_coordinates_checked": coordinates,
            **fhm_descent,
        },
        "full_hankel_monarch": {
            "local_dimension": n,
            "global_dimension": n * n,
            "pairs_per_local_block": slots,
            "single_bank_scalar_forgetting_error": forgetting_error,
            "finite_difference_scaled_max_error": monarch_gradient_error,
            "real_coordinates_checked": monarch_coordinates,
            **monarch_descent,
            "fiber_block_ranks_before_delta_write": old_ranks,
            "fiber_block_ranks_after_delta_write": new_ranks,
        },
    }, indent=2))


if __name__ == "__main__":
    main()
