"""Check a rectangular extension of the simultaneous low-rank DFG construction.

This standalone diagnostic does not change the square-only LowRankPlan API.
All pump-minus-data products are generated, unwanted latent frequencies are
filtered, and a second conjugating interaction returns to the output comb.
The model is finite-grid, flat-coupling, undepleted field algebra; physical
carrier placement, mode isolation, dynamics, and efficiency are not simulated.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from lowrank_tensor_families import sparse_dfg
from pump_frontends import combine_trine, trine_rails


def rectangular_action(
    left: np.ndarray,
    right: np.ndarray,
    inputs: np.ndarray,
    group_size: int,
    *,
    normalized_data_optics: bool = False,
) -> np.ndarray:
    """Apply U V† using grouped sparse latent combs and fixed-phase pumps.

    U has shape (n_out, K_out, r); V has shape (n_in, K_in, r).
    Latents are separated by L=max(K_in,K_out), ensuring that no unintended
    product reaches a retained latent or output coordinate.
    """
    left = np.asarray(left, dtype=complex)
    right = np.asarray(right, dtype=complex)
    inputs = np.asarray(inputs, dtype=complex)
    if left.ndim != 3 or right.ndim != 3:
        raise ValueError("factors must have shapes (n_fibers, n_lines, rank)")
    n_out, k_out, rank = left.shape
    n_in, k_in, right_rank = right.shape
    if min(n_out, k_out, rank, n_in, k_in, group_size) < 1:
        raise ValueError("all dimensions and group_size must be positive")
    if right_rank != rank or inputs.shape != (n_in, k_in):
        raise ValueError("factor ranks and input dimensions must agree")
    stride = max(k_in, k_out)
    outputs = np.zeros((n_out, k_out), dtype=complex)
    for start in range(0, rank, group_size):
        width = min(group_size, rank - start)
        latent = np.zeros(width, dtype=complex)
        for fiber in range(n_in):
            values = right[fiber, :, start:start + width].T
            # The same three fixed phases are used for every pump target.
            encoded = combine_trine(trine_rails(values.ravel())).reshape(values.shape)
            pump = {
                ell * stride + k: encoded[ell, k]
                for ell in range(width) for k in range(k_in)
            }
            all_products = sparse_dfg(pump, dict(enumerate(inputs[fiber])))
            latent += [all_products.get(ell * stride, 0j) for ell in range(width)]
        # The intermediate filter is part of the mathematical construction.
        filtered_latent = {ell * stride: latent[ell] for ell in range(width)}
        for fiber in range(n_out):
            values = left[fiber, :, start:start + width].T
            encoded = combine_trine(trine_rails(values.ravel())).reshape(values.shape)
            pump = {
                ell * stride + j: encoded[ell, j]
                for ell in range(width) for j in range(k_out)
            }
            all_products = sparse_dfg(pump, filtered_latent)
            outputs[fiber] += [all_products.get(j, 0j) for j in range(k_out)]
    if normalized_data_optics:
        n_groups = (rank + group_size - 1) // group_size
        # Balanced split/sum/broadcast reference circuit; not a universal
        # retained-power fraction. Pump-frontend attenuation is excluded.
        outputs /= n_groups * np.sqrt(n_in * n_out)
    return outputs


def verification_report(seed: int = 339) -> dict:
    rng = np.random.default_rng(seed)
    configurations = [(2, 3, 3, 2, 3), (1, 2, 2, 4, 3),
                      (3, 4, 1, 2, 2), (3, 2, 2, 5, 4)]
    cases = []
    for n_in, k_in, n_out, k_out, rank in configurations:
        for complex_values in (False, True):
            def random_values(shape):
                values = rng.normal(size=shape)
                if complex_values:
                    values = values + 1j * rng.normal(size=shape)
                return values

            left = random_values((n_out, k_out, rank))
            right = random_values((n_in, k_in, rank))
            inputs = random_values((n_in, k_in))
            expected = (
                left.reshape(-1, rank) @ right.reshape(-1, rank).conj().T
                @ inputs.ravel()
            ).reshape(n_out, k_out)
            for group_size in sorted({1, 2, rank}):
                groups = (rank + group_size - 1) // group_size
                scale = 1 / (groups * np.sqrt(n_in * n_out))
                observed = rectangular_action(left, right, inputs, group_size)
                normalized = rectangular_action(
                    left, right, inputs, group_size, normalized_data_optics=True
                )
                error = np.linalg.norm(observed - expected) / np.linalg.norm(expected)
                normalized_error = (
                    np.linalg.norm(normalized - scale * expected)
                    / np.linalg.norm(scale * expected)
                )
                assert max(error, normalized_error) < 1e-12
                cases.append({
                    "n_in": n_in, "K_in": k_in, "n_out": n_out, "K_out": k_out,
                    "latent_rank": rank, "complex_values": complex_values,
                    "group_size": group_size, "groups": groups,
                    "latent_spacing_in_grid_units": max(k_in, k_out),
                    "data_dfg_sections": groups * (n_in + n_out),
                    "serial_data_dfgs": 2,
                    "complex_factor_coefficients": rank * (n_in * k_in + n_out * k_out),
                    "balanced_reference_field_scale": float(scale),
                    "relative_error": float(error),
                    "normalized_relative_error": float(normalized_error),
                })
    return {
        "seed": seed,
        "description": "Rectangular extension check; the existing square compiler is unchanged.",
        "scope": "Field-coefficient algebra, fixed trine phases, explicit products and intermediate filtering.",
        "num_cases": len(cases),
        "num_action_checks": 2 * len(cases),
        "max_relative_error": max(case["relative_error"] for case in cases),
        "max_normalized_relative_error": max(case["normalized_relative_error"] for case in cases),
        "cases": cases,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = verification_report()
    serialized = json.dumps(report, indent=2) + "\n"
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(serialized)
    print(json.dumps({key: value for key, value in report.items() if key != "cases"}, indent=2))


if __name__ == "__main__":
    main()
