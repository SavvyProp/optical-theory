"""Small algebraic diagnostics for requirements.md.

These are deterministic mathematical examples, not ML training or device tests.
Run from the repository root:
    python3 hankel_monarch/ml_operator_diagnostics.py
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np


def rank_r_approximation(matrix: np.ndarray, rank: int) -> np.ndarray:
    left, singular, right = np.linalg.svd(matrix, full_matrices=False)
    return (left[:, :rank] * singular[:rank]) @ right[:rank]


def diagnostics() -> dict:
    results = {}

    # One adjustable scalar can define full-rank matrices without dense freedom.
    d = 32
    shift = np.diag(np.ones(d - 1), k=-1)
    matrix = np.eye(d) + 0.2 * shift
    assert np.linalg.matrix_rank(matrix) == d
    assert np.linalg.cond(matrix) <= 1.5 + 1e-12
    results["one_parameter_full_rank"] = {
        "dimension": d,
        "rank": int(np.linalg.matrix_rank(matrix)),
        "condition_number": float(np.linalg.cond(matrix)),
    }

    # Best whole-weight low-rank approximation on isotropic activations.
    d, rank = 64, 4
    identity = np.eye(d)
    approximation = rank_r_approximation(identity, rank)
    relative_squared_error = np.linalg.norm(identity - approximation) ** 2 / d
    np.testing.assert_allclose(relative_squared_error, 1 - rank / d)
    results["identity_bottleneck"] = {
        "dimension": d,
        "allowed_rank": rank,
        "minimum_relative_frobenius_error": float(np.sqrt(relative_squared_error)),
        "minimum_relative_mse_if_second_moment_is_identity": float(
            relative_squared_error
        ),
    }

    # Minimizing entrywise error can discard the most used activation direction.
    target = np.diag(np.arange(1.0, 9.0))
    second_moment = np.diag([100.0] + [0.01] * 7)
    sqrt_second_moment = np.diag(np.sqrt(np.diag(second_moment)))
    naive = rank_r_approximation(target, 1)
    calibrated = rank_r_approximation(target @ sqrt_second_moment, 1) @ np.linalg.inv(
        sqrt_second_moment
    )
    target_energy = np.linalg.norm(target @ sqrt_second_moment) ** 2
    naive_error = np.linalg.norm((target - naive) @ sqrt_second_moment) ** 2
    calibrated_error = np.linalg.norm((target - calibrated) @ sqrt_second_moment) ** 2
    tail_energy = np.sum(np.linalg.svd(target @ sqrt_second_moment, compute_uv=False)[1:] ** 2)
    np.testing.assert_allclose(calibrated_error, tail_energy)
    assert calibrated_error < naive_error
    results["activation_weighted_rank_one"] = {
        "naive_relative_output_mse": float(naive_error / target_energy),
        "calibrated_relative_output_mse": float(calibrated_error / target_energy),
        "note": "Constructed diagonal example; not measured model activations.",
    }

    # Low-rank scores do not imply low-rank attention probabilities.
    logits = np.array([[0.0, 0.0], [0.0, 1.0]])
    probabilities = np.exp(logits - logits.max(axis=1, keepdims=True))
    probabilities /= probabilities.sum(axis=1, keepdims=True)
    expected_det = (np.e - 1) / (2 * (np.e + 1))
    np.testing.assert_allclose(np.linalg.det(probabilities), expected_det)
    assert np.linalg.matrix_rank(logits) == 1
    assert np.linalg.matrix_rank(probabilities) == 2
    results["softmax_changes_rank"] = {
        "logit_rank": 1,
        "probability_rank": 2,
        "probability_determinant": float(np.linalg.det(probabilities)),
    }

    # A full-rank recurrence matrix has rank-one communication across every cut.
    length, alpha = 16, 0.7
    offsets = np.arange(length)[:, None] - np.arange(length)[None, :]
    recurrence = np.where(offsets >= 0, alpha ** np.maximum(offsets, 0), 0.0)
    cut_ranks = [
        int(np.linalg.matrix_rank(recurrence[cut:, :cut]))
        for cut in range(1, length)
    ]
    assert np.linalg.matrix_rank(recurrence) == length
    assert set(cut_ranks) == {1}
    results["recurrence_cross_cut_ranks"] = {
        "dimension": length,
        "global_rank": length,
        "all_strict_past_future_block_ranks": cut_ranks,
    }

    # Native Hankel/permutation/Hankel: dense and full rank, rank-one fiber blocks.
    fibers = lines = 3
    reversal = np.eye(lines)[::-1]
    hankel = reversal + 0.05 * np.ones((lines, lines))
    bank = np.kron(np.eye(fibers), hankel)
    routing = np.zeros((fibers * lines, fibers * lines))
    for source in range(fibers):
        for wavelength in range(lines):
            destination = (source + wavelength) % fibers
            routing[destination * lines + wavelength, source * lines + wavelength] = 1
    matrix = bank @ routing @ bank.conj()
    block_ranks = [
        [
            int(np.linalg.matrix_rank(matrix[a * lines : (a + 1) * lines,
                                             b * lines : (b + 1) * lines]))
            for b in range(fibers)
        ]
        for a in range(fibers)
    ]
    assert np.linalg.matrix_rank(matrix) == fibers * lines
    assert np.all(matrix > 0)
    assert all(rank == 1 for row in block_ranks for rank in row)
    assert np.linalg.cond(matrix) <= 1.15 ** 2 + 1e-12
    results["native_shuffle_full_rank_low_rank_blocks"] = {
        "fibers": fibers,
        "lines": lines,
        "global_rank": int(np.linalg.matrix_rank(matrix)),
        "all_entries_nonzero": bool(np.all(matrix != 0)),
        "fiber_block_ranks": block_ranks,
        "condition_number": float(np.linalg.cond(matrix)),
        "note": "Assumes these Hankel pumps are synthesized; no dense spatial mixer.",
    }

    return {
        "scope": "Algebraic examples only; no model training or physical simulation.",
        "diagnostics": results,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path,
        default=Path(__file__).parent / "results" / "ml_operator_diagnostics.json",
    )
    args = parser.parse_args()
    results = diagnostics()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(results, indent=2) + "\n")
    print(f"Passed {len(results['diagnostics'])} algebraic diagnostics; wrote {args.output}")


if __name__ == "__main__":
    main()
