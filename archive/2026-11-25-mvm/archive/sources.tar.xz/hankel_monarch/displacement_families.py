"""Exact constant-width, two-factor Toeplitz families and inverse filters.

All branches represent simultaneous optical paths. This script checks algebra
and existing ideal global Toeplitz plans, not propagation or modulation speed.
Transpose in the displacement generators is algebraic transpose, not adjoint.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
from pathlib import Path

import numpy as np

from structured_transforms import compile_padded_toeplitz, toeplitz_matrix
from global_hankel_compositions import compile_fused_pair


def lower_toeplitz(column: np.ndarray) -> np.ndarray:
    column = np.asarray(column, dtype=complex)
    if column.ndim != 1 or not len(column):
        raise ValueError("column must be a nonempty vector")
    d = len(column)
    return toeplitz_matrix(np.r_[np.zeros(d - 1), column])


def downshift(d: int) -> np.ndarray:
    return np.eye(d, k=-1)


def stein_displacement(matrix: np.ndarray) -> np.ndarray:
    matrix = np.asarray(matrix, dtype=complex)
    if matrix.ndim != 2 or matrix.shape[0] != matrix.shape[1]:
        raise ValueError("matrix must be square")
    result = matrix.copy()
    result[1:, 1:] -= matrix[:-1, :-1]
    return result


def reconstruct(g: np.ndarray, h: np.ndarray) -> np.ndarray:
    """Return sum_l L(g_l) L(h_l)^T; columns carry branch generators."""
    g, h = np.asarray(g, dtype=complex), np.asarray(h, dtype=complex)
    if g.shape != h.shape or g.ndim != 2:
        raise ValueError("generators must have matching (dimension, rank) shape")
    result = np.zeros((g.shape[0], g.shape[0]), dtype=complex)
    for first, second in zip(g.T, h.T):
        result += lower_toeplitz(first) @ lower_toeplitz(second).T
    return result


def factor_displacement(matrix: np.ndarray, rank: int | None = None,
                        relative_tolerance: float = 1e-12) -> tuple:
    """Offline SVD compiler; truncation approximates displacement, not A itself."""
    residual = stein_displacement(matrix)
    left, values, right = np.linalg.svd(residual, full_matrices=False)
    if rank is None:
        cutoff = relative_tolerance * (values[0] if len(values) else 0)
        rank = int(np.count_nonzero(values > cutoff))
    if rank < 0 or rank > len(values):
        raise ValueError("rank outside valid range")
    scale = np.sqrt(values[:rank])
    # Vh.T, not Vh.conj().T, because reconstruct uses algebraic transpose.
    return left[:, :rank] * scale, right[:rank].T * scale, values


def gohberg_semencul(matrix: np.ndarray, relative_corner_tolerance=1e-12):
    """Two displacement generators for a Toeplitz inverse with usable x[0].

    The caller must supply Toeplitz input. Zero/near-zero corner cases can use
    factor_displacement(inv(T)); they do not invalidate rank-two coverage.
    """
    matrix = np.asarray(matrix, dtype=complex)
    d = len(matrix)
    columns = np.linalg.solve(matrix, np.eye(d)[:, [0, d - 1]])
    x, y = columns.T
    if abs(x[0]) <= relative_corner_tolerance * np.linalg.norm(x):
        raise ZeroDivisionError("Gohberg–Semencul corner is zero or too small")
    z = downshift(d)
    g = np.column_stack((x, z @ y))
    h = np.column_stack((y[::-1], -z @ x[::-1])) / x[0]
    return g, h


@dataclass(frozen=True)
class DisplacementPlan:
    """Conservative implementation: two standalone Toeplitz modules per arm.

    This means four data DFG traversals. A fused two-global-Hankel realization
    can reduce that to two; its spatial compiler is documented separately.
    """

    first_stage: tuple
    second_stage: tuple
    n_fibers: int
    n_frequencies: int

    def apply(self, inputs):
        inputs = np.asarray(inputs, dtype=complex)
        if inputs.shape != (self.n_fibers, self.n_frequencies):
            raise ValueError("incorrect input shape")
        result = np.zeros_like(inputs)
        for first, second in zip(self.first_stage, self.second_stage):
            result += second.apply(first.apply(inputs))
        return result


def compile_generators(g, h, n_fibers, n_frequencies):
    g, h = np.asarray(g, dtype=complex), np.asarray(h, dtype=complex)
    d = n_fibers * n_frequencies
    if g.shape != h.shape or g.ndim != 2 or g.shape[0] != d:
        raise ValueError("generators have wrong shape")
    first, second = [], []
    for a, b in zip(g.T, h.T):
        # U(b) has negative-lag coefficients b[d-1],...,b[1].
        upper_kernel = np.r_[b[::-1], np.zeros(d - 1)]
        lower_kernel = np.r_[np.zeros(d - 1), a]
        first.append(compile_padded_toeplitz(upper_kernel, n_fibers, n_frequencies))
        second.append(compile_padded_toeplitz(lower_kernel, n_fibers, n_frequencies))
    return DisplacementPlan(tuple(first), tuple(second), n_fibers, n_frequencies)


@dataclass(frozen=True)
class FusedDisplacementPlan:
    """Two serial data DFGs per simultaneous generator arm."""

    arms: tuple
    n_fibers: int
    n_frequencies: int

    def apply(self, inputs):
        inputs = np.asarray(inputs, dtype=complex)
        if inputs.shape != (self.n_fibers, self.n_frequencies):
            raise ValueError("incorrect input shape")
        result = np.zeros_like(inputs)
        for arm in self.arms:
            result += arm.apply(inputs)
        return result


def compile_fused_generators(g, h, n_fibers, n_frequencies):
    g, h = np.asarray(g, dtype=complex), np.asarray(h, dtype=complex)
    d = n_fibers * n_frequencies
    if g.shape != h.shape or g.ndim != 2 or g.shape[0] != d:
        raise ValueError("generators have wrong shape")
    arms = []
    for a, b in zip(g.T, h.T):
        outer_kernel = np.r_[np.zeros(d - 1), a]
        inner_kernel = np.r_[b[::-1], np.zeros(d - 1)]
        arms.append(compile_fused_pair(outer_kernel, inner_kernel,
                                       n_fibers, n_frequencies))
    return FusedDisplacementPlan(tuple(arms), n_fibers, n_frequencies)


def _relative_error(actual, expected):
    return float(np.linalg.norm(actual - expected) / max(np.linalg.norm(expected), 1e-30))


def verification_report(seed=20261103):
    rng = np.random.default_rng(seed)
    report = {"seed": seed, "cases": [], "max_relative_error": 0.0}

    def check(name, actual, expected, **metadata):
        error = _relative_error(actual, expected)
        if error > 1e-9:
            raise AssertionError(f"{name}: relative error {error}")
        report["max_relative_error"] = max(report["max_relative_error"], error)
        report["cases"].append({"name": name, "relative_error": error, **metadata})

    def random(shape):
        return rng.normal(size=shape) + 1j * rng.normal(size=shape)

    for n, k in [(1, 1), (1, 5), (2, 3), (3, 4), (4, 4)]:
        d = n * k
        for r in sorted({1, min(2, d), min(4, d)}):
            g, h = random((d, r)), random((d, r))
            target = reconstruct(g, h)
            check("generator_displacement", stein_displacement(target), g @ h.T,
                  dimension=d, branches=r)
            plan = compile_generators(g, h, n, k)
            actual = np.column_stack([plan.apply(v.reshape(n, k)).ravel()
                                      for v in np.eye(d)])
            check("global_two_stage_actions", actual, target, dimension=d, branches=r)
            fused_plan = compile_fused_generators(g, h, n, k)
            actual_fused = np.column_stack([
                fused_plan.apply(v.reshape(n, k)).ravel() for v in np.eye(d)])
            check("global_fused_two_dfg_actions", actual_fused, target,
                  dimension=d, branches=r)
            check("complex_linearity", plan.apply(1j * np.ones((n, k))),
                  1j * plan.apply(np.ones((n, k))), dimension=d, branches=r)
            # Algebra behind the fused two-global-Hankel implementation.
            j = np.eye(d)[::-1]
            fused = np.zeros((d, d), dtype=complex)
            for a, b in zip(g.T, h.T):
                first_h = (j @ lower_toeplitz(b).T).conj()
                second_h = lower_toeplitz(a) @ j
                fused += second_h @ first_h.conj()
            check("fused_hankel_pair_algebra", fused, target, dimension=d, branches=r)

        kernel = random(2 * d - 1)
        kernel[d - 1] += 10 * d
        t = toeplitz_matrix(kernel)
        inverse = np.linalg.inv(t)
        g, h = gohberg_semencul(t)
        check("gohberg_semencul", reconstruct(g, h), inverse, dimension=d)
        g, h, values = factor_displacement(inverse)
        assert g.shape[1] <= 2
        check("inverse_displacement_compiler", reconstruct(g, h), inverse,
              dimension=d, branches=g.shape[1])
        plan = compile_generators(g, h, n, k)
        vector = random(d)
        check("single_shot_inverse_action", plan.apply(vector.reshape(n, k)).ravel(),
              np.linalg.solve(t, vector), dimension=d)

    for d in [2, 3, 8, 16]:
        # Invertible circulant Toeplitz whose inverse has x[0]=0.
        t = downshift(d)
        t[0, -1] = 1
        inverse = np.linalg.inv(t)
        try:
            gohberg_semencul(t)
        except ZeroDivisionError:
            pass
        else:
            raise AssertionError("zero-corner example should reject generic formula")
        g, h, _ = factor_displacement(inverse)
        assert g.shape[1] <= 2
        check("zero_corner_inverse", reconstruct(g, h), inverse,
              dimension=d, branches=g.shape[1])

        u, v = random((d, 2)), random((d, 2))
        target = u @ v.T
        z = downshift(d)
        g = np.column_stack((u, z @ u))
        h = np.column_stack((v, -z @ v))
        check("rank_two_outer_product", reconstruct(g, h), target,
              dimension=d, branches=4)

    d = 24
    diagonal = np.repeat([1 + 1j, 2 - .3j, -.6 + .2j], 8)
    target = np.diag(diagonal)
    g, h, _ = factor_displacement(target)
    assert g.shape[1] == 3
    check("piecewise_constant_diagonal", reconstruct(g, h), target, branches=3)
    assert np.linalg.matrix_rank(stein_displacement(np.diag(np.arange(1, d + 1)))) == d

    product = np.eye(d, dtype=complex)
    for i in range(3):
        kernel = random(2 * d - 1)
        kernel[d - 1] += 8 * d
        t = toeplitz_matrix(kernel)
        product = product @ (t if i != 1 else np.linalg.inv(t))
    g, h, _ = factor_displacement(product)
    assert g.shape[1] <= 2 * 3
    check("three_factor_depth_to_width", reconstruct(g, h), product,
          dimension=d, branches=g.shape[1], bound=6)

    z = downshift(d)
    t = 2 * np.eye(d) - .3 * (z + z.T)
    p = np.eye(d) + .2 * t
    q = np.eye(d) + .1 * t + .05 * t @ t
    target = np.linalg.solve(q.T, p.T).T
    g, h, _ = factor_displacement(target)
    assert g.shape[1] <= 2 * (1 + 2)
    check("rational_toeplitz_filter", reconstruct(g, h), target,
          dimension=d, branches=g.shape[1], bound=6)

    # Truncation is an approximation in displacement space; check the bound.
    target = random((d, d))
    g, h, values = factor_displacement(target, rank=3)
    matrix_error = np.linalg.norm(target - reconstruct(g, h))
    displacement_tail = np.linalg.norm(values[3:])
    assert matrix_error <= d * displacement_tail * (1 + 1e-12)
    report["approximation_example"] = {
        "dimension": d, "branches": 3,
        "matrix_frobenius_error": float(matrix_error),
        "proven_upper_bound": float(d * displacement_tail),
    }
    report["verified_cases"] = len(report["cases"])
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = verification_report()
    output = json.dumps(report, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(output)
    print(json.dumps({k: v for k, v in report.items() if k != "cases"}, indent=2))
