"""Exact two-channel DFG gates and fixed-mixer block networks.

The model is generated-mode, small-signal DFG; scalar conversion constants are
absorbed into pump settings. No device bandwidth, noise, or power is simulated.
Run this file for deterministic checks. No optimizer or learned phase is used.
"""

from __future__ import annotations

import json

import numpy as np

from pump_frontends import combine_trine, dfg, hankel, trine_rails


def compile_two_channel(matrix: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Return first/second length-3 pumps implementing any complex 2x2 matrix.

    If H1,H2 are the pump Hankels, the physical operation is H2 conj(H1) x.
    Singular targets are allowed. This simple exact compiler is not guaranteed
    well-conditioned when the off-diagonal entries are very small.
    """
    matrix = np.asarray(matrix, dtype=complex)
    if matrix.shape != (2, 2):
        raise ValueError("matrix must be 2x2")
    a, b, c, d = matrix.ravel()
    if b == 0 and c == 0:
        symmetric = np.eye(2, dtype=complex)
    elif abs(b) >= abs(c):
        symmetric = np.array([[0, 1], [1, (d - a) / b]], dtype=complex)
    else:
        symmetric = np.array([[(a - d) / c, 1], [1, 0]], dtype=complex)
    second = matrix @ symmetric
    first = np.linalg.inv(symmetric).conj()
    # Balance the two factors' Frobenius norms without changing their product.
    norm_first, norm_second = np.linalg.norm(first), np.linalg.norm(second)
    if norm_first and norm_second:
        scale = np.sqrt(norm_second / norm_first)
        first *= scale
        second /= scale
    np.testing.assert_allclose(first, first.T, atol=1e-12, rtol=1e-12)
    np.testing.assert_allclose(second, second.T, atol=1e-12, rtol=1e-12)
    return first[[0, 0, 1], [0, 1, 1]], second[[0, 0, 1], [0, 1, 1]]


def apply_two_channel(matrix: np.ndarray, data: np.ndarray) -> np.ndarray:
    """Compile, encode with the same fixed trine phases, then execute two DFGs."""
    first, second = compile_two_channel(matrix)
    first = combine_trine(trine_rails(first))
    second = combine_trine(trine_rails(second))
    return dfg(second, dfg(first, data))


def apply_local_bank(blocks: np.ndarray, data: np.ndarray) -> np.ndarray:
    """One arbitrary two-channel gate per fiber, without data branching."""
    blocks, data = np.asarray(blocks), np.asarray(data)
    if blocks.shape != (len(data), 2, 2) or data.shape != (len(data), 2):
        raise ValueError("blocks must have shape (n,2,2), data (n,2)")
    return np.stack([apply_two_channel(block, row)
                     for block, row in zip(blocks, data)])


def apply_fixed_mixer_network(left: np.ndarray, mixer: np.ndarray,
                              right: np.ndarray, data: np.ndarray) -> np.ndarray:
    """Apply blockdiag(left) (mixer tensor I_2) blockdiag(right)."""
    return apply_local_bank(left, np.asarray(mixer) @ apply_local_bank(right, data))


def apply_binary_axis_gates(data: np.ndarray, matrices: list[np.ndarray]) -> np.ndarray:
    """A complete butterfly/tensor circuit with one shared 2x2 gate per bit.

    matrices[0] acts on the least significant bit. All pairings and their
    assignments to internal frequencies are fixed. Physical carrier adapters,
    if required, are separate from these mathematical gate operations.
    """
    values = np.asarray(data, dtype=complex).copy()
    if values.ndim != 1 or values.size != 2 ** len(matrices):
        raise ValueError("data length must equal 2**number_of_axes")
    for axis, gate in enumerate(matrices):
        stride = 2 ** axis
        for start in range(0, len(values), 2 * stride):
            for offset in range(stride):
                indices = [start + offset, start + offset + stride]
                values[indices] = apply_two_channel(gate, values[indices])
    return values


def verification_report(seed: int = 271828) -> dict:
    rng = np.random.default_rng(seed)
    relative_errors = []
    targets = [np.zeros((2, 2)), np.eye(2), np.diag([1, 3j]),
               np.array([[0, 1], [0, 0]]), np.array([[0, 0], [1j, 0]]),
               np.array([[1, 2j], [3, 4]]), np.ones((2, 2))]
    targets += [rng.normal(size=(2, 2)) + 1j*rng.normal(size=(2, 2))
                for _ in range(100)]
    for target in targets:
        first, second = compile_two_channel(target)
        actual = hankel(second) @ hankel(first).conj()
        relative_errors.append(float(np.linalg.norm(actual-target) /
                                     max(np.linalg.norm(target), 1)))
        data = rng.normal(size=2) + 1j*rng.normal(size=2)
        np.testing.assert_allclose(apply_two_channel(target, data), target @ data,
                                   atol=1e-11, rtol=1e-11)
        np.testing.assert_allclose(apply_two_channel(target, 1j*data),
                                   1j*(target @ data), atol=1e-11, rtol=1e-11)
    network_errors = []
    for n in [1, 2, 4, 9]:
        left = rng.normal(size=(n, 2, 2)) + 1j*rng.normal(size=(n, 2, 2))
        right = rng.normal(size=(n, 2, 2)) + 1j*rng.normal(size=(n, 2, 2))
        mixer = np.fft.fft(np.eye(n), axis=0, norm="ortho")
        exact = np.zeros((2*n, 2*n), dtype=complex)
        for i in range(n):
            for j in range(n):
                exact[2*i:2*i+2, 2*j:2*j+2] = mixer[i, j]*(left[i] @ right[j])
        actual = np.column_stack([
            apply_fixed_mixer_network(left, mixer, right, basis.reshape(n, 2)).ravel()
            for basis in np.eye(2*n)
        ])
        np.testing.assert_allclose(actual, exact, atol=1e-11, rtol=1e-11)
        network_errors.append(float(np.linalg.norm(actual-exact) / np.linalg.norm(exact)))
    tensor_errors = []
    for axes in range(1, 7):
        gates = [rng.normal(size=(2, 2)) + 1j*rng.normal(size=(2, 2))
                 for _ in range(axes)]
        exact = np.ones((1, 1))
        for gate in reversed(gates):
            exact = np.kron(exact, gate)
        data = rng.normal(size=2**axes) + 1j*rng.normal(size=2**axes)
        actual = apply_binary_axis_gates(data, gates)
        np.testing.assert_allclose(actual, exact @ data, atol=1e-10, rtol=1e-10)
        tensor_errors.append(float(np.linalg.norm(actual-exact@data) /
                                   np.linalg.norm(exact@data)))
        hadamard = np.array([[1, 1], [1, -1]]) / np.sqrt(2)
        exact_h = np.ones((1, 1))
        for _ in range(axes):
            exact_h = np.kron(exact_h, hadamard)
        np.testing.assert_allclose(apply_binary_axis_gates(data, [hadamard]*axes),
                                   exact_h @ data, atol=1e-11, rtol=1e-11)
    return {
        "two_channel_targets": len(targets),
        "max_two_channel_relative_error": max(relative_errors),
        "fixed_spatial_networks": len(network_errors),
        "max_fixed_network_relative_error": max(network_errors),
        "binary_axis_and_hadamard_cases": 2*len(tensor_errors),
        "max_tensor_relative_error": max(tensor_errors),
        "physical_claim": "ideal coefficient algebra only; no clock-rate or efficiency validation",
    }


if __name__ == "__main__":
    print(json.dumps(verification_report(), indent=2))
