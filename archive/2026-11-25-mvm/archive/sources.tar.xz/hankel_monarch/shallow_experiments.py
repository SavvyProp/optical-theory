#!/usr/bin/env python3
"""Small, reproducible expressivity probes for the raw optical architecture.

This is deliberately NOT a test of arbitrary signed-Hankel synthesis, branching,
or independently controlled spectral phase masks. Optimization failures are not
proofs of impossibility. These are retained exploratory calculations; README.md
defines the current baseline, and limitations.md proves its scoped restrictions.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import time

import numpy as np
from scipy.optimize import least_squares


def hankel_self_sfg(u):
    h = np.convolve(u, u)
    indices = np.add.outer(np.arange(len(u)), np.arange(len(u)))
    return h[indices]


def block_diagonal(blocks):
    rows = sum(a.shape[0] for a in blocks)
    result = np.zeros((rows, rows), dtype=np.result_type(*blocks))
    start = 0
    for a in blocks:
        end = start + len(a)
        result[start:end, start:end] = a
        start = end
    return result


def routing(n, k, kind):
    if kind == "cyclic":
        result = np.zeros((n * k, n * k))
        for fiber in range(n):
            for frequency in range(k):
                result[((fiber + frequency) % n) * k + frequency,
                       fiber * k + frequency] = 1
        return result
    if kind == "spatial_fourier":
        indices = np.arange(n)
        fourier = np.exp(-2j * np.pi * np.outer(indices, indices) / n) / np.sqrt(n)
        return np.kron(fourier, np.eye(k))
    raise ValueError(kind)


class Architecture:
    """q+1 local pair banks, q routers, one phase per fiber after each bank."""

    def __init__(self, n, k, q, router, phase_mode="fixed_signs"):
        self.n, self.k, self.q = n, k, q
        self.router_name = router
        self.phase_mode = phase_mode
        self.p = routing(n, k, router)
        self.pump_count = (q + 1) * n * 2 * k
        self.phase_count = (q + 1) * n if phase_mode == "tunable" else 0
        self.parameter_count = self.pump_count + self.phase_count
        self.fixed_phases = np.zeros((q + 1, n))
        # Boundary phases do not help coefficient magnitudes. Set them to zero
        # once, and use a target-independent mask only between two routers.
        for bank in range(1, q):
            multiplier = np.pi if phase_mode == "fixed_signs" else np.pi / 2
            self.fixed_phases[bank] = multiplier * (np.arange(n) % (2 if phase_mode == "fixed_signs" else 4))

    def matrix(self, parameters):
        pumps = parameters[:self.pump_count].reshape(self.q + 1, self.n, 2, self.k)
        phases = (parameters[self.pump_count:].reshape(self.q + 1, self.n)
                  if self.phase_mode == "tunable" else self.fixed_phases)
        result = np.eye(self.n * self.k, dtype=complex)
        for bank in range(self.q + 1):
            blocks = [hankel_self_sfg(v) @ hankel_self_sfg(u)
                      for u, v in pumps[bank]]
            result = block_diagonal(blocks) @ result
            result = np.repeat(np.exp(1j * phases[bank]), self.k)[:, None] * result
            if bank < self.q:
                result = self.p @ result
        return result

    def initial(self, rng):
        return np.concatenate((rng.uniform(0.1, 0.9, self.pump_count),
                               rng.uniform(-np.pi, np.pi, self.phase_count)))

    def bounds(self):
        return (np.concatenate((np.zeros(self.pump_count),
                                np.full(self.phase_count, -np.pi))),
                np.concatenate((np.ones(self.pump_count),
                                np.full(self.phase_count, np.pi))))


def best_global_gain(candidate, target, complex_gain=True):
    # Permit the arbitrary final gain assumed in the discussion. Its global
    # phase is already available in the phase banks, so this is generous but
    # introduces no new relative phases.
    denominator = np.vdot(candidate, candidate).real
    if denominator < np.finfo(float).tiny:
        return 0j
    gain = np.vdot(candidate, target) / denominator
    return gain if complex_gain else max(0.0, float(gain.real))


def fit(architecture, target, seed, restarts, max_nfev):
    rng = np.random.default_rng(seed)
    target_norm = np.linalg.norm(target)
    tunable = architecture.phase_mode == "tunable"

    def residual(parameters):
        candidate = architecture.matrix(parameters if tunable else parameters[:-1])
        if tunable:
            gain = best_global_gain(candidate, target)
            delta = (gain * candidate - target) / target_norm
        else:
            # Optimize a nonnegative gain explicitly. Analytically clipping the
            # best gain to zero creates an artificial flat optimization region.
            candidate_norm = max(np.linalg.norm(candidate), np.finfo(float).tiny)
            delta = parameters[-1] * candidate / candidate_norm - target / target_norm
        return np.concatenate((delta.real.ravel(), delta.imag.ravel()))

    attempts = []
    best = None
    for _ in range(restarts):
        initial = architecture.initial(rng)
        lower, upper = architecture.bounds()
        if not tunable:
            initial = np.append(initial, 1.0)
            lower, upper = np.append(lower, 0.0), np.append(upper, 2.0)
        fitted = least_squares(residual, initial,
                               bounds=(lower, upper), max_nfev=max_nfev,
                               ftol=1e-9, xtol=1e-9, gtol=1e-9)
        error = float(np.linalg.norm(fitted.fun))
        attempts.append({"relative_frobenius_error": error,
                         "nfev": int(fitted.nfev),
                         "termination_status": int(fitted.status)})
        if best is None or error < best[0]:
            best = (error, fitted.x)
    physical_parameters = best[1] if tunable else best[1][:-1]
    candidate = architecture.matrix(physical_parameters)
    gain = (best_global_gain(candidate, target) if tunable else
            best[1][-1] * target_norm / max(np.linalg.norm(candidate), np.finfo(float).tiny))
    return {"best_relative_frobenius_error": best[0],
            "attempts": attempts,
            "best_parameters": physical_parameters.tolist(),
            "global_gain_real_imag": [float(gain.real), float(gain.imag)],
            "singular_values": np.linalg.svd(gain * candidate, compute_uv=False).tolist()}


def targets(n, k, seed):
    d = n * k
    indices = np.arange(d)
    fourier = np.exp(-2j * np.pi * np.outer(indices, indices) / d) / np.sqrt(d)
    dct = np.sqrt(2 / d) * np.cos(np.pi * np.outer(indices, indices + 0.5) / d)
    dct[0] /= np.sqrt(2)
    result = {"identity": np.eye(d), "dct_ii": dct, "dft": fourier}
    if d > 0 and d & (d - 1) == 0:
        hadamard = np.ones((1, 1))
        while len(hadamard) < d:
            hadamard = np.block([[hadamard, hadamard], [hadamard, -hadamard]])
        result["hadamard"] = hadamard / np.sqrt(d)
    if n == k:
        rng = np.random.default_rng(seed)
        def random_blocks():
            return block_diagonal([(rng.normal(size=(k, k)) +
                                    1j * rng.normal(size=(k, k))) / np.sqrt(2 * k)
                                   for _ in range(n)])
        permutation = np.zeros((d, d))
        for a in range(n):
            for b in range(n):
                permutation[b * n + a, a * n + b] = 1
        result["random_complex_monarch"] = permutation @ random_blocks() @ permutation.T @ random_blocks()
    return result


def exact_checks():
    """Numerically illustrate independently derived mathematical identities."""
    rng = np.random.default_rng(20261103)
    report = {}
    for k in (2, 3, 5, 8):
        j = np.fliplr(np.eye(k))
        z = np.eye(k, k=-1)
        u, v = rng.uniform(0.1, 1, size=(2, k))
        h1, h2 = hankel_self_sfg(u), hankel_self_sfg(v)
        product = h2 @ h1
        report[f"K={k}"] = {
            "hankel_reversal_toeplitz_residual": float(max(
                np.max(np.abs((h1 @ j)[1:, 1:] - (h1 @ j)[:-1, :-1])),
                np.max(np.abs((j @ h2)[1:, 1:] - (j @ h2)[:-1, :-1])))),
            "two_hankel_shift_commutator_rank": int(np.linalg.matrix_rank(z @ product - product @ z)),
            "generic_diagonal_shift_commutator_rank": int(np.linalg.matrix_rank(
                z @ np.diag(np.arange(1, k + 1)) - np.diag(np.arange(1, k + 1)) @ z)),
        }
    model = Architecture(2, 2, 1, "cyclic", "tunable")
    parameters = model.initial(rng)
    pumps_only = parameters.copy()
    pumps_only[model.pump_count:] = 0
    phases = parameters[model.pump_count:].reshape(2, 2)
    expected = np.repeat(np.exp(1j * phases[1]), 2)[:, None] * model.matrix(pumps_only)
    expected *= np.repeat(np.exp(1j * phases[0]), 2)[None, :]
    report["one_shuffle_phase_pushthrough_residual"] = float(np.max(np.abs(model.matrix(parameters) - expected)))
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--n", type=int, default=2)
    parser.add_argument("--k", type=int, default=2)
    parser.add_argument("--restarts", type=int, default=3)
    parser.add_argument("--max-nfev", type=int, default=180)
    parser.add_argument("--seed", type=int, default=20261103)
    parser.add_argument("--phase-mode", choices=("fixed_signs", "fixed_quadrature", "tunable"),
                        default="fixed_signs",
                        help="Only tunable permits target-specific phases; it is a hardware co-design bound, not the fast amplitude-only model.")
    parser.add_argument("--output", type=Path,
                        default=None)
    args = parser.parse_args()
    start = time.monotonic()
    results = {
        "description": "Numerical probes only; nonzero fit error is not an impossibility certificate.",
        "model": "nonnegative self-SFG Hankel pairs; one phase per fiber after each pair bank; no branching",
        "phase_mode": args.phase_mode,
        "global_gain": "complex (optimistic co-design)" if args.phase_mode == "tunable" else "nonnegative real",
        "n_fibers": args.n, "k_frequencies": args.k,
        "restarts": args.restarts, "max_nfev": args.max_nfev, "seed": args.seed,
        "numpy_version": np.__version__, "exact_checks": exact_checks(), "fits": []}
    for router in ("cyclic", "spatial_fourier"):
        for q in (1, 2):
            architecture = Architecture(args.n, args.k, q, router, args.phase_mode)
            for index, (target_name, target) in enumerate(targets(args.n, args.k, args.seed).items()):
                entry = {"router": router, "shuffle_count": q, "target": target_name,
                         "raw_real_parameter_count": architecture.parameter_count}
                entry.update(fit(architecture, target, args.seed + 100 * q + index,
                                 args.restarts, args.max_nfev))
                results["fits"].append(entry)
                print(f"{router:17s} q={q} {target_name:24s} error={entry['best_relative_frobenius_error']:.6g}", flush=True)
    results["elapsed_seconds"] = time.monotonic() - start
    destination = args.output or (Path(__file__).parent / "results" /
                                  f"shallow_n{args.n}_k{args.k}_{args.phase_mode}.json")
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(results, indent=2) + "\n")
    print(f"Saved {destination}", flush=True)


if __name__ == "__main__":
    main()
