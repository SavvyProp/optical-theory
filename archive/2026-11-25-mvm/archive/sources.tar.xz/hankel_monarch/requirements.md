# Requirements for a useful underparameterized optical multiplier

[Structure and notation](README.md) · [Proven limitations](limitations.md)

The objective is a useful, rapidly programmable ML projection with substantially fewer physical controls than a dense matrix. An **underparameterized matrix family** has few adjustable parameters; an individual matrix in that family can still be full rank. A globally low-rank matrix instead forces every input through a lower-dimensional bottleneck. These are different design choices.

## Physical constraints

| Constraint | Working requirement |
|---|---|
| Depth | Start with one or two complete mixing blocks. Report serial nonlinear interactions separately. Depth growing linearly with fiber count is outside the intended design. |
| Temporal reuse | The original baseline uses one shot. The temporal-sum variant under study explicitly relaxes this: hold the same coherent input over `T` weight settings and report slots per result, latency and sustained independent-vector throughput. |
| Reprogramming | Changing weights must use fast WDM amplitude modulation. Offline compilation of weights is allowed. Approximately 100 GHz is a target, not demonstrated system throughput. |
| Fixed optics | Phase shifters and routing remain fixed across matrix updates. Uniform phase within a fiber is the practical baseline. |
| Spatial cost | Avoid quadratic growth in replicated data fibers and nonlinear waveguides. Count data copies separately from pump-generation branches. |
| Optical interface | Preserve coherent optical outputs in an explicitly specified carrier, mode and timing format that subsequent multipliers can accept. Electronics are for control. |
| Components | Specify actual routing, filters, pump generation, combiners and adapters. A cheap arbitrary dense optical mixer is not an available primitive. |
| Scope | Evaluate the multiplier. Activation design, feasibility and cost are excluded. |

A temporal filter acting on different past input vectors is a memory operation. Accumulating different matrix settings while holding the input fixed instead implements a sum of matrices. These are separate services. The temporal variant must also specify how a completed optical output is held or repeated for the next layer's accumulation window. FFT is not an essential capability of this multiplier.

## Choose the mathematical service

For column vectors, write `y = W x`.

| Service | What must be supplied |
|---|---|
| Structured learned projection `W(theta)` | A trainable restricted family with useful connectivity and sufficient capacity for the selected task |
| Intentional low-rank projection `UV†` | Learned input and output directions, with an explicit rank budget |
| Correction `B + UV†` | The entire base computation `B`, as well as the correction and coherent addition |
| Dynamic multiplication with arriving weights | An online encoder for those operands; an offline compiler alone does not establish this service |

The initial target is the first row. Low-rank adaptation results do not establish that a low-rank update can replace the base computation. In particular, an identity bypass does not supply an arbitrary pretrained matrix. [LoRA](https://arxiv.org/abs/2106.09685)

## Capability screens depend on the intended role

| Intended role | Properties to examine |
|---|---|
| General learned feature projection | Signed mixing; independently learned directions; connectivity under the actual router |
| Preserve information | Usable singular values; logical identity or an explicitly supplied bypass where needed |
| Compress or expand features | Rectangular input/output layouts and independently learned projection directions |
| Select or reweight coordinates | Nonuniform diagonal gains, selectors and relevant permutations |
| Filter a meaningful axis | The required convolution kernels, coordinate ordering and boundary conditions |
| Modify a supplied computation | Residual addition with its base, fanout, path matching and losses counted |

These are diagnostic screens, not a universal checklist that every useful ML layer must pass. Failure limits the claimed service; task performance decides whether the restriction is acceptable. Covering every rank-one map is a strong requirement for a general low-rank primitive, but is not mandatory for every structured projection. Exact FFT, DCT or Hadamard coverage is secondary unless a workload specifically needs it.

Declare the logical encoding. A known fixed channel permutation may be handled by labels, but physical routing is still necessary when an addition or downstream interface requires a particular alignment. Intensity `|Wx|²` alone is not a signed linear output.

## Which requirements force quadratic parameter counts?

Use `d=nK` for the total vector dimension. The necessary real degrees of freedom for ordinary smooth parameterizations are:

| Entire real matrix family to be covered | Dimension |
|---|---:|
| Rank-one matrices | `2d-1` |
| Rank-`r` matrices | `r(2d-r)` |
| Diagonal matrices | `d` |
| Toeplitz matrices | `2d-1` |
| Orthogonal matrices | `d(d-1)/2` |
| Arbitrary dense matrices | `d²` |

Covering every orthogonal matrix would itself impose a quadratic budget. It is a diagnostic, not a hard requirement for this restricted projection engine. Full rank and useful conditioning alone do not impose that budget.

For a mathematical parameter-count example,

\[
W=\operatorname{diag}(g)+\operatorname{Toeplitz}(h)+uv^{\mathsf T}
\]

uses only `5d-1` real parameters before removing redundancies. It contains every rank-one map, every diagonal, every Toeplitz kernel, identity, and dense full-rank examples. Thus these screens can coexist with `O(d)` parameters. This is an algebraic counterexample to a quadratic lower bound, not a proposed inexpensive optical implementation. Arbitrary dense coverage and every orthogonal transform remain absent. Covering all rank-one maps becomes dense universality only if arbitrary sums must also be supported without increasing the parameter budget.

Distinguish **learned parameters**, **independently writable slot settings**, and **physical hardware**. An unconstrained `T`-slot Hankel program has `O(Td)` settings; at `T=d` this is quadratic. A rank-one target can nevertheless be learned and stored as two length-`d` vectors, with the longer optical schedule compiled from them. Compilation does not automatically remove the schedule's weight-delivery, timing or energy costs. The limitations of the present Hankel topology therefore do not prove that every useful matrix family needs quadratic learned parameterization.

## Evaluation and decision rule

First train the actual constrained family in a selected projection layer. Separately test compilation of pretrained weights, with optional fine-tuning. A correction to a supplied base is a third experiment with different costs. Keep these conclusions separate.

For a target `W_*` and input second moment `C = E[xx†]`, evaluate

\[
\mathbb E\|(W_*-W)x\|_2^2
=\|(W_*-W)C^{1/2}\|_F^2.
\]

Thus matrix Frobenius error alone need not predict output error on the data. Use held-out inputs and end-task quality; neither full rank nor a favorable synthetic fit establishes model accuracy.

Report four groups of measurements:

- **Quality:** task loss, held-out output error, usable singular values and sensitivity to channel grouping.
- **Programmability:** actual independent amplitude controls, the local dimension of the realizable matrix family, compilation stability and weight precision.
- **Physical cost:** data paths, weight vectors and line counts, nonlinear sections, serial depth, filters, split/sum ports, pump bandwidth and optical power.
- **Timing and robustness:** weight delivery, path matching, modulation sidebands, fixed-phase error, conversion nonuniformity, noise and cancellation.

Compare with dense, grouped and low-rank software baselines at stated parameter budgets. A Monarch reference may use substantially more controls and is not automatically a parts-matched comparison. Add hardware only to address a measured limitation, with its resource and encoding costs explicit.

## Research context retained from the investigation

- [Monarch](https://proceedings.mlr.press/v162/dao22a/dao22a.pdf): structured matrix families and transform constructions. Raw Hankel-restricted blocks do not inherit its guarantees. The [full-Hankel array](README.md#8-arrays-of-full-hankel-matmuls-and-monarch) supplies arbitrary local blocks through temporal accumulation and establishes equivalence in the balanced layout, subject to its coefficient, timing and output-order assumptions.
- [Searching for Efficient Linear Layers](https://proceedings.neurips.cc/paper_files/paper/2024/file/0729c38b421cd66f2313ab397d099e37-Paper-Conference.pdf): empirical evaluation of structured linear-layer choices.
- [SVD-LLM](https://arxiv.org/html/2403.07378v4): compression informed by the inputs a layer receives.
- [Mamba-2 / SSD](https://proceedings.mlr.press/v235/dao24a.html): structured communication and state-space operators; this supplies mathematical context, not a shallow optical implementation.

The [algebraic diagnostics](ml_operator_diagnostics.py) illustrate rank and approximation distinctions. They are not ML accuracy measurements.
