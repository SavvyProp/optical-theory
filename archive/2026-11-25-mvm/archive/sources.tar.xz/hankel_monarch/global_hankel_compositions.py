"""One-DFG global Hankel operators and fused two-DFG Toeplitz compositions.

Fixed spatial Fourier matrices, padding/cropping, fiber reversal and a fixed
optional wavelength-preserving router surround programmable local Hankel DFGs.
This tests carrier field algebra, not propagation or a physical clock rate.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from fractions import Fraction
import json
from pathlib import Path

import numpy as np

from structured_transforms import hankel_matrix, spatial_dft, toeplitz_matrix


@dataclass(frozen=True)
class GlobalHankelPlan:
    n_fibers: int
    n_frequencies: int
    pumps: np.ndarray

    def apply(self, inputs: np.ndarray) -> np.ndarray:
        """Apply G(h) conjugate(x) using ONE parallel bank of DFG sections."""
        x = np.asarray(inputs, dtype=complex)
        if x.shape != (self.n_fibers, self.n_frequencies):
            raise ValueError("inputs must have shape (n_fibers, n_frequencies)")
        q = len(self.pumps)
        F = spatial_dft(q)
        padded = np.zeros((q, self.n_frequencies), dtype=complex)
        padded[:self.n_fibers] = x[::-1]  # Fiber reversal, not frequency reversal.
        mixed = F.conj() @ padded
        generated = np.stack([hankel_matrix(h) @ field.conj()
                              for h, field in zip(self.pumps, mixed)])
        return (F.conj().T @ generated)[:self.n_fibers]


def compile_global_hankel(coefficients: np.ndarray, n_fibers: int,
                          n_frequencies: int, n_spatial_modes: int | None = None
                          ) -> GlobalHankelPlan:
    h = np.asarray(coefficients, dtype=complex)
    n, k = n_fibers, n_frequencies
    if n < 1 or k < 1 or h.shape != (2*n*k-1,):
        raise ValueError("positive n,K and 2*n*K-1 generator coefficients required")
    q = 2*n if n_spatial_modes is None else n_spatial_modes
    if q < 2*n-1:
        raise ValueError("at least 2*n-1 padded spatial modes are required")
    block_generators = np.zeros((q, 2*k-1), dtype=complex)
    for lag in range(-n+1, n):
        start = (lag+n-1)*k
        block_generators[lag % q] = h[start:start+2*k-1]
    return GlobalHankelPlan(n, k, np.fft.fft(block_generators, axis=0))


@dataclass(frozen=True)
class FusedToeplitzPair:
    first: GlobalHankelPlan
    second: GlobalHankelPlan
    physical_router: np.ndarray

    def apply(self, inputs: np.ndarray) -> np.ndarray:
        first_output = self.first.apply(inputs)
        routed = (self.physical_router @ first_output.ravel()).reshape(first_output.shape)
        return self.second.apply(routed)


def compile_fused_pair(outer_kernel: np.ndarray, inner_kernel: np.ndarray,
                       n_fibers: int, n_frequencies: int,
                       router: np.ndarray | None = None) -> FusedToeplitzPair:
    """Compile T_outer P T_inner; P is fixed hardware, not a fast control.

    The function accepts arbitrary P algebraically. Only wavelength-preserving
    spatial routers are assumed inexpensive in the physical notes.
    """
    d = n_fibers*n_frequencies
    P = np.eye(d, dtype=complex) if router is None else np.asarray(router, complex)
    if P.shape != (d, d):
        raise ValueError("router must have shape (n*K, n*K)")
    first = compile_global_hankel(np.asarray(inner_kernel).conj()[::-1],
                                  n_fibers, n_frequencies)
    second = compile_global_hankel(outer_kernel, n_fibers, n_frequencies)
    return FusedToeplitzPair(first, second, P.conj()[::-1, ::-1])


def cyclic_wavelength_router(n: int, k: int) -> np.ndarray:
    P = np.zeros((n*k, n*k), dtype=int)
    for a in range(n):
        for j in range(k):
            P[((a+j) % n)*k+j, a*k+j] = 1
    return P


def apply_local_bank_pair(outer_kernels: np.ndarray, inner_kernels: np.ndarray,
                          router: np.ndarray, inputs: np.ndarray) -> np.ndarray:
    """Apply blockdiag(T2) P blockdiag(T1) with two local DFG banks.

    No global-Hankel padding is needed. P must be an available fixed optical
    router; a wavelength-preserving P remains so after the compilation below.
    """
    outer, inner = np.asarray(outer_kernels), np.asarray(inner_kernels)
    x = np.asarray(inputs)
    if outer.shape != inner.shape or outer.ndim != 2:
        raise ValueError("both kernel banks must have shape (n, 2*K-1)")
    n, length = outer.shape
    k = (length+1)//2
    if length != 2*k-1 or x.shape != (n, k):
        raise ValueError("kernel and input shapes disagree")
    P = np.asarray(router)
    if P.shape != (n*k, n*k):
        raise ValueError("router shape disagrees with data")
    first = np.stack([hankel_matrix(t.conj()[::-1]) @ v.conj()
                      for t, v in zip(inner, x)])
    local_reverse = np.arange(n*k).reshape(n, k)[:, ::-1].ravel()
    physical_router = P.conj()[np.ix_(local_reverse, local_reverse)]
    intermediate = (physical_router @ first.ravel()).reshape(n, k)
    return np.stack([hankel_matrix(t) @ v.conj()
                     for t, v in zip(outer, intermediate)])


def stein_displacement(A: np.ndarray) -> np.ndarray:
    shifted = np.zeros_like(A)
    shifted[1:, 1:] = A[:-1, :-1]
    return A-shifted


def exact_integer_rank(matrix: np.ndarray) -> int:
    """Rational elimination for the small integer noncontainment witness."""
    a = [[Fraction(int(v)) for v in row] for row in matrix]
    rows, columns = len(a), len(a[0])
    rank = 0
    for col in range(columns):
        pivot = next((r for r in range(rank, rows) if a[r][col]), None)
        if pivot is None:
            continue
        a[rank], a[pivot] = a[pivot], a[rank]
        scale = a[rank][col]
        a[rank] = [v/scale for v in a[rank]]
        for row in range(rank+1, rows):
            scale = a[row][col]
            if scale:
                a[row] = [v-scale*w for v, w in zip(a[row], a[rank])]
        rank += 1
        if rank == rows:
            break
    return rank


def verification_report(seed: int = 90210) -> dict:
    rng = np.random.default_rng(seed)
    max_hankel = max_pair = max_frontend = max_local = 0.0
    cases = 0
    shapes = [(1, 1), (1, 5), (2, 3), (3, 2), (3, 3), (4, 4)]
    for n, k in shapes:
        d = n*k
        h = rng.normal(size=2*d-1)+1j*rng.normal(size=2*d-1)
        x = rng.normal(size=(n, k))+1j*rng.normal(size=(n, k))
        for q in {2*n-1, 2*n}:
            plan = compile_global_hankel(h, n, k, q)
            expected = hankel_matrix(h) @ x.ravel().conj()
            error = np.linalg.norm(plan.apply(x).ravel()-expected)/np.linalg.norm(expected)
            max_hankel = max(max_hankel, float(error))
            assert error < 1e-11
            assert np.allclose(plan.apply(1j*x), -1j*plan.apply(x))
            cases += 1

        # Independent, cheaper local bank construction: no padded spatial modes.
        outer = rng.normal(size=(n, 2*k-1))+1j*rng.normal(size=(n, 2*k-1))
        inner = rng.normal(size=(n, 2*k-1))+1j*rng.normal(size=(n, 2*k-1))
        A, B = np.zeros((d, d), complex), np.zeros((d, d), complex)
        for a in range(n):
            sl = slice(a*k, (a+1)*k)
            A[sl, sl], B[sl, sl] = toeplitz_matrix(outer[a]), toeplitz_matrix(inner[a])
        for P in (cyclic_wavelength_router(n, k), np.kron(spatial_dft(n), np.eye(k))):
            actual = np.column_stack([apply_local_bank_pair(outer, inner, P, e.reshape(n, k)).ravel()
                                       for e in np.eye(d)])
            expected = A @ P @ B
            error = np.linalg.norm(actual-expected)/np.linalg.norm(expected)
            max_local = max(max_local, float(error))
            assert error < 1e-11
            assert np.allclose(apply_local_bank_pair(outer, inner, P, 1j*x),
                               1j*apply_local_bank_pair(outer, inner, P, x))
            cases += 1
        inner = rng.normal(size=2*d-1)+1j*rng.normal(size=2*d-1)
        for P in (np.eye(d), cyclic_wavelength_router(n, k),
                  np.kron(spatial_dft(n), np.eye(k))):
            plan = compile_fused_pair(h, inner, n, k, P)
            actual = np.column_stack([plan.apply(e.reshape(n, k)).ravel()
                                       for e in np.eye(d)])
            expected = toeplitz_matrix(h) @ P @ toeplitz_matrix(inner)
            error = np.linalg.norm(actual-expected)/np.linalg.norm(expected)
            max_pair = max(max_pair, float(error))
            assert error < 1e-11
            assert np.allclose(plan.apply(1j*x), 1j*plan.apply(x))
            # Conjugate/reversed physical routing retains wavelength index.
            i, j = np.nonzero(abs(plan.physical_router) > 1e-12)
            assert np.all(i % k == j % k)
            cases += 1

    # Independently compile the pump coefficients through the fixed five-port
    # self-SFG frontend before applying a complete two-DFG global composition.
    from constant_branch import factor_generator
    from factor_frontends import self_sfg_from_factors
    for n, k in [(2, 3), (3, 4)]:
        d = n*k
        a = rng.normal(size=2*d-1)+1j*rng.normal(size=2*d-1)
        b = rng.normal(size=2*d-1)+1j*rng.normal(size=2*d-1)
        plan = compile_fused_pair(a, b, n, k, cyclic_wavelength_router(n, k))
        physical_stages = []
        for stage in (plan.first, plan.second):
            pumps = []
            for h in stage.pumps:
                p, q = factor_generator(h, k)
                # Account for balanced combiner by scaling fundamental fields.
                pump, _, _ = self_sfg_from_factors(2**0.5*p, q)
                pumps.append(pump)
            physical_stages.append(GlobalHankelPlan(n, k, np.array(pumps)))
        physical = FusedToeplitzPair(*physical_stages, plan.physical_router)
        x = rng.normal(size=(n, k))+1j*rng.normal(size=(n, k))
        error = np.linalg.norm(physical.apply(x)-plan.apply(x))/np.linalg.norm(plan.apply(x))
        max_frontend = max(max_frontend, float(error))
        assert error < 1e-9
        cases += 1

    P = cyclic_wavelength_router(3, 3)
    witness_rank = exact_integer_rank(stein_displacement(P))
    assert witness_rank == 7  # Every product of two Toeplitz matrices has rank <=4.
    return {
        "seed": seed, "cases": cases,
        "max_global_hankel_error": max_hankel,
        "max_fused_pair_matrix_error": max_pair,
        "max_five_port_end_to_end_error": max_frontend,
        "max_local_bank_pair_matrix_error": max_local,
        "exact_cyclic_router_stein_rank_n3_k3": witness_rank,
        "ordinary_two_toeplitz_stein_rank_upper_bound": 4,
        "serial_DFGs_per_global_hankel": 1,
        "serial_DFGs_per_fused_pair": 2,
        "warning": "Ideal carrier-field algebra; not propagation, power efficiency, or 100-GHz validation.",
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = verification_report()
    encoded = json.dumps(report, indent=2)
    if args.output:
        args.output.write_text(encoded+"\n")
    print(encoded)
