"""Exact shallow global Toeplitz constructions; NumPy is the only dependency.

Coordinates are (fiber, frequency), flattened with frequency varying fastest.
The ideal DFG primitive is z -> H(h) conjugate(z). No efficiency or device
dynamics are modeled. All arms in these constructions operate simultaneously.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
from pathlib import Path

import numpy as np


def spatial_dft(size: int) -> np.ndarray:
    """Normalized negative-exponent DFT on spatial ports, not frequencies."""
    if size < 1:
        raise ValueError("size must be positive")
    indices = np.arange(size)
    return np.exp(-2j * np.pi * np.outer(indices, indices) / size) / np.sqrt(size)


def hankel_matrix(coefficients: np.ndarray) -> np.ndarray:
    h = np.asarray(coefficients, dtype=complex)
    if h.ndim != 1 or len(h) % 2 != 1:
        raise ValueError("Hankel coefficients must have odd positive length")
    size = (len(h) + 1) // 2
    index = np.arange(size)
    return h[index[:, None] + index[None, :]]


def toeplitz_matrix(kernel: np.ndarray) -> np.ndarray:
    """kernel indexes lags -(d-1), ..., d-1, with entry T_ij=t_(i-j)."""
    t = np.asarray(kernel, dtype=complex)
    if t.ndim != 1 or len(t) % 2 != 1:
        raise ValueError("Toeplitz kernel must have odd positive length")
    size = (len(t) + 1) // 2
    index = np.arange(size)
    return t[size - 1 + index[:, None] - index[None, :]]


def _lag_blocks(kernel: np.ndarray, n_fibers: int, n_frequencies: int) -> dict:
    if n_fibers < 1 or n_frequencies < 1:
        raise ValueError("fiber and frequency counts must be positive")
    kernel = np.asarray(kernel, dtype=complex)
    dimension = n_fibers * n_frequencies
    if kernel.shape != (2 * dimension - 1,):
        raise ValueError("kernel length must be 2*n_fibers*n_frequencies-1")
    frequency = np.arange(n_frequencies)
    offsets = frequency[:, None] - frequency[None, :]
    return {
        lag: kernel[dimension - 1 + lag * n_frequencies + offsets]
        for lag in range(-n_fibers + 1, n_fibers)
    }


def _circulant_blocks_to_pumps(blocks: np.ndarray) -> np.ndarray:
    """Spatial block-DFT; each Toeplitz diagonal block Lambda becomes H=Lambda J."""
    local_toeplitz = np.fft.fft(blocks, axis=0)
    local_hankel = local_toeplitz[:, :, ::-1]
    return np.concatenate(
        (local_hankel[:, 0, :], local_hankel[:, 1:, -1]), axis=1
    )


@dataclass(frozen=True)
class PaddedToeplitzPlan:
    n_fibers: int
    n_frequencies: int
    pumps: np.ndarray

    @property
    def n_spatial_modes(self) -> int:
        return self.pumps.shape[0]

    def apply(self, inputs: np.ndarray) -> np.ndarray:
        """Simulate two DFGs with the first J-DFG before spatial expansion.

        x -> J conjugate(x) -> pad -> conjugate(F) -> H conjugation
          -> F^dagger -> crop.
        """
        inputs = np.asarray(inputs, dtype=complex)
        if inputs.shape != (self.n_fibers, self.n_frequencies):
            raise ValueError("inputs must have shape (n_fibers, n_frequencies)")
        modes = self.n_spatial_modes
        fourier = spatial_dft(modes)
        first_dfg = np.conj(inputs[:, ::-1])
        padded = np.zeros((modes, self.n_frequencies), dtype=complex)
        padded[: self.n_fibers] = first_dfg
        after_spatial = fourier.conj() @ padded
        second_dfg = np.stack(
            [hankel_matrix(h) @ np.conj(z) for h, z in zip(self.pumps, after_spatial)]
        )
        return (fourier.conj().T @ second_dfg)[: self.n_fibers]


def compile_padded_toeplitz(
    kernel: np.ndarray,
    n_fibers: int,
    n_frequencies: int,
    n_spatial_modes: int | None = None,
) -> PaddedToeplitzPlan:
    """Compile any global Toeplitz kernel to at most 2n spatial Hankel banks."""
    lag_blocks = _lag_blocks(kernel, n_fibers, n_frequencies)
    modes = 2 * n_fibers if n_spatial_modes is None else n_spatial_modes
    if modes < 2 * n_fibers - 1:
        raise ValueError("exact padding requires at least 2*n_fibers-1 spatial modes")
    blocks = np.zeros((modes, n_frequencies, n_frequencies), dtype=complex)
    for lag, block in lag_blocks.items():
        blocks[lag % modes] = block
    return PaddedToeplitzPlan(
        n_fibers=n_fibers,
        n_frequencies=n_frequencies,
        pumps=_circulant_blocks_to_pumps(blocks),
    )


@dataclass(frozen=True)
class CSCSToeplitzPlan:
    """Two simultaneous n-port circulant arms with permanent phase ramps."""

    n_fibers: int
    n_frequencies: int
    circulant_pumps: np.ndarray
    skew_pumps: np.ndarray

    def apply(self, inputs: np.ndarray) -> np.ndarray:
        phase = np.exp(1j * np.pi * np.arange(self.n_fibers) / self.n_fibers)
        # PaddedToeplitzPlan.apply also applies arbitrary block-circulant pumps
        # when the number of spatial modes equals the input fiber count.
        arm_zero = PaddedToeplitzPlan(
            self.n_fibers, self.n_frequencies, self.circulant_pumps
        )
        arm_one = PaddedToeplitzPlan(
            self.n_fibers, self.n_frequencies, self.skew_pumps
        )
        return arm_zero.apply(inputs) + phase[:, None] * arm_one.apply(
            phase.conj()[:, None] * inputs
        )


def compile_cscs_toeplitz(
    kernel: np.ndarray, n_fibers: int, n_frequencies: int
) -> CSCSToeplitzPlan:
    blocks = _lag_blocks(kernel, n_fibers, n_frequencies)
    circulant = np.stack(
        [blocks[0] / 2]
        + [(blocks[r] + blocks[r - n_fibers]) / 2 for r in range(1, n_fibers)]
    )
    skew = np.stack(
        [blocks[0] / 2]
        + [(blocks[r] - blocks[r - n_fibers]) / 2 for r in range(1, n_fibers)]
    )
    skew *= np.exp(-1j * np.pi * np.arange(n_fibers) / n_fibers)[:, None, None]
    return CSCSToeplitzPlan(
        n_fibers,
        n_frequencies,
        _circulant_blocks_to_pumps(circulant),
        _circulant_blocks_to_pumps(skew),
    )


@dataclass(frozen=True)
class ChirpTransformPlan:
    """Fixed chirp masks around one/two simultaneous global Toeplitz arms.

    This is a carrier-frequency matrix model. A physical dispersive chirp can
    distort or delay fast modulation envelopes; this class does not model that.
    """

    n_fibers: int
    n_frequencies: int
    arms: tuple

    def apply(self, inputs: np.ndarray) -> np.ndarray:
        inputs = np.asarray(inputs, dtype=complex)
        if inputs.shape != (self.n_fibers, self.n_frequencies):
            raise ValueError("inputs must have shape (n_fibers, n_frequencies)")
        output = np.zeros_like(inputs)
        for coefficient, input_mask, plan, output_mask in self.arms:
            output += coefficient * output_mask * plan.apply(input_mask * inputs)
        return output


def compile_bilinear_transform(
    n_fibers: int,
    n_frequencies: int,
    alpha: float,
    row_offset: float = 0.0,
    column_offset: float = 0.0,
    kind: str = "exp",
    row_scale: np.ndarray | None = None,
    column_scale: np.ndarray | None = None,
) -> ChirpTransformPlan:
    """Compile exp/cos/sin(alpha*(i+b)*(j+c)) times fixed row/column scales."""
    if kind not in {"exp", "cos", "sin"}:
        raise ValueError("kind must be exp, cos, or sin")
    size = n_fibers * n_frequencies
    if n_fibers < 1 or n_frequencies < 1:
        raise ValueError("fiber and frequency counts must be positive")
    coordinates = np.arange(size)
    lags = np.arange(-size + 1, size)
    row_scale = np.ones(size) if row_scale is None else np.asarray(row_scale)
    column_scale = np.ones(size) if column_scale is None else np.asarray(column_scale)
    if row_scale.shape != (size,) or column_scale.shape != (size,):
        raise ValueError("scales must have length n_fibers*n_frequencies")
    coefficients = [(1, 1)] if kind == "exp" else (
        [(1, 0.5), (-1, 0.5)] if kind == "cos" else [(1, -0.5j), (-1, 0.5j)]
    )
    arms = []
    for sign, coefficient in coefficients:
        input_mask = column_scale * np.exp(
            0.5j * sign * alpha * (coordinates + column_offset) ** 2
        )
        output_mask = row_scale * np.exp(
            0.5j * sign * alpha * (coordinates + row_offset) ** 2
        )
        kernel = np.exp(
            -0.5j * sign * alpha * (lags + row_offset - column_offset) ** 2
        )
        arms.append(
            (
                coefficient,
                input_mask.reshape(n_fibers, n_frequencies),
                compile_padded_toeplitz(kernel, n_fibers, n_frequencies),
                output_mask.reshape(n_fibers, n_frequencies),
            )
        )
    return ChirpTransformPlan(n_fibers, n_frequencies, tuple(arms))


def compile_dft(n_fibers: int, n_frequencies: int) -> ChirpTransformPlan:
    size = n_fibers * n_frequencies
    return compile_bilinear_transform(
        n_fibers, n_frequencies, -2 * np.pi / size,
        row_scale=np.full(size, 1 / np.sqrt(size)),
    )


def compile_dct2(n_fibers: int, n_frequencies: int) -> ChirpTransformPlan:
    size = n_fibers * n_frequencies
    scale = np.full(size, np.sqrt(2 / size))
    scale[0] = 1 / np.sqrt(size)
    return compile_bilinear_transform(
        n_fibers, n_frequencies, np.pi / size, column_offset=0.5,
        kind="cos", row_scale=scale,
    )


def compile_dst1(n_fibers: int, n_frequencies: int) -> ChirpTransformPlan:
    size = n_fibers * n_frequencies
    return compile_bilinear_transform(
        n_fibers, n_frequencies, np.pi / (size + 1),
        row_offset=1, column_offset=1, kind="sin",
        row_scale=np.full(size, np.sqrt(2 / (size + 1))),
    )


def _dense_from_plan(plan: PaddedToeplitzPlan | CSCSToeplitzPlan | ChirpTransformPlan) -> np.ndarray:
    size = plan.n_fibers * plan.n_frequencies
    return np.column_stack(
        [
            plan.apply(column.reshape(plan.n_fibers, plan.n_frequencies)).ravel()
            for column in np.eye(size, dtype=complex)
        ]
    )


def verification_report(seed: int = 2026) -> dict:
    rng = np.random.default_rng(seed)
    results = []
    for n_fibers, n_frequencies in [(1, 1), (1, 4), (2, 3), (3, 4), (5, 7), (7, 10)]:
        dimension = n_fibers * n_frequencies
        for real_kernel in [False, True]:
            kernel = rng.normal(size=2 * dimension - 1).astype(complex)
            if not real_kernel:
                kernel += 1j * rng.normal(size=2 * dimension - 1)
            target = toeplitz_matrix(kernel)
            for method in ["padding_2n", "padding_2n_minus_1", "cscs"]:
                if method == "cscs":
                    plan = compile_cscs_toeplitz(kernel, n_fibers, n_frequencies)
                else:
                    modes = 2 * n_fibers - (method == "padding_2n_minus_1")
                    plan = compile_padded_toeplitz(
                        kernel, n_fibers, n_frequencies, modes
                    )
                realized = _dense_from_plan(plan)
                error = float(np.linalg.norm(realized - target) / np.linalg.norm(target))
                inputs = rng.normal(size=(n_fibers, n_frequencies)) + 1j * rng.normal(
                    size=(n_fibers, n_frequencies)
                )
                # This guards against inadvertently simulating an antilinear map.
                alpha = 0.3 + 0.7j
                linearity_error = float(
                    np.linalg.norm(plan.apply(alpha * inputs) - alpha * plan.apply(inputs))
                    / max(np.linalg.norm(plan.apply(inputs)), np.finfo(float).tiny)
                )
                if error > 1e-12 or linearity_error > 1e-12:
                    raise AssertionError((method, n_fibers, n_frequencies, error, linearity_error))
                results.append(
                    {
                        "method": method,
                        "n_fibers": n_fibers,
                        "n_frequencies": n_frequencies,
                        "real_kernel": real_kernel,
                        "relative_frobenius_error": error,
                        "complex_linearity_error": linearity_error,
                    }
                )
    chirp_results = []
    for n_fibers, n_frequencies in [(1, 1), (2, 3), (3, 4), (5, 7)]:
        size = n_fibers * n_frequencies
        rows = np.arange(size)[:, None]
        columns = np.arange(size)[None, :]
        scale = np.full(size, np.sqrt(2 / size))
        scale[0] = 1 / np.sqrt(size)
        cases = [
            ("dft", compile_dft(n_fibers, n_frequencies), spatial_dft(size)),
            ("dct2", compile_dct2(n_fibers, n_frequencies),
             scale[:, None] * np.cos(np.pi * rows * (columns + 0.5) / size)),
            ("dst1", compile_dst1(n_fibers, n_frequencies),
             np.sqrt(2 / (size + 1)) * np.sin(np.pi * (rows + 1) * (columns + 1) / (size + 1))),
        ]
        for method, plan, target in cases:
            realized = _dense_from_plan(plan)
            error = float(np.linalg.norm(realized - target) / np.linalg.norm(target))
            if error > 1e-12:
                raise AssertionError((method, n_fibers, n_frequencies, error))
            chirp_results.append({
                "method": method, "n_fibers": n_fibers,
                "n_frequencies": n_frequencies,
                "relative_frobenius_error": error,
            })
    return {
        "seed": seed,
        "model": "ideal undepleted DFG and fixed discrete spatial Fourier transforms",
        "n_cases": len(results),
        "max_relative_frobenius_error": max(r["relative_frobenius_error"] for r in results),
        "max_complex_linearity_error": max(r["complex_linearity_error"] for r in results),
        "cases": results,
        "n_chirp_cases": len(chirp_results),
        "max_chirp_relative_frobenius_error": max(r["relative_frobenius_error"] for r in chirp_results),
        "chirp_cases": chirp_results,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = verification_report()
    encoded = json.dumps(report, indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(encoded + "\n", encoding="utf-8")
    print(
        json.dumps(
            {key: value for key, value in report.items() if key not in {"cases", "chirp_cases"}},
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
