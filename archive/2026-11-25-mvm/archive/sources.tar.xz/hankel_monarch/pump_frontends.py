"""Fixed-phase, amplitude-only pump encodings and their ideal normalizations.

This module models field coefficients. It does not model conversion efficiency,
dispersion, depletion, temporal response, or optical noise.
"""

from __future__ import annotations

import numpy as np


QUADRATURE_PHASES = np.array([1.0, -1.0, 1.0j, -1.0j])
TRINE_PHASES = np.exp(2j * np.pi * np.arange(3) / 3)


def quadrature_rails(coefficients: np.ndarray) -> np.ndarray:
    """Four nonnegative CW-SFG weight rails; same fixed phases for all targets."""
    h = np.asarray(coefficients, dtype=complex)
    if h.ndim != 1:
        raise ValueError("coefficients must be a one-dimensional vector")
    return np.stack((np.maximum(h.real, 0), np.maximum(-h.real, 0),
                     np.maximum(h.imag, 0), np.maximum(-h.imag, 0)))


def combine_quadrature(rails: np.ndarray, *, normalized: bool = False) -> np.ndarray:
    """Combine four pump fields, optionally retaining balanced-combiner scaling."""
    rails = np.asarray(rails)
    if rails.ndim != 2 or rails.shape[0] != 4:
        raise ValueError("rails must have shape (4, number_of_lines)")
    return QUADRATURE_PHASES @ rails / (2 if normalized else 1)


def trine_rails(coefficients: np.ndarray) -> np.ndarray:
    """Three fixed 120-degree rails; smallest common offset per coefficient.

    Their nonnegative cone covers the complex plane. This saves a pump rail over
    quadrature encoding, with a target-dependent passive combining penalty.
    """
    h = np.asarray(coefficients, dtype=complex)
    if h.ndim != 1:
        raise ValueError("coefficients must be a one-dimensional vector")
    base = (2 / 3) * np.real(TRINE_PHASES.conj()[:, None] * h)
    return base - base.min(axis=0)


def combine_trine(rails: np.ndarray, *, normalized: bool = False) -> np.ndarray:
    rails = np.asarray(rails)
    if rails.ndim != 2 or rails.shape[0] != 3:
        raise ValueError("rails must have shape (3, number_of_lines)")
    return TRINE_PHASES @ rails / (np.sqrt(3) if normalized else 1)


def hankel(coefficients: np.ndarray, size: int | None = None) -> np.ndarray:
    h = np.asarray(coefficients)
    if h.ndim != 1 or h.size % 2 != 1:
        raise ValueError("a square Hankel generator needs an odd number of lines")
    if size is None:
        size = (h.size + 1) // 2
    if h.size != 2 * size - 1:
        raise ValueError("generator length must be 2*size-1")
    return h[np.add.outer(np.arange(size), np.arange(size))]


def dfg(pump: np.ndarray, data: np.ndarray) -> np.ndarray:
    """Generated-mode small-signal DFG, including its complex conjugation."""
    return hankel(pump) @ np.asarray(data).conj()


def reversal_pump(size: int) -> np.ndarray:
    if size < 1:
        raise ValueError("size must be positive")
    h = np.zeros(2 * size - 1, dtype=complex)
    h[size - 1] = 1
    return h


def toeplitz_from_two_dfg(pump: np.ndarray, data: np.ndarray) -> np.ndarray:
    return dfg(pump, dfg(reversal_pump(len(data)), data))
