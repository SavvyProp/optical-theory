"""Encoding and mode-selection checks for proposed chainable optical layers.

The SHG calculation is an ideal, normalized, dispersion-free finite-mode ODE.
It is NOT a fabricated-device simulation, a clock-rate test, or an energy
estimate. Guard modes are evolved before filtering at the module boundary.
Run from the repository root: python3 hankel_monarch/chainability_checks.py
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy.integrate import solve_ivp


def hankel(h: np.ndarray) -> np.ndarray:
    k = (len(h) + 1) // 2
    j = np.arange(k)
    return h[j[:, None] + j[None, :]]


def relative(a: np.ndarray, b: np.ndarray) -> float:
    return float(np.linalg.norm(a - b) / max(np.linalg.norm(b), 1e-15))


def dfg(pump: dict[int, complex], seed: dict[int, complex]) -> dict[int, complex]:
    out: dict[int, complex] = {}
    for p, h in pump.items():
        for k, x in seed.items():
            out[p - k] = out.get(p - k, 0j) + h * np.conj(x)
    return out


def shg(initial: np.ndarray, length: float, guard: int = 4):
    """a'=-C_a^dagger b, b'=conv(a,a)/2, with initially empty SH band.

    A fixed phase has been absorbed into b. The normalized Manley-Rowe invariant
    is ||a||^2 + 2||b||^2; broadband energy has frequency weights. All selected
    fundamental modes and guard modes couple.
    """
    a0 = np.pad(np.asarray(initial, dtype=complex), (guard, guard))
    m = len(a0)
    sums = np.arange(m)[:, None] + np.arange(m)[None, :]

    def rhs(_z, state):
        a, b = state[:m], state[m:]
        return np.concatenate((-b[sums] @ a.conj(), np.convolve(a, a) / 2))

    state0 = np.concatenate((a0, np.zeros(2 * m - 1, dtype=complex)))
    sol = solve_ivp(rhs, (0, length), state0, method="DOP853", rtol=2e-11, atol=2e-13)
    if not sol.success:
        raise RuntimeError(sol.message)
    a, b = sol.y[:m, -1], sol.y[m:, -1]
    selected = a[guard:guard + len(initial)]
    energy_error = abs(np.vdot(a, a).real + 2 * np.vdot(b, b).real - np.vdot(a0, a0).real)
    leakage = max(0.0, float(np.vdot(a, a).real - np.vdot(selected, selected).real))
    return selected, a, b, float(energy_error), leakage


def gain_map(g: np.ndarray, length: float) -> np.ndarray:
    """Ideal closed bipartite undepleted amplifier, not a general comb chip."""
    u, s, vh = np.linalg.svd(g, full_matrices=False)
    return (u * np.sinh(length * s)) @ vh


def main():
    rng = np.random.default_rng(20261103)
    k, n = 3, 2
    rand = lambda shape: rng.normal(size=shape) + 1j * rng.normal(size=shape)
    h1, h2 = rand(2 * k - 1), rand(2 * k - 1)
    x, z = rand(k), rand(k)

    # Distinct carrier bands make ordinary wavelength filtering sufficient.
    a0, b0 = 1000, 1100  # Abstract frequency-grid units, not a wavelength design.
    pumps1 = {a0 + b0 + s: h for s, h in enumerate(h1)}
    pumps2 = {a0 + b0 + s: h for s, h in enumerate(h2)}
    first_all = dfg(pumps1, {a0 + j: v for j, v in enumerate(x)})
    first = {b0 + j: first_all[b0 + j] for j in range(k)}
    second = dfg(pumps2, first)
    actual = np.array([second[a0 + j] for j in range(k)])
    expected = hankel(h2) @ hankel(h1).conj() @ x
    unfiltered = dfg(pumps2, first_all)
    wrong = np.array([unfiltered[a0 + j] for j in range(k)])

    # Fixed route phases must be conjugated by the second DFG as well.
    first_bank = np.zeros((n * k, n * k), complex)
    second_bank = np.zeros_like(first_bank)
    for f in range(n):
        sl = slice(f * k, (f + 1) * k)
        first_bank[sl, sl] = hankel(rand(2 * k - 1)) / 4
        second_bank[sl, sl] = hankel(rand(2 * k - 1)) / 4
    permutation = np.zeros((n * k, n * k))
    for fiber in range(n):
        for line in range(k):
            permutation[((fiber + line) % n) * k + line, fiber * k + line] = 1
    rows, columns = np.nonzero(permutation)
    assert np.all(rows % k == columns % k), "Passive routing must preserve wavelength."
    route = np.diag(np.exp(1j * rng.uniform(-np.pi, np.pi, n * k))) @ permutation
    w = second_bank @ route.conj() @ first_bank.conj()

    def core(v):
        return second_bank @ (route @ (first_bank @ v.conj())).conj()

    v, q = rand(n * k), rand(n * k)
    lam, mu = 0.3 + 0.5j, -0.7 + 0.2j
    route_error = relative(core(v), w @ v)
    linear_error = relative(core(lam * v + mu * q), lam * core(v) + mu * core(q))

    a = np.array([0.8 + 0.2j, -0.4 + 0.3j, 0.5 - 0.1j])
    length = 0.5
    activated, _, harmonic, conservation_error, leakage = shg(a, length)
    theta = 0.63
    rotated, _, _, _, _ = shg(a * np.exp(1j * theta), length)
    negative, _, negative_harmonic, _, _ = shg(-a, length)
    doubled_guard, _, _, _, _ = shg(a, length, guard=8)
    scalar_outputs = np.array([shg(np.array([value]), length)[0][0] for value in a])

    scalar = np.array([-0.6 + 0.8j])
    scalar_expected = scalar / np.cosh(np.abs(scalar) * length / np.sqrt(2))
    scalar_error = relative(shg(scalar, length)[0], scalar_expected)

    # The short-length cubic approximation is derived, not prescribed as ODE.
    aa = np.convolve(a, a)
    idx = np.arange(k)[:, None] + np.arange(k)[None, :]
    cubic = aa[idx] @ a.conj()
    expansion_errors = []
    for small_length in (0.08, 0.04):
        exact = shg(a, small_length)[0]
        approximate = a - small_length**2 / 4 * cubic
        expansion_errors.append(float(np.linalg.norm(exact - approximate)))

    # Two complete matmul -> activation stages keep the same field interface.
    def activation_bank(values):
        return np.concatenate([shg(row, 0.25)[0] for row in values.reshape(n, k)])

    chained = activation_bank(core(activation_bank(core(v))))
    equivalent = activation_bank(w @ activation_bank(w @ v))

    g = hankel(h1) / np.linalg.norm(hankel(h1), 2)
    gain_errors = {str(t): relative(gain_map(g, t), t * g) for t in (0.1, 1.0)}

    # Moving a scalar nonlinearity into a rank-one latent is a different layer.
    u = np.array([1.0, 2.0])
    latent = 0.8
    phi = lambda t: t / np.cosh(np.abs(t))

    results = {
        "model_scope": "Ideal field algebra and normalized SHG mode ODE; no device, noise, pulse or rate validation.",
        "two_band_selected_mode_relative_error": relative(actual, expected),
        "omitting_intermediate_filter_relative_error": relative(wrong, expected),
        "complex_route_phase_relative_error": route_error,
        "two_dfg_complex_linearity_error": linear_error,
        "single_dfg_i_input_error_if_mistaken_for_linear": relative(hankel(h1) @ (1j * x).conj(), 1j * hankel(h1) @ x.conj()),
        "shg_manley_rowe_invariant_absolute_error": conservation_error,
        "shg_common_phase_equivariance_relative_error": relative(rotated, activated * np.exp(1j * theta)),
        "shg_fundamental_oddness_relative_error": relative(negative, -activated),
        "shg_harmonic_sign_ambiguity_relative_error": relative(negative_harmonic, harmonic),
        "shg_scalar_sech_relative_error": scalar_error,
        "shg_coupled_vs_independent_scalar_relative_difference": relative(activated, scalar_outputs),
        "shg_out_of_grid_fundamental_power": leakage,
        "shg_guard_convergence_relative_error": relative(activated, doubled_guard),
        "shg_retained_fundamental_power_fraction": float(np.vdot(activated, activated).real / np.vdot(a, a).real),
        "shg_zero_input_norm": float(np.linalg.norm(shg(np.zeros(k), length)[0])),
        "shg_cubic_expansion_errors_L_008_L_004": expansion_errors,
        "shg_cubic_expansion_error_ratio": expansion_errors[0] / expansion_errors[1],
        "two_layer_encoding_closure_relative_error": relative(chained, equivalent),
        "intensity_sign_collision_absolute_error": float(np.linalg.norm(np.abs(a)**2 - np.abs(-a)**2)),
        "undepleted_gain_map_vs_first_order_relative_errors": gain_errors,
        "moving_activation_into_latent_changes_map_norm": float(np.linalg.norm(phi(u * latent) - u * phi(latent))),
    }
    for key in ("two_band_selected_mode_relative_error", "complex_route_phase_relative_error", "two_dfg_complex_linearity_error", "shg_common_phase_equivariance_relative_error", "shg_fundamental_oddness_relative_error", "shg_scalar_sech_relative_error", "two_layer_encoding_closure_relative_error"):
        assert results[key] < 1e-9, (key, results[key])
    assert conservation_error < 1e-9
    assert results["shg_guard_convergence_relative_error"] < 1e-8
    assert results["shg_harmonic_sign_ambiguity_relative_error"] < 1e-9
    assert results["shg_retained_fundamental_power_fraction"] <= 1 + 1e-10
    assert results["shg_zero_input_norm"] < 1e-12
    assert results["omitting_intermediate_filter_relative_error"] > 0.01
    assert results["shg_coupled_vs_independent_scalar_relative_difference"] > 0.01
    assert 14 < results["shg_cubic_expansion_error_ratio"] < 18
    target = Path(__file__).parent / "results" / "chainability_checks.json"
    target.parent.mkdir(exist_ok=True)
    target.write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
