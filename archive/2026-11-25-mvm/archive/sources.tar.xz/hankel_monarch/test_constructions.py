"""Independent regression checks of constructions, not tests of device physics."""

import numpy as np
import pytest
from scipy.fft import dct, dst

from constant_branch import branch_contributions, encode_factors, factor_generator
from factor_frontends import (
    FIXED_FIVE_PORT, cross_sfg_from_factors, joint_amplitude_rails,
    mix_joint_rails, selected_factor_retention, self_sfg_from_factors,
)
from pump_frontends import (
    combine_quadrature, combine_trine, dfg, hankel, quadrature_rails,
    reversal_pump, toeplitz_from_two_dfg, trine_rails,
)
from structured_transforms import (
    compile_cscs_toeplitz, compile_dct2, compile_dft, compile_dst1,
    compile_padded_toeplitz, toeplitz_matrix,
)


@pytest.mark.parametrize("size", [1, 2, 5, 12])
def test_fixed_phase_frontends_and_combiner_normalization(size):
    rng = np.random.default_rng(100 + size)
    h = rng.normal(size=2*size-1) + 1j*rng.normal(size=2*size-1)
    four = quadrature_rails(h)
    three = trine_rails(h)
    assert np.all(four >= 0) and np.all(three >= 0)
    np.testing.assert_allclose(combine_quadrature(four), h, atol=1e-13)
    np.testing.assert_allclose(combine_trine(three), h, atol=1e-13)
    np.testing.assert_allclose(combine_quadrature(four, normalized=True), h/2)
    np.testing.assert_allclose(combine_trine(three, normalized=True), h/np.sqrt(3))
    energy = np.sum(abs(h)**2)
    np.testing.assert_allclose(np.sum(four**2), energy)
    assert energy*(1-1e-12) <= np.sum(three**2) <= 2*energy*(1+1e-12)


@pytest.mark.parametrize("size", [1, 2, 3, 7, 16])
def test_eight_rails_from_independent_coefficients(size):
    rng = np.random.default_rng(200 + size)
    h = rng.normal(size=2*size-1) + 1j*rng.normal(size=2*size-1)
    p, q = factor_generator(h, size)
    rails = encode_factors(p, q)
    assert np.all(rails >= 0)
    np.testing.assert_allclose(branch_contributions(rails).sum(axis=0), h,
                               rtol=1e-9, atol=1e-9)


@pytest.mark.parametrize("size", [1, 2, 4, 9])
def test_two_dfg_is_complex_linear_toeplitz(size):
    rng = np.random.default_rng(300 + size)
    h = rng.normal(size=2*size-1) + 1j*rng.normal(size=2*size-1)
    x = rng.normal(size=size) + 1j*rng.normal(size=size)
    np.testing.assert_allclose(dfg(reversal_pump(size), x), x[::-1].conj())
    expected = toeplitz_matrix(h) @ x
    np.testing.assert_allclose(toeplitz_from_two_dfg(h, x), expected, atol=1e-12)
    np.testing.assert_allclose(toeplitz_from_two_dfg(h, 1j*x), 1j*expected, atol=1e-12)


@pytest.mark.parametrize("n,k", [(1, 1), (1, 4), (2, 3), (3, 2), (5, 7)])
def test_global_toeplitz_matrix_not_just_one_vector(n, k):
    rng = np.random.default_rng(400 + 10*n + k)
    d = n*k
    kernel = rng.normal(size=2*d-1) + 1j*rng.normal(size=2*d-1)
    exact = toeplitz_matrix(kernel)
    plans = [compile_padded_toeplitz(kernel, n, k),
             compile_padded_toeplitz(kernel, n, k, 2*n-1),
             compile_cscs_toeplitz(kernel, n, k)]
    for plan in plans:
        actual = np.column_stack([plan.apply(x.reshape(n, k)).ravel()
                                  for x in np.eye(d)])
        np.testing.assert_allclose(actual, exact, rtol=1e-11, atol=1e-11)
        x = rng.normal(size=(n, k)) + 1j*rng.normal(size=(n, k))
        np.testing.assert_allclose(plan.apply(1j*x), 1j*plan.apply(x), atol=1e-11)


@pytest.mark.parametrize("n,k", [(1, 2), (2, 3), (3, 4)])
def test_global_toeplitz_with_actual_fixed_phase_sfg_pumps(n, k):
    rng = np.random.default_rng(500 + 10*n + k)
    kernel = rng.normal(size=2*n*k-1) + 1j*rng.normal(size=2*n*k-1)
    plan = compile_padded_toeplitz(kernel, n, k)
    encoded = []
    for h in plan.pumps:
        p, q = factor_generator(h, k)
        encoded.append(branch_contributions(encode_factors(p, q)).sum(axis=0))
    # Replacing only compiled pumps leaves routing/phase topology identical.
    physical_plan = type(plan)(n, k, np.array(encoded))
    x = rng.normal(size=(n, k)) + 1j*rng.normal(size=(n, k))
    np.testing.assert_allclose(physical_plan.apply(x).ravel(),
                               toeplitz_matrix(kernel) @ x.ravel(), atol=1e-9)


@pytest.mark.parametrize("n,k", [(1, 1), (2, 3), (3, 4)])
def test_chirp_transform_carrier_matrices(n, k):
    d = n*k
    tests = [
        (compile_dft(n, k), np.fft.fft(np.eye(d), axis=0, norm="ortho")),
        (compile_dct2(n, k), dct(np.eye(d), type=2, axis=0, norm="ortho")),
        (compile_dst1(n, k), dst(np.eye(d), type=1, axis=0, norm="ortho")),
    ]
    for plan, exact in tests:
        actual = np.column_stack([plan.apply(x.reshape(n, k)).ravel()
                                  for x in np.eye(d)])
        np.testing.assert_allclose(actual, exact, rtol=1e-10, atol=1e-10)


def test_uniform_fiber_phase_moves_to_boundary():
    rng = np.random.default_rng(601)
    n, k = 3, 4
    R = np.zeros((n*k, n*k))
    L = np.zeros_like(R)
    for i in range(n):
        sl = slice(i*k, (i+1)*k)
        R[sl, sl] = rng.uniform(size=(k, k))
        L[sl, sl] = rng.uniform(size=(k, k))
    P = np.zeros_like(R)
    for a in range(n):
        for j in range(k):
            P[((a+j) % n)*k+j, a*k+j] = 1
    D = np.diag(np.repeat(np.exp(1j*rng.uniform(size=n)), k))
    np.testing.assert_allclose(L @ P @ D @ R, (L @ P @ R) @ D, atol=1e-13)


@pytest.mark.parametrize("size", [1, 3, 8, 16])
def test_five_port_sfg_frontend_reprograms_only_amplitudes(size):
    rng = np.random.default_rng(700 + size)
    fixed_mixer = FIXED_FIVE_PORT.copy()
    for _ in range(5):
        h = rng.normal(size=2*size-1) + 1j*rng.normal(size=2*size-1)
        p, q = factor_generator(h, size)
        rails = joint_amplitude_rails(p, q)
        outputs = mix_joint_rails(rails)
        assert np.all(rails >= 0)
        np.testing.assert_allclose(outputs[1:3], np.stack((p, q)), atol=1e-10)
        np.testing.assert_allclose(np.sum(abs(outputs)**2), np.sum(rails**2))
        assert 0.1-1e-12 <= selected_factor_retention(rails) <= 0.4+1e-12
        self_pump, _, retention = self_sfg_from_factors(p, q)
        cross_pump, _ = cross_sfg_from_factors(p, q)
        assert 0 <= retention <= 1+1e-12
        np.testing.assert_allclose(np.sqrt(2)*self_pump, h, atol=1e-8)
        np.testing.assert_allclose(cross_pump, h, atol=1e-8)
    np.testing.assert_array_equal(FIXED_FIVE_PORT, fixed_mixer)


@pytest.mark.parametrize("size", [3, 4, 9])
def test_external_fourier_diagonal_and_afdf_upgrade(size):
    rng = np.random.default_rng(800 + size)
    F = np.fft.fft(np.eye(size), axis=0, norm="ortho")
    A = np.diag(rng.normal(size=size) + 1j*rng.normal(size=size))
    D = np.diag(rng.normal(size=size) + 1j*rng.normal(size=size))
    CA, CD = F @ A @ F.conj().T, F @ D @ F.conj().T
    # Both programmed factors are circulants, hence Toeplitz.
    indices = (np.arange(size)[:, None] - np.arange(size)) % size
    np.testing.assert_allclose(CA, CA[:, 0][indices], atol=1e-12)
    np.testing.assert_allclose(CD, CD[:, 0][indices], atol=1e-12)
    np.testing.assert_allclose(F.conj().T @ CD @ F, D, atol=1e-12)
    np.testing.assert_allclose(F.conj().T @ CA @ F @ CD,
                               A @ F @ D @ F.conj().T, atol=1e-12)


@pytest.mark.parametrize("size", [2, 5, 8])
def test_common_carrier_fixed_transform_cancels_conjugation(size):
    rng = np.random.default_rng(900 + size)
    U, _ = np.linalg.qr(rng.normal(size=(size, size))
                        + 1j*rng.normal(size=(size, size)))
    x = rng.normal(size=size) + 1j*rng.normal(size=size)
    common_carrier = x.conj()
    mixed = U.conj() @ common_carrier
    restored_carriers = mixed.conj()
    np.testing.assert_allclose(restored_carriers, U @ x, atol=1e-12)
