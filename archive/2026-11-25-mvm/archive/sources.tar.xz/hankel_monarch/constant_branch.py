"""Eight fixed-phase, amplitude-only SFG branches synthesize any Hankel pump.

Run with Python 3 and NumPy: ``python3 hankel_monarch/constant_branch.py``.
This verifies a polynomial identity, not nonlinear propagation or a 100 GHz
weight compiler. Polynomial coefficients are in ascending powers throughout.
"""

from __future__ import annotations

import math
import numpy as np


THETA = 2 * np.pi * np.arange(8) / 8
FIXED_PHASES = np.exp(3j * THETA)


def factor_generator(h: np.ndarray, k: int) -> tuple[np.ndarray, np.ndarray]:
    """Offline floating-point compiler for h=p*q, each factor length k.

    Root partitioning here is a simple heuristic, not a conditioning optimizer.
    For demanding inputs use supplied factors or a more robust factor compiler.
    """
    h = np.asarray(h, dtype=complex)
    if h.ndim != 1 or len(h) > 2 * k - 1 or k < 1:
        raise ValueError("Require a one-dimensional generator of length <= 2*k-1")
    nonzero = np.flatnonzero(h != 0)
    if not len(nonzero):
        return np.zeros(k, complex), np.zeros(k, complex)
    h = h[: nonzero[-1] + 1]
    roots = np.polynomial.polynomial.polyroots(h)
    # Interleave by argument to avoid concentrating all roots in one half-plane.
    roots = roots[np.argsort(np.angle(roots))]
    leading_sqrt = np.sqrt(h[-1])
    p = leading_sqrt * np.polynomial.polynomial.polyfromroots(roots[::2])
    q = leading_sqrt * np.polynomial.polynomial.polyfromroots(roots[1::2])
    p = np.pad(p, (0, k - len(p)))
    q = np.pad(q, (0, k - len(q)))
    # This minimizes ||s*p||^2 + ||q/s||^2 for positive scalar s.
    scale = np.sqrt(np.linalg.norm(q) / np.linalg.norm(p))
    return p * scale, q / scale


def encode_factors(p: np.ndarray, q: np.ndarray) -> np.ndarray:
    """Return eight nonnegative real weight combs, with phases always fixed.

    sum_j FIXED_PHASES[j] * convolve(u[j], u[j]) == convolve(p, q).
    """
    p, q = np.asarray(p, complex), np.asarray(q, complex)
    if p.ndim != 1 or p.shape != q.shape:
        raise ValueError("p and q must be vectors of the same length")
    samples = np.real(
        np.exp(-1j * THETA[:, None]) * p
        + np.exp(-2j * THETA[:, None]) * q
    )
    # Smallest offset making this finite set of sampled coefficients nonnegative.
    offset = np.maximum(0.0, np.max(-samples, axis=0))
    u = (offset + samples) / 2
    assert np.min(u) >= -1e-14 * max(1.0, np.max(np.abs(u)))
    return np.maximum(u, 0.0)


def branch_contributions(u: np.ndarray) -> np.ndarray:
    return np.array([
        phase * np.convolve(row, row)
        for phase, row in zip(FIXED_PHASES, u)
    ])


def relative_error(actual: np.ndarray, target: np.ndarray) -> float:
    return float(np.linalg.norm(actual - target) / max(np.linalg.norm(target), 1e-300))


def combining_metrics(contributions: np.ndarray) -> tuple[float, float, float]:
    """gamma, ideal optimized-combiner retention, equal-combiner retention.

    Optimized retention assumes independently rescaled branch powers and splitter
    ratios. It excludes SFG conversion, DFG conversion, losses, and pump noise.
    """
    result_norm = np.linalg.norm(np.sum(contributions, axis=0))
    norms = np.linalg.norm(contributions, axis=1)
    gamma = np.sum(norms) / max(result_norm, 1e-300)
    eta_optimized = 1 / gamma**2
    eta_equal = result_norm**2 / max(len(norms) * np.sum(norms**2), 1e-300)
    return float(gamma), float(eta_optimized), float(eta_equal)


def verify() -> None:
    rng = np.random.default_rng(271828)
    maximum_factor_error = 0.0
    maximum_identity_error = 0.0
    cases = 0
    for k in (1, 2, 3, 4, 8, 16, 32):
        for _ in range(30):
            p = rng.normal(size=k) + 1j * rng.normal(size=k)
            q = rng.normal(size=k) + 1j * rng.normal(size=k)
            h = np.convolve(p, q)
            u = encode_factors(p, q)
            result = branch_contributions(u).sum(axis=0)
            error = relative_error(result, h)
            maximum_identity_error = max(maximum_identity_error, error)
            assert error < 2e-12, (k, error)
            # A DFG Hankel matrix is built directly from this synthesized pump.
            indices = np.arange(k)[:, None] + np.arange(k)[None, :]
            z = rng.normal(size=k) + 1j * rng.normal(size=k)
            assert np.allclose(result[indices] @ z.conj(), h[indices] @ z.conj())
            cases += 1

    # Independent target coefficients test the offline root factor compiler too.
    print("K  target error   gamma   optimized retention  equal retention")
    for k in (2, 4, 8, 16, 32):
        worst_error, worst_gamma, min_opt, min_equal = 0.0, 0.0, 1.0, 1.0
        for _ in range(20):
            h = rng.normal(size=2*k-1) + 1j * rng.normal(size=2*k-1)
            p, q = factor_generator(h, k)
            factor_error = relative_error(np.convolve(p, q), h)
            maximum_factor_error = max(maximum_factor_error, factor_error)
            contributions = branch_contributions(encode_factors(p, q))
            error = relative_error(contributions.sum(axis=0), h)
            gamma, eta_opt, eta_equal = combining_metrics(contributions)
            worst_error, worst_gamma = max(worst_error, error), max(worst_gamma, gamma)
            min_opt, min_equal = min(min_opt, eta_opt), min(min_equal, eta_equal)
            assert error < 1e-8, (k, error)
            cases += 1
        print(f"{k:2d} {worst_error:12.3e} {worst_gamma:8.2f} {min_opt:19.3e} {min_equal:16.3e}")

    # Zeros, monomials, and the highest allowed degree.
    for k in (1, 2, 5, 10):
        for degree in range(2*k-1):
            h = np.zeros(2*k-1, complex)
            h[degree] = -0.7 + 0.2j
            p, q = factor_generator(h, k)
            result = branch_contributions(encode_factors(p, q)).sum(axis=0)
            assert relative_error(result, h) < 2e-12
            cases += 1
        p, q = factor_generator(np.zeros(2*k-1), k)
        assert np.all(branch_contributions(encode_factors(p, q)) == 0)

    print(f"Verified {cases} nonzero cases; direct-identity max error {maximum_identity_error:.3e}; "
          f"root-factor max error {maximum_factor_error:.3e}.")

    # Same target, dramatically different root partitions: exact expressivity
    # does not imply that a factor compiler produces an economical pump.
    print("Stress target (1-t^2)^d: poor versus balanced root partitions")
    for d in (2, 4, 8, 12):
        p_bad = np.array([math.comb(d, j) for j in range(d+1)], complex)
        q_bad = p_bad * (-1.)**np.arange(d+1)
        p_good = np.zeros(d+1, complex)
        p_good[::2] = [(-1.)**j * math.comb(d//2, j) for j in range(d//2+1)]
        target = np.convolve(p_bad, q_bad)
        assert np.allclose(np.convolve(p_good, p_good), target)
        bad = branch_contributions(encode_factors(p_bad, q_bad))
        good = branch_contributions(encode_factors(p_good, p_good))
        bad_metrics, good_metrics = combining_metrics(bad), combining_metrics(good)
        assert relative_error(good.sum(axis=0), target) < 1e-10
        assert relative_error(bad.sum(axis=0), target) < 1e-6
        print(f"d={d:2d}: gamma {bad_metrics[0]:.3e} -> {good_metrics[0]:.3e}; "
              f"optimized retention {bad_metrics[1]:.3e} -> {good_metrics[1]:.3e}")


if __name__ == "__main__":
    verify()
