"""Diagnostics for the proofs in limitations.md.

These are finite-dimensional algebra checks, not an optical-device simulation
or an empirical ML benchmark. Run from the repository root with:
    python3 hankel_monarch/single_shuffle_checks.py
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy.linalg import block_diag


def hankel(h: np.ndarray) -> np.ndarray:
    k = (len(h) + 1) // 2
    indices = np.arange(k)
    return h[indices[:, None] + indices[None, :]]


def cyclic_shuffle(n: int, k: int) -> np.ndarray:
    p = np.zeros((n * k, n * k))
    for b in range(n):
        for line in range(k):
            p[((b + line) % n) * k + line, b * k + line] = 1
    return p


def invariant_entries(a: int, j: int, n: int) -> list[tuple[int, int]]:
    """Entries p1,p2,q0,q1 for ports 0 and 1 of output fiber a."""
    source0, source1 = a, (a - 1) % n
    return [(a * n + 1, source0 * n + j),
            (a * n + 2, source0 * n + j),
            (a * n, source1 * n + j),
            (a * n + 1, source1 * n + j)]


def main() -> None:
    rng = np.random.default_rng(20261103)
    n = k = 3
    p = cyclic_shuffle(n, k)
    max_minor = max_phase_error = max_block_tail = 0.0
    for _ in range(20):
        def bank():
            return block_diag(*[
                hankel(rng.normal(size=2 * k - 1)
                       + 1j * rng.normal(size=2 * k - 1)) for _ in range(n)
            ])

        b1, b2 = bank(), bank()
        phase = np.diag(np.repeat(np.exp(1j * rng.normal(size=n)), k))
        w = b2 @ p @ phase.conj() @ b1.conj()
        shifted = b2 @ p @ b1.conj() @ phase.conj()
        max_phase_error = max(max_phase_error, float(np.max(np.abs(w - shifted))))
        for a in range(n):
            for b in range(n):
                block = w[a*k:(a+1)*k, b*k:(b+1)*k]
                max_block_tail = max(max_block_tail,
                                     float(np.linalg.svd(block, compute_uv=False)[1]))
            for j in range(k):
                values = [w[index] for index in invariant_entries(a, j, n)]
                max_minor = max(max_minor, float(abs(np.linalg.det(np.array(values).reshape(2, 2)))))
    assert max(max_minor, max_phase_error, max_block_tail) < 1e-10

    # The nine four-entry groups are disjoint, allowing squared errors to add.
    groups = [invariant_entries(a, j, n) for a in range(n) for j in range(k)]
    indices = [index for group in groups for index in group]
    assert len(indices) == len(set(indices)) == 36
    target = np.outer(np.tile([1., 1., 2.], n), np.ones(n*k))
    error2_lower = sum(np.linalg.svd(
        np.array([target[index] for index in group]).reshape(2, 2),
        compute_uv=False)[1] ** 2 for group in groups)
    relative_bound = float(np.sqrt(error2_lower) / np.linalg.norm(target))
    assert np.isclose(relative_bound, (3 - np.sqrt(5)) / (2 * np.sqrt(18)))

    reversal = np.kron(np.eye(n), np.eye(k)[::-1])
    canonical_q = reversal @ p @ reversal
    assert np.array_equal(canonical_q.T @ canonical_q, np.eye(n*k))

    # Size-three exception: monomial supports {0,3} then {1,4} can
    # encode arbitrary positive gains after their associated output relabel.
    s1 = np.array([1., 0., 0., 1., 0.])
    s2 = np.array([0., 1., 0., 0., 1.])
    q = block_diag(*[hankel(s2)]*n) @ p @ block_diag(*[hankel(s1)]*n)
    log_gain_map = np.zeros((n*k, 4*n))
    for b in range(n):
        for line in range(k):
            a = (b + line) % n
            j = (-line) % k  # First-bank permutation i+j == 0 (mod 3).
            log_gain_map[b*k+j, 2*b + (line != 0)] = 1
            log_gain_map[b*k+j, 2*n + 2*a + (line == 2)] = 1
    assert np.linalg.matrix_rank(log_gain_map) == n*k
    gains = np.exp(rng.normal(size=n*k))
    coefficients = np.exp(np.linalg.lstsq(log_gain_map, np.log(gains), rcond=None)[0])
    first = block_diag(*[hankel(np.array([
        coefficients[2*b], 0., 0., coefficients[2*b+1], 0.])) for b in range(n)])
    second = block_diag(*[hankel(np.array([
        0., coefficients[2*n+2*a], 0., 0., coefficients[2*n+2*a+1]])) for a in range(n)])
    diagonal_error = float(np.max(np.abs(q.T @ second @ p @ first - np.diag(gains))))
    assert diagonal_error < 1e-12

    # Positive Toeplitz witness: every 2x2 minor is nonzero.
    coordinate = np.arange(n*k)
    toeplitz = np.exp(-0.03 * (coordinate[:, None] - coordinate[None, :])**2)
    minors = [abs(np.linalg.det(toeplitz[np.ix_([i, r], [j, s])]))
              for i in range(n*k) for r in range(i+1, n*k)
              for j in range(n*k) for s in range(j+1, n*k)]
    assert min(minors) > 1e-8

    result = {
        "scope": "Ideal algebra only; proofs in limitations.md",
        "random_complex_trials": 20,
        "max_phase_relocation_error": max_phase_error,
        "max_block_second_singular_value": max_block_tail,
        "max_hankel_overlap_minor": max_minor,
        "rank_one_target_relative_error_lower_bound": relative_bound,
        "disjoint_four_entry_groups": len(groups),
        "n3_alternative_encoding_log_gain_rank": int(np.linalg.matrix_rank(log_gain_map)),
        "n3_alternative_encoding_diagonal_error": diagonal_error,
        "positive_toeplitz_min_abs_2x2_minor": float(min(minors)),
    }
    path = Path(__file__).with_name("results") / "single_shuffle_checks.json"
    path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
