# Structural limitations and temporal-sum constructions

[Structure and notation](README.md) · [Requirements and evaluation](requirements.md)

Sections 1–6 concern the ideal selected-mode model with **one local Hankel on each side of one shuffle**. Section 7 treats a different topology: temporal sums of two Hankels acting consecutively on the same vector, without a shuffle. These are algebraic results, not optimizer failures or device measurements. Except where stated otherwise, allow arbitrary complex Hankel coefficients: impossibility in this larger family also applies to the original amplitude-only self-SFG design.

The strongest results assume the balanced cyclic router: `n=K`, with wavelength `l` from fiber `b` sent to fiber `(b+l) mod n`. Exactly one intermediate wavelength then connects each source/destination fiber pair. Do not transfer these results unchanged to a dense mixer, additional parallel branches, two local Hankels on each side, or two complete routed cores.

The [full Hankel matmul array](README.md#8-arrays-of-full-hankel-matmuls-and-monarch) replaces each local Hankel by a temporally completed arbitrary block using section 7's construction. It removes the shared-Hankel-coefficient obstructions to general rank-one projections and logical diagonal gains, under independent signed/complex coefficient control. The one-route fiber-block rank bound still applies. Its two separate local accumulations implement a product of sums, which differs from section 6's sum of whole shuffled cores.

## Capability summary

| Capability | Definite result and scope |
|---|---|
| Internal phase control | A uniform fiber phase before the shuffle can move to the input boundary; it adds no expressivity with arbitrary complex Hankel coefficients |
| Independent communication between fiber pairs | Fiber-block rank is at most the route count; at most one in the balanced case |
| All-input dependence | Impossible in one core if `K<n`: at most `K²` inputs can affect one scalar output |
| Every learned rank-one map | Missing in the balanced case for `K>=3`, even for positive targets |
| Independent coordinate gains | Missing under every fixed input/output relabeling for balanced `n=K>=4` |
| Every Toeplitz convolution | Missing in the balanced case for `K>=2`, even after fixed relabeling |
| Arbitrary signs and genuine unitary rotations | Additionally excluded for raw nonnegative pumps with only boundary phases |

The full matrix can nevertheless be dense and invertible. These limits concern specific learned directions and controls. Their importance depends on the intended role described in [requirements.md](requirements.md).

## 1. Phase relocation and communication rank

Let `B_1,B_2` be the block-diagonal Hankel banks, `P` the real routing permutation, and `D = diag(exp(i theta_b) I_K)` the fixed phase shifters. The two DFG conjugations give

\[
W=B_2P\bar D\,\overline{B_1}
 =B_2P\overline{B_1}\,\bar D.
\]

The equality uses commutation within a fiber, not commutation through the shuffle. With arbitrary complex coefficients, absorb `D` into the first Hankel bank. With nonnegative coefficients, it supplies only a common source-fiber phase.

If `r_ab` wavelengths route from fiber `b` to fiber `a`, then

\[
W_{ab}=e^{-i\theta_b}
\sum_{l:\pi_l(b)=a}H^{(2)}_a[:,l]\,
\overline{H^{(1)}_b[l,:]},
\qquad \operatorname{rank}W_{ab}\le r_{ab}.
\]

Each term is an outer product. In the balanced case a source contributes only one scalar summary to a given destination. The Hankel equalities further tie those summaries and output directions across destinations.

For `K<n`, an output fiber receives at most `K` source fibers. Each contains `K` input coordinates, giving the `K²` reachability bound. This argument applies to any wavelength-preserving permutation.

## 2. A positive rank-one projection that is impossible

For `n=K=3`, consider

\[
W_*=u\mathbf1_9^{\mathsf T},\qquad
u=(1,1,2,\;1,1,2,\;1,1,2)^{\mathsf T}.
\]

It sums every input and distributes that sum in a positive output pattern. Two columns reaching adjacent intermediate ports of one output fiber must have the form

\[
p=\alpha(h_0,h_1,h_2)^{\mathsf T},\qquad
q=\beta(h_1,h_2,h_3)^{\mathsf T}.
\]

Every realizable matrix therefore obeys `p_1 q_1 - p_2 q_0 = 0`. The target requires `p=q=(1,1,2)^T`, for which the expression is `-1`. No choice of complex coefficients realizes it. The same three-entry witness extends to larger balanced combs.

The restriction also prevents arbitrarily close approximation. The rearranged entries `[[p_1,p_2],[q_0,q_1]]` must have rank at most one. Their target is `[[1,2],[1,1]]`, whose smallest singular value is `(3-sqrt(5))/2`. Across three output fibers and three input coordinates there are nine disjoint such entry groups. Consequently,

\[
\frac{\|W-W_*\|_F}{\|W_*\|_F}
\ge\frac{3-\sqrt5}{2\sqrt{18}}\approx 0.09003.
\]

This **9.003% lower bound** is for that target and the stated layout. Its square bounds relative mean-square output error for inputs with identity second moment; other input distributions can weight the error differently. Fixed permutations cannot repair coverage of *all* rank-one maps, since they map that target family bijectively to itself.

## 3. Logical identity does not establish independent gains

Physical identity is impossible in the balanced layout for `K>1`: each diagonal fiber block has rank at most one, whereas `I_K` has rank `K`. In the original physical ordering,

\[
\frac{\|W-I\|_F}{\|I\|_F}\ge\sqrt{1-1/K}.
\]

However, logical identity is possible in the arbitrary-complex model. Let `R=I_n tensor J_K`, where `J_K` reverses the frequency index. Choosing both Hankel banks as reversals, with the fixed phases absorbed into coefficients, gives the permutation `Q=RPR`. Relabeling output as `Q^{-1}y` makes this setting identity. Physical routing may still be needed to align an actual residual sum or a downstream interface.

Now allow **any fixed output permutation** `Q` and ask for all nonzero diagonal gains: `W=Q diag(d)`. Its `n²` nonzero entries lie in `n²` physical fiber blocks. A block can contain at most one permutation entry because its rank is at most one; hence every block contains exactly one. The outer-product form forces every local Hankel to have one nonzero per row and column.

Such an invertible Hankel has at most two nonzero anti-diagonals. Anti-diagonals below index `K-1` occupy overlapping row prefixes, and those above it occupy overlapping suffixes, so at most one of each is possible. The supports are `{K-1}` or `{s,s+K}`, `0<=s<=K-2`.

Thus, for each of finitely many support patterns, the `2n` local Hankels provide at most `4n` complex coefficients. One common scaling cancels between banks, giving

\[
\dim_{\mathbb C}\{\text{realizable nonzero diagonal gains}\}
\le 4n-1<n^2\qquad(n\ge4).
\]

A finite union of these lower-dimensional algebraic images cannot cover arbitrary diagonals. An additional fixed input permutation only changes the requested ordering of gains. Therefore no fixed coordinate relabeling repairs general independent gain control for `n=K>=4`.

**Small-size exception:** at `n=K=3`, first-bank supports `{0,3}` and second-bank supports `{1,4}` permit arbitrary nonzero gains after their associated output permutation. The checks below retain this exception; the `n>=4` qualification is essential.

## 4. A positive convolution kernel that is impossible

Every `2 by 2` minor inside a physical fiber block vanishes in the balanced layout. Consider instead the Toeplitz matrix

\[
T_{ij}=q^{(i-j)^2},\qquad 0<q<1.
\]

This is a finite-window discrete Gaussian convolution. For distinct rows `i,r` and columns `j,s`, the two products in its minor have exponents differing by

\[
(i-j)^2+(r-s)^2-(i-s)^2-(r-j)^2
=2(i-r)(s-j)\ne0.
\]

Every such minor is nonzero. Therefore this target is impossible even after fixed input/output permutations. This excludes general Toeplitz coverage; special kernels may remain possible. A separate temporal filter or a second routed core is a different architecture.

## 5. Extra restrictions of raw amplitude-only pumps

With nonnegative Hankel entries, `W=A bar(D)` with `A=B_2 P B_1>=0`. All coefficients from one source fiber have the same fixed phase. A row contrast `(1,-1)` between two wavelengths of that fiber is impossible. Different fibers can have different phases, which does not provide independently signed wavelength weights.

Even allowing boundary phase gauges, the form is `D_out A D_in`, `A>=0`. If this square matrix is unitary, the nonnegative columns of `A` must be orthogonal, hence have disjoint support. A square unitary then reduces to a permutation with phases. Genuine rotations are excluded. These positivity arguments do not apply when independently programmable complex Hankel coefficients are supplied.

## 6. Which requirements temporal sums repair

Assessment added **4 November 2026**. Let `W_T = sum_t c_t A_t`, with the same input vector in all slots, both banks changing, and fixed scalar taps shared across wavelengths. The following table assumes balanced `n=K`, `d=K²`. “Raw positive” means the original nonnegative self-SFG weights and nonnegative temporal taps after removal of fixed boundary phases. The complex-Hankel column is an expressivity bound, not an assumed raw-pump capability.

| Requirement | Raw positive sums | Arbitrary complex Hankel sums |
|---|---|---|
| Full rank | Available already; conditioning remains a separate test | Available already |
| Independent fiber-pair communication | Block rank rises to at most `min(K,T)` | Same bound |
| All-input connectivity | No new connections; zero route counts stay zero | Same |
| Programmable signed mixing | Still absent within a source fiber for every `T` | Available at coefficient level; arbitrary sign patterns are not guaranteed at small `T` |
| Every rank-one projection | Still missing for every `T` | Still missing for `T<K`; all are available by `T=d`, with no general sharp bound between these stated |
| Logical identity and positive coordinate gains | Available in at most `d` slots after fixed output relabeling by `P`; odd `K` also has an at-most-`K` construction in the canonical ordering | In canonical ordering, minimum slots for a gain table `G` are exactly `rank(G)<=K` |
| Every signed diagonal in that canonical ordering | Not covered by positive taps | Exactly `rank(G)` slots, as above |
| General feature-axis convolution | Still missing in the physical ordering for every `T`, even for some positive kernels | Generic kernels require at least `K` slots; `d` slots suffice |
| General orthogonal/unitary mixing | Only phase-weighted permutations possible | General coverage requires at least `K` slots; `d` slots suffice |
| Rectangular projections | Selecting existing outputs or padding inputs is possible; independent expansion still requires output modes and a specified interface | Same interface issue; small-`T` arbitrary rectangular coverage is not established |
| A supplied base plus a correction | Accumulate their realizable decompositions consecutively, paying the sum of their slot counts | Same; the base must actually be supplied |

Reaching a necessary slot count is not a sufficiency proof. These are exact representation statements; task quality, conditioning and optical efficiency remain unmeasured.

The convolution and general-unitary lower bounds follow from the fiber-block rank bound: their families include matrices with a full-rank `K by K` fiber block. In particular, a Gaussian Toeplitz block becomes a Vandermonde matrix with distinct nodes after nonzero row/column scalings, so it has rank `K`.

### A shared-coefficient restriction survives at small slot counts

For each physical fiber block let `ell_ab=(a-b) mod K` and extract one entry:

\[
S(W)_{ab}=W_{ab}[K-1-\ell_{ab},K-1-\ell_{ab}].
\]

In one slot this is the product of the two central Hankel coefficients:

\[
S(A_t)_{ab}=h^{(2)}_{a,t}[K-1]\,
\overline{h^{(1)}_{b,t}[K-1]}e^{-i\theta_b},
\qquad \boxed{\operatorname{rank}S(W_T)\le T.}
\]

This is stronger than checking fiber-block ranks alone. Consider the rank-one operation that sums the last wavelength across all fibers and broadcasts the sum to the last wavelength of every output fiber. Its target is `W_*=u u^T`, with `u=(e_(K-1),...,e_(K-1))`. Here `S(W_*)=I_K`, so it needs at least `K` slots even though its ordinary matrix rank is one. Because the extracted entries are distinct and `||W_*||_F=K`,

\[
\frac{\|W_T-W_*\|_F}{\|W_*\|_F}
\ge\frac{\sqrt{K-T}}{K},\qquad T<K.
\]

For three fibers and two slots, the error is at least **33.3%**. Replacing the zeros in each local target vector by any fixed `0<epsilon<1` gives a strictly positive rank-one target that still requires at least `K` slots.

For canonical logical output ordering `Q^{-1}`, `Q=RPR`, an independent diagonal has exactly these extracted entries: `S(Q diag(g))=G`, where `G` is its `K by K` destination/source gain table. Thus `T>=rank(G)`. Conversely, factoring `G` into rank-one terms and setting each local Hankel to a scalar multiple of `J_K` attains this count. Generic independent gains therefore require **exactly `K` slots** in this ordering, while identity needs one. Known fixed phases are absorbed into the complex coefficients.

### Positive temporal sums retain a raw-pump constraint forever

For raw `h=u*u`, `u>=0`, and `K>=3`,

\[
h_1=2u_0u_1\le u_0^2+u_1^2\le h_0+h_2.
\]

The same-fiber block uses intermediate port zero. Every one of its columns, after removing the fixed source phase, is a positive sum of vectors `(h_0,h_1,h_2,...)`. Therefore

\[
(W_T)_{aa}[1,k]\le
(W_T)_{aa}[0,k]+(W_T)_{aa}[2,k]
\]

for every number of slots. A desired column segment `(0,1,0)` violates this inequality; its distance to the allowed halfspace is `1/sqrt(3)`. Consequently some positive coordinate maps, arbitrary positive rank-one coverage and physical identity remain impossible. The positive Toeplitz kernel `q^((i-j)^2)` with `0<q<1/2` also fails: its relevant segment is `(q,1,q)`. These examples use the declared physical ordering. Failure to cover all rank-one maps persists under any fixed coordinate permutations.

Logical coordinate gains have a different answer. Choose one source fiber `b` and one wavelength `k`; activate only that first-bank fiber and second-bank fiber `a=b+k mod K`, using raw pump vectors proportional to `e_k`. The only surviving entry is `E_((a,k),(b,k))`. At most `d` such slots implement `P diag(g)` for any `g>=0`, up to the known source phase. Fixed output relabeling by `P^{-1}` supplies logical gains and selectors. Take `D=I` for real identity, or explicitly retain its known phase convention. For odd `K`, raw pumps can implement `J_K` directly, giving the faster at-most-`K` positive-gain construction in canonical ordering.

### Larger sums and changes to the filter

In the arbitrary-complex model, `d` slots suffice for any square matrix: isolate one source fiber per group, use `K` rank-one Hankels whose selected rows form a Fourier basis, and choose each second-bank column to supply the desired output coefficients. Generic dense coverage requires `T=Omega(d)` by parameter counting. Small fixed `T` therefore remains a restricted matrix family.

Fixed negative or quadrature tap classes change the raw result by permitting cancellation. To see existence, write `F_s` for a single anti-diagonal Hankel. Even indices are raw squares, `F_(2p)=H(e_p)`, while

\[
F_{p+q}=\tfrac12[H(e_p+e_q)-H(e_p)-H(e_q)]\quad(p\ne q).
\]

Here `H(u)` denotes the raw self-SFG Hankel. Isolating a source/destination pair and multiplying two such basis Hankels isolates any matrix entry. Expansion therefore gives dense real coverage with enough fixed signed-tap slots; quadrature classes extend it to complex coefficients. This is an existence proof, not a low-slot-count or energy-efficient construction. Equal positive accumulation does not provide this cancellation.

### Physical requirements that change

Temporal accumulation keeps the original spatial paths and two serial DFG interactions. It relaxes the original single-shot requirement and consumes `T` weight settings per independent result. With one core, independent-vector throughput is at most the slot rate divided by `T`; a sliding-window output every slot does not remove that work requirement. Coherent optical storage/filtering, WDM tap calibration, framing and an input holding/repetition protocol for subsequent layers must be specified. Matching carrier grids alone does not establish a chainable temporal interface.

[temporal_sum_checks.py](temporal_sum_checks.py) and its [recorded results](results/temporal_sum_checks.json) check the extracted-rank invariant, examples, gain constructions and raw-pump inequality. These diagnostics do not establish ML accuracy or a physical implementation.

## 7. Sums of local Hankel-product pairs: an exact dense construction

Here **`N` is the dimension of each Hankel**, not the number of fibers in the routed architecture above. Consider

\[
A=\sum_{t=1}^{T}H_{2,t}H_{1,t},\qquad H_{r,t}\in\mathbb F^{N\times N},
\quad \mathbb F=\mathbb R\text{ or }\mathbb C.
\]

**Every matrix `A` has such a decomposition with `T=ceil(N/2)`**, provided the Hankel coefficients can be independently signed or complex. For even `N`, `N/2` is also the exact worst-case minimum. This counts products: `N/2` terms contain `N` individual Hankel factors. A sum of individual Hankels always remains Hankel and cannot cover arbitrary matrices for `N>1`.

This is a constructive algebraic result. A two-DFG implementation gives `H_2 conjugate(H_1)`; preconjugating the programmed first factor recovers the displayed product in the unrestricted coefficient model.

### Two-vector interpolation lemma

Write `v(z)=(1,z,...,z^(N-1))^T`. For nonzero nodes `lambda,mu` with `lambda^N != mu^N`, a Hankel matrix can satisfy

\[
Hv(\lambda)=a,\qquad Hv(\mu)=b
\]

if and only if `v(lambda)^T b = v(mu)^T a`. Transposes here are ordinary transposes, including over the complex field. Necessity follows because every Hankel is symmetric.

For sufficiency, the map from the `2N-1` Hankel coefficients to these two output vectors is injective. Indeed, if both outputs vanish, subtracting `lambda` times row `i+1` from row `i` gives

\[
h_i=\lambda^N h_{i+N},\qquad
h_i=\mu^N h_{i+N},\qquad 0\le i<N-1.
\]

All coefficients except `h_(N-1)` therefore vanish; either original row-zero equation kills that coefficient too. The domain and the compatible-output hyperplane both have dimension `2N-1`, so the map is onto that hyperplane. The corresponding single-vector interpolation map is also onto.

### Construction for every target matrix

Choose generic distinct nonzero nodes `lambda_1,...,lambda_N` with distinct `N`th powers, and form the Vandermonde matrix `V=[v_1,...,v_N]`. Define

\[
U=AV^{-\mathsf T},\qquad C=V^{\mathsf T}U,
\qquad A=\sum_{i=1}^{N}u_i v_i^{\mathsf T}.
\]

Pair columns `(1,2),(3,4),...`. For a pair `i,j`, choose nonzero scalars `c_i,c_j` with `c_i C_ij = c_j C_ji`. When both crossentries are nonzero, take `c_i=C_ji,c_j=C_ij`; when both vanish, take both scalars one. Then set

\[
H_1=c_i v_i v_i^{\mathsf T}+c_j v_j v_j^{\mathsf T}.
\]

Each outer product is Hankel. The lemma supplies a Hankel `H_2` such that `H_2 v_i=u_i/c_i` and `H_2 v_j=u_j/c_j`, because the scalar choice enforces exactly its compatibility condition. Consequently,

\[
H_2H_1=u_i v_i^{\mathsf T}+u_j v_j^{\mathsf T}.
\]

Summing the paired terms gives `A`. For odd `N`, use `H_1=v_N v_N^T` and single-vector interpolation for the leftover term.

Why do suitable nodes exist for **every** fixed `A`? The entries `C_ij` and `C_ji` are rational functions of the nodes and are exchanged by swapping node labels `i,j`. Hence they are either both identically zero or both nonzero rational functions. In the latter case, exclude the zero sets of both numerators. A finite collection of nonzero polynomials cannot vanish throughout an open set. Thus nodes can simultaneously avoid all the forbidden sets, including coincident nodes and coincident `N`th powers. Positive real nodes suffice, so real targets have all-real factors. The nodes may depend on `A`.

**`V` is used only to compile weights offline; the data path does not implement a Vandermonde transform or an arbitrary dense mixer.** This proof does not bound conditioning, factor amplitudes or compilation cost. Near-zero crossentries and poorly conditioned interpolation can be physically expensive even when the exact decomposition exists.

### Why fewer than `N/2` terms cannot always work

For `W=H(a)H(b)`, its interior diagonal difference satisfies

\[
\Delta(W)_{ij}:=W_{i+1,j+1}-W_{ij}
=a_{i+N}b_{j+N}-a_i b_j,\qquad 0\le i,j<N-1.
\]

This is a difference of two outer products. Therefore `rank(Delta(sum_t H_(2,t) H_(1,t))) <= 2T`. The target `A=diag(0,1,...,N-1)` has `Delta(A)=I_(N-1)`, so

\[
T\ge\left\lceil\frac{N-1}{2}\right\rceil.
\]

For even `N`, this matches the construction exactly. For odd `N`, the bounds here differ by one; no sharp odd-dimensional minimum is claimed.

### What this does and does not give the optical design

- **Representation:** unrestricted pairs can implement every dense map, and therefore every rank-one projection, diagonal, convolution and unitary, by this slot count. Their individual optimal counts may be smaller.
- **Physical scope:** the two Hankels must each act on the entire `N`-coordinate vector. Separate `K by K` local pairs on multiple fibers remain block diagonal without cross-fiber mixing. This theorem does not replace the routed bounds in section 6.
- **Resources:** for even `N`, the decomposition has `2T(2N-1)=N(2N-1)` coefficient slots, still quadratic. Hardware can be reused with two serial DFG stages, but each independent result consumes `N/2` weight slots plus coherent accumulation. This is spatial reuse, not a subquadratic universal matrix parameterization.
- **Original raw pumps:** independently signed/complex coefficients are essential to this guarantee. Positive sums of products of nonnegative Hankels cannot even cover all positive rank-one matrices. If `f_t,g_t>=0` and temporal taps `c_t>=0`, then

\[
(W_T)_{ii}=\sum_t c_t\sum_{s=i}^{i+N-1}(f_t)_s(g_t)_s
\le (W_T)_{00}+(W_T)_{N-1,N-1},\qquad 0<i<N-1.
\]

The inequality holds because each interior index window lies in the union of the endpoint windows. For `N=3`, the positive rank-one target `(1,3,1)^T (1,1,1)` violates it. This excludes that target for every positive-tap slot count, even before imposing the stronger raw self-SFG constraint `h=u*u`. Fixed cancellation paths or a richer pump encoder need a separate construction and cost accounting.

[hankel_pair_sum_checks.py](hankel_pair_sum_checks.py) implements the compiler and checks 91 cases for `N=2,...,8`, including real and complex targets, identity, diagonal and rank-one cases. [Recorded results](results/hankel_pair_sum_checks.json) have maximum relative reconstruction error `1.61e-9`. These small-size checks support the implementation; the proof above establishes exact coverage. They do not validate large-size conditioning or optical efficiency.

## What remains open

Useful task accuracy, conditioning, sensitivity to layout and physical power efficiency remain unmeasured. A second core, additional routing or controlled parallel branches needs its own proof and component accounting; the single-core obstructions do not settle those extensions. None of these results establishes an optimal architecture.

[single_shuffle_checks.py](single_shuffle_checks.py) verifies the phase identity, block ranks, rank-one invariant and approximation bound, size-three gain exception, and positive Toeplitz witness. [Recorded results](results/single_shuffle_checks.json) are algebraic diagnostics, not physical or ML benchmarks.
