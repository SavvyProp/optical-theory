Previous work showed that only a couple thousand recirculations can be maintained before signal issues.

To extend the memory, some kind of electrical memory stabilization system has to be implemented

Every thousand timesteps inject back the previous thousand timestep's recurrent state. which is stored electrically