# Hankel and Monarch MLP with recirculating optical weights

Proposed paper contribution · 17 November 2026

Use the Hankel multiplier to implement the fixed linear maps in the MLP surrounding the optical TTT memory. Encode the digitally trained weights as optical coefficient frames, retain those frames in recirculating loops, and reuse them across inference evaluations. Periodically use the existing optical gradient writer with known input/output pairs to correct drift, with a less frequent full reload restoring the intended coefficient frame.

The starting proposal is **calibration every approximately 100 cycles and full reload every approximately 1,000 cycles**. These are intervals to investigate in simulation, not established retention limits. The cycle definition and the number of probes per calibration event must be specified.

The contribution is a common optical arithmetic architecture for adaptive TTT state and reusable fixed MLP matrices, together with a maintenance mechanism and an energy/accuracy analysis. The paper remains a theory and simulation study; offline model training takes place on conventional silicon, and performance claims concern inference.

## Contribution and operating modes

The earlier architecture assumed an optical implementation of the MLP. Reusing the Hankel cell supplies a specific implementation of its matrix multiplications and a way to maintain its optical weights. The earlier approximately 10M resident-weight ceiling is no longer the selected model constraint.

The [current TTT design point](../hankel_monarch_delta/paper_design_point.md) uses 24 layers, 16 logical heads, one physically simultaneous head, and eight spatial lanes × 64 wavelengths for a 512-wide head and residual stream. Each head has a unique two-layer optical FFN, three separate K/Q/V maps and one O map. With distinct weights in all layers, these six structured maps per head/layer contain **150,994,944 complex learned factor entries**, or **301,989,888 real parameters**, and require **299,630,592 native optical coefficients**. A tied real 16,000 × 512 embedding/readout adds 8,192,000 parameters for the selected **310,181,888-parameter subtotal**, before ancillary weights. Representation redundancy and optional sharing are counted separately there.

Each two-bank map uses the selected [MZI interleaver shuffle](../hankel_monarch_delta/mzi_shuffle.md): eight three-level demultiplexer trees, fixed cyclic group connections modulo eight and eight multiplexer trees. Each physically instantiated map needs its own router. Optical loss, phase calibration and control power belong in its resource budget; an energy improvement over free-space routing has not yet been established.

The proposed FFN places a nonlinearity after each complete two-bank map. Free-space demultiplexing with saturable absorption is the tentative activation choice; SHG depletion remains an alternative. Train the actual complex-field transfer and include transit time, recovery and losses in the inference model. The current layer boundary applies optical O projections before intensity detection, then sums detected head outputs and the residual electrically.

| Mode | Coefficient behavior | Role of the writer |
| --- | --- | --- |
| TTT inference | Adaptive state changes in response to the sequence | Apply the sequence-derived learning update |
| Fixed MLP inference | Preserve the digitally trained mapping | Disabled during ordinary inference reads |
| MLP calibration | Correct error relative to prescribed reference outputs | Apply small corrective gradient updates |
| Full coefficient reload | Restore a known coefficient frame | Replace the circulating frame with the reference encoding |

Fixed MLP operation targets unity net retention after compensating physical losses. It does not deliberately forget the trained weights. Calibration is maintenance of the intended operator, rather than learning from inference inputs.

The full reusable cell has four DFG sections, one SFG section and two coherent temporal accumulators. Its first backward DFG supplies the intermediate field used by the coefficient writer. Independently calibrating a known local MLP matrix does not require the cell's backward-error output; that remaining adjoint path can be idle. Calibration of a complete two-bank Monarch map can use the full backward path.

## Linear maps and coefficient representation

With \(H(h)_{ji}=h_{i+j}\), the calibrated local reader is

\[
F_a(x)=c\sum_{m=0}^{R-1}H(b_m)H(\overline{a_m})x.
\]

The stored \(a_m\) are the variable coefficient frames. The \(b_m\) are fixed reference partners. The current numerical setting is \(K=R=64\), with \(c=1/128\) from the passive temporal accumulator.

Two mapping strategies are available:

- Train the digital model using the native Hankel or Monarch parameterization, then transfer its coefficients.
- Fit an existing digital matrix to the optical parameterization offline, checking representation error and coefficient magnitude.

Arbitrary local matrix coverage and numerical conditioning depend on the selected fixed-partner basis. The chosen phase-ramp family still requires that check; its coverage should not be assumed merely from the coefficient count.

One local frame stores \(R(2K-1)=8,128\) complex optical coefficients for a \(64\times64\) map with at most 4,096 complex matrix degrees of freedom. Count learned model parameters, physical optical coefficients and replicated copies separately. The current larger model relies on recirculating storage rather than the earlier approximately 10M ceiling; its loading, maintenance energy and storage footprint still require accounting.

Larger and rectangular MLP matrices require a specified tiling, accumulation or structured Monarch mapping. This proposal supplies the linear operators. Nonlinear activation, gating, normalization, fan-out and the complete MLP schedule remain separate design requirements.

## Recirculation and refresh protocol

1. **Load:** prepare a trusted coefficient frame \(a_\star\) from the digitally trained model.
2. **Reuse:** circulate the frame and tap it to supply the DFG reader. Compensate storage, tap and injection losses while preserving the encoded amplitudes and phases.
3. **Calibrate:** insert scheduled probe inputs and their known coherent targets, enable the writer, and correct the represented mapping.
4. **Reload:** restore \(a_\star\) at the longer interval, replacing the previous frame rather than adding another full copy to it.

Apply corrections only in designated windows. Delayed probe inputs, reference partners and coefficient slots must refer to the same calibration event. Preserve the old coefficients needed by any adjoint computation before overwriting them.

Define the physical loop roundtrip \(T_{\rm loop}\), full-reload interval \(N_{\rm lap}\), useful reads between reloads \(N_{\rm use}\), calibration interval and probes per event separately. A physical circulation may supply zero, one or several useful reads depending on the schedule.

If a cycle means the assumed 1.28 ns reader frame, the proposed intervals correspond to 128 ns and 1.28 microseconds. A loop holding multiple weight frames need not have that roundtrip time. Reduced average loading frequency also does not eliminate the peak bandwidth needed to recreate the coefficient waveform.

## Calibration with known input and output vectors

For the desired local matrix \(W_\star\), precompute a library

\[
v_s=W_\star x_s.
\]

At a calibration visit, form

\[
e_s=v_s-F_a(x_s),\qquad
\mathcal L_{\rm cal}=\frac12\sum_s\|v_s-F_a(x_s)\|^2.
\]

The existing writer supplies the per-probe update

\[
\Delta a_m=\eta c\,x_s*
\left[H(b_m)\overline{e_s}\right],\qquad
a_m^+=a_m+\Delta a_m.
\]

Here \(*\) is the full convolution over frequency indices. Keep all 127 output coefficient channels and preserve the slot index \(m\); the writer does not temporally sum different coefficient slots.

The probe targets must be coherent amplitude-and-phase fields for the complex subtraction circuit. An intensity-only output comparison would define a different loss. Precomputing the library avoids repeated digital matrix multiplications, but encoding, storing and distributing the reference fields still has an energy cost. Their stability must be maintained independently enough to reveal drift in the matrix being calibrated.

For a fixed two-bank map \(W_\star\), one can instead use a single final target:

\[
z=PB_1x,\qquad e_2=W_\star x-B_2z,\qquad
e_1=P^{-1}B_2^\dagger e_2.
\]

Use \(z,e_2\) for the second-bank writer and \(x,e_1\) for the first-bank writer, with the same pre-update states used for prediction and adjoint evaluation. Alternatively, known fixed factors can be calibrated locally against their own prescribed maps; this is a distinct calibration arrangement.

### Probe coverage and correction limits

One probe constrains the mapping only along its input direction. Write \(F_a(x)=M(a)x\) and define the per-probe loss \(\ell(a;x)=\frac12\|W_\star x-M(a)x\|^2\). For probe covariance \(C_x=\mathbb E[xx^\dagger]\),

\[
\mathbb E_x[\ell(a;x)]
=\frac12\operatorname{Tr}
\left[(M(a)-W_\star)C_x(M(a)-W_\star)^\dagger\right].
\]

A positive-definite covariance exposes every matrix direction. For a \(64\times64\) map, 64 independent probes identify the complete mapping in an ideal noiseless setting if it stays fixed during the probe sweep. Tracking a drifting map also requires a probe schedule fast enough relative to that drift. Gradient convergence can require more updates and depends on the coefficient representation's conditioning.

If each calibration event contains only one probe, an event every 100 useful reads gives approximately ten probes before a reload every 1,000 reads. That schedule may track a few dominant gain or phase errors, but does not establish correction of arbitrary independent matrix drift. Compare rotating basis probes, diverse random probes and small probe batches.

The coefficient representation is redundant. Even complete input/output calibration cannot observe coefficient changes in the nullspace of the map from coefficients to matrix entries. Such changes can consume optical power or dynamic range and become observable under later transfer changes. Full coefficient reload provides a way to reset those hidden directions.

The writer implements the stated gradient when the reference partners, filters and conversion transfers match the calibrated model. Drift of those paths can also alter the correction operator. Model coefficient-storage drift separately from read/write-path drift.

## Energy amortization

The reusable resource is the encoded weight information. Repeated use amortizes electronic weight fetching, DAC/modulation and full-frame loading. Optical energy extracted by read taps, circulation loss, amplifier consumption and reference-pump generation remain ongoing costs.

Over one reload interval, a useful accounting model is

\[
\overline E_{\rm useful}
=E_{\rm read}
+\frac{E_{\rm reload}+\sum_j E_{{\rm cal},j}
+\int_0^{T_{\rm interval}}P_{\rm keep}(t)\,dt}{N_{\rm use}}.
\]

Use electrical input energy consistently, including laser and amplifier efficiencies. \(E_{\rm read}\) includes per-read input and reference generation not already counted in upkeep. \(P_{\rm keep}\) includes memory maintenance and continuously powered controls. Each calibration-event cost includes all probes, target generation and writer operations. Avoid counting any contribution twice.

If there are exactly 1,000 useful reads per reload and one equal-cost calibration event every 100 useful reads, this simplifies approximately to

\[
\overline E_{\rm useful}
=E_{\rm read}+E_{\rm upkeep/use}
+\frac{E_{\rm reload}}{1000}
+\frac{E_{\rm cal,event}}{100}.
\]

Only the loading term obtains the factor of 1,000. A net saving requires maintenance and calibration to cost less than the repeated re-encoding they replace, at the required output accuracy. Report calibration and reload occupancy in the throughput model as well as their energy.

The first-order loop model

\[
a_{n+1}=Q_n a_n+u_n+\xi_n
\]

separates gain/phase transfer \(Q_n\), corrective injection \(u_n\) and added noise \(\xi_n\). With nominal unity gain, independent additive noise accumulates across uncorrected laps. Gain compensation restores amplitude but does not automatically restore the original coefficient information.

## Simulation study

Compare the following at matched matrix error or language-model quality:

| Variant | Purpose |
| --- | --- |
| Ideal fixed weights | Establish the error-free model reference |
| Re-encode for every useful read | Establish the loading-energy comparison |
| Periodic reload only | Measure the fidelity and energy benefit of reuse without calibration |
| Calibration plus periodic reload | Test whether corrective writes permit longer reuse at acceptable cost |

Sweep reload and calibration intervals around the proposed 1,000/100-cycle values, probe count, learning rate, read-tap loss, gain error, phase drift, added noise and reference/write-path mismatch. Include both common drift and independent spectral or slot-dependent perturbations.

Measure matrix error on held-out inputs, downstream language-model degradation, recovery after disturbances, coefficient power, calibration duty fraction, sustained inference throughput and electrical energy per useful read. Include full MLP tiling and nonlinear interfaces when converting cell results into model-level latency.

The useful result would be an accuracy-constrained reuse interval and calibration policy, together with the conditions under which optical reuse reduces total loading and maintenance energy.

## Related notes and precedents

- [Shared weights and internal reasoning](../hankel_monarch_delta/parameter_sharing_and_deliberation.md): optional sharing variants and internal-deliberation experiments after removing the 10M ceiling.
- [Coefficient-loop gain and retention](../hankel_monarch_delta/coefficient_loop_gain.md): gain compensation, near-visible coefficient storage, amplifier noise and phase control.
- [Hankel cell pathways](../hankel_monarch_delta/cell_pathways.md): complex forward, adjoint and gradient paths for the joint-error multifunction cell.
- [Current TTT design point](../hankel_monarch_delta/paper_design_point.md): counts, dedicated query hardware, the illustrative 30.72 ns layer schedule and sixteen approximately 150 m recurrent coefficient rings; fixed-MLP storage is additional.
- [Hamerly et al., Physical Review X 2019](https://journals.aps.org/prx/pdf/10.1103/PhysRevX.9.021032): amortizes optically encoded weight-generation cost through reuse across a batch in a different architecture.
- [Miller, Photonics Research 2013](https://arxiv.org/abs/1303.4602): prescribed input/output pairs and feedback for self-configuration and drift stabilization of optical linear transformations.
- [Atmer et al., Who Needs DRAM? We Have Fiber, 2026](https://arxiv.org/abs/2607.08407): proposes recirculating immutable LLM weights with optical delivery and regeneration. Its digital data representation does not establish retention of this design's analog complex coefficient fields.

The proposed contribution centers on the Hankel coefficient representation and use of its existing optical gradient writer to maintain fixed MLP operators. Optical weight reuse and reference-based calibration have broader precedents.
